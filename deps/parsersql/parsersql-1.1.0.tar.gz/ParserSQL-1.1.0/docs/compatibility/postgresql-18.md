# PostgreSQL 18 Compatibility

Generated: 2026-09-27T21:16:51Z
ParserSQL commit: `3a98211c2f45a20b93d2b067d3771d04547f90de`
libpg_query previous: `17-latest` `815abf77660ca3c38511e3f5af7777b31764c1d5` (PostgreSQL 17.7)
libpg_query target: `18-latest` `9ab9951b7021adcc6d25d261d5016ca0b83726b8` (PostgreSQL 18.4)

## Result Totals

| Result | Count |
| --- | --- |
| DEEP_SUPPORTED | 49848 |
| CLASSIFIED_ONLY | 0 |
| PARTIAL | 52 |
| ERROR | 1041 |
| TRAILING_INPUT | 377 |
| TYPE_MISMATCH | 97 |

## PG18 Backlog

| Result | Oracle Node | ID | SQL |
| --- | --- | --- | --- |
| ERROR | PG_QUERY__NODE__NODE_ALTER_COLLATION_STMT | a0486d2963f9fda2a1d3e2db | -- ALTER ALTER COLLATION "en_US" REFRESH VERSION |
| ERROR | PG_QUERY__NODE__NODE_ALTER_COLLATION_STMT | fc2018854a04a7f01c3fec5c | -- ALTER ALTER COLLATION "en-x-icu" REFRESH VERSION |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DATABASE_SET_STMT | 2498cb3c54029713aa07d76c | ALTER DATABASE sepgsql_test_regression SET search_path TO regtest_schema, public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DATABASE_SET_STMT | 98d81acd5c6e6a7e6c88b695 | ALTER DATABASE regression_utf8 RESET TABLESPACE |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DATABASE_STMT | 1d27ad63befc7c845ee3e4a7 | ALTER DATABASE regression_utf8 CONNECTION_LIMIT 123 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DATABASE_STMT | 54824d82e593941b69fb84f2 | ALTER DATABASE sepgsql_test_regression CONNECTION LIMIT 999 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DATABASE_STMT | 5df7fdac733d8a72e7868b60 | ALTER DATABASE regression_utf8 SET TABLESPACE regress_tblspace |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 026cea1d97759f79a357d51c | -- yes ALTER DEFAULT PRIVILEGES REVOKE ALL ON SCHEMAS FROM regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 045890d04cccec2cd712524b | alter default privileges for role regress_evt_user revoke delete on tables from regress_evt_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 090b1ce389b2c10a2b506f15 | ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON LARGE OBJECTS TO public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 0f66a2f2795b848304668f3f | -- no ALTER DEFAULT PRIVILEGES REVOKE USAGE ON SCHEMAS FROM regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 1227b461788547dcfc723a5e | -- no ALTER DEFAULT PRIVILEGES IN SCHEMA testns GRANT INSERT ON TABLES TO regress_priv_user1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 1481cefecb17b977e7f35f04 | ALTER DEFAULT PRIVILEGES FOR ROLE regress_priv_user1 REVOKE USAGE ON TYPES FROM public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 2a3898006b6d804ce1070e2e | ALTER DEFAULT PRIVILEGES GRANT USAGE ON SCHEMAS TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 2b2a10fd18c9da10b2a918ef | ALTER DEFAULT PRIVILEGES FOR ROLE regress_matview_user REVOKE INSERT ON TABLES FROM regress_matview_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 3103e2dc468a58de91e8596c | -- no -- placeholder for test with duplicated schema and role names ALTER DEFAULT PRIVILEGES IN SCHEMA testns,testns GRANT SELECT ON TABLES TO public,public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 375ccc6f8d715dc5a929f310 | -- does not exist -- leave some default ACLs for pg_upgrade's dump-restore test input. ALTER DEFAULT PRIVILEGES FOR ROLE pg_signal_backend REVOKE USAGE ON TYPES FROM pg_signal_backend |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 429de9bd8b8b40ebfa24cc34 | ALTER DEFAULT PRIVILEGES IN SCHEMA testns GRANT USAGE ON SCHEMAS TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 492e790d282a64b0a2536442 | -- yes ALTER DEFAULT PRIVILEGES IN SCHEMA testns REVOKE INSERT ON TABLES FROM regress_priv_user1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 4e70e908ebfb55f930fb4fee | ALTER DEFAULT PRIVILEGES FOR ROLE regress_selinto_user GRANT INSERT ON TABLES TO regress_selinto_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 502b895cf225d7d286512da9 | -- no ALTER DEFAULT PRIVILEGES GRANT SELECT ON LARGE OBJECTS TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 56c82bec038885d11a68211d | ALTER DEFAULT PRIVILEGES GRANT ALL ON FUNCTIONS TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 6704cef4165d3fb53b0b4f00 | ALTER DEFAULT PRIVILEGES FOR ROLE regress_selinto_user REVOKE INSERT ON TABLES FROM regress_selinto_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 67e3f40014d2d2f347238a74 | -- true ALTER DEFAULT PRIVILEGES REVOKE UPDATE ON LARGE OBJECTS FROM regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 6ae1a6a6468c957427a88589 | -- no ALTER DEFAULT PRIVILEGES GRANT ALL ON LARGE OBJECTS TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 6be961adabb58bd762b71530 | -- no ALTER DEFAULT PRIVILEGES GRANT ALL ON SCHEMAS TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 7d03c0f940c6ed1ddade61ae | ALTER DEFAULT PRIVILEGES FOR ROLE regress_matview_user GRANT INSERT ON TABLES TO regress_matview_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 8251b1268afbd656737fc01c | ALTER DEFAULT PRIVILEGES GRANT ALL ON SEQUENCES TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 948064e7ce6cf75e8236e27a | -- no ALTER DEFAULT PRIVILEGES FOR ROLE regress_priv_user1 REVOKE EXECUTE ON FUNCTIONS FROM public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 9756031a1f1f6ea251a1f2e5 | -- no ALTER DEFAULT PRIVILEGES IN SCHEMA testns GRANT EXECUTE ON ROUTINES to public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | cacd8cc3ffcdb3eb0b2db9ab | ALTER DEFAULT PRIVILEGES FOR ROLE pg_read_all_settings REVOKE USAGE ON TYPES FROM pg_read_all_settings |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | ccf19bdf98b8439472ad5a7f | ALTER DEFAULT PRIVILEGES FOR ROLE regress_addr_user REVOKE DELETE ON TABLES FROM regress_addr_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | d2bbfc43a481182d0edb2ffa | ALTER DEFAULT PRIVILEGES GRANT ALL ON TABLES TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | d3c042739d5b0882d2e43eed | ALTER DEFAULT PRIVILEGES FOR ROLE regress_dep_user1 IN SCHEMA deptest GRANT ALL ON TABLES TO regress_dep_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | db63749555340a214eeac47b | ALTER DEFAULT PRIVILEGES FOR ROLE regress_addr_user IN SCHEMA public GRANT ALL ON TABLES TO regress_addr_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | ea66147cbc578ac15cd06379 | -- no ALTER DEFAULT PRIVILEGES IN SCHEMA testns GRANT USAGE ON TYPES to public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | f0736d691b97579e0e6cff5f | ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL PRIVILEGES ON TABLES FROM public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | fca62da6912e64c1b3deb5d8 | ALTER DEFAULT PRIVILEGES GRANT ALL ON TYPES TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EVENT_TRIG_STMT | 05185eda95733528118d4f36 | alter event trigger regress_event_trigger enable replica |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EVENT_TRIG_STMT | 0ace704489b56d68a76ec28b | -- with start trigger disabled. ALTER EVENT TRIGGER regress_reindex_start DISABLE |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EVENT_TRIG_STMT | 3e6b61d39a3e9ef6cdda2951 | ALTER EVENT TRIGGER on_login_trigger ENABLE ALWAYS |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EVENT_TRIG_STMT | a1704361a7f037b6f5b98779 | alter event trigger regress_event_trigger enable |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EVENT_TRIG_STMT | d35f24d0c1b4454a1b15c59f | alter event trigger regress_event_trigger enable always |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EVENT_TRIG_STMT | e8d7969e86ed60e88331f8b4 | -- test enabling and disabling alter event trigger regress_event_trigger disable |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 034b832b64d98d9db9d8abfd | ALTER EXTENSION test_pg_dump DROP MATERIALIZED VIEW test_pg_dump_mv1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 0351a5d26bd7f293f83fb4b7 | ALTER EXTENSION test_pg_dump DROP FOREIGN TABLE ft1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 059b3cec63c1511ce414406d | ALTER EXTENSION test_pg_dump DROP FOREIGN DATA WRAPPER dummy |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 09bd8ffec16dd9032b34cc9f | -- Add function and aggregate into extension alter extension postgres_fdw add function least_accum(anyelement, variadic anyarray) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 0edcd0bee2608a5c1885a911 | ALTER EXTENSION test_pg_dump DROP AGGREGATE newavg(int4) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 1d9530023c2a23d9c43fc690 | ALTER EXTENSION test_pg_dump ADD CAST (text AS casttesttype) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 1d97d5bfb01259159d88ba2e | ALTER EXTENSION pg_stat_statements DROP FUNCTION pg_stat_statements(boolean) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 22ca2a1506cf6b193468f5e2 | alter extension postgres_fdw drop aggregate least_agg(variadic items anyarray) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 249cbb211edd05bd02f384aa | ALTER EXTENSION postgres_fdw ADD OPERATOR === (int, int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 2d80462dca436c6a9afe35b4 | ALTER EXTENSION test_pg_dump DROP FUNCTION test_pg_dump(int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 38b7ca960741cee4839b29d7 | ALTER EXTENSION test_pg_dump DROP SERVER s0 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 460a7c2f2cac6ee2ea87aed8 | -- Remove function and aggregate from extension alter extension postgres_fdw drop function least_accum(anyelement, variadic anyarray) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 4680ead5a86a85a319142a63 | alter extension postgres_fdw add operator public.<^(int, int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 49fbbad7eda9e173f1a29f30 | ALTER EXTENSION citext DROP FUNCTION regexp_matches( citext, citext, text ) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 5149aa7256f20deff216245d | alter extension test_ext7 add sequence old_table1_col1_seq |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 51e7daa640177ae263db291b | alter extension postgres_fdw add aggregate least_agg(variadic items anyarray) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 596645824035b9e55ca83fa1 | ALTER EXTENSION cube DROP function g_cube_decompress(pg_catalog.internal) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 5d0e150238ed3fceba44332f | ALTER EXTENSION test_pg_dump ADD AGGREGATE newavg(int4) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 5d98e23a7195535e7f1b66fe | ALTER EXTENSION test_pg_dump ADD FUNCTION test_pg_dump(int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 64f19e8ce74d04e51c2844db | -- but if it's in a shippable extension, it can be shipped ALTER EXTENSION postgres_fdw ADD TEXT SEARCH CONFIGURATION public.custom_search |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 670d1d2073e5c79e1a67e3ff | alter extension postgres_fdw add operator family my_op_family using btree |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 6e1ed48166bfcdda914c2d11 | ALTER EXTENSION seg DROP function gseg_compress(pg_catalog.internal) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 7c0bffb9efd35d61901e7bd1 | ALTER EXTENSION test_pg_dump ADD TYPE test_pg_dump_e1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 7fdb8a03936bc6ea9477b1a7 | ALTER EXTENSION test_pg_dump ADD TABLE test_pg_dump_t1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 84eb55b5d516a7500b9a8a6d | ALTER EXTENSION test_pg_dump DROP TYPE test_pg_dump_e1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 88878e912236b9d606e5d586 | ALTER EXTENSION test_pg_dump ADD SERVER s0 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 8d53bd20e5620bd43862e9d6 | alter extension postgres_fdw drop operator family my_op_family using btree |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 8d59b12c0f22969bb0b4de5b | ALTER EXTENSION test_pg_dump ADD FOREIGN TABLE ft1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 90417c6730553bf8e39da38f | ALTER EXTENSION test_pg_dump ADD DATABASE postgres |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 916c1075fdd0b3ac275d363a | alter extension postgres_fdw add operator public.>^(int, int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 94e5c4320f7d53f3bf3f4288 | alter extension postgres_fdw add operator public.=^(int, int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 969b030a5f0c1c8ca48ec609 | ALTER EXTENSION test_pg_dump ADD ACCESS METHOD gist2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | 990fe0f5356e45374420bae8 | -- but let's put them in an extension ... ALTER EXTENSION postgres_fdw ADD FUNCTION postgres_fdw_abs(int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | a4ef934bc8dc6452be911e94 | ALTER EXTENSION seg DROP function gseg_decompress(pg_catalog.internal) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | a6f69c1a8268f60da86111bb | ALTER EXTENSION test_pg_dump DROP ACCESS METHOD gist2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | b405ca764c9e2f4e1f6d4b71 | ALTER EXTENSION test_pg_dump ADD SCHEMA test_pg_dump_s1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | b4b0ed077f7d47560c666275 | /* First we have to remove them from the extension */ ALTER EXTENSION pg_stat_statements DROP VIEW pg_stat_statements |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | b4e293ef5124803be003b0fa | ALTER EXTENSION test_pg_dump ADD OPERATOR ==== (int, int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | b611f58d642506f32f0401f0 | ALTER EXTENSION test_pg_dump DROP SCHEMA test_pg_dump_s1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | b726dad55860ea6dda926890 | ALTER EXTENSION test_pg_dump ADD MATERIALIZED VIEW test_pg_dump_mv1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | bb844082bba4d459e1cdd445 | ALTER EXTENSION test_pg_dump DROP TABLE test_pg_dump_t1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | bd6945321c19976839b14085 | -- Add into extension alter extension postgres_fdw add operator class my_op_class using btree |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | c57e75922bd0da4c01485bb5 | alter extension postgres_fdw drop function my_op_cmp(a int, b int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | ca03fbd58315cbbbe18e35be | alter extension postgres_fdw drop operator public.=^(int, int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | d577202560e73a50ac6e395e | ALTER EXTENSION test_pg_dump ADD VIEW test_pg_dump_v1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | d58b5c0f6ee3e6c027886b97 | ALTER EXTENSION pg_stat_statements DROP FUNCTION pg_stat_statements() |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | d88789da3c565e479ef95a57 | ALTER EXTENSION test_pg_dump DROP OPERATOR ==== (int, int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | d898cefe1c7d30a134f04b9f | alter extension postgres_fdw drop operator public.<^(int, int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | e0011882b7da987f2e6eaeac | alter extension postgres_fdw drop operator public.>^(int, int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | e428357d131f0d02f1795298 | alter extension postgres_fdw add function my_op_cmp(a int, b int) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | e44ec8a61b7dbdaf41495e50 | ALTER EXTENSION test_pg_dump DROP VIEW test_pg_dump_v1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | f075abd5cc6768fd96ffd7a4 | ALTER EXTENSION test_pg_dump DROP CAST (text AS casttesttype) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | f0ae007c9a1a53570cd787ad | -- Remove from extension alter extension postgres_fdw drop operator class my_op_class using btree |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | f7dc7cedf5ba33d6c998b983 | ALTER EXTENSION test_pg_dump ADD FOREIGN DATA WRAPPER dummy |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_CONTENTS_STMT | ff7af393530865577d6521a4 | ALTER EXTENSION cube DROP function g_cube_compress(pg_catalog.internal) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | 341a7aa2c1176a23a742bc10 | -- New functions and views for pg_stat_statements in 1.11 AlTER EXTENSION pg_stat_statements UPDATE TO '1.11' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | 3bb96c951c8d69803a4c048b | AlTER EXTENSION pg_stat_statements UPDATE TO '1.5' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | 543df94d774969e247a0b7a1 | -- page_header() uses int instead of smallint for lower, upper, special and -- pagesize in pageinspect >= 1.10. ALTER EXTENSION pageinspect UPDATE TO '1.9' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | 59f0ba07c50a4fbea09faeb3 | -- New functions and views for pg_stat_statements in 1.10 AlTER EXTENSION pg_stat_statements UPDATE TO '1.10' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | 60e4138abc32c7f86a55d632 | ALTER EXTENSION test_ext_evttrig UPDATE TO '2.0' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | 6a6f8e7e23dca156c632048e | alter extension test_ext7 update to '2.2bad' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | 7df339acfb52f91fc4747503 | ALTER EXTENSION pageinspect UPDATE TO '1.12' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | b714bdf4645f52f39124c30b | -- New functions and views for pg_stat_statements in 1.12 AlTER EXTENSION pg_stat_statements UPDATE TO '1.12' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | bdb91fad67b352798bfd0e10 | -- In 1.6, it got restricted back to superusers. AlTER EXTENSION pg_stat_statements UPDATE TO '1.6' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | c32cd4007781474574b8fead | -- New functions and views for pg_stat_statements in 1.8 AlTER EXTENSION pg_stat_statements UPDATE TO '1.8' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | d3f91867e45d4fe42769c0b6 | -- New function for pg_stat_statements_reset introduced, still -- restricted for non-superusers. AlTER EXTENSION pg_stat_statements UPDATE TO '1.7' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | d42c5d15d10dd18fb16f1c04 | -- New function pg_stat_statement_info, and new function -- and view for pg_stat_statements introduced in 1.9 AlTER EXTENSION pg_stat_statements UPDATE TO '1.9' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | d5d40ba3cc1eb435690f8a07 | -- Move to new version 1.1. ALTER EXTENSION pg_walinspect UPDATE TO '1.1' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | f964e6f9c4acc3b16ebbd5fa | -- brin_page_items() added a new "empty" flag in 1.12, make sure we detect -- an old function definition ALTER EXTENSION pageinspect UPDATE TO '1.11' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_DEPENDS_STMT | 18e509e3cd96932c8456c335 | ALTER TRIGGER c ON a NO DEPENDS ON EXTENSION test_ext5 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_DEPENDS_STMT | 2b59e5a92d86388c8e737591 | ALTER INDEX e NO DEPENDS ON EXTENSION test_ext5 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_DEPENDS_STMT | 2b5d948d0cd85a66849feb45 | ALTER MATERIALIZED VIEW d NO DEPENDS ON EXTENSION test_ext5 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 1a9fca0f4fc59c377ab6f112 | alter text search dictionary alter1.dict set schema alter2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 62f7d98330ed9a6c80ea0d99 | alter text search configuration alter1.cfg set schema alter2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 68280e3f1ab63b45075b59e1 | -- OK ALTER TEXT SEARCH DICTIONARY alt_ts_dict2 SET SCHEMA alt_nsp2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 68ba9cbce584d849f45cccbe | ALTER EXTENSION test_ext_req_schema1 SET SCHEMA test_s_dep2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 694d1132c934ba57bea463ef | ALTER EXTENSION test_ext_set_schema SET SCHEMA s2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 6bd0f36212d461614e389f0d | -- fails ALTER EXTENSION test_ext_req_schema2 SET SCHEMA test_s_dep |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 79368cb762ffb84598ab9ffc | -- failed (no role membership) ALTER TEXT SEARCH DICTIONARY alt_ts_dict3 SET SCHEMA alt_nsp2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 7db34571a4815782eca861c7 | alter text search template alter1.tmpl set schema alter2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 95ec766ddd4497ee4e9bf6dc | -- failed (no role membership) ALTER TEXT SEARCH CONFIGURATION alt_ts_conf3 SET SCHEMA alt_nsp2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | 96bdcfe198e6dcea4cf92394 | -- OK ALTER TEXT SEARCH TEMPLATE alt_ts_temp2 SET SCHEMA alt_nsp2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | ba679985f036fb6643561da6 | alter text search parser alter1.prs set schema alter2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | c1394783bb0fc00034ed9e03 | -- OK ALTER TEXT SEARCH PARSER alt_ts_prs2 SET SCHEMA alt_nsp2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | e046d1da15fab51157064ef8 | -- fails, as function dep_req1 is not in the same schema as the extension. ALTER EXTENSION test_ext_req_schema1 SET SCHEMA test_func_dep3 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OBJECT_SCHEMA_STMT | e4e6defef5a9da4bf0f99299 | -- OK ALTER TEXT SEARCH CONFIGURATION alt_ts_conf2 SET SCHEMA alt_nsp2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 0aad23f5ec8975bb521c9a96 | -- OK ALTER TEXT SEARCH DICTIONARY alt_ts_dict2 OWNER TO regress_alter_generic_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 0c652d3ce4311d9351da3c68 | ALTER LARGE OBJECT 42 OWNER TO regress_lo_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 0ea429243c94fee57d13dccf | -- failed (no role membership) ALTER TEXT SEARCH CONFIGURATION alt_ts_conf2 OWNER TO regress_alter_generic_user3 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 1e334e4fee7ca387d9f4265a | ALTER LANGUAGE alt_lang1 OWNER TO regress_alter_generic_user1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 230786150c247432dcca9d59 | -- failed (no role membership) ALTER LANGUAGE alt_lang3 OWNER TO regress_alter_generic_user3 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 2ab4ce8ef03aeb4da3e627cb | -- OK ALTER TEXT SEARCH DICTIONARY alt_ts_dict3 OWNER TO regress_alter_generic_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 2d66fd5974d4db698550c9bd | -- OK ALTER LANGUAGE alt_lang2 OWNER TO regress_alter_generic_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 376e3cc7f09178008bb201f4 | -- fail - new owner must be superuser ALTER PUBLICATION testpub4 owner to regress_publication_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 46cead7e1d7d6a4fd2223db2 | ALTER PUBLICATION testpub_default OWNER TO regress_publication_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 475702bab91eec3b0f674048 | -- failed (no role membership) ALTER TEXT SEARCH DICTIONARY alt_ts_dict2 OWNER TO regress_alter_generic_user3 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 7391864a658a90f4b429c0a8 | ALTER PUBLICATION testpub4 OWNER TO regress_publication_user3 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | 82f2d0aff03eadd2985e9f86 | -- OK ALTER LANGUAGE alt_lang2 OWNER TO regress_alter_generic_user3 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | a7b1564e95fff784a9c92816 | -- alter owner to non-superuser should fail alter event trigger regress_event_trigger owner to regress_evt_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | b62968d72ce23ed1a99af009 | -- fail ALTER PUBLICATION testpub4 owner to regress_publication_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | cc1ec095333dc0e314357740 | ALTER TABLESPACE regress_tblspace OWNER TO regress_tablespace_user1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | d49d3de35fcb0c0250b0c1f9 | -- we cannot give the subscription away to some random user ALTER SUBSCRIPTION regress_testsub OWNER TO regress_subscription_user |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | e4fda3ff57b1adaf4f4b1aaa | -- ok, we're a superuser ALTER SUBSCRIPTION regress_testsub OWNER TO regress_subscription_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | e5403659a6603a00fa31d15e | -- OK ALTER TEXT SEARCH CONFIGURATION alt_ts_conf2 OWNER TO regress_alter_generic_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | f4dd8052b59add969a5a7eb0 | -- failed (not owner) ALTER LANGUAGE alt_lang3 OWNER TO regress_alter_generic_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | f945f931b9f44de868c616d6 | -- OK ALTER TEXT SEARCH CONFIGURATION alt_ts_conf3 OWNER TO regress_alter_generic_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 02943481957998163dc52eda | -- error: duplicates not allowed in column list ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5 (a, a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 06a2ecc2f0bf2982fce48151 | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_pk WHERE (b > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 0790346d643b7715ec42cafc | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_pk (a, b, c) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 0b508171240b3c26fc26552a | -- error: column "x" does not exist ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5 (a, x) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 0dce40464b6c9d6297214d3c | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE ((a, a + 1) < (2, 3)) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 13d331613b661655458e7e12 | -- fail - aggregate functions not allowed in WHERE clause ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl3 WHERE (e < AVG(e)) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 1b66134e1292b70c9a6acc0a | -- Tests for partitioned table -- set PUBLISH_VIA_PARTITION_ROOT to false and test row filter for partitioned -- table ALTER PUBLICATION testpub6 SET (PUBLISH_VIA_PARTITION_ROOT=0) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 2714a132fa387a16c2935b6e | -- error: virtual generated column "e" can't be in list ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5 (a, e) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 271653d0a737dc5711092b91 | -- ok - can use column list for partitioned table ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_part_pk (b) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 288dda2d545f41c7aa9b4a17 | -- fail - can't drop from all tables publication ALTER PUBLICATION testpub_foralltables DROP TABLE testpub_tbl2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 292d2b5f4ab4c44ba09acf12 | ALTER PUBLICATION testpub_fortable DROP TABLE testpub_tbl5 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 2c8c0e69ee04b57ae67c71ed | -- Table publication that includes both the parent table and the child table ALTER PUBLICATION pub ADD TABLE sch1.tbl1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 2fdfafb1cdabedaf2fe1ee80 | ALTER PUBLICATION testpub_default SET TABLE testpub_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 31e8f3b00a6eee8e03a057d7 | ALTER PUBLICATION testpub_default ADD TABLE pub_test.testpub_addpk |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 34a6142782641819ef2dd2d6 | -- set PUBLISH_VIA_PARTITION_ROOT to true and test row filter for partitioned -- table ALTER PUBLICATION testpub6 SET (PUBLISH_VIA_PARTITION_ROOT=1) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 42c336fc259566581271ca57 | -- fail - can't set schema to 'FOR ALL TABLES' publication ALTER PUBLICATION testpub_foralltables SET TABLES IN SCHEMA pub_test |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 42e6e0b1ad003dd2359e4d2e | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (CASE a WHEN 5 THEN true ELSE false END) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 48c9e2c441e53e1f6ba8e4f6 | -- fail - WHERE not allowed in DROP ALTER PUBLICATION testpub5 DROP TABLE testpub_rf_tbl1 WHERE (e < 27) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 4b0ae51a610f46e9ac976224 | -- failure - cannot ADD column list and schema together ALTER PUBLICATION testpub_tbl9 ADD TABLES IN SCHEMA public, TABLE public.testpub_tbl7(a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 4b5551bd3755bf072535b461 | ALTER PUBLICATION testpub_forparted1 SET (publish='insert') |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 4e2ad345404fe6a6355ac17d | ALTER PUBLICATION testpub1_forschema SET TABLES IN SCHEMA pub_test1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 4e45eb06d82416d2bd6ab46a | -- ok - built-in operators are allowed ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (a IS NULL) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 4f26e53d47faaf6603393fbf | -- fail ALTER PUBLICATION testpub3 ADD TABLES IN SCHEMA pub_test |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 502a8749715e9b94f44f339c | -- failure - add a table with column list when there is already a schema in the -- publication ALTER PUBLICATION testpub_tbl9 ADD TABLE public.testpub_tbl7(a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 52d7259230f9645916abd830 | ALTER PUBLICATION testpub_fortable SET TABLE testpub_tbl1 (id, ctid) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 559de4f431d4ed3699bd9eba | -- only parent is listed as being in publication, not the partition ALTER PUBLICATION testpub_forparted ADD TABLE testpub_parted |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 56db355538e3514f6734f8ac | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (GREATEST(a, 10) > 10) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 58dce02ea105db84fbc46b2c | -- 1b. REPLICA IDENTITY is DEFAULT and table has no PK ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_nopk WHERE (a > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 5a1e67e8006f2c446f8e69ad | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_pk (a, b, c, d) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 5cc9b5f71b8e583a67857d1d | ALTER PUBLICATION testpub5 ADD TABLE testpub_rf_tbl1 WHERE (a >= testpub_rf_func2()) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 5e40bbae0f53b088eb04d38c | -- fail - cannot use column list for partitioned table ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_part_pk (a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 5e7064cf3c1ff6c5686c9218 | -- fail - non-immutable functions are not allowed. random() is volatile. ALTER PUBLICATION testpub5 ADD TABLE testpub_rf_tbl1 WHERE (a < random()) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 5f2808070f07fc14d2a104eb | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_pk (a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 5f570c9908548a44966948f7 | ALTER PUBLICATION testpub_table_ins ADD TABLE testpub_tbl5 (a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 6085fd07943b23b086f3a045 | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (ARRAY[a] <@ ARRAY[2, 4, 6]) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 63f89c47e089575192553add | -- should be able to set table to schema publication ALTER PUBLICATION testpub_forschema SET TABLE pub_test.testpub_nopk |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 6657d0ed224e68d2605dc36c | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_pk (b) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 6786ce81ce5d507063b13a46 | ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl6 (a, b, c) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 6bcb609b45f35135e00ace51 | -- ok - can use column list for partition ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_part_pk_1 (a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 6ccd84b272ecc766800072f6 | -- 1b. REPLICA IDENTITY is DEFAULT and table has no PK ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_nopk (a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 6e2f5588791e1a4e56698a33 | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_nopk WHERE (c > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 742e4e5f326fc0befe37cdbb | -- ok ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5 (a, c) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 7933a572a55073a5ef65632f | ALTER PUBLICATION testpub_default ADD TABLE testpub_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 7a92af7d292fa2c4b855e056 | ALTER PUBLICATION testpub5 ADD TABLE testpub_rf_tbl1 WHERE (b < '2' COLLATE user_collation) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 7bcc8506216519ebeadcc065 | -- ok - only publish table with column list ALTER PUBLICATION testpub_tbl9 SET TABLE public.testpub_tbl7(a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 7bf11b708d79adb912fab539 | -- fail - can't add to for all tables publication ALTER PUBLICATION testpub_foralltables ADD TABLE testpub_tbl2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 7d85d0f10d0f46fecad4a383 | -- should be able to add a table of the same schema to the schema publication ALTER PUBLICATION testpub_forschema ADD TABLE pub_test.testpub_nopk |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 7e913d982e7f8b0f5ae03515 | ALTER PUBLICATION testpub2 ADD TABLE testpub_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 7f9a87d58aef3386f256c493 | -- error: replica identity "a" not included in the column list ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5 (b, c) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 7fe1f081a326903f4c947b60 | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl5 WHERE (xmlexists('//foo[text() = ''bar'']' PASSING BY VALUE a)) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 812a3f49f6dfaf028738bc65 | -- fail - publication WHERE clause must be boolean ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl3 WHERE (1234) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 83fa4621f6698c82e3005b00 | ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl7 (a, b) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 85b5058aa1212043d7c4e888 | -- ok - conditional expressions are allowed ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl5 WHERE (a IS DOCUMENT) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 85f3e538cee384b6054e8431 | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (COALESCE(b, 'foo') = 'foo') |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 861a13507572c4a18f19d1e2 | -- Now change the root column list to use a column "b" -- (which is not in the replica identity) ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_part_pk_1 (b) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 899a2b0abe8024e93ae15a1a | -- no dice -- ok: for insert-only publication, any column list is acceptable ALTER PUBLICATION testpub_fortable_insert ADD TABLE testpub_tbl5 (b, c) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 8a9abe99ffa36ad6ea342995 | ALTER PUBLICATION testpub_default SET (publish = update) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 8bda94eca54403ffa12c9394 | -- ok - can use row filter for partitioned table ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_part_pk WHERE (b > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 8c1633b050c3026a140cc887 | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_nopk (a, b, c, d) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 8d7ec67e8f09cebea22d89b7 | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (a IS DISTINCT FROM 5) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 8df5e5c2cdc53071fd3d9afe | -- ok - NULLIF is allowed ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (NULLIF(1,2) = a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 957f6b30e47cf09c369ae9d4 | ALTER PUBLICATION testpub_col_list ADD TABLE testpub_tbl8 (a, c) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 967c3dac1ea2808be7af9109 | -- fail - can't add schema to 'FOR ALL TABLES' publication ALTER PUBLICATION testpub_foralltables ADD TABLES IN SCHEMA pub_test |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 9ad2a5b2b8ff00148104cbe5 | -- ok - drop table ALTER PUBLICATION testpub_tbl9 DROP TABLE public.testpub_tbl7 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 9c6dabc0e20c711daeb52dfa | -- failure - cannot SET column list and schema together ALTER PUBLICATION testpub_tbl9 SET TABLES IN SCHEMA public, TABLE public.testpub_tbl7(a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 9cf433a0d5a92346a6cca172 | ALTER PUBLICATION testpub1_forschema DROP TABLES IN SCHEMA pub_test1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 9e3bf76ec4267effae8401a1 | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_pk (c) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | a1788f53fc8b2cede5b672d7 | ALTER PUBLICATION testpub_ins_trunct ADD TABLE pub_test.testpub_nopk, testpub_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | a237738640e1de3cbfb23551 | -- error: system attributes "ctid" not allowed in column list ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5 (a, ctid) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | a612309ee696554109396e49 | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_nopk (d) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | a7de8f622f81bb26a141310d | ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5d |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | a84bebf064e2376259410b57 | ALTER PUBLICATION testpub_forparted DROP TABLE testpub_parted |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | b060466f32ee21469e27ffb2 | -- ok: the same thing, but try plain ADD TABLE ALTER PUBLICATION testpub_col_list DROP TABLE testpub_tbl8 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | b15008af5350ecace71abe5f | ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl6 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | b34933b73328f79a92028278 | -- fail - nonexistent ALTER PUBLICATION testpub_default DROP TABLE pub_test.testpub_nopk |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | b8d5fece8f26185d5123a134 | -- fail - can't drop schema from 'FOR ALL TABLES' publication ALTER PUBLICATION testpub_foralltables DROP TABLES IN SCHEMA pub_test |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | bb24d0c00b15ead76037f34f | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_nopk (c) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | bce10bf030b3aa5a86af9f71 | -- ok - immutable built-in functions are allowed ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl4 WHERE (length(g) < 6) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | be5a93bc99d5240ec596d80a | -- should be able to add schema to 'FOR TABLE' publication ALTER PUBLICATION testpub_fortable ADD TABLES IN SCHEMA pub_test |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | be5c7a59b3c5d7a87fb94fda | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_pk WHERE (c > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | bed15e076e510d241e77e7e1 | ALTER PUBLICATION testpub_both_filters ADD TABLE testpub_tbl_both_filters (a,c) WHERE (c != 1) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | bffb14318544190ec2ed5770 | -- Now change the root filter to use a column "b" -- (which is not in the replica identity) ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_part_pk_1 WHERE (b > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | c28fe9d30a3a648fc7614fd8 | -- ok - can use row filter for partition ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_part_pk_1 WHERE (a > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | c4479debd7fd9bfdf1d78bd3 | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (ROW(a, 2) IS NULL) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | c6f55e0004ca70de107d8039 | -- cleanup pub_test1 schema for invalidation tests ALTER PUBLICATION testpub2_forschema DROP TABLES IN SCHEMA pub_test1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | c8787237081f5ece753529a0 | -- ok - built-in type coercions between two binary compatible datatypes are allowed ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (b::varchar < '2') |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | c8bad2dbff96a97953d30969 | ALTER PUBLICATION testpub_foralltables SET (publish = 'insert, update') |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | d7832e8ac555b07df6a35244 | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE ((a > 5) IS FALSE) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | dc40c55e35a1e1878ac541ed | -- fail - already added ALTER PUBLICATION testpub_fortbl ADD TABLE testpub_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | e24f57dfdf585d3b3729cf2e | ALTER PUBLICATION testpub5 SET TABLE testpub_rf_tbl1 WHERE (a IN (2, 4, 6)) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | e54302750e198e033c1af83b | -- failure - specify a schema when there is already a column list in the -- publication ALTER PUBLICATION testpub_tbl9 ADD TABLES IN SCHEMA public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | e5534ea190ad8050de52f72c | ALTER PUBLICATION testpub_forparted SET (publish_via_partition_root = true) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | eb10fe780d623a2b11665e5f | -- fail - cannot use row filter for partitioned table ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_part_pk WHERE (a > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | ed188bb77cc64f702810b4b1 | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_pk WHERE (d > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | ee57689f1a244c12c2e58372 | ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_pk WHERE (a > 99) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | f1a4835c6798466fbeea94f8 | ALTER PUBLICATION testpub_fortable DROP TABLE testpub_tbl6 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | f39713452e9ce688d31e4659 | ALTER PUBLICATION testpub_col_list ADD TABLE testpub_tbl8 (a, b) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | f4c9f0a54e5585b5c5243e19 | -- should be able to set publication with schema and table of the same schema ALTER PUBLICATION testpub6 SET TABLES IN SCHEMA testpub_rf_schema2, TABLE testpub_rf_schema2.testpub_rf_tbl6 WHERE (i <... |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | fa84e21d7f1116e10338005f | ALTER PUBLICATION testpub_default ADD TABLE pub_test.testpub_nopk |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | faa7e5f23b2ac74375864cfb | -- ok: stored generated column "d" can be in the list too ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5 (a, d) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | fc3cb3903bca7dab8f30ea24 | ALTER PUBLICATION testpub_fortable SET TABLE testpub_tbl5 (a, a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | fc92f39efcf15148dc964260 | -- remove partitioned table's row filter ALTER PUBLICATION testpub6 SET TABLE rf_tbl_abcd_part_pk |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | ffc44839d983b9a73fee56ab | -- fail - can't add to for all tables publication ALTER PUBLICATION testpub_foralltables SET TABLE pub_test.testpub_nopk |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 1335807b4a4beb8c4d3786d2 | -- fail ALTER SUBSCRIPTION regress_doesnotexist CONNECTION 'dbname=regress_doesnotexist2' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 180c3905588453cf06b49567 | -- ok - add two publications into subscription ALTER SUBSCRIPTION regress_testsub ADD PUBLICATION testpub1, testpub2 WITH (refresh = false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 2b09d4a12d8414d7ed952928 | -- fail ALTER SUBSCRIPTION regress_testsub SKIP (lsn = '0/0') |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 39641742bbe44371cf116c17 | ALTER SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist2' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 3feb9aa752472a6839ff532d | -- fail - publication used more than once ALTER SUBSCRIPTION regress_testsub ADD PUBLICATION testpub1, testpub1 WITH (refresh = false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 42a43828c66b3607d911540a | ALTER SUBSCRIPTION regress_testsub_foo SET (synchronous_commit = foobar) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 49e0e6b9f4e537927cd13555 | ALTER SUBSCRIPTION regress_testsub SET (run_as_owner = false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 527411375d52fb4a9fa1db67 | ALTER SUBSCRIPTION regress_testsub REFRESH PUBLICATION |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 535d4a6928fa2db9a82650d5 | ALTER SUBSCRIPTION regress_testsub SET (password_required = false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 690034a2bb7359fe28770314 | -- fail ALTER SUBSCRIPTION regress_testsub SET (slot_name = '') |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 730e52e1da0e8539e54bf8ec | ALTER SUBSCRIPTION regress_testsub SET (failover) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 73d8e03f95c69820abbb0e5b | -- fail - publication does not exist in subscription ALTER SUBSCRIPTION regress_testsub DROP PUBLICATION testpub3 WITH (refresh = false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 7716eba3a2df0e8d4d20b5a6 | ALTER SUBSCRIPTION regress_testsub SET (slot_name = NONE) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 7b0e56207c2688dbc131085f | -- ok ALTER SUBSCRIPTION regress_testsub SKIP (lsn = '0/12345') |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 82cd702c8d4676c354d15ebd | ALTER SUBSCRIPTION regress_testsub SET (create_slot = false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 8677dde83960d5fba61a6bee | ALTER SUBSCRIPTION regress_testsub3 REFRESH PUBLICATION |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 8f926de3ce7ac5befab7cac8 | ALTER SUBSCRIPTION regress_testsub SET PUBLICATION mypub WITH (refresh = true) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | 952b8c11b154d7472a22543d | -- fail ALTER SUBSCRIPTION regress_testsub3 ENABLE |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | a16244e3aa372d1c395723d3 | -- ok - delete publications ALTER SUBSCRIPTION regress_testsub DROP PUBLICATION testpub1, testpub2 WITH (refresh = false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | b4ebd07abf74a82a97748900 | -- fail - invalid connection string during ALTER ALTER SUBSCRIPTION regress_testsub CONNECTION 'foobar' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | b78e045c0c7a826ef9271dd9 | ALTER SUBSCRIPTION regress_testsub SET (slot_name = 'newname') |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | b992def84da137b440d25145 | -- fail - all publications are deleted ALTER SUBSCRIPTION regress_testsub DROP PUBLICATION testpub, testpub1, testpub2 WITH (refresh = false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | cfc5ddeeee0cd193f503a6e1 | ALTER SUBSCRIPTION regress_testsub ENABLE |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | d9e43ca519cc86ea8ee09cf1 | ALTER SUBSCRIPTION regress_testsub DISABLE |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | e2c2eb66b96bb6894c2749ed | ALTER SUBSCRIPTION regress_testsub_foo SET (synchronous_commit = local) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SUBSCRIPTION_STMT | e8960a1ae4ff6e63ffb74c5c | ALTER SUBSCRIPTION regress_testsub SET (run_as_owner = true) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 0aa6eb85530206521545a5fe | -- ok ALTER SYSTEM SET DateStyle = 'ISO, MDY' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 0d81bff3e032f3edfc51cb14 | ALTER SYSTEM SET work_mem = 8192 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 121d9264c1904b13f20e16a0 | -- Superuser should be able to ALTER SYSTEM SET a non-existent custom GUC. ALTER SYSTEM SET none.such = 'whiz bang' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 1885e9db4422db6c6f3200e1 | ALTER SYSTEM SET test_oat_hooks.user_var1 = true |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 2334c315db33ac36a53b8130 | -- ok ALTER SYSTEM RESET lc_messages |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 2753776f9a1cc62ebed8187e | -- fail, cannot be changed ALTER SYSTEM RESET block_size |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 2e3e53b9a95a7b93ed4cd8df | -- fail, insufficient privileges ALTER SYSTEM SET shared_buffers = 50 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 2e60728aff73de9ee4f87e7a | -- ok ALTER SYSTEM SET lc_messages = 'C' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 3633494edf4f11f81dc00e0d | -- ok ALTER SYSTEM SET ssl_renegotiation_limit = 0 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 3d6d55115020530e5643eea5 | -- fail, requires reload ALTER SYSTEM SET autovacuum = OFF |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 406f1f21ae74fda0996ae25d | -- ok ALTER SYSTEM RESET jit_debugging_support |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 41e51e94d25af34205aa60a2 | -- fail, cannot be changed ALTER SYSTEM RESET config_file |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 4395ec46568fe267239a30b0 | -- Can set synchronized_standby_slots to a non-existent slot name ALTER SYSTEM SET synchronized_standby_slots='missing' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 4d5e0daac4bcb9d0f2fccc96 | -- ok, privileges have been granted ALTER SYSTEM RESET max_stack_depth |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 605f7aa3f707cb8277754328 | ALTER SYSTEM SET auto_explain.bogus = 1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 623e913f44667f4233c3cc35 | -- fail, cannot be changed ALTER SYSTEM RESET ssl_renegotiation_limit |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 624b7875692d5a241eb2cc76 | ALTER SYSTEM SET test_oat_hooks.user_var2 = true |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 6a57d189d7b321458cebf6e5 | ALTER SYSTEM SET autovacuum_work_mem = 32 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 6b03da04d2109dede5d8996c | -- ok ALTER SYSTEM SET config_file = '/usr/local/data/postgresql.conf' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 834fdfa0cb74bb671de52109 | -- ok, privileges have been granted ALTER SYSTEM RESET ALL |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 8deaed599469dea79cbdf049 | -- cannot be changed now ALTER SYSTEM RESET temp_file_limit |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 9e8afb469e93b38de15238d5 | -- ok ALTER SYSTEM RESET shared_buffers |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | 9f1954da86bb6ab5bbda6157 | ALTER SYSTEM RESET work_mem |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | a6c97c4c5a5ab05fc994a724 | -- fail, insufficient privileges ALTER SYSTEM RESET autovacuum_multixact_freeze_max_age |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | bacec581fddf1ec00130ca2e | -- ok -- Test for GUC synchronized standby slots -- Cannot set synchronized_standby_slots to an invalid slot name ALTER SYSTEM SET synchronized_standby_slots='invalid*' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | c8857a2212f1c0088ac42078 | -- fail, requires restart ALTER SYSTEM SET autovacuum_freeze_max_age = 1000050000 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | c8e4e3d57470085b038952e4 | ALTER SYSTEM SET test_oat_hooks.super_var2 = true |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | c9e9af1b29d92e652acb6e7a | -- ok ALTER SYSTEM RESET autovacuum_freeze_max_age |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | d78d6afdba6fdd02915ee78e | -- ok ALTER SYSTEM RESET DateStyle |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | de9c0908edf789fc8c3ad8a5 | -- fail, cannot be set after connection start ALTER SYSTEM SET jit_debugging_support = OFF |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | e2dd4fe72ec57dbd7fa385bc | -- ok ALTER SYSTEM RESET autovacuum |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | e78c489faf521460b31d35ef | -- fail, cannot be changed ALTER SYSTEM SET block_size = 50 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | e8cb53f33a3af2fdfd726c6b | -- fail, insufficient privileges ALTER SYSTEM SET none.such2 = 'whiz bang' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | ea85e55d5144c9d36eeaaaab | -- ok ALTER SYSTEM RESET ignore_system_indexes |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | efa31dd2ef119e0ed9749ad8 | ALTER SYSTEM SET test_oat_hooks.super_var1 = true |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | f05e87657509b082e0446e94 | -- fail, cannot be set after connection start ALTER SYSTEM SET ignore_system_indexes = OFF |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | f0a6c8746594fd70dd74a4f2 | -- ok ALTER SYSTEM RESET autovacuum_work_mem |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | f28d251eaf447dbf3918b6e7 | -- ok, privileges have been granted ALTER SYSTEM SET max_stack_depth = '100kB' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | f2e32e818f6057d7b17579ff | ALTER SYSTEM RESET auto_explain.bogus |
| ERROR | PG_QUERY__NODE__NODE_ALTER_SYSTEM_STMT | ff6ddcfd6472a90b9328481d | -- Reset the GUC ALTER SYSTEM RESET synchronized_standby_slots |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TABLE_MOVE_ALL_STMT | 11cc817c67fe3823190415b5 | ALTER MATERIALIZED VIEW ALL IN TABLESPACE regress_tblspace_renamed SET TABLESPACE pg_default |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TABLE_MOVE_ALL_STMT | 6754663b4e19bbf1fe34dbbe | ALTER TABLE ALL IN TABLESPACE regress_tblspace_renamed SET TABLESPACE pg_default |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TABLE_MOVE_ALL_STMT | ac4fc7f2012d101a93ae7053 | ALTER INDEX ALL IN TABLESPACE regress_tblspace_renamed SET TABLESPACE pg_default |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TABLE_SPACE_OPTIONS_STMT | 25f3b8622cd50c0ab1bd88cb | -- fail ALTER TABLESPACE regress_tblspace RESET (random_page_cost, effective_io_concurrency) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TABLE_SPACE_OPTIONS_STMT | 2cc871266faaeed83d7e392d | -- fail ALTER TABLESPACE regress_tblspace RESET (random_page_cost = 2.0) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TABLE_SPACE_OPTIONS_STMT | 484b0befa4381d7278350c45 | ALTER TABLESPACE regress_tblspace SET (some_nonexistent_parameter = true) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TABLE_SPACE_OPTIONS_STMT | 8c8443fb9ba797eb4b95a3e4 | -- try setting and resetting some properties for the new tablespace ALTER TABLESPACE regress_tblspace SET (random_page_cost = 1.0, seq_page_cost = 1.1) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 6f801183163cf42ea740de96 | -- try removing an oid column, should succeed (as it's nonexistent) alter table atacc1 SET WITHOUT OIDS |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | 00b8e077303276c06f56d685 | ALTER TEXT SEARCH CONFIGURATION dummy_tst DROP MAPPING IF EXISTS FOR not_a_token, not_a_token |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | 030a3b95da02bcb8eb2e1f35 | ALTER TEXT SEARCH CONFIGURATION dummy_tst ADD MAPPING FOR not_a_token WITH ispell |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | 085aadd36d04726127b18e4b | ALTER TEXT SEARCH CONFIGURATION hunspell_tst ALTER MAPPING REPLACE hunspell_long WITH hunspell_num |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | 18ac1c507d22f34c711cb985 | ALTER TEXT SEARCH CONFIGURATION dummy_tst ALTER MAPPING FOR word, word WITH ispell |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | 1c9a1c1a211c282dbdb73a10 | ALTER TEXT SEARCH CONFIGURATION dummy_tst DROP MAPPING IF EXISTS FOR word, word |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | 5ffca48f8e01844fc4f59d1f | ALTER TEXT SEARCH CONFIGURATION evttrig_tscfg DROP MAPPING FOR word |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | 6a3884d766ff25669c3dc414 | ALTER TEXT SEARCH CONFIGURATION synonym_tst ALTER MAPPING FOR asciiword, hword_asciipart, asciihword WITH synonym, english_stem |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | 7e6f3a50c5f4ab91f7ec7f3c | ALTER TEXT SEARCH CONFIGURATION ispell_tst ALTER MAPPING FOR word, numword, asciiword, hword, numhword, asciihword, hword_part, hword_numpart, hword_asciipart WITH ispell, english_stem |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | baacbf802b8999b44c03581c | ALTER TEXT SEARCH CONFIGURATION dummy_tst DROP MAPPING FOR word, word |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | bbf06eb855063569c9bf50e4 | ALTER TEXT SEARCH CONFIGURATION hunspell_tst ALTER MAPPING REPLACE hunspell WITH hunspell_long |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | c23bb34d36ff08093fa5d3b7 | ALTER TEXT SEARCH CONFIGURATION thesaurus_tst ALTER MAPPING FOR asciiword, hword_asciipart, asciihword WITH synonym, thesaurus, english_stem |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | cb518ad35fafba5534951114 | ALTER TEXT SEARCH CONFIGURATION en ALTER MAPPING FOR host, email, url, sfloat WITH simple |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | dc322220a6a18aac52dd0c60 | ALTER TEXT SEARCH CONFIGURATION dummy_tst DROP MAPPING FOR not_a_token, not_a_token |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | e0e58a96c431367f98c47807 | ALTER TEXT SEARCH CONFIGURATION dummy_tst ADD MAPPING FOR word, word WITH ispell |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | ea5274d72632238cef7b08d7 | ALTER TEXT SEARCH CONFIGURATION hunspell_tst ALTER MAPPING REPLACE ispell WITH hunspell |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | ec3e3ca380da60f96c7bc072 | ALTER TEXT SEARCH CONFIGURATION testcfg ADD MAPPING FOR word WITH simple |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | f78a9d05053fb80057174c16 | ALTER TEXT SEARCH CONFIGURATION dummy_tst DROP MAPPING FOR word |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | 12ff9102e1d34e511d810f90 | ALTER TEXT SEARCH DICTIONARY xsyn (RULES='xsyn_sample', KEEPORIG=true, MATCHORIG=true, KEEPSYNONYMS=true, MATCHSYNONYMS=true) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | 2811b1f357d2c9a9b6894e1d | ALTER TEXT SEARCH DICTIONARY intdict (REJECTLONG = 1) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | 3446898c462669e808828f21 | ALTER TEXT SEARCH DICTIONARY synonym (CaseSensitive = 2) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | 36e192726e5c4cb2faf886d1 | ALTER TEXT SEARCH DICTIONARY intdict (MAXLEN = 6.7) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | 4a817c16d07035d501b248d2 | ALTER TEXT SEARCH DICTIONARY xsyn (RULES='xsyn_sample', KEEPORIG=false, MATCHORIG=true, KEEPSYNONYMS=true, MATCHSYNONYMS=false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | 59b31a2e28c5ccffafa43eb3 | ALTER TEXT SEARCH DICTIONARY xsyn (RULES='xsyn_sample', KEEPORIG=true, MATCHORIG=false, KEEPSYNONYMS=false, MATCHSYNONYMS=true) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | 6dfa956fc71f6c97533aa3a9 | ALTER TEXT SEARCH DICTIONARY synonym (CaseSensitive = off) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | 6ffe61325fe6858a6dc9122b | ALTER TEXT SEARCH DICTIONARY xsyn (RULES='xsyn_sample', KEEPORIG=false, MATCHORIG=false, KEEPSYNONYMS=false, MATCHSYNONYMS=false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | 9d1a572fc5dce5495f02d7b6 | ALTER TEXT SEARCH DICTIONARY synonym (CaseSensitive = 1) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | a08f3d4504888ff3390c089c | ALTER TEXT SEARCH DICTIONARY intdict (MAXLEN = -214783648) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | adb9f09f64f02aba5f716258 | ALTER TEXT SEARCH DICTIONARY intdict (ABSVAL = true) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | b9225b3c6943475bf4fdb186 | ALTER TEXT SEARCH DICTIONARY xsyn (RULES='xsyn_sample', KEEPORIG=false, MATCHORIG=true, KEEPSYNONYMS=true, MATCHSYNONYMS=true) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | d885aecf9d514d9e6d296ab0 | ALTER TEXT SEARCH DICTIONARY xsyn (RULES='xsyn_sample', KEEPORIG=true, MATCHORIG=true, KEEPSYNONYMS=true, MATCHSYNONYMS=false) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSDICTIONARY_STMT | de206d2d634ddec8b835615a | ALTER TEXT SEARCH DICTIONARY xsyn (RULES='xsyn_sample', KEEPORIG=false, MATCHORIG=true, KEEPSYNONYMS=false, MATCHSYNONYMS=true) |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 0b5f280b932616ef267ea817 | copy (update copydml_test set t = 'g' where t = 'f' returning id) to stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 0e3fc3e245654303cc044937 | copy (update copydml_test set t = 'g') to stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 0f4b250be4a93147c90bb66f | copy donothingbrtrig_test from stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 1021fb3d0a7c5db4f2f75029 | COPY (UPDATE stats_track_tab SET x = 2 WHERE x = 1 RETURNING x) TO stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 1bb8c2dfe1b91fa54b2f3c70 | -- Error cases copy (insert into copydml_test default values) to stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 21a551ddacfd544860681ac8 | COPY ( MERGE INTO sq_target t USING sq_source s ON tid = sid WHEN MATCHED AND tid >= 2 THEN UPDATE SET balance = t.balance + delta WHEN NOT MATCHED THEN INSERT (balance, tid) VALUES (balance + delt... |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 3248857831e7e2f46e4d9d03 | COPY (SELECT * FROM copy_t ORDER BY a ASC) TO STDOUT WITH DELIMITER ',' |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 4de6f52a158c5d0f246accd2 | COPY (INSERT INTO copy_stats VALUES (2, 2) RETURNING *) TO STDOUT |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 529687f25417ec009ccbae05 | -- -- Test COPY (insert/update/delete ...) -- copy (insert into copydml_test (t) values ('f') returning id) to stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 56d4e588e1b708f07c42468a | COPY (UPDATE copy_stats SET b = b + 2 RETURNING *) TO STDOUT |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 6278a550ddeebe7faf694f62 | COPY t1 FROM stdin WITH |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 70ab556e344dfb2e04d835a7 | COPY (DELETE FROM copy_stats WHERE a = 1 RETURNING *) TO STDOUT |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 8c0817d1d5f952b6d8224adb | COPY (UPDATE copy_stats SET b = b + 1 RETURNING *) TO STDOUT |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 97a87590b73ff273af267947 | COPY (MERGE INTO stats_track_tab USING (SELECT 1 id) ON x = id WHEN MATCHED THEN UPDATE SET x = id WHEN NOT MATCHED THEN INSERT (x) VALUES (id) RETURNING x) TO stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 9b46c73306a625f23f8f618a | COPY (INSERT INTO stats_track_tab (x) VALUES (1) RETURNING x) TO stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | a5969c7fb138218e8e3832c6 | COPY (INSERT INTO copy_stats VALUES (1, 1) RETURNING *) TO STDOUT |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | b52f0ce5a44e02c0373dc963 | COPY copy_rel_to TO STDOUT WITH DELIMITER ',' |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | c87ec9b42f46d240fdc80022 | copy (update copydml_test set t = 'f') to stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | ee941d1a42b417ea59e2af41 | -- used in COPY without RETURNING COPY ( MERGE INTO target USING source ON (true) WHEN MATCHED THEN DELETE ) TO stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | f2d68abea63367ca5082c94f | copy (delete from copydml_test) to stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | f423500b01ba561a2426a805 | copy (delete from copydml_test where t = 'g' returning id) to stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | fd4a7deb7ff5aaa96a94b6e4 | COPY (DELETE FROM stats_track_tab WHERE x = 2 RETURNING x) TO stdout |
| ERROR | PG_QUERY__NODE__NODE_CREATE_AM_STMT | 11622e1b7f6eca018170e25e | CREATE ACCESS METHOD gist2 TYPE INDEX HANDLER gisthandler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_AM_STMT | b409c3330aeae9591cd3e76a | CREATE ACCESS METHOD regress_test_am TYPE INDEX HANDLER bthandler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_AM_STMT | cf4f8707bcc9b30affe8511d | -- Access method CREATE ACCESS METHOD bloom TYPE INDEX HANDLER blhandler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_AM_STMT | d5f4782e7ca9770f8b45ba88 | -- Access method CREATE ACCESS METHOD dummy_index_am TYPE INDEX HANDLER dihandler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_AM_STMT | de8828076d972ea4c69be873 | CREATE ACCESS METHOD heap_psql TYPE TABLE HANDLER heap_tableam_handler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 0393c11263e9c3938432299e | CREATE CAST (varchar AS citext) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 052cbed8e25b1665a675ce3f | create cast (xfloat4 as float4) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 19ad89f1f97002731af26c1a | CREATE CAST (ismn AS ismn13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 1eb5e036f5139bb0d9adc90b | CREATE CAST (hstore AS json) WITH FUNCTION hstore_to_json(hstore) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 21a8d14b6cfc0b8b1fb6fd16 | CREATE CAST (isbn AS isbn13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 225959bc6895013a4a23be79 | CREATE CAST (ean13 AS ismn) WITH FUNCTION ismn(ean13) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 29d74d1feaac5e38bd3bd4c3 | create cast (int4 as myint) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 32a9bb0e2800a94d04c89653 | CREATE CAST (ean13 AS upc) WITH FUNCTION upc(ean13) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 39e3ecaf09e0376bede21978 | create cast (xfloat8 as float8) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 3a8757c01f20844f0c678547 | CREATE CAST (text[] AS hstore) WITH FUNCTION hstore(text[]) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 49e10bfbeab811f4562883fa | CREATE CAST (issn13 AS ean13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 4ba80167eb18ca4cfd7722c0 | create cast (float8 as xfloat8) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 5409f726d3592fa95d679837 | CREATE CAST (hstore AS jsonb) WITH FUNCTION hstore_to_jsonb(hstore) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 5717ed40da741b1ea12cb63d | CREATE CAST (ean13 AS isbn13) WITH FUNCTION isbn13(ean13) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 5bfd629ab2152fb54acd01c8 | create cast (float4 as xfloat4) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 5f03532a5528ab301a65e6b8 | CREATE CAST (int4 AS casttesttype) WITH FUNCTION int4_casttesttype(int4) AS IMPLICIT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 6280420bf4e8f05dfffe53a3 | CREATE CAST (ean13 AS ismn13) WITH FUNCTION ismn13(ean13) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 63b739d6b970d23691ef6479 | -- -- Implicit and assignment type casts. -- CREATE CAST (citext AS text) WITHOUT FUNCTION AS IMPLICIT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 65b437f0433c999bd8976d88 | CREATE CAST (citext AS varchar) WITHOUT FUNCTION AS IMPLICIT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 684f18bc37fca2d25c26bc56 | CREATE CAST (text AS citext) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 6a1b2767cfc08c203aca1358 | create cast (myint as int4) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 6a5d3fd3a4f6c420efae4dbe | CREATE CAST (inet AS citext) WITH FUNCTION citext(inet) AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 6f36b5748f2701842569e21c | create cast (int8alias2 as int8) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 7082da2b06f30ad113b2b231 | CREATE CAST (priv_testdomain1 AS priv_testdomain3a) WITH FUNCTION castfunc(int) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 933e0df37d4f1dcc8e3c51b1 | CREATE CAST (isbn13 AS ean13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 94a39e174592b244cee4a483 | create cast (bigint as xfloat8) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 98b17dfeb18244fb09b80d04 | create cast (integer as xfloat4) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | 98d6e6860af6878604e2b9f5 | CREATE CAST (ismn13 AS ismn) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | a23db2ffd76b5c7c3428391b | CREATE CAST (boolean AS citext) WITH FUNCTION citext(boolean) AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | a475765ac37c0459e01e93bf | CREATE CAST (isbn13 AS isbn) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | a6b3c71d9841a1a0ba68333f | CREATE CAST (int4 AS casttesttype) WITH FUNCTION bar_int4_text(int4) AS IMPLICIT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | a7bd705e69ff887304c84d8a | CREATE CAST (text AS casttesttype) WITHOUT FUNCTION AS IMPLICIT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | b0c5eecc4a35c105e55ad4da | create cast (xfloat8 as bigint) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | b551d57f17fe72494d84b442 | CREATE CAST (citext AS bpchar) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | b5836eb4886de888d2b77539 | CREATE CAST (ismn AS ean13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | b6721d38df0d6da9fb295fd7 | create cast (int8 as int8alias1) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | b6d442fdcd5b2e90773ea77b | CREATE CAST (mood AS json) WITH FUNCTION mood_to_json(mood) AS IMPLICIT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | ba4007074dfa11e8ca9ae32e | CREATE CAST (bpchar AS citext) WITH FUNCTION citext(bpchar) AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | bd9fe70e58f539f8c94c04f7 | CREATE CAST (ean13 AS issn13) WITH FUNCTION issn13(ean13) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | c6a8c234dc74f9a02e70aa7f | create cast (integer as date) with function sql_to_date(integer) as assignment |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | ca6bbf2f4e58652571124758 | CREATE CAST (issn AS ean13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | cdb23962936cd345857332af | CREATE CAST (issn AS issn13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | cf5e05e3930878f58d51c830 | create cast (int8alias1 as int8) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | d43b4450355afb566c2b3e20 | CREATE CAST (upc AS ean13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | db87dd9b607233d17a266138 | create cast (xfloat4 as integer) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | e053d317b80d8a73a67ace22 | CREATE CAST (text AS casttesttype) WITHOUT FUNCTION |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | e08c94c35de9fd24f1b6eda6 | CREATE CAST (ismn13 AS ean13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | e1c39dd6eca031a898b53436 | CREATE CAST (int4 AS casttesttype) WITH INOUT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | ed407d07839d0cf81c779e1c | CREATE CAST (ean13 AS isbn) WITH FUNCTION isbn(ean13) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | edcd428e9be87590c5e936d3 | CREATE CAST (isbn AS ean13) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | f5b71d6d6c109196d747697f | CREATE CAST (priv_testdomain1 AS priv_testdomain3b) WITH FUNCTION castfunc(int) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | f9b927ad8a448dc1eb191f05 | CREATE CAST (issn13 AS issn) WITHOUT FUNCTION AS ASSIGNMENT |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | ff42bcd5294e9da3e452cf9d | create cast (int8 as int8alias2) without function |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CAST_STMT | ffc0554252fb8f9c31335d60 | CREATE CAST (ean13 AS issn) WITH FUNCTION issn(ean13) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CONVERSION_STMT | 3ac28fb90068a084160ea288 | create conversion alter1.latin1_to_utf8 for 'latin1' to 'utf8' from iso8859_1_to_utf8 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CONVERSION_STMT | 427f16bbc051bb80fbcb204f | CREATE CONVERSION test_conversion_exists FOR 'LATIN1' TO 'UTF8' FROM iso8859_1_to_utf8 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CONVERSION_STMT | 8f02978934230a0dfae3a2d4 | CREATE CONVERSION alt_conv2 FOR 'LATIN1' TO 'UTF8' FROM iso8859_1_to_utf8 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CONVERSION_STMT | a86fc6808e6bae34984faad9 | -- -- create default conversion with qualified name -- CREATE DEFAULT CONVERSION public.mydef FOR 'LATIN1' TO 'UTF8' FROM iso8859_1_to_utf8 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CONVERSION_STMT | cf8bdd3ebc70c7b5fd190485 | CREATE CONVERSION myconv FOR 'LATIN1' TO 'UTF8' FROM iso8859_1_to_utf8 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CONVERSION_STMT | e9dcca31b1953f0299131516 | CREATE CONVERSION alt_conv1 FOR 'LATIN1' TO 'UTF8' FROM iso8859_1_to_utf8 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_CONVERSION_STMT | fa0fcbf97c79dea0c9769f55 | -- -- cannot make default conversion with same schema/for_encoding/to_encoding -- CREATE DEFAULT CONVERSION public.mydef2 FOR 'LATIN1' TO 'UTF8' FROM iso8859_1_to_utf8 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 00c8155741840c600c171be2 | CREATE EVENT TRIGGER always_drop ON sql_drop EXECUTE PROCEDURE event_trigger_test() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 043276e3bba55e48b056588c | -- OK create event trigger regress_event_trigger_end on ddl_command_end execute function test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 0c154916ccef2333a2d07339 | create event trigger tcl_b_snitch on ddl_command_end execute procedure tclsnitch() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 14d6f01d160c5181f22144bb | CREATE EVENT TRIGGER start_rls_command ON ddl_command_start WHEN TAG IN ('CREATE POLICY', 'ALTER POLICY', 'DROP POLICY') EXECUTE PROCEDURE start_command() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 1cf68c2621a7ff91a7c2fc7f | -- should fail, create skunkcabbage is not a valid command tag create event trigger regress_event_trigger2 on ddl_command_start when tag in ('create table', 'create skunkcabbage') execute procedure... |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 2dfccf8c1667a0485b328a77 | CREATE EVENT TRIGGER always_end ON ddl_command_end EXECUTE PROCEDURE event_trigger_test() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 381235c1ccad3065ad8152c0 | -- should fail, can't have same filter variable twice create event trigger regress_event_trigger2 on ddl_command_start when tag in ('create table') and tag in ('CREATE FUNCTION') execute procedure ... |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 3fb2684961a726187f519728 | -- should fail, can't have event triggers on global objects create event trigger regress_event_trigger2 on ddl_command_start when tag in ('CREATE ROLE') execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 4623dadcf2b049a92a7851fa | CREATE EVENT TRIGGER end_rls_command ON ddl_command_end WHEN TAG IN ('CREATE POLICY', 'ALTER POLICY', 'DROP POLICY') EXECUTE PROCEDURE end_command() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 4c89e68bbd42d90e6b28fa9d | CREATE EVENT TRIGGER regress_reindex_end ON ddl_command_end WHEN TAG IN ('REINDEX') EXECUTE PROCEDURE reindex_end_command() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 546ac72f0a2df8b6015eb9ab | -- should fail, can't have event triggers on event triggers create event trigger regress_event_trigger2 on ddl_command_start when tag in ('DROP EVENT TRIGGER') execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 58d1a52cbc00f9df0927a4b1 | -- should fail, no elephant_bootstrap entry point create event trigger regress_event_trigger on elephant_bootstrap execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 5b073554b24bf3635dfc90af | create event trigger regress_event_trigger_noperms on ddl_command_start execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 6f7d6ef94436bd25ba33897d | CREATE EVENT TRIGGER regress_event_trigger_drop_objects ON sql_drop WHEN TAG IN ('drop table', 'drop function', 'drop view', 'drop owned', 'drop schema', 'alter table') EXECUTE PROCEDURE test_evtri... |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 721047a7ab2a240fab181d71 | CREATE EVENT TRIGGER undroppable ON sql_drop EXECUTE PROCEDURE undroppable() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 7faa17683319fee44019732b | CREATE EVENT TRIGGER regress_event_trigger_report_dropped ON sql_drop EXECUTE PROCEDURE event_trigger_report_dropped() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 8167e728c6f5bccb5fbd92c1 | -- should fail, return type mismatch create event trigger regress_event_trigger on ddl_command_start execute procedure pg_backend_pid() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 938153ec757840e22e5c0dd5 | -- should fail, food is not a valid filter variable create event trigger regress_event_trigger2 on ddl_command_start when food in ('sandwich') execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 93ca0cf0f767aecf3ed7ef55 | -- OK create event trigger regress_event_trigger on ddl_command_start execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 93f738c2c9e1f75b31c3528c | create event trigger perl_a_snitch on ddl_command_start execute procedure perlsnitch() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 9659d100929c4ec6b4001f90 | CREATE EVENT TRIGGER test_ddl_deparse ON ddl_command_end EXECUTE PROCEDURE test_ddl_deparse() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 97c76eeefc269d58f6d94cac | CREATE EVENT TRIGGER sql_drop_command ON sql_drop WHEN TAG IN ('DROP POLICY') EXECUTE PROCEDURE drop_sql_command() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | 9c1a085ff4dfd89ed79f9d0c | -- OK create event trigger regress_event_trigger2 on ddl_command_start when tag in ('create table', 'CREATE FUNCTION') execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | a1ca1b1bccfcde002bd1cc34 | -- should fail, sandwich is not a valid command tag create event trigger regress_event_trigger2 on ddl_command_start when tag in ('sandwich') execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | a45d63d139a96c052eefa163 | -- should fail, can't have event triggers on global objects create event trigger regress_event_trigger2 on ddl_command_start when tag in ('CREATE DATABASE') execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | ad9cb4adba8867467ab2604f | create event trigger perl_b_snitch on ddl_command_end execute procedure perlsnitch() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | af438d0564ed46d922e1b553 | create event trigger tcl_a_snitch on ddl_command_start execute procedure tclsnitch() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | af4b292b2bd466b9e7beb6ef | CREATE EVENT TRIGGER always_start ON ddl_command_start EXECUTE PROCEDURE event_trigger_test() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | b549d8dea4328c1501fb6499 | CREATE EVENT TRIGGER regress_event_trigger_report_end ON ddl_command_end EXECUTE PROCEDURE event_trigger_report_end() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | c643dc3cf54ba40d67635c8b | CREATE EVENT TRIGGER table_rewrite_trg ON table_rewrite EXECUTE PROCEDURE _evt_table_rewrite_fnct() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | c91fd390f21d4d40b134d373 | CREATE EVENT TRIGGER test_event_trigger_guc ON sql_drop WHEN TAG IN ('DROP POLICY') EXECUTE FUNCTION test_event_trigger_guc() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | cce6283df61eddc1111859c2 | create event trigger no_rewrite_allowed on table_rewrite execute procedure test_evtrig_no_rewrite() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | d2c507806a5eb1f8b6bdb039 | CREATE EVENT TRIGGER regress_reindex_start ON ddl_command_start WHEN TAG IN ('REINDEX') EXECUTE PROCEDURE reindex_start_command() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | e1fa989dbda1a85f517fb46c | CREATE EVENT TRIGGER has_volatile_rewrite ON table_rewrite EXECUTE PROCEDURE log_rewrite() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | e8552674ffc0c799cfaea5b8 | CREATE EVENT TRIGGER on_login_trigger ON login EXECUTE PROCEDURE on_login_proc() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | e88112cf054c77f8bf0abf41 | CREATE EVENT TRIGGER always_rewrite ON table_rewrite EXECUTE PROCEDURE event_trigger_test() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | e9a1cc56aab2e9b7a096a9ae | -- should fail, can't have event triggers on global objects create event trigger regress_event_trigger2 on ddl_command_start when tag in ('CREATE TABLESPACE') execute procedure test_event_trigger() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EVENT_TRIG_STMT | f5422673c3e1d000bd83f724 | CREATE EVENT TRIGGER regress_reindex_end_snap ON ddl_command_end EXECUTE FUNCTION reindex_end_command_snap() |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 02d2bc53a29c34021ca07608 | CREATE EXTENSION test_lfind |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 042bd91645f93d9de7cc7396 | CREATE EXTENSION test_radixtree |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 04451fb05ba4ee8e078039c7 | CREATE EXTENSION citext |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 061fb7031d96439885f3d3e3 | CREATE EXTENSION jsonb_plperl CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 07ac961e2eed4bfbd3d9c6ef | CREATE EXTENSION test_ext_extschema SCHEMA has$dollar |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 0bd5ee549ac169daa6f5a5ec | CREATE EXTENSION intarray |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 0d83b8a728b45d3f386ce4bc | -- -- SELECT statements -- CREATE EXTENSION pg_stat_statements |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 12fcd0e126c803746d69783d | CREATE EXTENSION test_ext1 SCHEMA test_ext1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 16893092bd4e6de7507a890a | create extension test_ext7 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 19483b66e15a186af7b753bb | CREATE EXTENSION pg_buffercache |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 1a38cb8ed977a1ce63232fad | CREATE EXTENSION pgcrypto |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 1c06bdbc14cf30a525aa3393 | -- -- Test earthdistance extension -- -- In this file we also do some testing of extension create/drop scenarios. -- That's really exercising the core database's dependency logic, so ideally -- we'... |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 1c086de5f084e5b52146a091 | CREATE EXTENSION plpython3u |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 1dccc85b56f7c1d58c4ea41b | create extension pg_surgery |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 23dd1029d5bba8c70d73048d | CREATE EXTENSION autoinc |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 26b391a08f07faf62932a1cc | CREATE EXTENSION jsonb_plperlu CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 2777d0baf2d3aa3b8f47721d | CREATE EXTENSION test_pg_dump |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 27a6d058c113cd9585dbbc66 | create extension spgist_name_ops |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 27fcb6f0bb1bd35f120b5b1e | CREATE EXTENSION tsm_system_rows |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 291156923fc462a0a25d64fa | CREATE EXTENSION test_ext_cyclic1 CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 295bd82bc69e0bfe354ff26e | CREATE EXTENSION test_ext_req_schema1 SCHEMA test_s_dep |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 2f9c2f942c413431beb2576e | CREATE EXTENSION btree_gin |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 353788be6909b5133e390604 | -- finally success CREATE EXTENSION test_ext1 SCHEMA has$dollar CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 35ab32dd00b6998e6145ef3d | -- -- Test seg datatype -- CREATE EXTENSION seg |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 379351048c2e40c216465b7b | CREATE EXTENSION test_ext_cine |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 40dcf682ce056fb0bfeed40c | CREATE EXTENSION test_ext_cor |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 4403e4f2a3147c4f214ddadb | CREATE EXTENSION dict_int |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 446a9ae8bb61aa18bd736abf | CREATE EXTENSION lo |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 45492cc8a9561ea4fbedc148 | CREATE EXTENSION test_dsm_registry |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 472a865ffecde0b19c164871 | CREATE EXTENSION btree_gist |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 4787630702dd6f6124f85a7e | CREATE EXTENSION hstore |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 489c0ce1af9ec1f42be8b01b | CREATE EXTENSION dummy_seclabel |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 4ae7679300b453eb8bf6eaa7 | CREATE EXTENSION test_ext1 SCHEMA has$dollar |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 4c86d12c7a6312c28f48f51d | CREATE EXTENSION test_predtest |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 4d9df46e3e961d3d5c2ce714 | -- -- The test uses a GIN index over int[]. The table contains arrays -- with integers from 1 to :next_i. Each integer occurs exactly once, -- no gaps or duplicates, although the index does contain... |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 4eb2659e27cfd2840db8ef4b | CREATE EXTENSION isn |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 4ee33dec9020e165be69c59d | CREATE EXTENSION hstore_plperl CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 50493346e36829049d5676b3 | CREATE EXTENSION pg_prewarm |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 54cefe6033806b54a0f5b683 | CREATE EXTENSION bloom |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 55099cf44a73233595c7a2d1 | CREATE EXTENSION xml2 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 578049aab8d5668b267bf841 | CREATE EXTENSION test_ginpostinglist |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 643f1b80ea1f7836840b37d3 | CREATE EXTENSION test_ext6 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 6a08a12651b7c8d197cacf9a | create extension cube with schema c |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 6bd0ac56c26b1ce2703ecf04 | CREATE EXTENSION hstore_plperl |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 6bdb567ce014a1c87be4330d | -- -- Test cube datatype -- CREATE EXTENSION cube |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 6e13cb021722c608a1dbab49 | CREATE EXTENSION bool_plperl CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 71c3e850c7525dad2b841e94 | -- has priv but no user mapping -- Install file_fdw CREATE EXTENSION file_fdw |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 72a579dd6bacf94a972db143 | CREATE EXTENSION plsample |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 789ffd360ab49f4168f823be | -- =================================================================== -- create FDW objects -- =================================================================== CREATE EXTENSION postgres_fdw |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 79c21238d13b65f9a45596a9 | CREATE EXTENSION test_slru |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 7a21fbf9236ffe05b7e5383d | CREATE EXTENSION pg_visibility |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 83ed3ee83c8487a323ff9de2 | CREATE EXTENSION test_integerset |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 85e3c9b0a1b0b7082271f709 | CREATE EXTENSION test_parser |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 8cbaa521c8b55fe099505c9d | CREATE EXTENSION tablefunc |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 908fd92d87919895ec4a1095 | -- Test old extension version entry points. CREATE EXTENSION pg_walinspect WITH VERSION '1.0' |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 917335f41adb51819df515ad | CREATE EXTENSION plperl |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 992b5be1266fa02eeec6c1b4 | CREATE EXTENSION test_ext_extschema SCHEMA "has space" |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 9a2193d1d0f12d280b8853a2 | CREATE EXTENSION fuzzystrmatch |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 9e1718c06dcdee082d69809d | CREATE EXTENSION pgstattuple |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | a32e81b238fec94e2eafe719 | CREATE EXTENSION test_ddl_deparse |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | a361c8029c7188f01dcfc88f | CREATE EXTENSION pageinspect |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | a3c1f91ad698bbcf1c2fb205 | -- Tests with various custom types CREATE EXTENSION test_custom_types |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | a5052c6ebcf82ca980654e5d | CREATE EXTENSION tsm_system_time |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | a6dd3f8738e0b98102490f6a | -- test some errors CREATE EXTENSION test_ext1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | a93222982285c427b218c7c2 | CREATE EXTENSION refint |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | a988b34c39b2cfb3c99bbd12 | -- test handling of temp objects created by extensions create extension test_ext8 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | ab957ebec782844c1b9900b2 | CREATE EXTENSION hstore_plpython3u CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | acac9ad880e702db12852f06 | CREATE EXTENSION test_ext1 SCHEMA test_ext |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | aeb591763891068fa86469db | CREATE EXTENSION pg_walinspect |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | b152316da520bd6fb76eca12 | CREATE EXTENSION test_shm_mq |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | b218e9c82f1756d89b66b93a | CREATE EXTENSION dict_xsyn |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | b4def01ca905c6bba6f8a466 | CREATE EXTENSION test_resowner |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | b5a3d13f075714c635672751 | CREATE EXTENSION amcheck |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | b7f4341c70f656431f4dea30 | CREATE EXTENSION test_copy_callbacks |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | bacb29c7e6fb948433506350 | CREATE EXTENSION test_dsa |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | baee3286b1c712d5aaf8ca53 | CREATE EXTENSION jsonb_plpython3u CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | bb8657f22625f469b04760f8 | CREATE EXTENSION dummy_index_am |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | bcdd5232dbbf39f543b9ed45 | CREATE EXTENSION test_tidstore |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | be26e3bb7d86d5ae20d6ff52 | -- check handling of types as extension members create extension test_ext9 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | c13359dc561f5b6498cfd07d | CREATE EXTENSION ltree |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | c3a70f5ba62505e88519f8f7 | -- fail CREATE EXTENSION plperlu |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | c70897132439365c5a68f778 | CREATE EXTENSION test_ext_req_schema1 SCHEMA test_func_dep1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | c72317fae82d2391f8d12e26 | CREATE EXTENSION pageinspect VERSION '1.8' |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | c7d642ccba1a8d56ff5fc430 | CREATE EXTENSION hstore_plperlu CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | c80814a395d7a15d7d1fb4e4 | CREATE EXTENSION "uuid-ossp" |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | c8223d3929665105de3012e7 | CREATE EXTENSION citext SCHEMA s |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | cedc59780c463971860b2d29 | CREATE EXTENSION pg_logicalinspect |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | d2724130e9cbe9a41fbc445f | CREATE EXTENSION test_rbtree |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | d65e65bd8ad23b24bb49559c | CREATE EXTENSION bool_plperlu CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | d8e9e38ca1366f8eeb4f1373 | CREATE EXTENSION pg_trgm |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | dc4c5b6fecd507a29beb3242 | CREATE EXTENSION ltree_plpython3u CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | dc57f7a6ada8f8f39087bfe8 | CREATE EXTENSION test_ext_set_schema SCHEMA s1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | e5c41a68af894efa9e0775c7 | CREATE EXTENSION test_bloomfilter |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | e693953405cbde930dc82a1c | CREATE EXTENSION test_ext_req_schema3 CASCADE |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | eb243968d5cfbb0f6e592d61 | CREATE EXTENSION dblink |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | ebbbfd38df620abfaded32ae | -- test old extension version entry points CREATE EXTENSION pg_stat_statements WITH VERSION '1.4' |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | ed59ed022621c5e6270070e4 | -- -- Test @extschema:extname@ syntax and no_relocate option -- CREATE EXTENSION test_ext_req_schema1 SCHEMA has$dollar |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | f1ed96d0d6ea79901ce201fc | create extension test_regex |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | f4be13f03ca55a5519cdb354 | CREATE EXTENSION pg_freespacemap |
| ERROR | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 10b807de222492ae98e8b09d | CREATE FUNCTION functest_S_2(a text[]) RETURNS int RETURN a[1]::int |
| ERROR | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 1faf46ce11177ac2f1ed8935 | CREATE FUNCTION functest_S_14() RETURNS bigint RETURN (SELECT count(*) FROM functestv3) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 387b54c840c303f10f68bbd6 | CREATE FUNCTION functest_S_3() RETURNS boolean RETURN false |
| ERROR | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 4a3d66522246ffec30cda346 | CREATE FUNCTION functest_S_13() RETURNS boolean BEGIN ATOMIC SELECT 1; SELECT false; END |
| ERROR | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8184afff251597d8d0a9d6c1 | CREATE FUNCTION functest_S_3a() RETURNS boolean BEGIN ATOMIC ;;RETURN false;; END |
| ERROR | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | a32b9784542bef58856f4241 | -- empty body CREATE PROCEDURE ptest8(x text) BEGIN ATOMIC END |
| ERROR | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | b7c02295c435b742055c9d8e | CREATE FUNCTION hobbies_by_name(hobbies_r.name%TYPE) RETURNS hobbies_r.person%TYPE AS 'select person from hobbies_r where name = $1' LANGUAGE SQL |
| ERROR | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d48631b501a8986ca8fbddd5 | CREATE OR REPLACE FUNCTION list_partitioned_table() RETURNS SETOF public.partitioned_table.a%TYPE AS $$ DECLARE row public.partitioned_table%ROWTYPE; a_val public.partitioned_table.a%TYPE; BEGIN FO... |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PLANG_STMT | 0a70b0ee5a8b89032a03d998 | CREATE TRUSTED LANGUAGE pltcl HANDLER pltcl_call_handler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PLANG_STMT | 2cdcaa5cfd76b896c1df5ca6 | CREATE LANGUAGE plpython3u HANDLER plpython3_call_handler INLINE plpython3_inline_handler VALIDATOR plpython3_validator |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PLANG_STMT | 3c01d0716d7d08dbe8db4988 | CREATE LANGUAGE pltclu HANDLER pltclu_call_handler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PLANG_STMT | 414834ccf5649056b2b41b83 | CREATE TRUSTED LANGUAGE plpgsql HANDLER plpgsql_call_handler INLINE plpgsql_inline_handler VALIDATOR plpgsql_validator |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PLANG_STMT | 4543a8ad83ade4a3c56572f9 | CREATE TRUSTED LANGUAGE plperl HANDLER plperl_call_handler INLINE plperl_inline_handler VALIDATOR plperl_validator |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PLANG_STMT | 8da81d2676f40aabf7a9e212 | CREATE LANGUAGE plperlu HANDLER plperlu_call_handler INLINE plperlu_inline_handler VALIDATOR plperlu_validator |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PLANG_STMT | a59703ad5d06c68426e329ff | CREATE LANGUAGE alt_lang2 HANDLER plpgsql_call_handler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PLANG_STMT | b143f564c3e37706079058e0 | -- -- Procedural Language -- CREATE LANGUAGE alt_lang1 HANDLER plpgsql_call_handler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PLANG_STMT | f4ee38b6cf870facbb4c5456 | CREATE TRUSTED LANGUAGE plsample HANDLER plsample_call_handler |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 03a66b4f338787a1f3cbf6d6 | -- Generated columns in column list, when 'publish_generated_columns'='none' CREATE PUBLICATION pub1 FOR table gencols(a, gen1) WITH (publish_generated_columns = none) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 06eb811f9ec5e440d6bdad0f | -- check create publication on an object which is not schema CREATE PUBLICATION testpub1_forschema1 FOR TABLES IN SCHEMA testpub_view |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 09261ae46a3ce91cf6d2dee9 | CREATE PUBLICATION dummy_pub |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 09e480c8fc9f56c078550714 | -- ok CREATE PUBLICATION testpub3 FOR TABLES IN SCHEMA pub_test |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 1179d8e348f3f5cd4ef7dc5c | CREATE PUBLICATION testpub6 FOR TABLE rf_bug WHERE (status = 'open') WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 143b8daab1c089f74da48812 | CREATE PUBLICATION testpub4_forschema FOR TABLES IN SCHEMA "CURRENT_SCHEMA" |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 1749ea534b59f90accf48e54 | CREATE PUBLICATION testpub6 FOR TABLE rf_tbl_abcd_pk (a, b) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 1922b5c82d9a31fcc3478c87 | CREATE PUBLICATION testpubpart_forschema FOR TABLES IN SCHEMA pub_testpart2 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 2897635b6f4de4db02753b47 | CREATE PUBLICATION testpub_xxx WITH (publish_generated_columns) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 2c2375960320f34b0962657e | -- failure - cannot use column list and schema together CREATE PUBLICATION testpub_tbl9 FOR TABLES IN SCHEMA public, TABLE public.testpub_tbl7(a) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 2d5e0efa1560c9a5112495a2 | CREATE PUBLICATION testpub6 FOR TABLES IN SCHEMA testpub_rf_schema2 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 32446179331e3134e1c8be06 | -- fail - temporary table CREATE PUBLICATION testpub_fortemptbl FOR TABLE testpub_temptbl |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 35daaf75eaa8dcb07dae65e9 | CREATE PUBLICATION testpub3_forschema |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 38ca3cba73bde1fa8e567308 | CREATE PUBLICATION testpub_fortable_insert WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 42c158e35d2cb2224f110f79 | CREATE PUBLICATION testpub_syntax1 FOR TABLE testpub_rf_tbl1, ONLY testpub_rf_tbl3 WHERE (e < 999) WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 486296a50665ad66774455d4 | CREATE PUBLICATION testpub_dups FOR TABLE testpub_rf_tbl1 WHERE (a = 1), testpub_rf_tbl1 WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 4a88011ed4300ea926b7eba9 | CREATE PUBLICATION testpub_xxx WITH (publish_generated_columns = stored, publish_generated_columns = none) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 4b3facd48ac0fc79bb76175f | CREATE PUBLICATION testpub_foralltables FOR ALL TABLES |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 4ba171237ad8c25e20d465eb | CREATE PUBLICATION dump_pub_all FOR TABLE ONLY pubme.t0, TABLE ONLY pubme.t1 WHERE (c < 0), TABLES IN SCHEMA pubme, TABLES IN SCHEMA pubme2 WITH (publish_via_partition_root = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 4ed59fd4b92d388f7cb818c2 | CREATE PUBLICATION addr_pub_schema FOR TABLES IN SCHEMA addr_nsp |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 4f5adf24b6391a3bd88e3503 | -- fail - system columns are not allowed CREATE PUBLICATION testpub6 FOR TABLE testpub_rf_tbl1 WHERE ('(0,1)'::tid = ctid) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 52152bb6f5dc475835defc46 | CREATE PUBLICATION pub FOR TABLE target_tbl |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 53328fec1ac616e1f2430f39 | -- fail CREATE PUBLICATION testpub3 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 5417f8acdb300810551841f9 | CREATE PUBLICATION testpub_xxx WITH (publish = 'cluster, vacuum') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 54aed3337db56625b868ac83 | CREATE PUBLICATION pub1 FOR ALL TABLES |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 560ad5263c1b9252d58d1564 | CREATE PUBLICATION dump_pub_nsp_1ct FOR TABLES IN SCHEMA pubme |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 5f5f52f00a84465abddbf778 | CREATE PUBLICATION testpub_both_filters |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 5f83b3039ccdfe3a4592cd44 | CREATE PUBLICATION testpub_dups FOR TABLE testpub_rf_tbl1, testpub_rf_tbl1 WHERE (a = 2) WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 5f9ef6228b17e740e0972477 | CREATE PUBLICATION testpubpart_forschema FOR TABLES IN SCHEMA pub_testpart1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 60878ba0024ba5a865c0f717 | CREATE PUBLICATION dump_pub_nsp_2ct FOR TABLES IN SCHEMA pubme, TABLES IN SCHEMA pubme2 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 60ab7eb7164288d01c2e6599 | CREATE PUBLICATION testpub4 FOR TABLES IN SCHEMA pub_test |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 63699738efc0f83fe7344851 | -- check create publication on a schema that does not exist CREATE PUBLICATION testpub_forschema FOR TABLES IN SCHEMA non_existent_schema |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 6899d8f1e683ae5b6ab4c897 | CREATE PUBLICATION testpub_foralltables FOR ALL TABLES WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 6d0c35883f1994ec4f535f31 | CREATE PUBLICATION testpub_forschema FOR TABLES IN SCHEMA CURRENT_SCHEMA |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 6dfe9fb009f4d92b020e64c9 | CREATE PUBLICATION testpub_default |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 70ad35693fd583a851b3681b | -- Schema publication that does not include the schema that has the parent table CREATE PUBLICATION pub FOR TABLES IN SCHEMA sch2 WITH (PUBLISH_VIA_PARTITION_ROOT=0) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 732731ba3f57f3c1c3a8ba67 | create publication pub1 for table alter1.t1, tables in schema alter2 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 7c8fdc7c5818f3a09bad096a | CREATE PUBLICATION testpub_table_ins WITH (publish = 'insert, truncate') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 7e4852556bdf381938cfbb98 | CREATE PUBLICATION testpub_dups FOR TABLE testpub_tbl1, testpub_tbl1 (a) WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 7f1f400957e7d499a3faf91e | CREATE PUBLICATION testpub5_forschema FOR TABLES IN SCHEMA CURRENT_SCHEMA, "CURRENT_SCHEMA" |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 80ba0b632a3f02e48cb926e4 | CREATE PUBLICATION testpub_xxx WITH (publish_via_partition_root = 'true', publish_via_partition_root = '0') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 854a2977540b65cdd77b5339 | CREATE PUBLICATION testpub_forschema_fortable FOR TABLES IN SCHEMA pub_test1, TABLE pub_test2.tbl1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 86be625c7824399044c8f413 | -- =================================================================== -- test error case for create publication on foreign table -- ================================================================... |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 8796caefd4e58608a5a9e5b8 | CREATE PUBLICATION testpub_ins_trunct WITH (publish = insert) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 8a9ea69b3d13cc16dfc10caf | -- ok - only publish schema CREATE PUBLICATION testpub_tbl9 FOR TABLES IN SCHEMA public |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 8bfda548fd0b04fa309bf316 | CREATE PUBLICATION testpub_forparted |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 8dcf5ca665068956dd435507 | -- fail - view CREATE PUBLICATION testpub_fortbl FOR TABLE testpub_view |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 8f661fedfdeb925d159ae2ca | CREATE PUBLICATION pub FOR TABLES IN SCHEMA sch1 WITH (PUBLISH_VIA_PARTITION_ROOT=1) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 8fa519e0e9fdae36b3492f51 | -- fail - system table CREATE PUBLICATION testpub_forsystemtbl FOR TABLE pg_publication |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 90ef26fa007e64ce56fa4b9c | CREATE PUBLICATION testpub_forschema FOR TABLES IN SCHEMA pub_test |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 92cdda89011e57af1205066f | CREATE PUBLICATION testpub8 FOR TABLE testpub_rf_tbl7 WHERE (y > 100) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 943cc6a8a363ae7a8cfd07bb | CREATE PUBLICATION testpub_dups FOR TABLE testpub_tbl1 (a), testpub_tbl1 WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 94d27a9ccede98814eaa115d | -- Table publication that does not include the parent table CREATE PUBLICATION pub FOR TABLE sch2.tbl1_part1 WITH (PUBLISH_VIA_PARTITION_ROOT=0) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 9abb37de72b3a7de6e36f807 | CREATE PUBLICATION testpub7 FOR TABLE testpub_rf_tbl6 WHERE (y > 100) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | a4a0b8e031456fa3739f07b4 | CREATE PUBLICATION pub1 FOR ALL TABLES WITH (publish_generated_columns = stored) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | a4acaff1d09eb7bb1e2f80d7 | CREATE PUBLICATION testpub_rf_yes FOR TABLE testpub_rf_tbl1 WHERE (a > 1) WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | a50a913380e9016947e12064 | -- Schema publication that does not include the schema that has the parent table CREATE PUBLICATION pub FOR TABLES IN SCHEMA sch2 WITH (PUBLISH_VIA_PARTITION_ROOT=1) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | a576379b73bc054222f16159 | -- should be able to create publication with schema and table of the same -- schema CREATE PUBLICATION testpub_for_tbl_schema FOR TABLES IN SCHEMA pub_test, TABLE pub_test.testpub_nopk |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | a5e09d1078d0b1f769deaf71 | -- error - generated column "b" must be published explicitly as it is -- part of the REPLICA IDENTITY index. CREATE PUBLICATION pub_gencol FOR TABLE testpub_gencol |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | a83ecb627802fc0ef90a1804 | CREATE PUBLICATION testpub3 FOR TABLE testpub_tbl3 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | a97ca272571c3a34f11bc35b | CREATE PUBLICATION testpub6 FOR TABLE rf_tbl_abcd_pk WHERE (a > 99) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | ad0dbf221b3f5cea215175e8 | -- fail - already added CREATE PUBLICATION testpub_fortbl FOR TABLE testpub_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | aed21f6e5d7ea1f3d1823482 | CREATE PUBLICATION testpub6_forschema FOR TABLES IN SCHEMA "CURRENT_SCHEMA", CURRENT_SCHEMA |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | aedeb29a127920e699f50398 | CREATE PUBLICATION testpub_fortable FOR TABLE testpub_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | b001b2b357e5cd6aa750fcbd | CREATE PUBLICATION testpub1_forschema FOR TABLES IN SCHEMA pub_test1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | b1600339b04bcecb1f435be5 | CREATE PUBLICATION testpub_col_list FOR TABLE testpub_tbl8 (a, b) WITH (publish_via_partition_root = 'true') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | b1c0f6277b26e1ef8ede216b | CREATE PUBLICATION testpub_fortable FOR TABLE "CURRENT_SCHEMA"."CURRENT_SCHEMA" |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | b1f39566e0f5f35c1dc739d0 | -- ok - generated column "b" is published explicitly CREATE PUBLICATION pub_gencol FOR TABLE testpub_gencol with (publish_generated_columns = stored) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | b7f6db8a68a912f0bfd64083 | -- fail - unlogged table CREATE PUBLICATION testpub_forunloggedtbl FOR TABLE testpub_unloggedtbl |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | b88eb17d6e340cc0da05bae4 | CREATE PUBLICATION testpub2 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | bba05a23a2e5c2a727d31c7e | CREATE PUBLICATION dump_pub_qual_2ct FOR TABLE ONLY pubme.t0 (c) WHERE (c > 0), TABLE ONLY pubme.t1 (c) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | c5cbc7689ee5e5759d0553b6 | -- fail - row filter expression is not simple CREATE PUBLICATION testpub6 FOR TABLE testpub_rf_tbl1 WHERE (a IN (SELECT generate_series(1,5))) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | c605dd105a9dfab5c03c9395 | -- error cases CREATE PUBLICATION testpub_xxx WITH (foo) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | d7b4cba4cd6e590cd6415c46 | -- Table publication that does not include the parent table CREATE PUBLICATION pub FOR TABLE sch2.tbl1_part1 WITH (PUBLISH_VIA_PARTITION_ROOT=1) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | d7ebfe49ac3aae32cc22d215 | CREATE PUBLICATION testpub_xxx WITH (publish_generated_columns = foo) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | d9b53543a112338e43fe8ac2 | CREATE PUBLICATION testpub_fortable_forschema FOR TABLE pub_test2.tbl1, TABLES IN SCHEMA pub_test1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | dcc8dc344c5f9e7c7e2ed636 | CREATE PUBLICATION dump_pub_qual_1ct FOR TABLE ONLY pubme.t0 (c, d) WHERE (c > 0) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | dd69a5d876bd89e29dffa206 | CREATE PUBLICATION testpub_rf_no FOR TABLE testpub_rf_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | de63ef737b22077e501aa22b | CREATE PUBLICATION addr_pub FOR TABLE addr_nsp.gentable |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | e03d0dc87cd929857642068a | CREATE PUBLICATION testpub_fortbl FOR TABLE testpub_tbl1, pub_test.testpub_nopk |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | e0a7a3920b7a2acded7dbd0c | CREATE PUBLICATION testpub_syntax2 FOR TABLE testpub_rf_tbl1, testpub_rf_schema1.testpub_rf_tbl5 WHERE (h < 999) WITH (publish = 'insert') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | e0db9782d0ff4043a66a5571 | CREATE PUBLICATION testpub6 FOR TABLE testpub_rf_tbl3 WHERE (e =#> 27) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | f14dd4f113beac4ee8ef7ec9 | CREATE PUBLICATION testpub_forparted1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | f22ecfe8ddb8e0e775128929 | -- check create publication on a system schema CREATE PUBLICATION testpub_forschema FOR TABLES IN SCHEMA pg_catalog |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | f3552df4f4679386ebece8fe | CREATE PUBLICATION testpub4 FOR TABLE ONLY testpub_tbl3 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | fdbd82862a3f0a4b6962d85a | -- Firstly, test using the option publish='insert' because the row filter -- validation of referenced columns is less strict than for delete/update. CREATE PUBLICATION testpub5 FOR TABLE testpub_rf... |
| ERROR | PG_QUERY__NODE__NODE_CREATE_STMT | 5f4d1d0616ac091ef967f76f | CREATE TABLE withoid() WITH (oids) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_STMT | 7bfbc8c3dfe3165c0366e675 | -- Specifying name only for a non-Boolean option should fail CREATE TABLE reloptions_test2(i INT) WITH (fillfactor) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_STMT | b61f8504e316d3b54e162ab7 | create table 計算機用語 (用語 text, 分類コード varchar, 備考1Aだよ char(16)) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_STMT | e06e6ec92a7d3f86807488e6 | CREATE TEMP TABLE fktable2 (fk int references pktable ENFORCED NOT ENFORCED) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 07ebaa7b064e4b49306c6429 | -- fail - origin must be either none or any CREATE SUBSCRIPTION regress_testsub4 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (slot_name = NONE, connect = false, origin = foo) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 121e216e1ced684bb6b5e787 | CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION mypub WITH (connect = false, create_slot = false, copy_data = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 12439c3e6f6262a49f4bba63 | CREATE SUBSCRIPTION regress_testsub2 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION foo WITH (connect = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 1bc1fd65972004b80c5e4695 | CREATE SUBSCRIPTION regress_testsub2 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (slot_name = NONE, enabled = false, create_slot = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 2873507ccf9d80d776473693 | -- fail - duplicate publications CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION foo, testpub, foo WITH (connect = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 28c4812f46a9d3ddd155a2c0 | CREATE SUBSCRIPTION regress_testsub2 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, create_slot = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 2e4c5743cb12334c794ef9d3 | CREATE SUBSCRIPTION regress_testsub2 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (slot_name = NONE) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 300908b763a237434dff2c47 | CREATE SUBSCRIPTION regress_testsub2 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (slot_name = NONE, enabled = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 48875bb2b09f5c476970cf96 | CREATE SUBSCRIPTION regress_testsub2 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (slot_name = NONE, create_slot = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 50657bd8d95d4380b3cff5e9 | -- fail - streaming must be boolean or 'parallel' CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, streaming = foo) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 53c3e13612b844d7ba68acb9 | -- fail -- fail - binary must be boolean CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, binary = foo) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 6ea0f4c2a75237616b7f2c41 | -- fail, connection string parses, but doesn't work (and does so without -- connecting, so this is reliable and safe) CREATE SUBSCRIPTION regress_testsub5 CONNECTION 'port=-1' PUBLICATION testpub |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 74985fcf1ece2301f2590104 | -- fail - invalid option combinations CREATE SUBSCRIPTION regress_testsub2 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, copy_data = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 74b84d9aa7ea6b8e0c320163 | -- ok - with slot_name = NONE CREATE SUBSCRIPTION regress_testsub3 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (slot_name = NONE, connect = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 7cf1cf973f145dfbd0e9bf75 | CREATE SUBSCRIPTION regress_testsub2 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (slot_name = NONE, enabled = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 7e5d39abf6df01db45765f7d | CREATE SUBSCRIPTION regress_testsub CONNECTION 'testconn' PUBLICATION testpub WITH (create_slot) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 8dde59729ae2e6dde26db2e0 | -- now it works CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, two_phase = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | 9789e81a7cd1f8fc86dbc0b0 | -- fail, connection string does not parse CREATE SUBSCRIPTION regress_testsub5 CONNECTION 'i_dont_exist=param' PUBLICATION testpub |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | a658582fda1a99cc2d87dcfa | -- ok CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | acace7ce9ec2246cf1baa851 | CREATE SUBSCRIPTION dummy_sub CONNECTION '' PUBLICATION foo WITH (connect = false, slot_name = NONE) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | ad9ac43f86f69d6187fad88b | -- fail - disable_on_error must be boolean CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, disable_on_error = foo) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | b0f9ce1025e5223731723005 | -- now it works CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, binary = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | b683a3797a334a1f4dd6f770 | -- now it works CREATE SUBSCRIPTION regress_testsub4 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (slot_name = NONE, connect = false, origin = none) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | cf7b711e3b531858b78a4d9c | -- now it works CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, streaming = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | e0bb437e07700e035271d6d4 | -- two_phase and streaming are compatible. CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, streaming = true, two_phase = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | e703de3ead0aa13b4580e47b | -- fail - invalid connection string CREATE SUBSCRIPTION regress_testsub CONNECTION 'testconn' PUBLICATION testpub |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | e7cbd03da2d7fefed670a854 | CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist password=regress_fakepassword' PUBLICATION testpub WITH (connect = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | ec38b0152d2e9a8e7faa83bd | -- fail - two_phase must be boolean CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, two_phase = foo) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | ed160f3bc7887a90a380e59b | CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, password_required = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | f38420103e8b15ccadea4121 | -- now it works CREATE SUBSCRIPTION regress_testsub CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, disable_on_error = false) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | f8c814445dbe746122d71344 | CREATE SUBSCRIPTION regress_addr_sub CONNECTION '' PUBLICATION bar WITH (connect = false, slot_name = NONE) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_SUBSCRIPTION_STMT | ffa625383ceb5c3c97e2cc83 | CREATE SUBSCRIPTION regress_testsub2 CONNECTION 'dbname=regress_doesnotexist' PUBLICATION testpub WITH (connect = false, enabled = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | 0c130d849b16c1f8a60d6324 | CREATE TEMPORARY TABLE q5_prep_results AS EXECUTE q5(200, 'DTAAAA') |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | 2b8ba84770bdc5cb524e843b | CREATE TEMPORARY TABLE pgss_ctas_2 AS EXECUTE test_prepare_pgss |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | 3f00e78b511bbcca59d0def5 | CREATE TABLE selinto_schema.tbl_nodata3 (a) AS EXECUTE data_sel WITH NO DATA |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | 55880f2e11738903f5001875 | CREATE TEMPORARY TABLE pgss_ctas_4 AS EXECUTE test_prepare_pgss |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | ab8e5a215fbdecdaf1d70b22 | CREATE TABLE testschema.asexecute TABLESPACE regress_tblspace AS EXECUTE selectsource(2) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | b6bf244a21a76866ef586a6c | create table parallel_write as execute prep_stmt |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | bd0d91fc342a7dfb49d51b10 | CREATE TABLE as_select1 AS EXECUTE select1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | e2021c38620ba0d19c742155 | CREATE TEMPORARY TABLE q5_prep_nodata AS EXECUTE q5(200, 'DTAAAA') WITH NO DATA |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | f2dc073d588fe69f7f773d76 | CREATE TABLE selinto_schema.tbl_withdata3 (a) AS EXECUTE data_sel WITH DATA |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | fb939d4f59bd7cc881786670 | CREATE TABLE IF NOT EXISTS as_select1 AS EXECUTE select1 |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_SPACE_STMT | 1550a32005ca0ba21503db0e | -- fail CREATE TABLESPACE regress_tblspacewith LOCATION '' WITH (random_page_cost = 3.0) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_SPACE_STMT | 2e58e1b7f81af3c8b4abf3b7 | -- create a tablespace using WITH clause CREATE TABLESPACE regress_tblspacewith LOCATION '' WITH (some_nonexistent_parameter = true) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_SPACE_STMT | 6d8b86376ef12650d38b452b | -- fail -- empty tablespace locations are not usually allowed CREATE TABLESPACE regress_tblspace LOCATION '' |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_SPACE_STMT | 8048fb6fb06ea327ad4d3c37 | CREATE TABLESPACE regress_test_stats_tblspc LOCATION '' |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_SPACE_STMT | 85e34d552d31b28a7c7370f6 | CREATE TABLESPACE pg_foo LOCATION '/no/such/location' |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_SPACE_STMT | a582e7028dab82a95b5b26a2 | -- Will fail with bad path CREATE TABLESPACE regress_badspace LOCATION '/no/such/location' |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_SPACE_STMT | bf39bcb37ed395b68f94fe85 | CREATE TABLESPACE regress_create_idx_tblspace LOCATION '' |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_SPACE_STMT | f55813ea8454aa7d20b3854c | -- relative tablespace locations are not allowed CREATE TABLESPACE regress_tblspace LOCATION 'relative' |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 018990c9316a361ae59f434b | CREATE TRANSFORM FOR jsonb LANGUAGE plperl ( FROM SQL WITH FUNCTION jsonb_to_plperl(internal), TO SQL WITH FUNCTION plperl_to_jsonb(internal) ) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 0b1c96b240f3277aad068e65 | CREATE TRANSFORM FOR bool LANGUAGE plperlu ( FROM SQL WITH FUNCTION bool_to_plperlu(internal), TO SQL WITH FUNCTION plperlu_to_bool(internal) ) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 0b8350e4ce6da39a5cf6932e | -- fail CREATE TRANSFORM FOR hstore LANGUAGE foo (FROM SQL WITH FUNCTION hstore_to_plperl(internal), TO SQL WITH FUNCTION plperl_to_hstore(internal)) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 18803088b7d157e949ee66e6 | -- ok CREATE OR REPLACE TRANSFORM FOR hstore LANGUAGE plperl (TO SQL WITH FUNCTION plperl_to_hstore(internal)) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 314aea6414ad80ee9750c83c | -- fail CREATE TRANSFORM FOR hstore LANGUAGE plperl (FROM SQL WITH FUNCTION hstore_out(hstore), TO SQL WITH FUNCTION plperl_to_hstore(internal)) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 4838a006eadfc56837475273 | CREATE TRANSFORM FOR jsonb LANGUAGE plpython3u ( FROM SQL WITH FUNCTION jsonb_to_plpython3(internal), TO SQL WITH FUNCTION plpython3_to_jsonb(internal) ) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 5fed1e42e8653d1d426dc974 | CREATE TRANSFORM FOR foo LANGUAGE plperl (FROM SQL WITH FUNCTION hstore_to_plperl(internal), TO SQL WITH FUNCTION plperl_to_hstore(internal)) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 62a94b124385b557b1d2a8f0 | CREATE TRANSFORM FOR jsonb LANGUAGE plperlu ( FROM SQL WITH FUNCTION jsonb_to_plperlu(internal), TO SQL WITH FUNCTION plperlu_to_jsonb(internal) ) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 6778775f82eaf867d7d78a19 | -- ok CREATE OR REPLACE TRANSFORM FOR hstore LANGUAGE plperl (FROM SQL WITH FUNCTION hstore_to_plperl(internal)) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 740d3008eef4ac5424beee25 | -- fail CREATE TRANSFORM FOR hstore LANGUAGE plperl (FROM SQL WITH FUNCTION hstore_to_plperl(internal), TO SQL WITH FUNCTION plperl_to_hstore(internal)) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 79eeb734c733981303d8b01a | CREATE TRANSFORM FOR bool LANGUAGE plperl ( FROM SQL WITH FUNCTION bool_to_plperl(internal), TO SQL WITH FUNCTION plperl_to_bool(internal) ) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | 8ef58f73b71a47fa78542d3d | CREATE TRANSFORM FOR int LANGUAGE SQL ( FROM SQL WITH FUNCTION prsd_lextype(internal), TO SQL WITH FUNCTION int4recv(internal)) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | a7f9e2fb46b3b26cc94f2ee4 | -- fail CREATE TRANSFORM FOR hstore LANGUAGE plperl (FROM SQL WITH FUNCTION internal_in(cstring), TO SQL WITH FUNCTION plperl_to_hstore(internal)) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TRANSFORM_STMT | e59f670b472d591324148262 | -- fail CREATE OR REPLACE TRANSFORM FOR hstore LANGUAGE plperl (FROM SQL WITH FUNCTION hstore_to_plperl(internal), TO SQL WITH FUNCTION plperl_to_hstore(internal)) |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 0307eccae9adec018e1d24b2 | DROP OWNED BY regress_rls_dob_role1 |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 04447288cda271406e7deefb | DROP OWNED BY regress_alter_function_role |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 0f2bdcd8f09cf73bd1b9321c | DROP OWNED BY regress_heaptest_role |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 14f527efb488f7a46f4ec6d4 | DROP OWNED BY regress_user_mvtest CASCADE |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 16b09963d8bee57c96c22afa | DROP OWNED BY regress_plperl_user1 |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 2767cce3dd3782b3f7485899 | -- still fail, REASSIGN OWNED doesn't help DROP OWNED BY regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 419ab6f8048dd9f9889abdfd | -- ok, nothing was transferred -- Use "drop owned by" so we can drop the role DROP OWNED BY regress_host_resource_admin |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 4a8db335e9488de8bbc81524 | DROP OWNED BY regress_test_role2 CASCADE |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 6e03ca4e9f917f927e5fa0db | DROP OWNED BY regress_testrol0, "Public", "current_role", "current_user", regress_testrol1, regress_testrol2, regress_testrolx CASCADE |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 78f67ceab8390fbd7ef97fda | DROP OWNED BY regress_view_owner_another |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 7cc2c3af2a808e08376ff160 | DROP OWNED BY regress_seg_role |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 865f70c1651bb5ff0e8707ed | -- this one is allowed DROP OWNED BY regress_dep_user0 |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 8bb59a0c42e9788e4df096bd | DROP OWNED BY regress_dump_test_role RESTRICT |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | 9909f46f88231bbef2d07ecb | DROP OWNED BY regress_addr_user |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | a5483abf9bb8f699044d2bda | DROP OWNED BY regress_dep_user2, regress_dep_user0 |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | b5cd4ceaff58138c4a0af0b2 | DROP OWNED BY regress_dep_user0, regress_dep_user2 |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | c109ea8cfbbda4cf86854506 | DROP OWNED BY regress_bttest_role |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | c17699426fbaaf3afedfdd94 | DROP OWNED BY regress_evt_user |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | ce07e9a9d6a9ca85b9e07ab3 | DROP OWNED BY regress_nosuper |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | dbc85f6c7cac983ece963003 | DROP OWNED BY regress_sro_user |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | dc84fd48ab241f4c3a1c55c9 | DROP OWNED BY regress_test_role2 |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | e09a809c1b8a6c642344ec9e | DROP OWNED BY regress_priv_user1 |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | e3e40f1ab1ba818a4087d022 | DROP OWNED BY regress_sepgsql_test_user |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | e764fccf0e45fe1419780c7d | -- permission denied DROP OWNED BY regress_dep_user1 |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | e7737bd60636a60ced7b56ba | -- fail, privileges remain DROP OWNED BY regress_host_resource_admin RESTRICT |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | eab6497e3a5b826df9078bc8 | -- cleanup DROP OWNED BY regress_view_owner |
| ERROR | PG_QUERY__NODE__NODE_DROP_OWNED_STMT | f8ddd3dc2ffb90920444b936 | DROP OWNED BY regress_priv_user2, regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 1ab59e63bd4cde6462bcf518 | DROP TRANSFORM FOR foo LANGUAGE plperl |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 1b2f581f479bf3faef7b4d28 | DROP CAST IF EXISTS (text AS text) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 278ddd66feb40996ffba503e | drop table 計算機用語 |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 30cf6055f9ac9d4430189971 | DROP CAST IF EXISTS (INTEGER AS no_such_schema.bar) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 3236b9d2f456af2c0422d786 | DROP CAST IF EXISTS (no_such_type1 AS INTEGER) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 375fea96bc4d54d717960f81 | DROP TRANSFORM IF EXISTS FOR hstore LANGUAGE plperl |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 4762ec85a350fd990d4f06cb | DROP CAST (int4 AS casttesttype) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 48d18c813ab396b58a5e5352 | DROP TRANSFORM FOR int LANGUAGE SQL |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 7a897b0170b21d1fba5d58b3 | DROP TRANSFORM IF EXISTS FOR fake_type LANGUAGE plperl |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 7beae64781300cf06faae806 | DROP CAST IF EXISTS (INTEGER AS no_such_type2) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 805d0b6283a3489d3b68d1e0 | DROP TRANSFORM FOR hstore LANGUAGE plperl |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 852dd5da2ccf2694ef983773 | DROP CAST IF EXISTS (no_such_schema.foo AS INTEGER) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 8853de2b20ff2ce444fbbd30 | DROP TRANSFORM FOR hstore LANGUAGE foo |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | 96bd6ccca89725270885cf43 | DROP CAST (priv_testdomain1 AS priv_testdomain3b) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | b204bc4c9df55ef6fc74cfc4 | DROP CAST (text AS text) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | c952ec5b570621793bb4cd8f | DROP CAST (mood AS json) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | eefcba6d2aafb6a6a760fefe | DROP CAST (text AS casttesttype) |
| ERROR | PG_QUERY__NODE__NODE_DROP_STMT | f7ead06a3e19dd771acbf19e | DROP TRANSFORM IF EXISTS FOR hstore LANGUAGE fake_lang |
| ERROR | PG_QUERY__NODE__NODE_DROP_SUBSCRIPTION_STMT | 1b487efc733e2383893b2462 | DROP SUBSCRIPTION regress_addr_sub |
| ERROR | PG_QUERY__NODE__NODE_DROP_SUBSCRIPTION_STMT | 2b8c6e393bc19904af95897a | DROP SUBSCRIPTION regress_testsub |
| ERROR | PG_QUERY__NODE__NODE_DROP_SUBSCRIPTION_STMT | 5cfc587681a0b292359518c7 | DROP SUBSCRIPTION dummy_sub |
| ERROR | PG_QUERY__NODE__NODE_DROP_SUBSCRIPTION_STMT | d99fb7591141dcd56764f669 | DROP SUBSCRIPTION regress_testsub4 |
| ERROR | PG_QUERY__NODE__NODE_DROP_SUBSCRIPTION_STMT | f0c064206ad845bf20daab19 | DROP SUBSCRIPTION IF EXISTS regress_testsub |
| ERROR | PG_QUERY__NODE__NODE_DROP_TABLE_SPACE_STMT | 019755b2edf9e7be77095743 | -- drop the tablespace so we can re-use the location DROP TABLESPACE regress_tblspacewith |
| ERROR | PG_QUERY__NODE__NODE_DROP_TABLE_SPACE_STMT | 5e92c937c3e2390c23d3d485 | -- Fail, in use for some partitioned object DROP TABLESPACE regress_tblspace |
| ERROR | PG_QUERY__NODE__NODE_DROP_TABLE_SPACE_STMT | 8953eca847d23d1b05e63eca | DROP TABLESPACE regress_test_stats_tblspc |
| ERROR | PG_QUERY__NODE__NODE_DROP_TABLE_SPACE_STMT | a7f180b9df80307f24befd6c | -- Should succeed DROP TABLESPACE regress_tblspace_renamed |
| ERROR | PG_QUERY__NODE__NODE_DROP_TABLE_SPACE_STMT | c5660cb804e6788a8f7a6ae0 | DROP TABLESPACE regress_create_idx_tblspace |
| ERROR | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 35063cd3ceb296f14fd4f885 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF) CREATE TABLE ctas_ine_tbl AS EXECUTE ctas_ine_query |
| ERROR | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 672103ee48c450acf9c502cd | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF) CREATE TABLE IF NOT EXISTS ctas_ine_tbl AS EXECUTE ctas_ine_query |
| ERROR | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7e1fdba29b1d8bad4d5b4ace | explain (costs off) create table parallel_write as execute prep_stmt |
| ERROR | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 88426cde677fdf2db899fe39 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE TABLE selinto_schema.tbl_withdata4 (a) AS EXECUTE data_sel WITH DATA |
| ERROR | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 93f278c08e373e77b5b6ec22 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE TABLE selinto_schema.tbl_nodata4 (a) AS EXECUTE data_sel WITH NO DATA |
| ERROR | PG_QUERY__NODE__NODE_GRANT_STMT | 1493d1ec817b42b5f5085e64 | -- if we revoke the privileges we can drop the group REVOKE SELECT ON deptest FROM GROUP regress_dep_group |
| ERROR | PG_QUERY__NODE__NODE_GRANT_STMT | 1ce6a6886b07bf48aea72ad1 | GRANT SELECT ON atest4 TO GROUP regress_priv_group1 WITH GRANT OPTION |
| ERROR | PG_QUERY__NODE__NODE_GRANT_STMT | 404e1692abac21ef7902c0d7 | GRANT SELECT ON TABLE deptest TO GROUP regress_dep_group |
| ERROR | PG_QUERY__NODE__NODE_GRANT_STMT | e14965f3b086b4843a21cd80 | GRANT DELETE ON atest3 TO GROUP regress_priv_group2 |
| ERROR | PG_QUERY__NODE__NODE_INDEX_STMT | ae845886aca7b8f1176c7801 | create index 計算機用語index2 on 計算機用語 using hash (分類コード) |
| ERROR | PG_QUERY__NODE__NODE_INDEX_STMT | b7c15dc007ada6fa77dd4d6e | create index 計算機用語index1 on 計算機用語 using btree (用語) |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 00c7d8ee48aacf49c76595ca | ALTER TABLESPACE regress_tblspace RENAME TO regress_tblspace_renamed |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 043de1fdd68ded7201e68ad0 | alter trigger parenttrig on parent rename to anothertrig |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 0651db681ffb0bce9d58f7aa | -- failed (name conflict) ALTER TEXT SEARCH PARSER alt_ts_prs1 RENAME TO alt_ts_prs3 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 19eb46d5ac860c54c67ce51b | ALTER PUBLICATION testpub_default RENAME TO testpub_foo |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 1afb05cbebd7490dfadc7eec | -- failed (not owner) ALTER TEXT SEARCH CONFIGURATION alt_ts_conf1 RENAME TO alt_ts_conf4 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 1d9bc0c6a92cfdfb680165f8 | ALTER TRIGGER t1 ON pg_description RENAME TO t2 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 1fe1eac51d7c6a0a52628412 | ALTER TEXT SEARCH CONFIGURATION alt_ts_conf3 RENAME TO alt_ts_conf4 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 22d44278d244a7138c397638 | ALTER TEXT SEARCH DICTIONARY alt_ts_dict1 RENAME TO alt_ts_dict2 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 25215f2b8fed42101796b7d1 | ALTER RULE r1 ON pg_description RENAME TO r2 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 27a9c1b3741e6c8a34b3f628 | ALTER TEXT SEARCH CONFIGURATION alt_ts_conf1 RENAME TO alt_ts_conf2 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 2b0c0091193c27385bdb0f36 | -- but we can rename the subscription we just created ALTER SUBSCRIPTION regress_testsub RENAME TO regress_testsub2 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 3514ac1b2d4a9fad63cfc32d | ALTER RULE InsertRule ON rule_v1 RENAME to NewInsertRule |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 3760b2b52ad1d170aa8e4395 | ALTER TEXT SEARCH PARSER alt_ts_prs1 RENAME TO alt_ts_prs2 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 3ae2bb20b47fc37b66d64dae | -- failed (name conflict) ALTER TEXT SEARCH DICTIONARY alt_ts_dict1 RENAME TO alt_ts_dict3 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 50830440c8c28885300bf215 | ALTER LANGUAGE alt_lang1 RENAME TO alt_lang2 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 5af6ae5ab9a2e1a38a7fb48d | -- failed (name conflict) ALTER LANGUAGE alt_lang2 RENAME TO alt_lang3 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 61d1623aca8818dc62d370e8 | ALTER RULE rules_parted_table_insert ON rules_parted_table RENAME TO rules_parted_table_insert_redirect |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 67acb1c1fad55fd44bb957f3 | alter trigger a on grandparent rename to b |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 6fa0fa03b682aabd81c75532 | -- already exists ALTER RULE "_RETURN" ON rule_v1 RENAME TO abc |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 7a01cf59f089206aa142fb5f | ALTER SUBSCRIPTION regress_testsub RENAME TO regress_testsub_dummy |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 7d690c1ac2fbc1683a0e2455 | -- doesn't exist ALTER RULE NewInsertRule ON rule_v1 RENAME TO "_RETURN" |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 816f2f86f18fb8226fd6a6e3 | -- failed (name conflict) ALTER TEXT SEARCH CONFIGURATION alt_ts_conf1 RENAME TO alt_ts_conf3 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 8c93f6b53470ecd6dea2c771 | ALTER SUBSCRIPTION regress_testsub2 RENAME TO regress_testsub |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 8eafbc49d3804d4381d42bde | -- ONLY not supported alter trigger b on middle rename to c |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 95f4d639a15d03fbdf017358 | ALTER SUBSCRIPTION regress_testsub RENAME TO regress_testsub_foo |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | 9664a2dc6ffe09b2a841123c | ALTER PUBLICATION testpub_default RENAME TO testpub_dummy |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | a43b033cfdfeeff2737a09e4 | -- Test RENAME TRIGGER ALTER TRIGGER modified_a ON main_table RENAME TO modified_modified_a |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | ac81ff9cae06f143c819d6dd | -- failed (not owner) ALTER LANGUAGE alt_lang1 RENAME TO alt_lang3 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | ae00de0a2a62929987fe4f8d | -- should fail, name collision alter event trigger regress_event_trigger rename to regress_event_trigger2 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | b234c3e9f22edd86485982bf | -- OK alter event trigger regress_event_trigger rename to regress_event_trigger3 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | cab32c3ebcb3c3500bb4974e | ALTER TEXT SEARCH DICTIONARY alt_ts_dict3 RENAME TO alt_ts_dict4 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | d4be7caec570c3524caa9da5 | -- failed (not owner) ALTER TEXT SEARCH DICTIONARY alt_ts_dict1 RENAME TO alt_ts_dict4 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | d542079b61793bca1fcf7e7f | ALTER TEXT SEARCH TEMPLATE alt_ts_temp1 RENAME TO alt_ts_temp2 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | e54342cf0e70bc4ba36c5c20 | -- failed (name conflict) ALTER TEXT SEARCH TEMPLATE alt_ts_temp1 RENAME TO alt_ts_temp3 |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | f49041582279ec2adf1eca04 | alter trigger p on grandparent rename to q |
| ERROR | PG_QUERY__NODE__NODE_RENAME_STMT | f7ae72dcceed63ea365cf99c | alter trigger b on grandparent rename to c |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 0478311755f975b6235b519f | CREATE RULE rule1 AS ON INSERT TO ruletest1 DO INSTEAD INSERT INTO ruletest2 VALUES (NEW.*) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 096d3e7278ea89b1e455d370 | create rule qqq as on delete to copydml_test do instead nothing |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 0acb28d90e769629eea7dcce | create rule rrule as on update to vview do instead ( insert into cchild (pid, descrip) select old.pid, new.descrip where old.descrip isnull; update cchild set descrip = new.descrip where cchild.pid... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 0bffae2e456bebd8184a92fa | create rule qqq as on update to copydml_test do instead (delete from copydml_test; delete from copydml_test) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 0d3ee88a22f3bfffada5b77c | create rule rtest_order_r3 as on insert to rtest_order1 do instead insert into rtest_order2 values (new.a, nextval('rtest_seq'), 'rule 3 - this should run 3rd') |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 0d59590df257d1282efdfc2d | CREATE RULE rw_view1_ins_rule AS ON INSERT TO rw_view1 DO INSTEAD INSERT INTO base_tbl VALUES (NEW.a) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 0d7ac22f163b147dbc4d1dfa | create rule t1_upd_1 as on update to t1 where old.a >= 0 and old.a < 10 do instead update t1_1 set a = new.a where a = old.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 0debbb12399f1c9adfdfc0ae | CREATE OR REPLACE RULE voo_d AS ON DELETE TO voo DO INSTEAD DELETE FROM foo WHERE f1 = old.f1 RETURNING f1, f2 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 0f347e6644c155fb205311a8 | CREATE RULE european_city_update_rule AS ON UPDATE TO european_city_view DO INSTEAD UPDATE city_view SET city_name = NEW.city_name, population = NEW.population, country_name = NEW.country_name WHER... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 0f57415a88628e25db89241e | create rule qqq as on insert to copydml_test do instead (delete from copydml_test; delete from copydml_test) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 119533c599cf290e5157fa4b | CREATE RULE r2 AS ON UPDATE TO x DO INSTEAD WITH t AS (SELECT OLD.*) UPDATE y SET a = t.n FROM t |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 13606ba80e03398750ed811a | create rule qqq as on insert to copydml_test do instead nothing |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 141a972411e82da901436de3 | create rule rtest_v1_ins as on insert to rtest_v1 do instead insert into rtest_t1 values (new.a, new.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 15160cc790e8e08fdae73c38 | -- DO NOTHING without ON CONFLICT CREATE RULE hat_nosert_all AS ON INSERT TO hats DO INSTEAD INSERT INTO hat_data VALUES ( NEW.hat_name, NEW.hat_color) ON CONFLICT DO NOTHING RETURNING * |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 1a0dbb258c916d77dc7f579c | create rule shipped_view_insert as on insert to shipped_view do instead insert into shipped values('wt', new.ordnum, new.partnum, new.value) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 1c861c502731fa612f8290e5 | create rule updlog as on update to tt15v do also insert into tt15v_log values(old, new, row(old,old) < row(new,new)) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 1fa2e33381043290fbae550c | CREATE RULE shoelace_ins AS ON INSERT TO shoelace DO INSTEAD INSERT INTO shoelace_data VALUES ( NEW.sl_name, NEW.sl_avail, NEW.sl_color, NEW.sl_len, NEW.sl_unit) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 20cce5bbde287b82c8a292b6 | CREATE RULE rw_view1_ins_rule AS ON INSERT TO rw_view1 DO INSTEAD INSERT INTO base_tbl VALUES (NEW.a, NEW.b) RETURNING * |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 229a79a10a9ede78f05e85b9 | create or replace rule r1 as on update to rules_base do instead select * from rules_base where f1 = 11 for update of rules_base |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 277be6ec70b71c4c3a0bfd64 | create rule shipped_view_update as on update to shipped_view do instead update shipped set partnum = new.partnum, value = new.value where ttype = new.ttype and ordnum = new.ordnum |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 281a052f6ccfc85d4537197d | create rule r6 as on update to rules_src do instead UPDATE rules_log AS trgt SET tag = 'updated' WHERE trgt.f1 = new.f1 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 28fed6388ae663a6a4c9f9fb | create rule r1 as on delete to t1 do delete from t2 where t2.b = old.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 2a0ddd9e30fa97046262c498 | create rule rtest_t5_ins as on insert to rtest_t5 where new.a > 15 do insert into rtest_t7 values (new.a, new.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 2dbbafb4c1952eb401b76262 | CREATE RULE joinview_u AS ON UPDATE TO joinview DO INSTEAD UPDATE foo SET f1 = new.f1, f3 = new.f3 FROM joinme WHERE f2 = f2j AND f2 = old.f2 RETURNING foo.*, other |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 2e39c17b4605411aa5879811 | create rule r3 as on insert to rules_src do also insert into rules_log values(null, null, '-', default), (new.*, 'new', default) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 353f94e901e154c6fd4fa0f1 | CREATE RULE r1 AS ON INSERT TO pg_description DO INSTEAD NOTHING |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 3918dd6dedd5021512c33776 | create rule rtest_nothn_r1 as on insert to rtest_nothn1 where new.a >= 10 and new.a < 20 do instead nothing |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 397ba0e42f57a397302a0b7e | create rule insert_tt_rule as on insert to tt do also insert into tt_log values(new.*) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 3999cd962c9bd3bd04d326db | -- this should fail because f1 is not exposed for unqualified reference: create rule rules_foorule as on insert to rules_foo where f1 < 100 do instead insert into rules_foo2 values (f1) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 3b8bbd36644fc37a95dbf56c | CREATE RULE regtest_test_rule AS ON INSERT TO regtest_table_3 DO ALSO NOTHING |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 3cfaf27f02a0c60d4dbd7f1b | CREATE RULE rule1 AS ON INSERT TO rule_merge1 DO INSTEAD INSERT INTO rule_merge2 VALUES (NEW.*) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 3f3ab3eb948f395342ae2bc7 | -- fails, incompatible list: CREATE OR REPLACE RULE voo_i AS ON INSERT TO voo DO INSTEAD INSERT INTO foo VALUES(new.*, 57) RETURNING * |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 3f892aa4bec8f5146ad6cd5e | create rule rtest_emp_upd as on update to rtest_emp where new.salary != old.salary do insert into rtest_emplog values (new.ename, current_user, 'honored', new.salary, old.salary) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 42603419708a81d4b1c42ee1 | create rule rr as on update to rule_t1 do instead UPDATE rule_dest trgt SET (f2[1], f1, tag) = (SELECT new.f2, new.f1, 'updated'::varchar) WHERE trgt.f1 = new.f1 RETURNING new.* |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 46b0b13bb507adc506d6bb1e | CREATE RULE base_tbl_ins_rule AS ON INSERT TO base_tbl WHERE EXISTS (SELECT 1 FROM base_tbl t WHERE t.id = new.id) DO INSTEAD UPDATE base_tbl SET data = new.data, deleted = false WHERE id = new.id |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 494fcc53382a209ca0206acd | -- DELETE turned into UPDATE by a rule has OLD and NEW CREATE RULE foo_del_rule AS ON DELETE TO foo DO INSTEAD UPDATE foo SET f2 = f2\|\|' (deleted)', f3 = -1, f4 = -1 WHERE f1 = OLD.f1 RETURNING * |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 4a67baa2d80786e84b5c0982 | create rule qqq as on insert to copydml_test do also delete from copydml_test |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 4bfae52c7f5421d32981f649 | -- unconditional DO INSTEAD rule CREATE RULE y_rule AS ON DELETE TO y DO INSTEAD INSERT INTO y VALUES(42) RETURNING * |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 50113dfd73f9f642f8754186 | create rule irule1 as on insert to inserttest2 do also insert into inserttestb (f3.if2[1], f3.if2[2]) values (new.f1,new.f2) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 501768036d36510593232bea | -- most variants of rules aren't allowed CREATE RULE y_rule AS ON INSERT TO y WHERE a=0 DO INSTEAD DELETE FROM y |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 52d8cc82f520ce52bd04cbf1 | CREATE RULE rule2 AS ON UPDATE TO ruletest_t1 DO INSTEAD INSERT INTO ruletest_t2 VALUES (OLD.*) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 543e6164c3ecd422fd9b1b98 | CREATE RULE base_tbl_del_rule AS ON DELETE TO base_tbl DO INSTEAD UPDATE base_tbl SET deleted = true WHERE id = old.id |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 567a9180a6578ab122565281 | CREATE RULE bug6051_3_ins AS ON INSERT TO bug6051_3 DO INSTEAD SELECT i FROM bug6051_2 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 56c061371e1bc89e79af8ef1 | create rule rtest_pers_upd as on update to rtest_person do also update rtest_admin set pname = new.pname where pname = old.pname |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 56e3cdc7d6d869b757d37448 | create rule rtest_order_r4 as on insert to rtest_order1 where a < 100 do instead insert into rtest_order2 values (new.a, nextval('rtest_seq'), 'rule 4 - this should run 4th') |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 5a4c883170c8a4478ebae4ab | create rule r2 as on update to rules_src do also values(old.*, 'old'), (new.*, 'new') |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 5ad867da5547b60ba81697ef | create rule rtest_pers_del as on delete to rtest_person do also delete from rtest_admin where pname = old.pname |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 5bfc18b5827241ad3f01688e | -- DO NOTHING with ON CONFLICT CREATE RULE hat_nosert AS ON INSERT TO hats DO INSTEAD INSERT INTO hat_data VALUES ( NEW.hat_name, NEW.hat_color) ON CONFLICT (hat_name COLLATE "C" bpchar_pattern_ops... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 5cc14e8591e0ce10fbd2461f | create rule base_tab_def_view_ins_rule as on insert to base_tab_def_view do instead insert into base_tab_def values (new.a, new.b, new.c, new.d, new.e) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 5e2f05992ba98993606ac142 | create rule irule2 as on insert to inserttest2 do also insert into inserttestb (f4[1].if1, f4[1].if2[2]) values (1,'fool'),(new.f1,new.f2) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 5f5c5824af52afa5dec40b9d | create rule silly as on delete to dcomptable do instead update dcomptable set d1.r = (d1).r - 1, d1.i = (d1).i + 1 where (d1).i > 0 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 5ff2698baf515528673f5a53 | create rule base_tab_def_view_ins_rule as on insert to base_tab_def_view do also insert into base_tab_def values (new.a, new.b, new.c, new.d, new.e) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 6372a09e6f8192c3afb409a4 | CREATE RULE rule1 AS ON INSERT TO ruletest_v1 DO INSTEAD INSERT INTO ruletest_t2 VALUES (NEW.*) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 64fad9cb504e47f1bd396cb4 | create rule r1 as on update to rules_base do instead select * from rules_base where f1 = 1 for update |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 65b066b516a9ede2a52358fa | create rule rtest_order_r1 as on insert to rtest_order1 do instead insert into rtest_order2 values (new.a, nextval('rtest_seq'), 'rule 1 - this should run 1st') |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 65dbeb0ff154b3136d20f333 | create rule qqq as on delete to copydml_test where old.t <> 'f' do instead insert into copydml_test default values |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 684d1eccbad2965ceb6fe4de | -- Want "log_who" to be CURRENT_USER, -- but that is non-portable for the regression test -- - thomas 1999-02-21 CREATE RULE log_shoelace AS ON UPDATE TO shoelace_data WHERE NEW.sl_avail != OLD.sl_... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 6a5e33e63d6a53aafef09b95 | CREATE OR REPLACE RULE myrule AS ON INSERT TO ruletest_tbl DO INSTEAD INSERT INTO ruletest_tbl2 VALUES (10, 10) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 6a61c0d87dd6e42f3a9d2025 | create rule rtest_v1_del as on delete to rtest_v1 do instead delete from rtest_t1 where a = old.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 6a724ae3c6f87ff94f91f978 | -- check INSERT ... SELECT rule actions are disallowed on commands -- that have modifyingCTEs CREATE OR REPLACE RULE bug6051_ins AS ON INSERT TO bug6051 DO INSTEAD INSERT INTO bug6051_2 SELECT NEW.i |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 6ac942f7bc4b92e02d6a8f31 | CREATE RULE rw_view1_upd_rule AS ON UPDATE TO rw_view1 DO INSTEAD UPDATE base_tbl SET a=NEW.a WHERE a=OLD.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 6ce5aa11f51b0b38ab2124bc | CREATE RULE test_oat_notify AS ON UPDATE TO test_oat_schema.test_oat_tab DO ALSO NOTIFY test_oat_tab |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 6cf59eda2ee67a8d344fc4de | -- -- Ensure an aliased target relation for insert is correctly deparsed. -- create rule r5 as on insert to rules_src do instead insert into rules_log AS trgt SELECT NEW.* RETURNING trgt.f1, trgt.f2 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 735fc5f49a0f99d9cbcff478 | create rule rtest_nothn_r3 as on insert to rtest_nothn2 where new.a >= 100 do instead insert into rtest_nothn3 values (new.a, new.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 74228f1e713954f592ce4736 | -- A view with a conditional INSTEAD rule but no unconditional INSTEAD rules -- or INSTEAD OF triggers should be non-updatable and generate useful error -- messages with appropriate detail CREATE R... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 7489ef0e931730fcc92ea3ee | CREATE RULE r1 AS ON INSERT TO TBL1 DO (INSERT INTO TBL2 VALUES (new.i); NOTIFY TBL2) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 74c9fc480ce6834108c5228a | -- -- Check deparse disambiguation of INSERT/UPDATE/DELETE targets. -- create rule r7 as on delete to rules_src do instead with wins as (insert into int4_tbl as trgt values (0) returning *), wupd a... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 763ea7f2028685e2dfcdda65 | CREATE RULE shoelace_ok_ins AS ON INSERT TO shoelace_ok DO INSTEAD UPDATE shoelace SET sl_avail = sl_avail + NEW.ok_quant WHERE sl_name = NEW.ok_name |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 77e4e4e0d0e71b9c257ea9bc | CREATE RULE test_rule_exists AS ON INSERT TO test_exists DO INSTEAD INSERT INTO test_exists VALUES (NEW.a, NEW.b \|\| NEW.a::text) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 7a29fd0f37ff403b335101ec | create rule silly as on delete to dcomptable do instead update dcomptable set d1[1].r = d1[1].r - 1, d1[1].i = d1[1].i + 1 where d1[1].i > 0 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 7b791bb4a7df838b37f7518d | create rule rtest_t6_ins as on insert to rtest_t6 where new.a > 25 do instead insert into rtest_t8 values (new.a, new.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 7f4af5c4ed5aabde8806dc03 | CREATE RULE shoelace_upd AS ON UPDATE TO shoelace DO INSTEAD UPDATE shoelace_data SET sl_name = NEW.sl_name, sl_avail = NEW.sl_avail, sl_color = NEW.sl_color, sl_len = NEW.sl_len, sl_unit = NEW.sl_... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 805ff7aceb1bb211cbea139c | create rule rtest_t4_ins1 as on insert to rtest_t4 where new.a >= 10 and new.a < 20 do instead insert into rtest_t5 values (new.a, new.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 8269fc811d807aa70f92b816 | create rule v1_upd_rule as on update to v1 do also insert into log values (new.*) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 87d9c5707cbef3a560160190 | create rule irule2 as on insert to inserttest2 do also insert into inserttest (f4[1].if1, f4[1].if2[2]) values (1,'fool'),(new.f1,new.f2) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 8b161341f820a57d21f0aa94 | CREATE RULE rule_3 AS ON DELETE TO datatype_table DO ALSO NOTHING |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 8c08d691e7a72d363f35ee82 | CREATE RULE sj_del_rule AS ON DELETE TO sj DO INSTEAD UPDATE sj SET a = 1 WHERE a = old.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 9173ce8131567820f7d81c68 | CREATE RULE rule3 AS ON DELETE TO rule_merge1 DO INSTEAD DELETE FROM rule_merge2 WHERE a = OLD.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 919c48d181d8f3a6257e5bd9 | create rule t1_ins_1 as on insert to t1 where new.a >= 0 and new.a < 10 do instead insert into t1_1 values (new.a) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 946cb39d4a73a3768d394f42 | create rule qqq as on insert to copydml_test where new.t <> 'f' do instead delete from copydml_test |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 9618d3a1d27560fb8fe9d607 | CREATE RULE ucrule AS ON DELETE TO ucview DO INSTEAD DELETE FROM uctest WHERE f1 = OLD.f1 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 9a0eab0c562c4c8953f938e2 | create rule qqq as on update to copydml_test do instead nothing |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 9e9af2575d4f7a0187bfbf8b | CREATE OR REPLACE RULE y_rule AS ON INSERT TO y DO INSTEAD (NOTIFY foo; NOTIFY bar) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 9f4d78f68e47e66c6746d26e | CREATE RULE r2 AS ON INSERT TO pg_description DO INSTEAD NOTHING |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 9fe4d40827e2849771f37f80 | CREATE RULE rules_stats AS ON INSERT TO tab_rule_stats DO INSTEAD INSERT INTO tab_rule_stats_2 VALUES(new.*, 1, 2) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 9ff8255bc28be323a084200d | CREATE RULE gtest_rule_ins AS ON INSERT TO gtest_rule DO ALSO INSERT INTO gtest_rule_log VALUES ('INS', NULL, NEW.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | a06a4b32c4a4f8f0df1a03d4 | create rule irule3 as on insert to inserttest2 do also insert into inserttest (f4[1].if1, f4[1].if2[2]) select new.f1, new.f2 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | a08a9325b1724161a58a0ce9 | create rule r4 as on delete to rules_src do notify rules_src_deletion |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | a1be2ecf4458e3c3b21d4fa2 | CREATE OR REPLACE RULE voo_u AS ON UPDATE TO voo DO INSTEAD UPDATE foo SET f1 = new.f1, f2 = new.f2 WHERE f1 = old.f1 RETURNING f1, f2 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | a305b3ce822f47be7910eaca | create rule rtest_emp_ins as on insert to rtest_emp do insert into rtest_emplog values (new.ename, current_user, 'hired', new.salary, '0.00') |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | a503aa81a2ae03ed190f0c73 | create rule rule_and_refint_t3_ins as on insert to rule_and_refint_t3 where (exists (select 1 from rule_and_refint_t3 where (((rule_and_refint_t3.id3a = new.id3a) and (rule_and_refint_t3.id3b = new... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | a6c6774f3c2add581ea6bd82 | CREATE RULE bug6051_ins AS ON INSERT TO bug6051 DO INSTEAD INSERT INTO bug6051_2 VALUES(NEW.i) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | aa3059041f54c46e78bf5800 | CREATE OR REPLACE RULE myrule AS ON INSERT TO ruletest_tbl DO INSTEAD INSERT INTO ruletest_tbl2 VALUES (1000, 1000) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | abca85ef4e33c815322e4bf4 | CREATE RULE rule_3 AS ON DELETE TO like_datatype_table WHERE id < 100 DO ALSO NOTHING |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | af6d454d74e341949b909a53 | create rule rtest_order_r2 as on insert to rtest_order1 do insert into rtest_order2 values (new.a, nextval('rtest_seq'), 'rule 2 - this should run 2nd') |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | b14b488469d7f922932f0064 | create rule rtest_sys_del as on delete to rtest_system do also ( delete from rtest_interface where sysname = old.sysname; delete from rtest_admin where sysname = old.sysname; ) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | b3ee9fcb758090ea3f04da2d | create rule irule3 as on insert to inserttest2 do also insert into inserttestb (f4[1].if1, f4[1].if2[2]) select new.f1, new.f2 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | b47a79d1aefba8288162bf37 | create rule rules_foorule as on insert to rules_foo where f1 < 100 do instead nothing |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | b6af72fd4f484eb1d81baea8 | create rule def_view_test_ins as on insert to def_view_test do instead insert into def_test select new.* |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | b7c1bbc1ef7b9936d4bbd4ec | CREATE RULE pg_settings_n AS ON UPDATE TO pg_settings DO INSTEAD NOTHING |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | b8053070cabe325aa55d87de | CREATE RULE rw_view16_del_rule AS ON DELETE TO rw_view16 WHERE OLD.a > 0 DO INSTEAD DELETE FROM base_tbl WHERE a=OLD.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | b87d616cca2e0d6f61d55571 | create rule rtest_sys_upd as on update to rtest_system do also ( update rtest_interface set sysname = new.sysname where sysname = old.sysname; update rtest_admin set sysname = new.sysname where sys... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | bb02e161ccb7efaece969232 | create rule irule1 as on insert to inserttest2 do also insert into inserttest (f3.if2[1], f3.if2[2]) values (new.f1,new.f2) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | bc43b25d4addcb75ad51e35e | CREATE RULE rw_view1_upd_rule AS ON UPDATE TO rw_view1 DO INSTEAD UPDATE base_tbl SET b=NEW.b WHERE a=OLD.a RETURNING * |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | befc774b6e9ab167e5e29191 | CREATE RULE pg_settings_u AS ON UPDATE TO pg_settings WHERE new.name = old.name DO SELECT set_config(old.name, new.setting, 'f') |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | bfb458da8a6e223c5668a9d7 | CREATE RULE base_tbl_log AS ON INSERT TO rw_view1 DO ALSO INSERT INTO base_tbl_hist(a,b) VALUES(new.a, new.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | bfc2593c338a67ace9fb428d | create rule qqq as on delete to copydml_test do instead (insert into copydml_test default values; insert into copydml_test default values) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c006a6e5d1f0ef133542ee6d | CREATE RULE InsertRule AS ON INSERT TO rule_v1 DO INSTEAD INSERT INTO rule_t1 VALUES(new.a) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c0e6f09a513d60d68dd2aea3 | create rule rtest_v1_upd as on update to rtest_v1 do instead update rtest_t1 set a = new.a, b = new.b where a = old.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c11aea7f5ecc4cd5b18991a2 | CREATE OR REPLACE RULE y_rule AS ON INSERT TO y DO INSTEAD NOTHING |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c281a2becc7be3b7be9a922e | CREATE RULE id_alw3_ins AS ON INSERT TO id_alw3 DO INSTEAD WITH t1 AS (INSERT INTO id_alw1 DEFAULT VALUES RETURNING i) INSERT INTO id_alw2_view DEFAULT VALUES RETURNING i |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c448f73dfc4d951c589cc8f6 | CREATE RULE european_city_delete_rule AS ON DELETE TO european_city_view DO INSTEAD DELETE FROM city_view WHERE city_id = OLD.city_id RETURNING * |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c4c0669dd66e75e2ae1f9d00 | create rule rtest_nothn_r2 as on insert to rtest_nothn1 where new.a >= 30 and new.a < 40 do instead nothing |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c621fbf1186a3626c77642ad | create rule "_RETURN" as on select to rules_fooview do instead select 1 as x, 'aaa'::text as y |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c839e066ea3ad9598fd7cd98 | create rule qqq as on insert to copydml_test do instead notify copydml_test |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c878254550fcda3fdc4daeb8 | CREATE RULE rules_parted_table_insert AS ON INSERT to rules_parted_table DO INSTEAD INSERT INTO rules_parted_table_1 VALUES (NEW.*) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | cb25e95b77b636eba42b8299 | -- this is the correct way: create rule rules_foorule as on insert to rules_foo where f1 < 100 do instead insert into rules_foo2 values (new.f1) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | cd1780a0ba637f7cce45f674 | CREATE OR REPLACE RULE y_rule AS ON INSERT TO y DO INSTEAD NOTIFY foo |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | cd1fde4ed87eed63fb5e62ef | -- DO UPDATE with a WHERE clause CREATE RULE hat_upsert AS ON INSERT TO hats DO INSTEAD INSERT INTO hat_data VALUES ( NEW.hat_name, NEW.hat_color) ON CONFLICT (hat_name) DO UPDATE SET hat_name = ha... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | cdeffb294873360392dfb5b2 | CREATE OR REPLACE RULE voo_i AS ON INSERT TO voo DO INSTEAD INSERT INTO foo VALUES(new.*, 57) RETURNING f1, f2 |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | cfc1eb2b37ad063deeec1eac | create rule qqq as on update to copydml_test do also delete from copydml_test |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | d127ee774392c6cda6555167 | CREATE RULE rule_1 AS ON INSERT TO datatype_table DO NOTHING |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | d2109490d877def8e561e796 | CREATE RULE v1_upd AS ON UPDATE TO rule_v1 DO ALSO UPDATE rule_t1 t SET c = tt.a * 10 FROM (SELECT a FROM rule_t1 WHERE a = OLD.a) tt WHERE t.a = tt.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | d343b1e94f526b9b109d98a5 | create rule rtest_emp_del as on delete to rtest_emp do insert into rtest_emplog values (old.ename, current_user, 'fired', '0.00', old.salary) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | d61d6973525998f1c29947db | create rule t1_ins_2 as on insert to t1 where new.a >= 10 and new.a < 20 do instead insert into t1_2 values (new.a) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | d6221464099c137576956416 | create rule r1 as on update to rules_src do also insert into rules_log values(old.*, 'old', default), (new.*, 'new', default) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | d81df74288f78640439cc74d | CREATE RULE rw_view1_ins_rule AS ON INSERT TO rw_view1 DO INSTEAD INSERT INTO base_tbl VALUES (NEW.a, 10) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | d96118f83a4ee18e2efc4641 | create rule rtest_t4_ins2 as on insert to rtest_t4 where new.a >= 20 and new.a < 30 do insert into rtest_t6 values (new.a, new.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | dc90926c207c1cb27e6e8fd3 | create rule base_tab_def_view_ins_rule as on insert to base_tab_def_view do also insert into base_tab_def (a, b, e) select new.a, new.b, 'xxx' |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | de6d7039381af38890754425 | CREATE RULE rule_2 AS ON UPDATE TO datatype_table DO INSERT INTO unlogged_table (id) VALUES(NEW.id) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | e1f2e2863f6e8f31fab6b94d | CREATE RULE rw_view1_del_rule AS ON DELETE TO rw_view1 DO INSTEAD DELETE FROM base_tbl WHERE a=OLD.a RETURNING OLD.* |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | e6d08150a978ce036cc7b29f | CREATE RULE rw_view1_upd_rule AS ON UPDATE TO rw_view1 DO INSTEAD UPDATE base_tbl SET b=NEW.b WHERE a=OLD.a RETURNING NEW.* |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | e93561421bc3e421e616d8bd | CREATE RULE v1_upd_rule AS ON UPDATE TO v1 DO INSTEAD UPDATE t1 SET a = NEW.a WHERE a = OLD.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | eb74ff3274cfabf24e97d9ee | CREATE RULE v1_ins AS ON INSERT TO rule_v1 DO ALSO INSERT INTO rule_t1 SELECT * FROM (SELECT a + 10 FROM rule_t1 WHERE a = NEW.a) tt |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | ed6c0d40e86d62324394b208 | create or replace rule r1 as on update to rules_base do instead select * from rules_base where f1 = 11 for update of old |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | eea8e5c5b5985ead6883847a | create rule qqq as on delete to copydml_test do also insert into copydml_test default values |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | ef73f520a22448ae828e6a38 | create rule qqq as on update to copydml_test where new.t <> 'f' do instead delete from copydml_test |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | f1aa3d1fbaca64416b33f144 | -- rule quals referring to generated columns: -- NEW.b in the rule qual should reflect the generated column's new value CREATE RULE gtest_rule_qual AS ON UPDATE TO gtest_rule WHERE NEW.b > 100 DO I... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | f3986d5189f9ff5a63864803 | create rule rtest_nothn_r4 as on insert to rtest_nothn2 do instead nothing |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | f5cd66113af6973f0b8b3038 | create rule "_RETURN" as on select to rules_fooview_part do instead select 1 as x, 'aaa'::text as y |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | f7e05c90c0cfd8fee0c847f7 | create rule update_id_ordered as on update to id_ordered do instead update id set name = new.name where id = old.id |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | f8e2d2293a161473eae51cd8 | create rule t1_upd_2 as on update to t1 where old.a >= 10 and old.a < 20 do instead update t1_2 set a = new.a where a = old.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | f9ef1d6ab2647f62955cbab1 | CREATE RULE shoelace_del AS ON DELETE TO shoelace DO INSTEAD DELETE FROM shoelace_data WHERE sl_name = OLD.sl_name |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | fa62f44cb08c637d2abbe1d1 | CREATE RULE rule2 AS ON UPDATE TO rule_merge1 DO INSTEAD UPDATE rule_merge2 SET a = NEW.a, b = NEW.b WHERE a = OLD.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | fb616ccb356ba622b8c66f74 | CREATE RULE gtest_rule_upd AS ON UPDATE TO gtest_rule DO ALSO INSERT INTO gtest_rule_log VALUES ('UPD', OLD.b, NEW.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | fc1dcedee824c67b86c4b7bd | CREATE RULE rw_view16_upd_rule AS ON UPDATE TO rw_view16 WHERE OLD.a > 0 DO INSTEAD UPDATE base_tbl SET b=NEW.b WHERE a=OLD.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | fd5df97d48b3b82d655044ea | CREATE OR REPLACE RULE y_rule AS ON INSERT TO y DO ALSO NOTIFY foo |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | febf6df2ed12a5bcf4af3db6 | CREATE RULE voo_i AS ON INSERT TO voo DO INSTEAD INSERT INTO foo VALUES(new.*, 57) |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | 1da0bfb394fec2e2e5770e3e | -- error, cannot use both PARALLEL and FULL VACUUM (PARALLEL) pvactst |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | 2db1be1a87b20a369c00f95d | -- Ensure only the parent is vacuumed VACUUM ONLY only_inh_parent |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | 76951a3bc86863d0e59649f1 | -- Try ANALYZE ONLY with a column list ANALYZE ONLY vacparted(a,b) |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | 98e35171ec0c7f5ca3952c20 | -- Ensure only parent is analyzed ANALYZE ONLY only_inh_parent |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | b80cd6f58cdc7b0899fd60db | -- Ensure only the partitioned table is analyzed ANALYZE ONLY only_parted |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | d000619583de4f04de5994cc | vacuum 計算機用語 |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | d6c97c0eaa46e6ac032287fc | ANALYZE (nonexistentarg) does_not_exit |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | f23eac5f2baa7393de3c7e95 | -- VACUUM ONLY on a partitioned table does nothing, ensure we get a warning. VACUUM ONLY vacparted |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 0160e03ddcd04c17585bb65d | SET LOCAL SESSION AUTHORIZATION DEFAULT |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 1ecabc22845de67696abbcf1 | -- SET SESSION AUTHORIZATION SET SESSION SESSION AUTHORIZATION DEFAULT |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 278202514ab9c9f1d0e03ba6 | SET LOCAL work_mem FROM CURRENT |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 5f2c699c2e5356a309c452f9 | SET custom.my.qualified.guc = 'foo' |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 663d123df1d48c5423a418e2 | SET work_mem FROM CURRENT |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 9a3202425cde5cf0cea2b6ce | SET LOCAL SESSION AUTHORIZATION regress_seq_user |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | a57b18b744c2f48fedc760dd | SET LOCAL SESSION AUTHORIZATION 'regress_stat_set_1' |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | efa1b85c4bda6d329cfe770a | SET LOCAL SESSION AUTHORIZATION 'regress_stat_set_2' |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 032d167d2c1239e9779571dc | CREATE VIEW pg_stats WITH (security_barrier) AS SELECT nspname AS schemaname, relname AS tablename, attname AS attname, stainherit AS inherited, stanullfrac AS null_frac, stawidth AS avg_width, sta... |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 0fc7df93738459f61f6dfb06 | CREATE VIEW my_property_secure WITH (security_barrier) AS SELECT * FROM customer WHERE name = current_user |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 1fd48a7623f88eb98390b08e | -- Tables referred to by security invoker views require explicit permission to -- be locked. CREATE VIEW lock_view8 WITH (security_invoker) AS SELECT * FROM lock_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 21527c3eaaaf981d5a6669c7 | create view rls_v with (security_invoker) as select * from rls_t |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 3569b1a71121630ed9527df7 | CREATE VIEW pg_stats_ext_exprs WITH (security_barrier) AS SELECT cn.nspname AS schemaname, c.relname AS tablename, sn.nspname AS statistics_schemaname, s.stxname AS statistics_name, pg_get_userbyid... |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 44d02c94666789215e9aa2eb | CREATE VIEW mysecview9 WITH (security_invoker) AS SELECT * FROM tbl1 WHERE a < 100 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 48c7f3627529529b6241f89b | CREATE VIEW my_credit_card_usage_secure WITH (security_barrier) AS SELECT * FROM my_credit_card_secure l NATURAL JOIN credit_usage r |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 5f9718c99df74a9503be8d8d | CREATE OR REPLACE RECURSIVE VIEW nums (n) AS VALUES (1) UNION ALL SELECT n+1 FROM nums WHERE n < 6 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 6ed0eefdfe92edac5c81ea40 | CREATE VIEW rls_view WITH (security_invoker) AS SELECT * FROM z1 WHERE f_leak(b) |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 710daa7dcbe2076afad7cddd | -- check display of assorted RTE_FUNCTION expressions create view tt20v as select * from coalesce(1,2) as c, collation for ('x'::text) col, current_date as d, localtimestamp(3) as t, cast(1+2 as in... |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 7207716068ca4a92de016e4e | CREATE VIEW my_credit_card_secure WITH (security_barrier) AS SELECT * FROM customer l NATURAL JOIN credit_card r WHERE l.name = current_user |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 7b1710fc737dca58ca150f9f | -- test interaction between subquery and partial_paths CREATE VIEW tenk1_vw_sec WITH (security_barrier) AS SELECT * FROM tenk1 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 923d13eab6ea15d7093c00be | -- recursive view CREATE RECURSIVE VIEW nums (n) AS VALUES (1) UNION ALL SELECT n+1 FROM nums WHERE n < 5 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 94281a019bbd0848299fb369 | CREATE VIEW rec2v WITH (security_barrier) AS SELECT * FROM rec2 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | 9810ac6dd24cfe9ac6c43d44 | CREATE VIEW mysecview4 WITH (security_barrier) AS SELECT * FROM tbl1 WHERE a <> 0 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | bf989ab8e8a6499e539ef956 | CREATE RECURSIVE VIEW nums_1_100 (n) AS VALUES (1) UNION ALL SELECT n+1 FROM nums_1_100 WHERE n < 100 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | c4fc245bc74503f474513511 | CREATE VIEW rls_sbv WITH (security_barrier) AS SELECT * FROM y1 WHERE f_leak(b) |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | c6f2828c8731840e9863e036 | CREATE VIEW rec1v WITH (security_barrier) AS SELECT * FROM rec1 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | cc0d95ad3e1f0791c5406af0 | CREATE VIEW bv1 WITH (security_barrier) AS SELECT * FROM b1 WHERE a > 0 WITH CHECK OPTION |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | d4818e42a5d4172f5fc06fd6 | CREATE VIEW mysecview6 WITH (invalid_option) -- Error AS SELECT * FROM tbl1 WHERE a < 100 |
| ERROR | PG_QUERY__NODE__NODE_VIEW_STMT | f21569323e589af7b4cb0786 | CREATE VIEW pg_stats_ext WITH (security_barrier) AS SELECT cn.nspname AS schemaname, c.relname AS tablename, sn.nspname AS statistics_schemaname, s.stxname AS statistics_name, pg_get_userbyid(s.stx... |
| PARTIAL | PG_QUERY__NODE__NODE_CONSTRAINTS_SET_STMT | 6d2a5e0e363611b7ccf78f79 | set constraints fkpart3.fkey deferred |
| PARTIAL | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 41cc0d34e333e02e1a48db40 | explain (costs off) insert into insertconflicttest values(0, 'Crowberry') on conflict (fruit, key, fruit text_pattern_ops, key) do nothing |
| PARTIAL | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 53a32d2146343a8dc7bb6746 | explain (costs off) insert into insertconflicttest values(0, 'Crowberry') on conflict (lower(fruit) collate "C", key, key) do nothing |
| PARTIAL | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 643b487d95136b238cadc447 | explain (costs off) insert into insertconflicttest values(0, 'Crowberry') on conflict (key, fruit text_pattern_ops) do nothing |
| PARTIAL | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9eb62ec475b2ab904fe106a1 | explain (costs off) insert into insertconflicttest values(0, 'Crowberry') on conflict (lower(fruit) collate "C", upper(fruit) text_pattern_ops) do nothing |
| PARTIAL | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9ff926f627fee5ebe2a66432 | explain (costs off) insert into insertconflicttest values(0, 'Crowberry') on conflict (lower(fruit) collate "C" text_pattern_ops, key, key) do nothing |
| PARTIAL | PG_QUERY__NODE__NODE_EXPLAIN_STMT | befb9f08e4f91089837a343a | explain (costs off) insert into insertconflicttest values(0, 'Crowberry') on conflict (lower(fruit) text_pattern_ops, upper(fruit) collate "C") do nothing |
| PARTIAL | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d0d86e169a6d9b5bc197cfad | explain (costs off) insert into insertconflicttest values(0, 'Crowberry') on conflict (key, fruit collate "C") do nothing |
| PARTIAL | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ddb84921f3cce2d9ec979c6a | explain (costs off) insert into insertconflicttest values(0, 'Crowberry') on conflict (fruit collate "C" text_pattern_ops, key) do nothing |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | 0e687abaf19d83cc110cc8bf | insert into arr_pk_tbl(pk, f1[1:2]) values (1, '{6,7,8}') on conflict (pk) do update set f1[1] = excluded.f1[1], f1[2] = excluded.f1[2], f1[3] = excluded.f1[3] returning pk, f1 |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | 2852eccba6ac4adf3cb81068 | insert into 計算機用語 values('コンピュータグラフィックス','分B10中') |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | 30f6d5a976bb0164926c8799 | insert into arr_pk_tbl(pk, f1[-2147483648:2147483647]) values (2, '{}') |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | 5affd2fd3542393270d13056 | -- error, type mismatch INSERT INTO arrtest (b[1:2]) VALUES(now()) |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | 5d7cdc942bb8b3784b0661b6 | INSERT INTO arrtest (a, b[1:2], c, d[1:2]) VALUES ('{}', '{3,4}', '{foo,bar}', '{bar,foo}') |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | 5f685f584deb7838d72c3d65 | INSERT INTO arrtest2 VALUES( ARRAY[[[113,142],[1,147]]], ARRAY[1.1,1.2,1.3]::float8[], ARRAY[1.1,1.2,1.3], ARRAY[[['aaa','aab'],['aba','abb'],['aca','acb']],[['baa','bab'],['bba','bbb'],['bca','bcb... |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | 687a915c1b971b946a48da92 | insert into 計算機用語 values('コンピュータディスプレイ','機A01上') |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | 92127ca4cb2e8ddb320b5fa5 | insert into arr_pk_tbl(pk, f1[0:2147483647]) values (2, '{}') |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | b4f0e3c53b785e755144f064 | -- -- only the 'e' array is 0-based, the others are 1-based. -- INSERT INTO arrtest (a[1:5], b[1:1][1:2][1:2], c, d, f, g) VALUES ('{1,2,3,4,5}', '{{{0,0},{1,2}}}', '{}', '{}', '{}', '{}') |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | bea89e870e0a098756d44fe6 | INSERT INTO arrtest (a, b[1:2][1:2], c, d, e, f, g) VALUES ('{11,12,23}', '{{3,4},{4,5}}', '{"foobar"}', '{{"elt1", "elt2"}}', '{"3.4", "6.7"}', '{"abc","abcde"}', '{"abc","abcde"}') |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | e2d63e3201f2cf3bef49b5f6 | insert into 計算機用語 values('コンピュータプログラマー','人Z01下') |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | fff040341e4a1456c3de7ef8 | INSERT INTO onek_with_null(unique1, unique2) VALUES (NULL, -1), (NULL, 2_147_483_647), (NULL, NULL), (100, NULL), (500, NULL) |
| PARTIAL | PG_QUERY__NODE__NODE_LOAD_STMT | 0f700b9e49ab23eebf123911 | LOAD 'plpgsql' |
| PARTIAL | PG_QUERY__NODE__NODE_LOAD_STMT | 21b258d05f002025775286e8 | LOAD '$libdir/sepgsql' |
| PARTIAL | PG_QUERY__NODE__NODE_LOAD_STMT | 34e97c7f5400854a3ab8a250 | -- test plperl.on_plperl_init -- This test tests setting on_plperl_init after loading plperl LOAD 'plperl' |
| PARTIAL | PG_QUERY__NODE__NODE_LOAD_STMT | 67038ced5ea428bbb2194e23 | LOAD 'passwordcheck' |
| PARTIAL | PG_QUERY__NODE__NODE_LOAD_STMT | a899cab5cecc27ed456af960 | LOAD 'auto_explain' |
| PARTIAL | PG_QUERY__NODE__NODE_LOAD_STMT | b8dd085345165ff20d3360dc | LOAD 'test_oat_hooks' |
| PARTIAL | PG_QUERY__NODE__NODE_LOAD_STMT | db5139026db1e213ea341752 | LOAD 'test_rls_hooks' |
| PARTIAL | PG_QUERY__NODE__NODE_LOAD_STMT | df5ab9de4096a79d0a2bcbef | LOAD 'pg_overexplain' |
| PARTIAL | PG_QUERY__NODE__NODE_SELECT_STMT | 196f9fdbab9ae36506fecb90 | SELECT collation for ('foo') |
| PARTIAL | PG_QUERY__NODE__NODE_SELECT_STMT | 4c90139ea2e01d191ff2991a | -- unknown type - null SELECT collation for ('foo'::text) |
| PARTIAL | PG_QUERY__NODE__NODE_SELECT_STMT | 7dbde44928cf6a4091a3c80e | -- non-collatable type - error SELECT collation for ((SELECT b FROM collate_test1 LIMIT 1)) |
| PARTIAL | PG_QUERY__NODE__NODE_SELECT_STMT | aafa53cced6d62d1c8c07705 | SELECT collation for ((SELECT a FROM collate_test1 LIMIT 1)) |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 0772efdab3aa3ab0b9ec8ef5 | UPDATE arrtest SET b[1:1][1:1][1:2] = '{113, 117}', b[1:1][1:2][2:2] = '{142, 147}' WHERE array_dims(b) = '[1:1][1:2][1:2]' |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 198ae741c56b06ac99b0f6ce | UPDATE arrtest SET a[1:2] = '{16,25}' WHERE NOT a = '{}'::_int2 |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 2d12fbcd7ef7883110abdddb | update arr_pk_tbl set f1[2147483646:2147483647] = array[4,2] where pk = 10 |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 324427dd57d07e8b6259ed26 | UPDATE arrtest SET c[1:NULL] = '{"can''t assign"}' WHERE array_dims(c) is not null |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 344377e4df9499c453a8cce5 | update arrtest1 set i[0:5] = array[0,1,2,null,4,5], t[0:5] = array['z','p1','p2',null,'p4','p5'] |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 5851bfa88c717600a439eaa6 | update arrtest1 set i[-12:-10] = array[-22,null,-20], t[-12:-10] = array['m22',null,'m20'] |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 6153f76c87704ebae16bc578 | update arrtest1 set i[15:16] = array[null,26], t[15:16] = array[null,'p26'] |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 6188d4d51ab022148e9f6d4c | UPDATE arrtest SET c[NULL:1] = '{"can''t assign"}' WHERE array_dims(c) is not null |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 6298a6a4276e2ef94f11c751 | update arrtest1 set i[0:2] = array[10,11,12], t[0:2] = array['ten','eleven','twelve'] |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 63feb65d3f94a13584cc2a60 | UPDATE arrtest_s SET a[3:] = '{23, 24, 25}', b[2:][2:] = '{{25,26}, {28,29}}' |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 64d5b965b43d1ff242f06b03 | update arrtest1 set i[-5:-3] = array[-15,-14,-13], t[-5:-3] = array['m15','m14','m13'] |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 7617e5dd903406b21766f4a3 | UPDATE arrtest_s SET a[:] = '{11, 12, 13, 14, 15}' |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 80153da75e40dce827583d6c | update arrtest1 set i[8:10] = array[18,null,20], t[8:10] = array['p18',null,'p20'] |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | 90a13637b23852dfe456b3cc | UPDATE arrtest_s SET a[:] = '{23, 24, 25}' |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | af87169a1f09597ad8e26de5 | update arrtest1 set i[11:12] = array[null,22], t[11:12] = array[null,'p22'] |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | b3b93d665e70c36beb714252 | -- updates UPDATE arrtest_s SET a[:3] = '{11, 12, 13}', b[:2][:2] = '{{11,12}, {14,15}}' WHERE array_lower(a,1) = 1 |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | c4ff20edd867c998a0fa1d7f | UPDATE arrtest SET c[2:2] = '{"new_word"}' WHERE array_dims(c) is not null |
| PARTIAL | PG_QUERY__NODE__NODE_UPDATE_STMT | fba60cf5cbd0923fb8ae55f6 | update arrtest1 set i[-7:-6] = array[-17,null], t[-7:-6] = array['m17',null] |
| PARTIAL | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 8ed641a0957afcf61da235ec | SET ROLE TO regress_display_role |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9561b52e5be5e680ed62a2fe | -- this should fail alter table renameColumn add column y int check (x > 0) not enforced enforced |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_COPY_STMT | 2981235bcd8c51c0865fbfab | COPY bool_test FROM STDIN NULL 'null' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_COPY_STMT | 43a2e4956c78b4a9cc61485b | -- -- Test headers, CSV and quotes -- copy (select t from test1 where id = 1) to stdout csv header force quote t |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_COPY_STMT | 91179538d562de426d2bacb7 | copy copyfreeze from stdin freeze |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_COPY_STMT | af14068f885fb027cf1c1f56 | COPY bitwise_test FROM STDIN NULL 'null' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_COPY_STMT | e578d1a5ddc7e105a5192fb3 | copy copytest3 from stdin csv header |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATEDB_STMT | f4cd53a0774351b44d4c0aa1 | CREATE DATABASE regression_tbd ENCODING utf8 LC_COLLATE "C" LC_CTYPE "C" TEMPLATE template0 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 02c1feda5a273db2fd42d0ec | CREATE OR REPLACE FUNCTION regexp_replace(string citext, pattern citext, replacement text, flags text) returns TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_replace( $1:... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0373bd4d5c037e1c3edac82f | CREATE FUNCTION functest_S_xx(x date) RETURNS boolean LANGUAGE SQL RETURN x > 1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 07e9dfbff7c03eafa8e4cba1 | CREATE OR REPLACE FUNCTION replace( citext, citext, citext ) RETURNS TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_replace( $1::text, pg_catalog.regexp_replace($2::text,... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0867e2097184f4ac1752b939 | CREATE OR REPLACE FUNCTION pg_sleep_until(timestamptz) RETURNS void LANGUAGE sql PARALLEL SAFE STRICT COST 1 RETURN pg_sleep(extract(epoch from $1) - extract(epoch from clock_timestamp())) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 08c6b070a034f8cb673c52d0 | CREATE FUNCTION _pg_char_max_length(typid oid, typmod int4) RETURNS integer LANGUAGE sql IMMUTABLE PARALLEL SAFE RETURNS NULL ON NULL INPUT RETURN CASE WHEN $2 = -1 /* default typmod */ THEN null W... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0abab773be184b7a4f70475a | CREATE OR REPLACE FUNCTION log(numeric) RETURNS numeric LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN log(10, $1) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0b2c06c29394cd0e371e41f5 | CREATE OR REPLACE FUNCTION age(timestamptz) RETURNS interval LANGUAGE sql STABLE PARALLEL SAFE STRICT COST 1 RETURN age(cast(current_date as timestamptz), $1) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0cd0d9d31cd0491c69c185ae | CREATE OR REPLACE FUNCTION interval_pl_timetz(interval, timetz) RETURNS timetz LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0d68ade6117f388caadfab27 | CREATE FUNCTION _pg_index_position(oid, smallint) RETURNS int LANGUAGE sql STRICT STABLE BEGIN ATOMIC SELECT (ss.a).n FROM (SELECT information_schema._pg_expandarray(indkey) AS a FROM pg_catalog.pg... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0fd6091c554e6a29b3ced0cc | CREATE OR REPLACE FUNCTION timestamptz(date, time) RETURNS timestamptz LANGUAGE sql STABLE PARALLEL SAFE STRICT COST 1 RETURN cast(($1 + $2) as timestamptz) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 107ae42789f49f72948134fe | CREATE FUNCTION functest_S_16(a int, b int) RETURNS void LANGUAGE SQL BEGIN ATOMIC INSERT INTO functest1 SELECT a + $2; END |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 1fcba1a6f7e4c8d8af2ef7a2 | CREATE OR REPLACE FUNCTION timedate_pl(time, date) RETURNS timestamp LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 224a0b1c9bf885ba365dc08e | CREATE OR REPLACE FUNCTION log10(numeric) RETURNS numeric LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN log(10, $1) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 29ed872195838cbbfb853d18 | CREATE OR REPLACE FUNCTION regexp_match(string citext, pattern citext, flags text) RETURNS TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_match( $1::text, $2::text, CAS... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 2afe9d3672c5de7dfb49cb5c | CREATE FUNCTION functest_S_10(a text, b date) RETURNS boolean LANGUAGE SQL BEGIN ATOMIC SELECT a = 'abcd' AND b > '2001-01-01'; END |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 33ec3c19f550a37f44cf9152 | CREATE OR REPLACE FUNCTION gc_to_sec(float8) RETURNS float8 LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN CASE WHEN $1 < '0'::float8 THEN '0'::float8 WHEN $1 / earth() > pi() THEN '2'::float8 ... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 34ddc60e42243b39b9a29ebc | CREATE OR REPLACE FUNCTION xpath_nodeset(text,text) RETURNS text LANGUAGE SQL STRICT IMMUTABLE PARALLEL SAFE RETURN xpath_nodeset($1, $2, ''::text, ''::text) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 3646d51766bddca8e038c981 | CREATE OR REPLACE FUNCTION int8pl_inet(bigint, inet) RETURNS inet LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 37b936d3aa479a5e133f329e | CREATE FUNCTION functest_S_15(x int) RETURNS boolean LANGUAGE SQL BEGIN ATOMIC select case when x % 2 = 0 then true else false end; END |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 3ebe594b041755ae5dba4ab5 | CREATE FUNCTION _pg_truetypmod(pg_attribute, pg_type) RETURNS int4 LANGUAGE sql IMMUTABLE PARALLEL SAFE RETURNS NULL ON NULL INPUT RETURN CASE WHEN $2.typtype = 'd' THEN $2.typtypmod ELSE $1.atttyp... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 44ddb11e231c3d18f28b5e3f | CREATE FUNCTION functest_IS_7() RETURNS int LANGUAGE SQL RETURN (SELECT count(a) FROM functest2) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 4524e1e19b05b7fc734e4d78 | CREATE OR REPLACE FUNCTION numeric_pl_pg_lsn(numeric, pg_lsn) RETURNS pg_lsn LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 48123bc87ca927b7065a9a3c | CREATE OR REPLACE FUNCTION obj_description(oid, name) RETURNS text LANGUAGE sql STABLE PARALLEL SAFE STRICT BEGIN ATOMIC select description from pg_description where objoid = $1 and classoid = (sel... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 4b08dac196f01eafc1a38efb | CREATE FUNCTION _pg_numeric_scale(typid oid, typmod int4) RETURNS integer LANGUAGE sql IMMUTABLE PARALLEL SAFE RETURNS NULL ON NULL INPUT RETURN CASE WHEN $1 IN (21, 23, 20) THEN 0 WHEN $1 IN (1700... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 4b16f2c13440254a7cc3bb81 | CREATE OR REPLACE FUNCTION lpad(text, integer) RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN lpad($1, $2, ' ') |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 53bbf7327cd8adf2f69e02aa | CREATE OR REPLACE FUNCTION polygon(circle) RETURNS polygon LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN polygon(12, $1) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5743295e875188f30d0e574f | CREATE OR REPLACE FUNCTION "overlaps"(timestamp, timestamp, timestamp, interval) RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE COST 1 RETURN ($1, $2) overlaps ($3, ($3 + $4)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 579f2738f99245515648840f | CREATE OR REPLACE FUNCTION interval_pl_time(interval, time) RETURNS time LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 582ac887e748820d06805fe7 | CREATE OR REPLACE FUNCTION split_part( citext, citext, int ) RETURNS TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN (pg_catalog.regexp_split_to_array( $1::text, pg_catalog.regexp_replace($... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5892995f75f217ee2d9916e7 | CREATE FUNCTION _pg_truetypid(pg_attribute, pg_type) RETURNS oid LANGUAGE sql IMMUTABLE PARALLEL SAFE RETURNS NULL ON NULL INPUT RETURN CASE WHEN $2.typtype = 'd' THEN $2.typbasetype ELSE $1.atttyp... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 59d01e0f132883c1ace3432d | CREATE FUNCTION _pg_interval_type(typid oid, mod int4) RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE RETURNS NULL ON NULL INPUT RETURN CASE WHEN $1 IN (1186) /* interval */ THEN pg_catalog.uppe... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5afc2b3e45a6fdb9a310633f | CREATE OR REPLACE FUNCTION path_contain_pt(path, point) RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN on_ppath($2, $1) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5b37390638b21777db780dc3 | CREATE OR REPLACE FUNCTION xpath(text, xml) RETURNS xml[] LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN xpath($1, $2, '{}'::text[]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 631aff120acf3f886c329740 | CREATE OR REPLACE FUNCTION xpath_exists(text, xml) RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN xpath_exists($1, $2, '{}'::text[]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6678e49f5283fe3bd751581b | CREATE FUNCTION brintest_func() RETURNS int LANGUAGE sql IMMUTABLE RETURN 0 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6f3b753da8b97bc8f2dce507 | create function fipshash(text) returns text strict immutable parallel safe leakproof return substr(encode(sha256($1::bytea), 'hex'), 1, 32) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 732be611398e0e89085b01ff | CREATE OR REPLACE FUNCTION regexp_matches(string citext, pattern citext, flags text) RETURNS SETOF TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE ROWS 10 RETURN pg_catalog.regexp_matches( $1::t... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 74ff680d1144f1a2d76a3057 | CREATE OR REPLACE FUNCTION interval_pl_timestamptz(interval, timestamptz) RETURNS timestamptz LANGUAGE sql STABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 76d077073fd75ae71b2d7674 | CREATE OR REPLACE FUNCTION ts_debug(document text, OUT alias text, OUT description text, OUT token text, OUT dictionaries regdictionary[], OUT dictionary regdictionary, OUT lexemes text[]) RETURNS ... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 77a934280f167a9f11cf22b5 | CREATE OR REPLACE FUNCTION regexp_split_to_array(string citext, pattern citext, flags text) RETURNS TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_split_to_array( $1::t... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 7afeb53ae81d14fd56094215 | CREATE OR REPLACE FUNCTION regexp_split_to_table(string citext, pattern citext) RETURNS SETOF TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_split_to_table( $1::text, $2:... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 7c27e24003a96e29310c938a | CREATE OR REPLACE FUNCTION pg_sleep_for(interval) RETURNS void LANGUAGE sql PARALLEL SAFE STRICT COST 1 RETURN pg_sleep(extract(epoch from clock_timestamp() + $1) - extract(epoch from clock_timesta... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 807d513d7d67adfe0fb061e5 | CREATE OR REPLACE FUNCTION bit_length(text) RETURNS integer LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN octet_length($1) * 8 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8100e33454f64b1095b4b847 | CREATE FUNCTION _pg_numeric_precision(typid oid, typmod int4) RETURNS integer LANGUAGE sql IMMUTABLE PARALLEL SAFE RETURNS NULL ON NULL INPUT RETURN CASE $1 WHEN 21 /*int2*/ THEN 16 WHEN 23 /*int4*... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8585be212ff42c970e4a2f89 | CREATE OR REPLACE FUNCTION shobj_description(oid, name) RETURNS text LANGUAGE sql STABLE PARALLEL SAFE STRICT BEGIN ATOMIC select description from pg_shdescription where objoid = $1 and classoid = ... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8ac6f3a5ff7e33879b7793df | CREATE OR REPLACE FUNCTION translate( citext, citext, text ) RETURNS TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.translate( pg_catalog.translate( $1::text, pg_catalog.lower($... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8de881cf670caab68e42204b | CREATE OR REPLACE FUNCTION pg_relation_size(regclass) RETURNS bigint LANGUAGE sql PARALLEL SAFE STRICT COST 1 RETURN pg_relation_size($1, 'main') |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8df005dcba9f73e442bcbcce | CREATE FUNCTION _pg_datetime_precision(typid oid, typmod int4) RETURNS integer LANGUAGE sql IMMUTABLE PARALLEL SAFE RETURNS NULL ON NULL INPUT RETURN CASE WHEN $1 IN (1082) /* date */ THEN 0 WHEN $... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8f046a6858e28b7fa5eefff1 | CREATE FUNCTION _pg_numeric_precision_radix(typid oid, typmod int4) RETURNS integer LANGUAGE sql IMMUTABLE PARALLEL SAFE RETURNS NULL ON NULL INPUT RETURN CASE WHEN $1 IN (21, 23, 20, 700, 701) THE... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8f3b5a835ac43107c7431661 | CREATE OR REPLACE FUNCTION regexp_matches(string citext, pattern citext) RETURNS SETOF TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE ROWS 1 RETURN pg_catalog.regexp_matches( $1::text, $2::text... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 93fce8d2c30a9ac7759e7f69 | CREATE OR REPLACE FUNCTION round(numeric) RETURNS numeric LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN round($1, 0) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 94fb6ad971d7b46a70f8223e | CREATE OR REPLACE FUNCTION bit_length(bit) RETURNS integer LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN length($1) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 9d71f32fc8d7f112ab85f8e2 | CREATE OR REPLACE FUNCTION regexp_replace(string citext, pattern citext, replacement text) returns TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_replace( $1::text, $2::t... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 9d86b593034f3a4f7ae567b0 | CREATE OR REPLACE FUNCTION "overlaps"(timestamptz, timestamptz, timestamptz, interval) RETURNS boolean LANGUAGE sql STABLE PARALLEL SAFE COST 1 RETURN ($1, $2) overlaps ($3, ($3 + $4)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 9f3fa8794b97165cebc5d56e | CREATE OR REPLACE FUNCTION "overlaps"(timestamptz, interval, timestamptz, timestamptz) RETURNS boolean LANGUAGE sql STABLE PARALLEL SAFE COST 1 RETURN ($1, ($1 + $2)) overlaps ($3, $4) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | a191778d8c5357b549c14702 | CREATE OR REPLACE FUNCTION "overlaps"(time, interval, time, interval) RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE COST 1 RETURN ($1, ($1 + $2)) overlaps ($3, ($3 + $4)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | a62e44692831c906aad13600 | CREATE OR REPLACE FUNCTION ts_debug(config regconfig, document text, OUT alias text, OUT description text, OUT token text, OUT dictionaries regdictionary[], OUT dictionary regdictionary, OUT lexeme... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | a86114ec744fc0962c485f18 | CREATE FUNCTION functest_S_xx(x anyarray) RETURNS anyelement LANGUAGE SQL RETURN x[1] |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | b2d8945058699d30ea11bf98 | CREATE OR REPLACE FUNCTION trunc(numeric) RETURNS numeric LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN trunc($1, 0) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | b68d16d074965c0cb4488cc6 | CREATE OR REPLACE FUNCTION interval_pl_timestamp(interval, timestamp) RETURNS timestamp LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | baff09b99ecc67af8b8fed5a | CREATE OR REPLACE FUNCTION regexp_split_to_table(string citext, pattern citext, flags text) RETURNS SETOF TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_split_to_table( $... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | bee8963b6a1e0f7fb0834fef | CREATE FUNCTION _pg_char_octet_length(typid oid, typmod int4) RETURNS integer LANGUAGE sql IMMUTABLE PARALLEL SAFE RETURNS NULL ON NULL INPUT RETURN CASE WHEN $1 IN (25, 1042, 1043) /* text, char, ... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | c3905a40278d9ff31f9f14fc | CREATE OR REPLACE FUNCTION age(timestamp) RETURNS interval LANGUAGE sql STABLE PARALLEL SAFE STRICT COST 1 RETURN age(cast(current_date as timestamp), $1) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | ca2bb148f733f74a462fecef | CREATE FUNCTION btree_test_func() RETURNS int LANGUAGE sql IMMUTABLE RETURN 0 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | ce6259a312f5e882727e5989 | CREATE OR REPLACE FUNCTION regexp_split_to_array(string citext, pattern citext) RETURNS TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_split_to_array( $1::text, $2::tex... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | ce8a5b9c19d19bffc236e69c | CREATE OR REPLACE FUNCTION obj_description(oid) RETURNS text LANGUAGE sql STABLE PARALLEL SAFE STRICT BEGIN ATOMIC select description from pg_description where objoid = $1 and objsubid = 0; END |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d00a70be6d075583b2b836e7 | CREATE OR REPLACE FUNCTION integer_pl_date(integer, date) RETURNS date LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d3b5eb86acf55cc5d4b78a2c | CREATE OR REPLACE FUNCTION rpad(text, integer) RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN rpad($1, $2, ' ') |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d76b16b1f46da0366cf50736 | CREATE OR REPLACE FUNCTION "overlaps"(timestamptz, interval, timestamptz, interval) RETURNS boolean LANGUAGE sql STABLE PARALLEL SAFE COST 1 RETURN ($1, ($1 + $2)) overlaps ($3, ($3 + $4)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d78a124388d8a659ad69218b | CREATE OR REPLACE FUNCTION "substring"(text, text, text) RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN substring($1, similar_to_escape($2, $3)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d84625aaaa38d64a919c31d1 | CREATE FUNCTION functest_S_xxx(x int) RETURNS int LANGUAGE SQL AS $$ SELECT x * 2 $$ RETURN x * 3 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d8a4cab3ba9ce68c90d447d6 | CREATE FUNCTION functest_sri2() RETURNS SETOF int LANGUAGE SQL STABLE BEGIN ATOMIC SELECT * FROM functest3; END |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d8cb0e80c345784753596ef9 | CREATE OR REPLACE FUNCTION sec_to_gc(float8) RETURNS float8 LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN CASE WHEN $1 < '0'::float8 THEN '0'::float8 WHEN $1 / ('2'::float8 * earth()) > '1'::f... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | df412050db5f3e1578e0a567 | CREATE OR REPLACE FUNCTION bit_length(bytea) RETURNS integer LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN octet_length($1) * 8 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | dfc4a6953697f459dd196a71 | CREATE OR REPLACE FUNCTION strpos( citext, citext ) RETURNS INT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.strpos( pg_catalog.lower( $1::text ), pg_catalog.lower( $2::text ) ) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e2da214f47ca40f875ed1dbb | CREATE OR REPLACE FUNCTION date_part(text, date) RETURNS double precision LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN date_part($1, cast($2 as timestamp)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e34cdcdd7d00900d65b7c9da | CREATE OR REPLACE FUNCTION "overlaps"(time, time, time, interval) RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE COST 1 RETURN ($1, $2) overlaps ($3, ($3 + $4)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e42f24cee87fb2c7ff5a98fc | CREATE OR REPLACE FUNCTION col_description(oid, integer) RETURNS text LANGUAGE sql STABLE PARALLEL SAFE STRICT BEGIN ATOMIC select description from pg_description where objoid = $1 and classoid = '... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e8b12575a2775c9d5ec572cf | CREATE OR REPLACE FUNCTION "overlaps"(timestamp, interval, timestamp, interval) RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE COST 1 RETURN ($1, ($1 + $2)) overlaps ($3, ($3 + $4)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | edc39de7c1fb4fe0c6cd5bc8 | CREATE OR REPLACE FUNCTION "overlaps"(timestamp, interval, timestamp, timestamp) RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE COST 1 RETURN ($1, ($1 + $2)) overlaps ($3, $4) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | ee8ffc992516bafae78244ae | -- -- These functions are used in tests that used to use md5(), which we now -- mostly avoid so that the tests will pass in FIPS mode. -- create function fipshash(bytea) returns text strict immutab... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | eeb135adf2eef827fa689eea | CREATE OR REPLACE FUNCTION "overlaps"(time, interval, time, time) RETURNS boolean LANGUAGE sql IMMUTABLE PARALLEL SAFE COST 1 RETURN ($1, ($1 + $2)) overlaps ($3, $4) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f1836879b0cb523b57df4f05 | CREATE OR REPLACE FUNCTION interval_pl_date(interval, date) RETURNS timestamp LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f3d19683f78af2a29e954f3d | CREATE OR REPLACE FUNCTION xpath_nodeset(text,text,text) RETURNS text LANGUAGE SQL STRICT IMMUTABLE PARALLEL SAFE RETURN xpath_nodeset($1, $2, ''::text, $3) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f5941fe42ff58e23beb991ba | CREATE FUNCTION functest_S_1(a text, b date) RETURNS boolean LANGUAGE SQL RETURN a = 'abcd' AND b > '2001-01-01' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f5a35ca0c45207be163cf151 | -- Other tests with token UNBOUNDED in potentially problematic position CREATE FUNCTION unbounded(x int) RETURNS int LANGUAGE SQL IMMUTABLE RETURN x |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f5e871d46f0d8e834b321667 | CREATE OR REPLACE FUNCTION timetzdate_pl(timetz, date) RETURNS timestamptz LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT COST 1 RETURN $2 + $1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f754d61331bb17c74d70ed45 | CREATE FUNCTION functest_IS_6() RETURNS int LANGUAGE SQL RETURN nextval('functest1') |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 03b05d606a6ac176475a3da6 | CREATE SCHEMA test_ns_schema_2 CREATE VIEW abc_view AS SELECT a FROM abc |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 07ad61d9e76ca91657b73643 | CREATE SCHEMA test_ns_schema_2 CREATE VIEW abc_view AS SELECT c FROM abc |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 16b99ae8f5bc8392429c4582 | CREATE SCHEMA AUTHORIZATION CURRENT_ROLE CREATE TABLE regress_create_schema_role.tab (id int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 20cdcc33a77340fa59c7516b | CREATE SCHEMA test_ns_schema_1 CREATE UNIQUE INDEX abc_a_idx ON abc (a) CREATE VIEW abc_view AS SELECT a+1 AS a, b+1 AS b FROM abc CREATE TABLE abc ( a serial, b int UNIQUE ) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 20f4433f7f23f5b82348ffff | -- ensure FK referencing a multi-level partitioned table are -- enforce reference to sub-children. CREATE SCHEMA fkpart9 CREATE TABLE pk (a INT PRIMARY KEY) PARTITION BY RANGE (a) CREATE TABLE fk (... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 27aa9c60bda6dd6971542dc0 | -- verify that attaching and detaching partitions manipulates the inheritance -- properties of their FK constraints correctly create schema fkpart2 create table pkey (a int primary key) create tabl... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 38f25c3c0d8e7da205331c3f | CREATE SCHEMA AUTHORIZATION regress_create_schema_role CREATE INDEX ON schema_not_existing.tab (id) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 3bcb806e33018a21d44073b3 | -- Leave this table around, for pg_upgrade/pg_dump tests -- Test creating a constraint at the parent that already exists in partitions. -- There should be no duplicated constraints, and attempts to... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 44ceec97aae01ff977fa9e05 | create schema s2 create table abc (f1 int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 481076875d69747620cc6a0c | create schema s1 create table abc (f1 int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 4dd6606cb74e2126ec071bf4 | CREATE SCHEMA AUTHORIZATION CURRENT_ROLE CREATE VIEW schema_not_existing.view AS SELECT 1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 4e04f80a3e9241602954b888 | -- verify foreign keys are enforced during cross-partition updates, -- especially on the PK side CREATE SCHEMA fkpart11 CREATE TABLE pk (a INT PRIMARY KEY, b text) PARTITION BY LIST (a) CREATE TABL... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 5083d916a635770a7a3189e3 | -- stage objects for pg_dump tests CREATE SCHEMA pubme CREATE TABLE t0 (c int, d int) CREATE TABLE t1 (c int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 593442743df4253928a3a935 | CREATE SCHEMA AUTHORIZATION regress_create_schema_role CREATE TABLE schema_not_existing.tab (id int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 628d077ab9a3d906f4fe4128 | CREATE SCHEMA AUTHORIZATION CURRENT_ROLE CREATE INDEX ON schema_not_existing.tab (id) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 62c9eb7b1d186b42e7ea7dd5 | CREATE SCHEMA AUTHORIZATION CURRENT_ROLE CREATE TABLE schema_not_existing.tab (id int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 6c3e59981435a5e3d5ec1da5 | CREATE SCHEMA AUTHORIZATION CURRENT_ROLE CREATE TRIGGER schema_trig BEFORE INSERT ON schema_not_existing.tab EXECUTE FUNCTION schema_trig.no_func() |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 6cb44a7f29a8c30aad4ae0a5 | CREATE SCHEMA regress_schema_1 AUTHORIZATION CURRENT_ROLE CREATE INDEX ON schema_not_existing.tab (id) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 74d171f4cf5bc333264f21f6 | CREATE SCHEMA regress_schema_1 AUTHORIZATION CURRENT_ROLE CREATE VIEW schema_not_existing.view AS SELECT 1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 7909831363f5926678c313b9 | -- doesn't exist -- verify constraint deferrability create schema fkpart3 create table pkey (a int primary key) create table fk_part (a int, constraint fkey foreign key (a) references fkpart3.pkey ... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 821528ce4bf585d88d974e48 | -- should fail CREATE SCHEMA test_view_schema CREATE TEMP VIEW testview AS SELECT 1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 842a93ba4630be8b7415b332 | -- Cases where the schema creation succeeds. -- The schema created matches the role name. CREATE SCHEMA AUTHORIZATION regress_create_schema_role CREATE TABLE regress_create_schema_role.tab (id int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 8ccf63bfb1d4c4f4e61f3bee | -- When a table is attached as partition to a partitioned table that has -- a foreign key to another partitioned table, it acquires a clone of the -- FK. Upon detach, this clone is not removed, but... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 8f8eb06fade59010793edbfc | CREATE SCHEMA AUTHORIZATION CURRENT_ROLE CREATE SEQUENCE schema_not_existing.seq |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 934c0ffe82603e7b9f77c717 | -- verify that attaching and detaching partitions maintains the right set of -- triggers create schema fkpart1 create table pkey (a int primary key) create table fk_part (a int) partition by list (... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 97011190ac5efd7581611dd8 | -- tests for temporary views CREATE SCHEMA temp_view_test CREATE TABLE base_table (a int, id int) CREATE TABLE base_table2 (a int, id int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | a3289bd6e34fc9ee98195687 | -- Cases where schema creation fails as objects are qualified with a schema -- that does not match with what's expected. -- This checks all the object types that include schema qualifications. CREA... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | ace9037fa0d44f8ca91d7502 | -- test that ri_Check_Pk_Match() scans the correct partition for a deferred -- ON DELETE/UPDATE NO ACTION constraint CREATE SCHEMA fkpart10 CREATE TABLE tbl1(f1 int PRIMARY KEY) PARTITION BY RANGE(... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | b1184f7b4e6eb64fe4e23542 | -- Again, with a schema name and a role specification. CREATE SCHEMA regress_schema_1 AUTHORIZATION CURRENT_ROLE CREATE TABLE regress_schema_1.tab (id int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | c5a2dab990eee2b6a4792b87 | CREATE SCHEMA evttrig CREATE TABLE one (col_a SERIAL PRIMARY KEY, col_b text DEFAULT 'forty two', col_c SERIAL) CREATE INDEX one_idx ON one (col_b) CREATE TABLE two (col_c INTEGER CHECK (col_c > 0)... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | d3e0415eb649567fecdf7fcf | CREATE SCHEMA AUTHORIZATION regress_create_schema_role CREATE VIEW schema_not_existing.view AS SELECT 1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | d79492ab895bd82f86d41124 | CREATE SCHEMA test_schema CREATE TABLE t(i int) PARTITION BY RANGE (i) CREATE TABLE p1 PARTITION OF t FOR VALUES FROM (1) TO (regress_seg_schema.exfun(2)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | da098b29800bc5b9a18c8c8a | CREATE SCHEMA regress_schema_1 AUTHORIZATION CURRENT_ROLE CREATE TABLE schema_not_existing.tab (id int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | df891db4ca52d19864119b12 | CREATE SCHEMA AUTHORIZATION regress_create_schema_role CREATE TRIGGER schema_trig BEFORE INSERT ON schema_not_existing.tab EXECUTE FUNCTION schema_trig.no_func() |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | e2f246955a10236a6bd7471a | -- test for reported bug: relispartition not set -- https://postgr.es/m/CA+HiwqHMsRtRYRWYTWavKJ8x14AFsv7bmAV46mYwnfD3vy8goQ@mail.gmail.com CREATE SCHEMA fkpart7 CREATE TABLE pkpart (a int) PARTITIO... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | e724bd67f8b9b04649a8e781 | -- Again, with a schema name and a role specification. CREATE SCHEMA regress_schema_1 AUTHORIZATION CURRENT_ROLE CREATE SEQUENCE schema_not_existing.seq |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | e81fc630e02fd0ea48b94579 | CREATE SCHEMA sts_sch1 CREATE TABLE sts_sch1.tbl (a INT, b INT, c INT GENERATED ALWAYS AS (b * 2) STORED) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | f0bfc5516cef6fa602e3bf72 | CREATE SCHEMA pubme2 CREATE TABLE t0 (c int, d int) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | f78f5e4b0bc029fe83890ca2 | CREATE SCHEMA regress_schema_1 AUTHORIZATION CURRENT_ROLE CREATE TRIGGER schema_trig BEFORE INSERT ON schema_not_existing.tab EXECUTE FUNCTION schema_trig.no_func() |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | fcba2d2e2b47dfa965faacda | -- ensure we check partitions are "not used" when dropping constraints CREATE SCHEMA fkpart8 CREATE TABLE tbl1(f1 int PRIMARY KEY) CREATE TABLE tbl2(f1 int REFERENCES tbl1 DEFERRABLE INITIALLY DEFE... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | fcd20638c40816103904b2bc | CREATE SCHEMA element_test CREATE TABLE foo (id int) CREATE VIEW bar AS SELECT * FROM foo |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_STMT | 5665e5a9f9ec13b80995406c | CREATE TABLE transition_table_level2 ( level2_no serial NOT NULL , parent_no int NOT NULL, level1_node_name varchar(255), PRIMARY KEY (level2_no) ) WITHOUT OIDS |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_STMT | 7761b0a9625aca913d513a48 | CREATE TABLE transition_table_status ( level int NOT NULL, node_no int NOT NULL, status int, PRIMARY KEY (level, node_no) ) WITHOUT OIDS |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_STMT | a7395c16add029931a8e5703 | -- but explicitly not adding oids is still supported CREATE TEMP TABLE withoutoid() WITHOUT OIDS |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_STMT | f12baae834771ed52f51fa2d | CREATE TABLE transition_table_level1 ( level1_no serial NOT NULL , level1_node_name varchar(255), PRIMARY KEY (level1_no) ) WITHOUT OIDS |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DELETE_STMT | 7fb55a2b470fca526d957f3f | delete from rtest_v1 where b isnull |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 02b5ef6d7c48911df3b1ddeb | DO LANGUAGE plpgsql $$ BEGIN -- this is a SELECT PERFORM 'hello world'::TEXT; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 049801ac86ec45cf7b7edb86 | DO LANGUAGE plpgsql $$ DECLARE my_schema pg_catalog.text := pg_catalog.quote_ident(pg_catalog.current_schema()); old_path pg_catalog.text := pg_catalog.current_setting('search_path'); BEGIN -- for ... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 08be288f282ef69b0f8faa1e | DO $$ warn $_SHARED{init} $$ language plperlu |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 0961b28f93124d936d6fd2d9 | DO $$ DECLARE o int; a int[] := ARRAY[1,2,3,2,3,1,2]; BEGIN o := array_position(a, 2); WHILE o IS NOT NULL LOOP RAISE NOTICE '%', o; o := array_position(a, 2, o + 1); END LOOP; END $$ LANGUAGE plpgsql |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 0d2ab2df708ddfff99e001a0 | DO LANGUAGE plpgsql $$ BEGIN ROLLBACK; SET TRANSACTION ISOLATION LEVEL REPEATABLE READ; FOR i IN 0..3 LOOP RAISE INFO 'transaction_isolation = %', current_setting('transaction_isolation'); INSERT I... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 10b37c7f180752175717c873 | DO $$ qx("/nonesuch"); $$ LANGUAGE plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 142879aaf2ade97141dd1403 | DO LANGUAGE plpgsql $$ BEGIN EXECUTE 'COPY copy1 FROM stdin'; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 1e89287784be0bb489d60f97 | DO LANGUAGE plperl $$ my $sth = spi_query("SELECT * FROM test2 ORDER BY x"); my $row; while (defined($row = spi_fetchrow($sth))) { spi_exec_query("INSERT INTO test1 (a) VALUES (" . $row->{x} . ")")... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 20f0fdb14a4df80572ea7b58 | DO LANGUAGE plperl $$ # this insert will fail during commit: spi_exec_query("INSERT INTO testfk VALUES (0)"); spi_commit(); elog(WARNING, 'should not get here'); $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 2256833852fc2907c1b14884 | DO LANGUAGE plpgsql $$ BEGIN MERGE INTO target t USING source AS s ON t.tid = s.sid WHEN MATCHED AND t.balance > s.delta THEN UPDATE SET balance = t.balance - s.delta; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 25a1affaa31030310c575146 | DO $do$ use warnings FATAL => qw(void) ; my @y; sort @y; 1; $do$ LANGUAGE plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 2e0a6db2823f1320800363d5 | DO LANGUAGE plpgsql $$ BEGIN EXECUTE 'COMMIT'; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 311f811fdfed715c181f7539 | DO $do$ use strict; my $name = "foo"; my $ref = $$name; $do$ LANGUAGE plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 322f8be79dabd8a27596cf0b | DO $do$ my $testlog = "/tmp/pgplperl_test.log"; warn "Run test, then examine contents of $testlog (which must already exist)\\n"; return unless -f $testlog; use IO::Handle; # for autoflush open my $... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 337fd15643534939c887a456 | DO $$ BEGIN SELECT plpy_raise_spiexception_override(); EXCEPTION WHEN SQLSTATE 'SILLY' THEN -- NOOP END $$ LANGUAGE plpgsql |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 3f781cb99fd2b23e7ccc7a0c | DO $$ plpy.info('wrong sqlstate', sqlstate='54444A') $$ LANGUAGE plpython3u |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 4084edf515782d4568b0c800 | DO LANGUAGE plpgsql $$ BEGIN BEGIN INSERT INTO test1 (a) VALUES (1); ROLLBACK; INSERT INTO test1 (a) VALUES (1/0); ROLLBACK; EXCEPTION WHEN division_by_zero THEN RAISE NOTICE 'caught division_by_ze... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 4318a456beea348bb55cd576 | DO LANGUAGE plpython3u $$ for i in range(0, 10): plpy.execute("INSERT INTO test1 (a) VALUES (%d)" % i) if i % 2 == 0: plpy.commit() else: plpy.rollback() $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 491142a81a2dc774e7a2bf90 | DO LANGUAGE plperl $$ foreach my $i (0..9) { spi_exec_query("INSERT INTO test1 (a) VALUES ($i)"); if ($i % 2 == 0) { spi_commit(); } else { spi_rollback(); } } $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 4bcbb66d20f4edb1a0c14549 | DO $$ warn 42 $$ language plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 50c7f44257f58ed5afabb829 | DO LANGUAGE plpgsql $$ BEGIN SAVEPOINT foo; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 544cc5aa10b86450ef553087 | DO LANGUAGE plpgsql $$ DECLARE x int := 3; y int := 4; BEGIN CALL test_proc6(2, x + 1, y); -- error RAISE INFO 'x = %, y = %', x, y; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 5e18bfe9d1c7767e70db9254 | DO $$ try: plpy.execute("select raise_exception(_message => 'my message', _sqlstate => 'XX987', _hint => 'some hint', _table_name => 'users_tab', _datatype_name => 'user_type')") except Exception a... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 618b9374b0caa06bdb8cc481 | DO $$ BEGIN DELETE FROM stats_track_tab; END; $$ LANGUAGE plpgsql |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 67fbd00460820a9a7034bf06 | DO LANGUAGE plpython3u $$ for row in plpy.cursor("SELECT * FROM test2 ORDER BY x"): plpy.execute("INSERT INTO test1 (a) VALUES (%s)" % row['x']) plpy.commit() $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 68e39bcdc6a5f4601324e615 | -- these are to check syntax error reporting DO LANGUAGE plpgsql $$begin return 1; end$$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 6b3e6486097148a5eb3ae267 | DO LANGUAGE plpython3u $$ for row in plpy.cursor("SELECT * FROM test2 ORDER BY x"): plpy.execute("INSERT INTO test1 (a) VALUES (%s)" % row['x']) plpy.rollback() $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 6e0c414af464374a0b861865 | DO $$ use blib; $$ LANGUAGE plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 7664b2dfd27cba148cf893ef | -- plperl should not be able to affect the process environment DO $$ $ENV{TEST_PLPERL_ENV_FOO} = "shouldfail"; untie %ENV; $ENV{TEST_PLPERL_ENV_FOO} = "testval"; my $penv = spi_exec_query("select u... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 7677dbfe0654206bcb885a58 | do language plperl $$ elog(NOTICE, ${^TAINT}); $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 7cf9ba78b306548cfce55433 | DO LANGUAGE plpgsql $$ BEGIN CREATE TABLE test3 (y int UNIQUE DEFERRABLE INITIALLY DEFERRED); COMMIT; INSERT INTO test3 (y) VALUES (1); COMMIT; INSERT INTO test3 (y) VALUES (1); INSERT INTO test3 (... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 7fbc088cf6dbad577bb27e9b | DO LANGUAGE plpgsql $$ BEGIN COPY copy1 FROM stdin; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 84132d3ceac5de362724f74c | DO LANGUAGE plpgsql $$ BEGIN SET TRANSACTION ISOLATION LEVEL REPEATABLE READ; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 8512b7b7dcb92edda55a8ee2 | DO $$ $a = 'This is a test'; elog(NOTICE, $a); $$ LANGUAGE plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 8710801f6ea4051d1d7264d2 | DO LANGUAGE plpgsql $$ DECLARE x int := 3; y int := 4; BEGIN CALL test_proc6(2, x, y); RAISE INFO 'x = %, y = %', x, y; CALL test_proc6(2, c => y, b => x); RAISE INFO 'x = %, y = %', x, y; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 88124b05b6d3c05a4ce06e54 | DO $$ try: plpy.error(message = 'my message', sqlstate = 'XX987', hint = 'some hint', table_name = 'users_tab', datatype_name = 'user_type') except Exception as e: plpy.info('sqlstate: %s, hint: %s... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 8ad9e985801ef9da006e3c15 | DO LANGUAGE plpython3u $$ for row in plpy.cursor("SELECT * FROM test2 ORDER BY x"): plpy.execute("INSERT INTO test1 (a) VALUES (%s)" % row['x']) if row['x'] % 2 == 0: plpy.commit() else: plpy.rollb... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 8ce1fd0ae9818ebf6b00610b | DO LANGUAGE plpgsql $$ BEGIN COMMIT; END $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 902d3161e38353cf81224620 | DO LANGUAGE plpgsql $$ DECLARE x int := 3; y int := 4; BEGIN FOR i IN 1..5 LOOP CALL test_proc6(i, x, y); RAISE INFO 'x = %, y = %', x, y; END LOOP; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 921b621eba6635f6646a4b21 | DO LANGUAGE plperl $$ my $sth = spi_query("SELECT * FROM test2 ORDER BY x"); my $row; while (defined($row = spi_fetchrow($sth))) { spi_exec_query("INSERT INTO test1 (a) VALUES (" . $row->{x} . ")")... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 926d74b1e8a5ec56942e48bd | DO LANGUAGE plpgsql $$ DECLARE r RECORD; BEGIN FOR r IN UPDATE test2 SET x = x * 2 RETURNING x LOOP INSERT INTO test1 (a) VALUES (r.x); ROLLBACK; END LOOP; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 958d01eb1fba5af44e4346e0 | DO $$ open my $fh, "</nonesuch"; $$ LANGUAGE plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 98d1f69ac062f1a3ac4f083f | DO LANGUAGE plpgsql $$ DECLARE r RECORD; BEGIN FOR r IN SELECT * FROM test2 ORDER BY x LOOP INSERT INTO test1 (a) VALUES (r.x); COMMIT; END LOOP; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | 9fb3e43474950911ae7b54d9 | DO LANGUAGE plpgsql $$ DECLARE r RECORD; BEGIN FOR r IN SELECT a FROM test1 FOR UPDATE LOOP UPDATE test1 SET b = b \|\| ' ' \|\| b WHERE a = r.a; COMMIT; END LOOP; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | a4cf94af83e1fdb33bc49f4c | DO LANGUAGE plpython3u $$ # this insert will fail during commit: plpy.execute("INSERT INTO testfk VALUES (0)") plpy.commit() plpy.warning('should not get here') $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | abb1e021365b61899ce8d1e4 | DO LANGUAGE plpgsql $$ BEGIN PERFORM 1; RAISE INFO '%', current_setting('transaction_isolation'); COMMIT; SET TRANSACTION ISOLATION LEVEL REPEATABLE READ; PERFORM 1; RAISE INFO '%', current_setting... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | aee4429c13d4a0f98391c91a | DO LANGUAGE plpgsql $$ DECLARE r RECORD; BEGIN FOR r IN SELECT * FROM test2 ORDER BY x LOOP INSERT INTO test1 (a) VALUES (r.x); IF r.x % 2 = 0 THEN COMMIT; ELSE ROLLBACK; END IF; END LOOP; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | b385f2e4be3037daa14412ad | DO LANGUAGE plpgsql $$ BEGIN ROLLBACK; CALL transaction_test9(); END $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | b575a13c9dc201e1a11fe473 | DO $$ plpy.info('other types', detail=(10, 20)) $$ LANGUAGE plpython3u |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | b58b4adcdbfe8c991c7ada1c | DO LANGUAGE plpgsql $$ DECLARE x constant int := 3; y int := 4; BEGIN CALL test_proc6(2, x, y); -- error because x is constant END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | b655f730931785625c9021c3 | DO LANGUAGE plpgsql $$ BEGIN FOR i IN 0..9 LOOP INSERT INTO test1 (a) VALUES (i); IF i % 2 = 0 THEN COMMIT; ELSE ROLLBACK; END IF; END LOOP; END $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | b855a93612397f7600f9357b | -- COPY TO/FROM not authorized from client. DO LANGUAGE plpgsql $$ BEGIN COPY copy1 TO stdout; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | bebc271924f77afe9def6ace | DO $$ basket = ['apple', 'orange', 'apple', 'pear', 'orange', 'banana'] plpy.info('other types', detail=basket) $$ LANGUAGE plpython3u |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | c2b9fafe9f1b8c51e1cfbc80 | DO LANGUAGE plperl $$ # this insert will fail during commit: spi_exec_query("INSERT INTO testfk VALUES (0)"); eval { spi_commit(); }; if ($@) { elog(INFO, $@); } # these inserts should work: spi_ex... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | c95e425ee244ce1d4446f549 | DO LANGUAGE plpgsql $$ DECLARE r RECORD; BEGIN FOR r IN SELECT * FROM test2 ORDER BY x LOOP INSERT INTO test1 (a) VALUES (12/(r.x-2)); COMMIT; END LOOP; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | c9abc089f9cbaff6b12fcaf4 | DO LANGUAGE plpython3u $$ # this insert will fail during commit: plpy.execute("INSERT INTO testfk VALUES (0)") try: plpy.commit() except Exception as e: plpy.info('sqlstate: %s' % (e.sqlstate)) # t... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | d249bd612d39655574258969 | DO $$ system("/nonesuch"); $$ LANGUAGE plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | d8ad203e9ec97e01fc65a5ad | DO LANGUAGE plpgsql $$ BEGIN BEGIN INSERT INTO test1 (a) VALUES (1); COMMIT; INSERT INTO test1 (a) VALUES (1/0); COMMIT; EXCEPTION WHEN division_by_zero THEN RAISE NOTICE 'caught division_by_zero';... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | dae052cb9e855690b975e4eb | DO LANGUAGE plpgsql $$ BEGIN FOR i IN 1..10 LOOP BEGIN INSERT INTO test1 VALUES (i, 'good'); INSERT INTO test1 VALUES (i/0, 'bad'); EXCEPTION WHEN division_by_zero THEN INSERT INTO test1 VALUES (i,... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | db10781f7b07b9146a0de4c6 | DO LANGUAGE plpgsql $$ BEGIN EXECUTE 'COPY copy1 TO stdout'; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | db9d43a98785ce478b5e9cc7 | DO LANGUAGE plpython3u $$ s = plpy.subtransaction() s.enter() plpy.commit() $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | df5a18074c56b6c48a248b0c | DO $$ raise Exception("error test") $$ LANGUAGE plpython3u |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | df747bfe7f4fb9af0dd07cf4 | DO $$ eval q{chdir '.';}; warn "Caught: $@"; $$ LANGUAGE plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | e13c067370a87d0502f385b3 | DO $$ BEGIN SELECT plpy_raise_spiexception(); EXCEPTION WHEN division_by_zero THEN -- NOOP END $$ LANGUAGE plpgsql |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | e2104596ec7a4f00b6a296cd | DO $$ plpy.info('first message', 'second message', message='third message') $$ LANGUAGE plpython3u |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | e33ca3a36fe6c75593326760 | DO $$ plpy.info('unsupported argument', blabla='fooboo') $$ LANGUAGE plpython3u |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | e5d31a49eaf98a6d99e0b1e8 | DO $$ plpy.notice("This is plpython3u.") $$ LANGUAGE plpython3u |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | e9258cef45b69fac055551ba | -- We have to update aggregates the hard way for lack of ALTER support DO LANGUAGE plpgsql $$ DECLARE my_schema pg_catalog.text := pg_catalog.quote_ident(pg_catalog.current_schema()); old_path pg_c... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | e9ecdaf5dfcbe6ac445e4808 | DO LANGUAGE plpgsql $$ DECLARE l_cur CURSOR FOR SELECT a FROM test1 ORDER BY 1 FOR UPDATE; BEGIN FOR r IN l_cur LOOP UPDATE test1 SET b = b \|\| ' ' \|\| b WHERE a = r.a; COMMIT; END LOOP; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | ec343b0df06a88962e94950a | DO $$ warn do "/dev/null"; $$ LANGUAGE plperl |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | f4349a420bac357b8fe785d4 | DO LANGUAGE plpgsql $$ declare c test1 := row(42, 'hello'); r bool; begin for i in 1..3 loop r := c is not null; raise notice 'r = %', r; commit; end loop; for i in 1..3 loop r := c is null; raise ... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | f5afc9a47e0d13da866d0220 | DO LANGUAGE plpython3u $$ for row in plpy.cursor("SELECT * FROM test2 ORDER BY x"): plpy.execute("INSERT INTO test1 (a) VALUES (12/(%s-2))" % row['x']) plpy.commit() $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | f61b7649d6bd0509c4128f1a | DO $$ import time; from datetime import date plpy.info('other types', detail=date(2016, 2, 26)) $$ LANGUAGE plpython3u |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | f763efeb4f903a755e440bb7 | DO $$ plpy.info('first message', message='second message') $$ LANGUAGE plpython3u |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | fa68a1184dbc662c9febf9cb | DO LANGUAGE plpgsql $$ DECLARE r RECORD; BEGIN FOR r IN SELECT * FROM test2 ORDER BY x LOOP INSERT INTO test1 (a) VALUES (r.x); ROLLBACK; END LOOP; END; $$ |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | fd7ec82595a9669adc6b7b87 | DO LANGUAGE plperl $$ my $sth = spi_query("SELECT * FROM test2 ORDER BY x"); my $row; while (defined($row = spi_fetchrow($sth))) { spi_exec_query("INSERT INTO test1 (a) VALUES (" . $row->{x} . ")")... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DO_STMT | fe06e27a75fc6c02ecc04ad2 | DO LANGUAGE plperl $$ my $sth = spi_query("SELECT * FROM test2 ORDER BY x"); my $row; while (defined($row = spi_fetchrow($sth))) { spi_exec_query("INSERT INTO test1 (a) VALUES (12/(" . $row->{x} . ... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DROPDB_STMT | adb2de973e1eecfb2aa44c05 | drop database if exists test_database_exists with (force) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DROPDB_STMT | aebcbb6ed04f056a781c8d18 | drop database if exists test_database_exists (force) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DROPDB_STMT | dfce96615d6417e5a8a2941f | drop database test_database_exists with (force) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_DROPDB_STMT | efae4f9fe20ffb0919c20b80 | drop database test_database_exists (force) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1ab56686d06e40a14ad4a59a | explain (costs off) select * from boolpart where a is false and a is unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 44283f06afae43f5513c8c1e | -- -- Similar to the previous test case, but this time it's a backwards scan -- using a < RowCompare. Must use the <= strategy (and not the < strategy). -- explain (costs off) SELECT proname, proar... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 58fa179e9a230d8ac6d8cd2d | explain (costs off) select * from boolpart where a is not unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 727bfb351526869d676571ea | -- exercise rescan code path via a repeatedly-evaluated subquery explain (costs off) SELECT ARRAY(SELECT f.i FROM ( (SELECT d + g.i FROM generate_series(4, 30, 3) d ORDER BY 1) UNION ALL (SELECT d ... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8af89dee5a893e8b9da8a4a4 | explain (costs off) select * from iboolpart where a is not unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9b1c426dfbdcbaf51b4e57b6 | -- all partitions pruned explain (costs off) select * from rparted_by_int2 where a > 100_000_000_000_000 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b9dc1147343f842033bb8e46 | explain (costs off) select * from lparted_by_int2 where a = 100_000_000_000_000 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c79a810f9f1c2a65e80ebeae | EXPLAIN (COSTS OFF) (WITH a AS (SELECT 4) (SELECT 1, 2)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | db7bddbcd9145f73a942effe | explain (costs off) select * from boolpart where a is unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ea268aaf64e749043cb2119c | explain (costs off) select * from boolpart where a is true and a is unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ea65596bba44b1031d549c52 | -- check that all partitions are pruned when faced with conflicting clauses explain (costs off) select * from boolpart where a is not unknown and a is unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | eb2806616bc69030c7ed07c9 | explain (costs off) select * from iboolpart where a is unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fda60997bc467070fd8ed800 | EXPLAIN (VERBOSE, COSTS OFF) SELECT * FROM ((SELECT * FROM async_p1 WHERE b < 10) UNION ALL (SELECT * FROM async_p2 WHERE b < 10)) s WHERE CURRENT_USER = SESSION_USER |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_INSERT_STMT | 3e97fad4c86f8610ecd5ec00 | INSERT INTO zerocol SELECT RETURNING old.*, new.*, * |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_INSERT_STMT | b269e341f499d75cf1d8cf66 | INSERT INTO zerocol SELECT RETURNING old.tableoid::regclass, old.ctid, new.tableoid::regclass, new.ctid, ctid, * |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 0051480c29e88fa31491a3b5 | SELECT (((SELECT 2)) UNION SELECT 2) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 0e76c8bd28dac6d76713e84b | -- run-time error SELECT U&'\\00E4\\24D1c' IS NORMALIZED AS test_default |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 104eea45322ba7f108a0aa9d | SELECT d, b IS TRUE AS istrue, b IS NOT TRUE AS isnottrue, b IS FALSE AS isfalse, b IS NOT FALSE AS isnotfalse, b IS UNKNOWN AS isunknown, b IS NOT UNKNOWN AS isnotunknown FROM booltbl3 ORDER BY o |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 11a104e822f3b438959bad62 | -- fail -- Appendrels excluded by constraints failed to check permissions in 8.4-9.2. select * from ((select a.q1 as x from int8_tbl a offset 0) union all (select b.q2 as x from int8_tbl b offset 0... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 124c83969dc3db708742dacb | SELECT ARRAY[[1,2],[3,4]] \|\| ARRAY[5,6] AS "{{1,2},{3,4},{5,6}}" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 18e7bdfe22cb1ae5584196ad | SELECT class, aa FROM a_star* x WHERE aa ISNULL |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 1ae30f65b161516689dc9b07 | select *,character_length(用語) from 計算機用語 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 1d38c100426f015fbf060d09 | select * from 計算機用語 where 用語 ~* 'コンピュータ[デグ]' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 1dfddd45b17864e9c109ab3e | select percentile_disc(array[[null,1,0.5],[0.75,0.25,null]]) within group (order by thousand) from tenk1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 22af652eb3a84169f1363ad7 | select *,position('デ' in 用語) from 計算機用語 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 2442b608284e5dff96ac99c7 | SELECT crypt('a very much longer text to encrypt. This one even stretches over more' 'than one line.', '$5$rounds=1400$anotherlongsaltstring') = '$5$rounds=1400$anotherlongsalts$Rx.j8H.h8HjEDGomFU8... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 27b6ef8e1eab255381c3aa8e | SELECT pg_typeof(ARRAY[['a','bc'],['def','hijk']]::text[]::varchar[]) AS "character varying[]" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 2c40c98f9d685e0fc642dbc1 | -- expressions SELECT t.f[1][3][1] AS "131", t.f[2][2][1] AS "221" FROM ( SELECT ARRAY[[[111,112],[121,122],[131,132]],[[211,212],[221,122],[231,232]]] AS f ) AS t |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 2c6c8abec93b7542fe3e1845 | SELECT test_slru_page_truncate(0x1234500000020) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 2fab6abce65c44a2bbf0c1e0 | SELECT (timestamp without time zone '2000-11-27', timestamp without time zone '2000-11-28') OVERLAPS (timestamp without time zone '2000-11-27 12:00', timestamp without time zone '2000-11-30') AS "T... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 3581370a4f3a3d697e7a238d | SELECT ((SELECT 2) UNION SELECT 2) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 35d18165dfe127a5be07c581 | select array_length(array[[1,2,3], [4,5,6]], 1) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 399f2307391dd7978b798789 | SELECT ARRAY[[[[[['hello'],['world']]]]]] |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 3f9c2fdcd4f4433183ffb1a1 | select array_length(array[[1,2,3], [4,5,6]], 3) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 3ffb69095e1b8cd7e4da1259 | SELECT * FROM test_type_conversion_array_int4(ARRAY[[1,2,3],[4,5,6]]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 40b7d3a6ea0c6f2a9c2b43bf | select array_length(array[[1,2,3], [4,5,6]], 0) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 4414b8358396adc3491bb8e9 | SELECT crypt('a very much longer text to encrypt. This one even stretches over more' 'than one line.', '$6$rounds=1400$anotherlongsaltstring') = '$6$rounds=1400$anotherlongsalts$POfYwTEok97VWcjxIiS... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 4a45acee114568e59c834431 | select ARRAY[['a','g','b'],['h','asd','i']]::hstore |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 4bca86aa231ccd63ad94e098 | SELECT (time '00:00', interval '1 hour') OVERLAPS (time '01:30', interval '1 day') AS "False" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 52a5e90c318c611438633843 | SELECT * FROM f_star* x WHERE x.c ISNULL |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 587294f8ac1a48977477763d | select delete('a=>1 , b=>2, c=>3'::hstore, ARRAY[['b'],['c'],['a']]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 5a27190a29c403db18893e70 | SELECT (time '00:00', time '01:00') OVERLAPS (time '00:30', time '01:30') AS "True" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 5ae6404a272148d9ba5132c7 | select hstore(ARRAY[['a','g'],['b','h'],['asd','i']]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 5bcc61ccac714b1f3abe0575 | select * from boolpart where a is unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 5dc92664391b4c1b18790aaa | SELECT CAST(ARRAY[[[[[['a','bb','ccc']]]]]] as text[]) as "{{{{{{a,bb,ccc}}}}}}" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 642991541d5988ff3a14ce1f | SELECT array_cat(ARRAY[1,2], ARRAY[[3,4],[5,6]]) AS "{{1,2},{3,4},{5,6}}" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 6582625e8acbcc51fab89565 | -- data-modifying WITH allowed only at the top level SELECT * FROM ( WITH t AS (UPDATE y SET a=a+1 RETURNING *) SELECT * FROM t ) ss |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 65b5034f3524c8ac6fa3f6d6 | select hstore(ARRAY[[['a','g'],['b','h'],['asd','i']]]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 67f880e5a1aaa577a90060e6 | SELECT class, c FROM e_star* x WHERE x.c NOTNULL |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 6f272beff925209382e7eb47 | select * from ((select 2 as v) union all (select 3 as v)) as q1 cross join lateral ((select * from ((select 4 as v) union all (select 5 as v)) as q3) union all (select q1.v) ) as q2 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 6f6c28262ff12a45c3921d8f | -- operators SELECT a FROM arrtest WHERE b = ARRAY[[[113,142],[1,147]]] |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 701b77f93f65be77072717af | SELECT ARRAY(SELECT f.i FROM ( (SELECT d + g.i FROM generate_series(4, 30, 3) d ORDER BY 1) UNION ALL (SELECT d + g.i FROM generate_series(0, 30, 5) d ORDER BY 1) ) f(i) ORDER BY f.i LIMIT 10) FROM... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 70b61d44839c5e2a27d3c92f | select array_length(array[[1,2,3], [4,5,6]], 2) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 73e1c21baaaee18bdb0c59b6 | SELECT num, val, val IS NFC NORMALIZED AS NFC, val IS NFD NORMALIZED AS NFD, val IS NFKC NORMALIZED AS NFKC, val IS NFKD NORMALIZED AS NFKD FROM (VALUES (1, U&'\\00E4bc'), (2, U&'\\0061\\0308bc'), (3,... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 753f0b17ead43276525e642e | select * from iboolpart where a is not unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 7701a448b799102d8dbc076b | SELECT (timestamp with time zone '2000-11-27', timestamp with time zone '2000-11-28') OVERLAPS (timestamp with time zone '2000-11-27 12:00', interval '1 day') AS "True" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 77aa7e7217d4efaa03a85e4e | select * from ((select a.q1 as x, random() from int8_tbl a where q1 > 0) union all (select b.q2 as x, random() from int8_tbl b where q2 > 0)) ss where x < 0 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 792026bf05353e5b3534a81e | SELECT test_slru_page_write(0x1234500000000, 'Test SLRU 64-bit') |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 7cc00119d8411a0b21a478b7 | SELECT (time '00:00', interval '1 hour') OVERLAPS (time '01:30', interval '1 hour') AS "False" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 7eb47503f7492e1feffd7fcf | SELECT array_positions(ARRAY[[1,2],[3,4]], 4) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 82b4b69a9d000bb0756f9c3e | SELECT U&'\\00E4\\24D1c' IS NFC NORMALIZED AS test_nfc |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 83257a08aad00d0c99c10854 | select foreach_test(ARRAY[[(10,20),(40,69)],[(35,78),(88,76)]]::xy_tuple[]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 8375e17d0330d41a6f31cf2d | SELECT (timestamp with time zone '2000-11-27', interval '12 hours') OVERLAPS (timestamp with time zone '2000-11-27 12:00', interval '12 hours') AS "False" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 83ff8988cd5e9c199f43265c | SELECT (timestamp with time zone '2000-11-27', timestamp with time zone '2000-11-28') OVERLAPS (timestamp with time zone '2000-11-27 12:00', timestamp with time zone '2000-11-30') AS "True" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 8618bef730061e5f2c737f12 | SELECT test_slru_page_exists(0x1234500000000) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 8697836859f3dc22510b33d2 | select foreach_test(ARRAY[[[1,2]],[[3,4]]]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 8701a0dc20bdf7ba812236df | select hstore(ARRAY[['a','g','b'],['h','asd','i']]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 873421d41b5290d8cd3bf90c | select * from rtest_v1 where b isnull |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 88af22bde7280c5f8a841f2e | SELECT sum(unique1) over (rows between unbounded.x preceding and unbounded.x following), unique1, four FROM tenk1, (values (1)) as unbounded(x) WHERE unique1 < 10 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 8c7b68d96d6689c2118a5867 | SELECT sum(unique1) over (rows between unbounded(1) preceding and unbounded(1) following), unique1, four FROM tenk1 WHERE unique1 < 10 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 8d87936ad471a0c232018b48 | SELECT * FROM test_type_conversion_array_timestamp(ARRAY[[['2016-09-21 15:34:24.078792-04','2016-10-22 11:34:24.078795-04',NULL], [NULL,'2016-10-21 11:34:25.078792-04','2016-10-21 11:34:24.098792-0... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 8f446acafba8601f238956f3 | select * from 計算機用語 where 分類コード like '_Z%' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 8f57590d909393200501cff4 | select armor('', array[['']], array['foo']) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 93e151090ea311d21652e606 | SELECT (timestamp without time zone '2000-11-27', interval '12 hours') OVERLAPS (timestamp without time zone '2000-11-27', interval '12 hours') AS "True" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 955088e13b194a4b55241f30 | select * from iboolpart where a is unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 971f16c75af88b76ccb1715b | SELECT array_sort(ARRAY[[2,4],[2,1],[6,5]]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 98a6db81538e2cbd127226cb | SELECT test_slru_page_delete(0x1234500000030) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 99aa9b1fedd8e79b004e38dc | select * from 計算機用語 where 分類コード ~* '人z01下' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 9bdcf352eb002ddcb537e16b | SELECT ARRAY[[['hello','world']]] \|\| ARRAY[[['happy','birthday']]] AS "ARRAY" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 9c4d3622c89385831388bb96 | SELECT test_slru_page_sync(0x1234500000030) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 9c592518d7e3dd8c18b69eb7 | select plperl_sum_array(ARRAY[[[[[[1,2],[3,4]],[[5,6],[7,8]]],[[[9,10],[11,12]], [[13,14],[15,16]]]], [[[[17,18],[19,20]],[[21,22],[23,24]]],[[[25,26],[27,28]],[[29,30],[31,32]]]]], [[[[[1,2],[3,4]... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | a0492fe84ebf3169df533b19 | SELECT test_slru_page_exists(0x1234500000030) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | a059554b77fac4e3915bf574 | select * from unnest2(array[[1,2,3],[4,5,6]]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | a3fc3782f79da2c2d93f350d | SELECT (timestamp without time zone '2000-11-27', interval '12 hours') OVERLAPS (timestamp without time zone '2000-11-27 12:00', timestamp without time zone '2000-11-30') AS "False" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | a83b390a6cd79d36de5bb959 | SELECT array_position(ARRAY[[1,2],[3,4]], 3) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | a9f19d05e1f0812ad4c2e6ad | select armor('', array['foo'], array[['']]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | acc3666c61ed6d8c539c7f42 | select * from boolpart where a is not unknown |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | af6390317ba0d7d8854d07a7 | select *,substring(用語 from 10 for 4) from 計算機用語 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | b0df8d41cbcff2d401ba7e0c | SELECT (time '00:00', interval '1 hour') OVERLAPS (time '00:30', interval '1 hour') AS "True" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | b2acdf3245205205eef95ec7 | SELECT * FROM test_type_conversion_array_int4(ARRAY[[[1,2,NULL],[NULL,5,6]],[[NULL,8,9],[10,11,12]]]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | b4b6be0d1fbf0563c34e78a0 | SELECT (timestamp with time zone '2000-11-27', interval '12 hours') OVERLAPS (timestamp with time zone '2000-11-27 12:00', timestamp with time zone '2000-11-30') AS "False" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | b52c6e8038d910d90e522b77 | SELECT (timestamp without time zone '2000-11-27', timestamp without time zone '2000-11-28') OVERLAPS (timestamp without time zone '2000-11-27 12:00', interval '1 day') AS "True" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | b69358dfef211a983124d290 | SELECT test_slru_page_exists(0x1234500000020) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | b8faa3917a3a457f5bb007e9 | select array_fill(1, array[[1,2],[3,4]]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | bc0bcf3eb1b79099513f7710 | SELECT test_slru_page_readonly(0x1234500000020) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | bd1293c85f9429f0dd4fd6b7 | SELECT (timestamp with time zone '2000-11-27', interval '12 hours') OVERLAPS (timestamp with time zone '2000-11-27', interval '12 hours') AS "True" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | bdff846187087647770231e0 | SELECT (timestamp with time zone '2000-11-26', timestamp with time zone '2000-11-27') OVERLAPS (timestamp with time zone '2000-11-27 12:00', timestamp with time zone '2000-11-30') AS "False" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | c1428b3b3b5c5256419b6e84 | SELECT array_cat(ARRAY[[3,4],[5,6]], ARRAY[1,2]) AS "{{3,4},{5,6},{1,2}}" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | c1850a2d38c3fca98271de6a | SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE (proname, pronamespace) < ('abs', 1_000_000) ORDER BY proname DESC, proargtypes DESC, pronamespace DESC LIMIT 1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | c1bc7d964065fa6cc8fc4dea | select heap_force_kill('htab2'::regclass, ARRAY[['(0, 2)']]::tid[]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | c55c5c3c2965534be98b2e48 | SELECT (timestamp without time zone '2000-11-27', interval '12 hours') OVERLAPS (timestamp without time zone '2000-11-27 12:00', interval '12 hours') AS "False" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | c72a304e3282b176c8411822 | SELECT count(test_slru_page_write(a, 'Test SLRU 64-bit')) FROM generate_series(0x1234500000001, 0x1234500000030, 1) as a |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | caf416b285569e09f2bc39cf | SELECT * FROM test_type_conversion_array_int8(ARRAY[[[1,2,NULL],[NULL,5,6]],[[NULL,8,9],[10,11,12]]]::int8[]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | cc2fd50309421bf428d2c7e6 | select ARRAY[['a','g'],['b','h'],['asd','i']]::hstore |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | cdd78a1079eec9bd1c5d1820 | SELECT test_slru_page_read(0x1234500000000) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | ce4a58bc619730a331fd5ee1 | SELECT test_slru_page_read(0x1234500000020, true) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | ce7da3e2130168aef6c19eb9 | select *,octet_length(用語) from 計算機用語 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | d62cf5861378a25986f295cf | select ARRAY[[['a','g'],['b','h'],['asd','i']]]::hstore |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | d8a215ade168c188f2a65818 | select * from 計算機用語 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | da0953de0f290c0c5ff878f3 | select 'a=>1 , b=>2, c=>3'::hstore - ARRAY[['b'],['c'],['a']] |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | db452239909bdc3706c0f824 | SELECT test_slru_page_readonly(0x1234500000001) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | dc58656c9ced960c942fe400 | SELECT (timestamp without time zone '2000-11-26', timestamp without time zone '2000-11-27') OVERLAPS (timestamp without time zone '2000-11-27 12:00', timestamp without time zone '2000-11-30') AS "F... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | e5cb740a5fb0dd7a06b48b9b | select foreach_test(ARRAY[[1,2],[3,4]]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | e6e93483e876328ed351cdbe | SELECT * FROM test_type_conversion_array_date(ARRAY[[['2016-09-21','2016-09-22',NULL],[NULL,'2016-10-21','2016-10-22']], [[NULL,'2016-11-21','2016-10-21'],['2015-09-21','2015-09-22','2014-09-21']]]... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | ef06fdedf511011e4a3f3d66 | select * from 計算機用語 where 用語 ~ 'コンピュータ[デグ]' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | f3456f7f77637b07a7bb3fe4 | select * from 計算機用語 where 分類コード like '_Z01_' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | f83f7887c4a67039ccecf1e9 | select 'aa=>1, c=>3, b=>2, d=>4'::hstore -> ARRAY[['b','d'],['aa','c']] |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | fa7c7d692b7dd19ceddcaaec | select * from 計算機用語 where 分類コード = '人Z01下' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | fadd5c83de9605fea9e56bd6 | SELECT ARRAY[['a','bc'],['def','hijk']]::text[]::varchar[] AS "{{a,bc},{def,hijk}}" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | fb39079244ed9893a307016e | SELECT * FROM test_type_conversion_array_text(ARRAY[['foo', 'bar'],['foo2', 'bar2']]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_UPDATE_STMT | 25c3493c48cbec2eaf1733a1 | -- let attribute a differ (must be done on rtest_t1 - see above) update rtest_t1 set a = a + 10 where b isnull |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 108241523c8781dfd555b9bd | SET TRANSACTION SNAPSHOT 'Incorrect Identifier' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 2883046f1e58bfa966e2f29d | SET SESSION CHARACTERISTICS AS TRANSACTION READ ONLY, READ ONLY |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 6d7cda546bc9e1ce8a44d90f | SET XML OPTION CONTENT |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 763b75d9edeab280716214d2 | -- SET XML OPTION SET XML OPTION DOCUMENT |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | b9ecaa55eb680ad640b74111 | SET TRANSACTION ISOLATION LEVEL SERIALIZABLE, READ ONLY, DEFERRABLE |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | bf92167628b07677b6aa8424 | SET LOCAL search_path = ctl_schema, public |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | d389de9fe57465b653789229 | SET LOCAL TIME ZONE 10.5 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | e1356d14e97ce520c935bed8 | SET TRANSACTION SNAPSHOT 'FFF-FFF-F' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | f8df4d44e2f17213c6326e62 | SET SESSION CHARACTERISTICS AS TRANSACTION READ ONLY, READ WRITE |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 0cac682a12cc29708e469913 | SHOW transaction_deferrable |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 21c69acd774ac99411761799 | -- passes with role member of pg_read_all_settings SHOW session_preload_libraries |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 309c3d6eb5ed49ffb65d0ba1 | SHOW TIME ZONE |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 4d9c8264bf8bbb9d5d4764be | SHOW is_superuser |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 609b4f46c153dce6727c258e | SHOW custom.my.qualified.guc |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 6541ce277725390360aa7416 | SHOW special."weird name" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 6b6c8b3bbddfd97dd05a27b4 | SHOW isn.weak |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 6e03c1be2a6c79291a9509f7 | SHOW custom.my_guc |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 7668c6fd1f07eb10203d61c0 | -- Checks on creating and manipulation of user defined relations in -- pg_catalog. SHOW allow_system_table_mods |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 8a2a06f6ce026603b69d5cad | SHOW transaction_read_only |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 9bc2d9d68ee109155e89db32 | -- None of the above should have created a placeholder GUC for none.such. SHOW none.such |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | a45e57b054a649b6e81996a1 | SHOW DateStyle |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | a5729e4f395b2886956a01bc | SHOW plpgsql.extra_foo_warnings |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | a577b367a46483d93453aaf9 | SHOW vacuum_cost_delay |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | b5da38d64de468721291fd47 | SHOW plperl.on_plperl_init |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | b6a7b95e1d83b1bc774ceed0 | -- -- Test cumulative stats system -- -- Must be run after tenk2 has been created (by create_table), -- populated (by create_misc) and indexed (by create_index). -- -- conditio sine qua non SHOW tr... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | b7136056163e7facc911cb94 | -- Make sure that the local settings have retained their values in spite -- of shenanigans on the connection. SHOW datestyle |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | b738855d8be91c790fe9a5de | SHOW transaction_isolation |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | c9e8af7ad004155146b8955b | SHOW search_path |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | cb6de80afd24796f97ee6add | SHOW intervalstyle |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | df48f7567739acc6f1cd7cbd | SHOW TimeZone |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | e0e973001836ffea0a90d95f | SHOW custom."bad-guc" |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | e964eccb7d846c0cb6040a30 | -- -- Verify correct calculation of checksums -- -- Postgres' checksum algorithm produces different answers on little-endian -- and big-endian machines. The results of this test also vary depending... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | fe9c493278ec4c922fcda8f5 | -- -- Commit Timestamp -- SHOW track_commit_timestamp |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VIEW_STMT | a0ca2fbcf42f7d0309ef3f51 | -- reverse-listing of various special function syntaxes required by SQL create view tt201v as select ('2022-12-01'::date + '1 day'::interval) at time zone 'UTC' as atz, extract(day from now()) as e... |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_REASSIGN_OWNED_STMT | 2e1439bc6ee75ff24beee170 | REASSIGN OWNED BY regress_dep_user1 TO regress_dep_user2 |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_REASSIGN_OWNED_STMT | 314472a8d2397328b1a2a17a | REASSIGN OWNED BY regress_dump_test_super TO CURRENT_ROLE |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_REASSIGN_OWNED_STMT | 6878a6bb5db6e8b9788c34c5 | REASSIGN OWNED BY regress_host_resource_admin TO regress_host_resource_newadmin |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_REASSIGN_OWNED_STMT | 7b1991b383360cd62273412f | REASSIGN OWNED BY regress_dep_user1 TO regress_dep_user0 |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_REASSIGN_OWNED_STMT | 887c3c9910cca7394e82d6e5 | REASSIGN OWNED BY regress_datdba_before TO regress_datdba_after |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_REASSIGN_OWNED_STMT | dbc990e88806c16726ec9fe1 | REASSIGN OWNED BY regress_dep_user0 TO regress_dep_user1 |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_REASSIGN_OWNED_STMT | e5ef64141b8c947e09cf828f | -- fail, dependency REASSIGN OWNED BY regress_priv_user2 TO regress_priv_user4 |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_REASSIGN_OWNED_STMT | e78fddd70f71fa3c97ac9160 | -- REASSIGN OWNED/DROP OWNED of foreign objects REASSIGN OWNED BY regress_test_role TO regress_test_role2 |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_REASSIGN_OWNED_STMT | ec74245840740384ddfe0f35 | REASSIGN OWNED BY regress_tenant TO regress_createrole |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 0709c5161b218601dd93c954 | RESET extra_float_digits |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 07aa6704c4eafd9ade6588e6 | RESET hash_mem_multiplier |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 096f4b0b73310691abeadfe7 | reset rls_test.blah |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 0e978c043f3f97455ae32cb5 | RESET maintenance_work_mem |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 104047cfb5d99d266e8e64ae | RESET default_statistics_target |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 10c46be1d52d986be8708630 | RESET client_min_messages |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 15bba42a29627995d2214b18 | reset enable_presorted_aggregate |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 15c689372703f4f4e43d8e0d | RESET custom.my_guc |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 1cda4a948d501c78c5108b86 | reset enable_sort |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 1e49eafbcedc8cfb9b37abca | RESET icu_validation_level |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 1e8c23b760b633310e0eaab3 | reset enable_incremental_sort |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 20ed7e434399cd7228d495b7 | RESET default_toast_compression |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 20ef69e17e901e4950c4dc83 | -- ok, privileges have been granted RESET max_stack_depth |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 23261259cc10653359e8f688 | -- If the INSERT runs the planner on index expressions, a search_path change -- survives. As of 2022-06, the INSERT reuses a cached plan. It does so even -- under debug_discard_caches, since each i... |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 24b24fd9ce91ca1604187054 | reset enable_parallel_append |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 27600bf454c0826c10bec261 | RESET allow_system_table_mods |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 277eee435718fd0dea99c383 | reset session_replication_role |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 323142138eb751b0b012c8af | RESET TIME ZONE |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 34b6474c81d4c29f627465bb | reset effective_io_concurrency |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 3747b884a086d1d9ec428b7d | RESET vacuum_truncate |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 3b8ba3c750b2de1b73c50a8b | RESET statement_timeout |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 3baf58f00cd43eaa02c10632 | reset bytea_output |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 3dd4013880dda28844ff9990 | reset plpgsql.extra_warnings |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 44a856df987c60da7636af4c | RESET postgres_fdw.application_name |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 461548f3aadfddbfc071508b | RESET enable_bitmapscan |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 48abb934414f107ad2cc1a3c | -- ERROR RESET restrict_nonsystem_relation_kind |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 4b8498aed90d75217b2f8c13 | RESET pgcrypto.builtin_crypto_enabled |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 4be7461efe81efe2eb40d9cc | RESET sepgsql.debug_audit |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 4e8071d301487487b288ba71 | reset enable_hashagg |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 511f5a02837dd98e9c59e091 | RESET default_transaction_read_only |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 5179fd078c9bec52f67a0321 | RESET enable_nestloop |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 5317505f9c19828f8371a8eb | RESET enable_mergejoin |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 53210da3255b2a4850ca0fbf | RESET enable_indexscan |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 5954f0934735e897c82231fe | RESET track_activities |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 5b2e316421132901dda50e54 | RESET transaction_read_only |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 5b597dee0d96fffdbbd72687 | -- Clean up reset max_parallel_workers_per_gather |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 5c2e53c7fc720616cdc54527 | RESET allow_in_place_tablespaces |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 63dcf1e11ee8a530b41b7e27 | RESET transaction_deferrable |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 66dc15d7bcfd909b8c56992d | RESET enable_material |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 68d361cd25639b4f79271ca1 | reset parallel_leader_participation |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 68dc13fba45bcbd2b0da221e | RESET enable_hashjoin |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 6c31cc899c701999c9d1e217 | reset enable_partition_pruning |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 6db20d8b2866a7e22e7cfb50 | RESET work_mem |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 6e5a01a5f52de65cff7ee4c4 | RESET min_parallel_table_scan_size |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7184085fb5d0e8c3ccd8deb8 | RESET enable_partitionwise_join |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 719d0df2ab02030aec20eb2f | -- Clean-up RESET enable_partitionwise_aggregate |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 736f43a8cb2f12dbbdbce013 | -- fail, cannot be set after connection start RESET jit_debugging_support |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 763cb5b16b160a3453099968 | RESET lc_numeric |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 76b0bb603c40b066d50a0ca6 | reset min_parallel_index_scan_size |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 77ada729aaed083a4992009a | reset max_parallel_workers |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7a20e3916f1713810a66fc65 | reset plpgsql.extra_errors |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7b065e4db12499fa33bdd96e | reset gin_fuzzy_search_limit |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7bc7deff6e7148e5e40ded94 | RESET max_parallel_maintenance_workers |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7fa5e558a33733a5bc71b1b9 | RESET intervalstyle |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 807d1f3d8db78e2ec2f53627 | RESET SESSION AUTHORIZATION |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 852eed84c6df40394eff07ad | RESET debug_logical_replication_streaming |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 885f9cfba65ab18e25963d87 | -- fail, cannot be set after connection start RESET ignore_system_indexes |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 8953ed1d43cc3954d778a6a4 | reset enable_indexonlyscan |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 8ac05b0ba5c9ca0866a68709 | RESET compute_query_id |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 8c3664745467079f9504c1eb | RESET wal_skip_threshold |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 8ddf023513b9ee302cdd8215 | RESET debug_parallel_query |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 908a661bddaf653c12ceab4f | RESET transaction_isolation |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 9589917c2cb455db1b41f8ef | RESET timezone |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 969d2d5c112d7194e819ee31 | -- ok RESET TimeZone |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 9bcf25b7af69d1100c63a25c | -- ok RESET lc_messages |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 9bebc418660494308c8fd3fa | reset plpgsql.check_asserts |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | ae1010135ce38130da1fc655 | RESET constraint_exclusion |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | b8b0f3eee76d180f4fadf151 | reset parallel_setup_cost |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | b962df2115d8146eb9f6ed56 | RESET datestyle |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | ba859e754b837e35ca89eec4 | -- out of transaction block RESET default_transaction_isolation |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | bb0007830f6c3da82202fcb1 | -- ok RESET DateStyle |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | bba88d7497010d59adebc3b8 | RESET plan_cache_mode |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | be6793ac25accd19b2c8a203 | RESET ROLE |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | c38a3966fb84217d94e71d23 | RESET SEARCH_PATH |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | c4d771b29e52dbee5bc49367 | -- fail, requires restart RESET autovacuum_freeze_max_age |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | c78fa84b15e205b7f8aeed69 | RESET logical_decoding_work_mem |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | c79f307fdb85a0dcc9750476 | RESET client_encoding |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | ca170ff06bce041d2255d66a | reset join_collapse_limit |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | d2cf4360d3461410b6d2fdde | -- fail, cannot be changed RESET block_size |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | d3b072b006aac5349cd73833 | RESET temp_buffers |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | d3c38437ffcac9c46de4b21a | RESET enable_seqscan |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | d4d8fbc97bfdf2422c745685 | reset plpgsql.print_strict_params |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | dc6dc77ebc5dabaaf10f9395 | RESET enable_memoize |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | e336a80662312435443ceae9 | RESET ALL |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | e5f0588ad8bbfbd187a60e8a | RESET default_tablespace |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | e98f2e0f9493948ffd6648c0 | -- fail, requires reload RESET autovacuum |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | f22da005a66dc8b65f13f47c | reset parallel_tuple_cost |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | ffb5ccbef8cb5f5e8b659e9f | reset check_function_bodies |

## CLASSIFIED_ONLY Routing Coverage

| Oracle Node | Count |
| --- | --- |
| - | - |

## PG17 to PG18 Release Delta

| Result | Oracle Node | ID | SQL |
| --- | --- | --- | --- |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_ENUM_STMT | b7ed99265edea652185d1c72 | -- enum values added later take some different codepaths internally, -- so make sure we have coverage for those too alter type rainbow add value 'y' before 'g' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FDW_STMT | 19614de4a47f91f2a6bcfb71 | -- should preserve dependency on test_fdw_handler ALTER FOREIGN DATA WRAPPER test_fdw VALIDATOR postgresql_fdw_validator |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FOREIGN_SERVER_STMT | 684ca81ae2786564cba837bc | ALTER SERVER fdtest OPTIONS (ADD oauth_client_id 'myID') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FOREIGN_SERVER_STMT | 73b6948233355748d81adf92 | ALTER SERVER testserver1 OPTIONS (ADD oauth_client_id 'myID') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FOREIGN_SERVER_STMT | 917ae882230ab58f56bfe22d | ALTER SERVER loopback OPTIONS (SET application_name 'fdw_conn_check') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FOREIGN_SERVER_STMT | c51ca4987598db73ed930b75 | -- OAuth options are not allowed in either context ALTER SERVER testserver1 OPTIONS (ADD oauth_issuer 'https://example.com') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FOREIGN_SERVER_STMT | f41fa8374ae236379a8943a7 | -- OAuth options are not allowed in either context ALTER SERVER fdtest OPTIONS (ADD oauth_issuer 'https://example.com') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FUNCTION_STMT | 1cdd8ef896873984e6d4543c | alter function whoami() security invoker |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FUNCTION_STMT | 317f08ecfce8fee22be8c1ad | -- security definer functions override the user who queued the trigger alter function whoami() security definer |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FUNCTION_STMT | 475bbad02029e33da516466e | -- -- check that an upper-level qual is not pushed down if it references a grouped -- Var whose underlying expression contains volatile functions -- alter function tattle(x int, y int) volatile |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_FUNCTION_STMT | ca868e4b06011234fbc3ef3d | ALTER FUNCTION isn_weak() STABLE PARALLEL SAFE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OPERATOR_STMT | 325fe2013414001a3194df07 | alter operator = (int8, int8alias1) set (hashes) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 00b199f99d246e5596c684b7 | ALTER OPERATOR FAMILY gist_bool_ops USING gist ADD FUNCTION 11 (bool, bool) gbt_bool_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 0f1b86cdecab2b7129d7835b | ALTER OPERATOR FAMILY gist_time_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 15d3adff48146142fa762e55 | ALTER OPERATOR FAMILY gist_enum_ops USING gist ADD FUNCTION 11 (anyenum, anyenum) gbt_enum_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 18b030e1a35d8fa52e3e172c | ALTER OPERATOR FAMILY gist_macaddr8_ops USING gist ADD FUNCTION 11 (macaddr8, macaddr8) gbt_macad8_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 1fcde82c98913e6863690752 | ALTER OPERATOR FAMILY gist_float8_ops USING gist ADD FUNCTION 11 (float8, float8) gbt_float8_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 227a5ff8dc8065846411fce5 | ALTER OPERATOR FAMILY gist_bpchar_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 278cb3beca990ed45f78f0ac | -- Should fail. Not allowed to have cross-type skip support function. ALTER OPERATOR FAMILY alt_opf18 USING btree ADD FUNCTION 6 (int4, int2) btint4skipsupport(internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 2ab97b70c7c6d7d50dac85a8 | ALTER OPERATOR FAMILY gist_timestamptz_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 2bf1bb890c91a90e2d099f9b | ALTER OPERATOR FAMILY gist_macaddr_ops USING gist ADD FUNCTION 11 (macaddr, macaddr) gbt_macaddr_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 2c1230d52c4994af082432ff | ALTER OPERATOR FAMILY gist_timestamp_ops USING gist ADD FUNCTION 11 (timestamp, timestamp) gbt_ts_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 319e59a067228113d6a62799 | ALTER OPERATOR FAMILY gist_float4_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 35154c12cbd52e5a04046f47 | ALTER OPERATOR FAMILY gist_int2_ops USING gist ADD FUNCTION 11 (int2, int2) gbt_int2_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 38006891148f2f683f095423 | -- invalid options parsing function ALTER OPERATOR FAMILY alt_opf4 USING btree ADD FUNCTION 7 btint42cmp(int4, int2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 399e99956fa3dc37effa3a84 | ALTER OPERATOR FAMILY gist_timestamp_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 42868909bfc811d1e05eda90 | ALTER OPERATOR FAMILY gist_numeric_ops USING gist ADD FUNCTION 11 (numeric, numeric) gbt_numeric_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 4d7a2cb2ab91156c9e57bfe4 | ALTER OPERATOR FAMILY gist_vbit_ops USING gist ADD FUNCTION 11 (varbit, varbit) gbt_varbit_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 4ff5bf9608f9227d8e04f102 | ALTER OPERATOR FAMILY gist_cidr_ops USING gist ADD FUNCTION 11 (cidr, cidr) gbt_inet_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 5587b033da74304eed208582 | ALTER OPERATOR FAMILY gist_inet_ops USING gist ADD FUNCTION 11 (inet, inet) gbt_inet_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 5b28a34a8155922227194c85 | ALTER OPERATOR FAMILY gist_time_ops USING gist ADD FUNCTION 11 (time, time) gbt_time_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 5b7f869fb7672a7a7befbe66 | ALTER OPERATOR FAMILY gist_oid_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 644b1e90a0bec27a049a3223 | alter operator family integer_ops using hash add function 1 hashint8alias1(int8alias1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 669f140fb528b0dad46e4f9c | ALTER OPERATOR FAMILY gist_timetz_ops USING gist ADD FUNCTION 11 (timetz, timetz) gbt_time_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 683e07cdf2da6b0579b3e82b | ALTER OPERATOR FAMILY gist_macaddr8_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 695e53e8541af77a9c7b5209 | ALTER OPERATOR FAMILY gist_cidr_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 69927e4a2356914e19c24e3a | ALTER OPERATOR FAMILY gist_uuid_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 720aa347ad4981b3e30b4bed | ALTER OPERATOR FAMILY gist_macaddr_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 755ff846e489f0b340103f8a | ALTER OPERATOR FAMILY gist_interval_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 7a1f7ba366c4dce87d84f4a7 | ALTER OPERATOR FAMILY gist_date_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 7dbfba3d1c70e4df227fa555 | ALTER OPERATOR FAMILY gist_int8_ops USING gist ADD FUNCTION 11 (int8, int8) gbt_int8_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 845a19340e374fe88fa13667 | ALTER OPERATOR FAMILY gist_oid_ops USING gist ADD FUNCTION 11 (oid, oid) gbt_oid_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 84754d09b7bd4cfe52d7c28e | ALTER OPERATOR FAMILY gist_bool_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 84acc381db04d530e2a0a5fe | ALTER OPERATOR FAMILY gist_timestamptz_ops USING gist ADD FUNCTION 11 (timestamptz, timestamptz) gbt_ts_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 87b4f37965872d5c1aae19e0 | ALTER OPERATOR FAMILY gist_text_ops USING gist ADD FUNCTION 11 (text, text) gbt_text_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 884e69657b5d28d2dba55e56 | ALTER OPERATOR FAMILY gist_bpchar_ops USING gist ADD FUNCTION 11 (bpchar, bpchar) gbt_bpchar_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 8f104b3fa62e4d1f19739f4b | ALTER OPERATOR FAMILY gist_bit_ops USING gist ADD FUNCTION 11 (bit, bit) gbt_bit_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | 95069a2fdfff75a0f14648ca | ALTER OPERATOR FAMILY gist_timetz_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | a0ae7a2548587c3a207a9108 | ALTER OPERATOR FAMILY gist_float8_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | a5fe251e9fb8d3b27f18ff81 | ALTER OPERATOR FAMILY gist_int2_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | b25085bfb6897921d615f40b | ALTER OPERATOR FAMILY gist_cash_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | ba151bb53a9f80fadf233b6a | ALTER OPERATOR FAMILY gist_float4_ops USING gist ADD FUNCTION 11 (float4, float4) gbt_float4_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | ba1a709a46613a1a18e6e413 | ALTER OPERATOR FAMILY gist_enum_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | bc601c22774b79de73939d9f | alter operator family integer_ops using hash add operator 1 = (int8, int8alias1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | bd581d782e39b8d60775bbb2 | ALTER OPERATOR FAMILY gist_cash_ops USING gist ADD FUNCTION 11 (money, money) gbt_cash_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | be3128a736951f712049ab15 | ALTER OPERATOR FAMILY gist_inet_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | c29315999722bfc8e6150b72 | ALTER OPERATOR FAMILY gist_int8_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | c68e2379bff015d52e8b719a | ALTER OPERATOR FAMILY gist_numeric_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | ce322b5410655351cb0fd57b | ALTER OPERATOR FAMILY gist_int4_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | db49fd2fa514536ac076cfc0 | ALTER OPERATOR FAMILY gist_interval_ops USING gist ADD FUNCTION 11 (interval, interval) gbt_intv_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | dc1a5029007cf69ce99f9fe1 | ALTER OPERATOR FAMILY gist_date_ops USING gist ADD FUNCTION 11 (date, date) gbt_date_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | e2ce07168706a8d15887dd4d | ALTER OPERATOR FAMILY gist_bit_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | e92e8b2a972f027fd28682ab | ALTER OPERATOR FAMILY gist_uuid_ops USING gist ADD FUNCTION 11 (uuid, uuid) gbt_uuid_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | ea49d74d3f54f0ba5626a5e6 | ALTER OPERATOR FAMILY gist_bytea_ops USING gist ADD FUNCTION 11 (bytea, bytea) gbt_bytea_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | eb6aa289137575b5ede99835 | ALTER OPERATOR FAMILY gist_vbit_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | ed4a5f2cfc63b0f0c43e9e66 | ALTER OPERATOR FAMILY gist_bytea_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | f1e2e0de160ce34dc8967f3e | ALTER OPERATOR FAMILY gist_int4_ops USING gist ADD FUNCTION 11 (int4, int4) gbt_int4_sortsupport (internal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OP_FAMILY_STMT | f367839f804884c8838a53a5 | ALTER OPERATOR FAMILY gist_text_ops USING gist ADD FUNCTION 12 ("any", "any") gist_translate_cmptype_btree (int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_OWNER_STMT | a7f92ce851d2676ea4611d77 | alter function whoami() owner to regress_fn_owner |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_ROLE_STMT | 3c7baea5f5430361758dbe5a | -- This is borderline unsafe in that an additional login-capable user exists -- during the test run. Under installcheck, a too-permissive pg_hba.conf -- might allow unwanted logins as regress_authe... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_ROLE_STMT | 3e52aa4163f4f270744ecce7 | ALTER USER regress_passwordcheck_user1 PASSWORD 'v_shrt' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_ROLE_STMT | 8200526bb371229e9cb6a49f | ALTER ROLE regress_passwd9 PASSWORD 'SCRAM-SHA-256$00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 001c761105d114480ef6dbc2 | alter table inh_parent add constraint inh_parent_uq unique (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 003a575a0731d3a287e8f2e8 | -- DROP CONSTRAINT recurses correctly on invalid constraints ALTER TABLE notnull_tbl1 ALTER CONSTRAINT nntbl1_a INHERIT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 003c9d80f24662a3e7b805ee | ALTER TABLE inh_nn_parent ALTER a SET NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 0047571bb40ca5fc74d89767 | alter table cnn2_parted add primary key (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 006f40fdef07f488f8d0db37 | ALTER TABLE test_add_column DROP c6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 00b7669988e4a3fd169335df | --error, notnull_tbl1_3 have null values ALTER TABLE notnull_tbl1_3 VALIDATE CONSTRAINT nn3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 012112ea98f38b1dc0e6c15b | ALTER TABLE atnnparted ATTACH PARTITION atnnpart1 FOR VALUES IN ('1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 01fc15c066805cd13de0ee08 | ALTER TABLE sl ADD COLUMN bool_col boolean |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 030bd70cb513b576e70a0b59 | ALTER TABLE temporal_rng2 ADD CONSTRAINT temporal_rng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 0349daccc7588273fad7efc9 | ALTER TABLE fktable ALTER CONSTRAINT fktable_fk_fkey NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 04aabb8698b9ec9373781fe7 | alter table inh_cc2 no inherit inh_pp1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 069b31f81beae46ed1099297 | ALTER TABLE testpub_rf_tbl7 ALTER COLUMN y SET EXPRESSION AS (x * testpub_rf_func2()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 06cb619bb32ed7c029c9a792 | ALTER FOREIGN TABLE ft1 DROP c11 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 08f2a4c4b84a4b17d71f146a | ALTER TABLE temporal_fk_rng2rng DROP CONSTRAINT temporal_fk_rng2rng_fk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 0b32908227962a456b8afc4a | -- add NOT NULL constraint recursively alter table inh_parent alter column f1 set not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 0d9e74318aa68e56115fd5c5 | ALTER TABLE notnull_parent_upg ADD CONSTRAINT nn NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 0ea20d1fa311f7c124484b11 | alter table cc3 no inherit cc1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1158087923d90edd4ca31b4d | -- should succeed -- Test wholerow & dropped column handling ALTER TABLE foo DROP COLUMN f3 CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 11fbab52e2eca12742343db6 | ALTER TABLE regular_table DETACH PARTITION any_name CONCURRENTLY |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 125b2a0a03f65b4a3a2663d6 | ALTER TABLE notnull_part1_upg ATTACH PARTITION notnull_part1_3_upg FOR VALUES IN (NULL,5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1568447ed48a289d2e5b1c48 | -- Some error cases. ALTER TABLE comment_test ALTER COLUMN xmin SET DATA TYPE x |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 160d94806197d6ff03052385 | alter table inh_child3 inherit inh_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1663440ac0cf84dcf19f2e99 | alter table p1_c1 add constraint inh_check_constraint9 check (f1 < 10) not valid enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 168fb72c9698b507a682c424 | ALTER TABLE ATACC1 ADD NOT NULL a NO INHERIT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 17e665fbdd654a91cc03a9b4 | -- succeeds ALTER TABLE attmp3 ADD CONSTRAINT b_greater_than_ten_not_enforced CHECK (b > 10) NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1a52cb168bb3198c9ff23da3 | ALTER TABLE fk_partitioned_pk VALIDATE CONSTRAINT selffk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1b8fa7452fdc598e02a0e11f | ALTER TABLE temporal_fk_rng2rng ADD CONSTRAINT temporal_fk_rng2rng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_rng ON UPDATE RESTRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1ba992de42b44a0bdf22136e | ALTER TABLE temporal_mltrng3 DROP CONSTRAINT temporal_mltrng3_uq |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1d33d1bad9908ce1095c5a83 | ALTER TABLE itest4 ALTER COLUMN c ADD GENERATED ALWAYS AS IDENTITY |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1dae06b0c6e78b2547c804cc | ALTER TABLE fk_notpartitioned_fk ADD CONSTRAINT fk_notpartitioned_fk_a_b_fkey2 FOREIGN KEY (a, b) REFERENCES fk_partitioned_pk NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1db01dc36b838b59bf139fed | ALTER TABLE inh_parent ADD COLUMN i int NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1f39a148e4a9a6b8e50a1dc7 | alter table part_abc attach partition part_abc_2 for values in (2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1f4ecfd3847947969fe4bb2d | ALTER TABLE fk_partitioned_fk_6 DETACH PARTITION fk_partitioned_fk_6_1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 1fdbc5bbdc459ac9f7986afd | alter table inh_nn2 alter constraint inh_nn1_f2_not_null no inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 202ad492828b44839cedb398 | ALTER TABLE temporal_fk2_mltrng2mltrng ADD CONSTRAINT temporal_fk2_mltrng2mltrng_fk FOREIGN KEY (parent_id1, parent_id2, PERIOD valid_at) REFERENCES temporal_mltrng2 (id1, id2, PERIOD valid_at) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 21603ae21f34e70a7fc73ae7 | alter table inh_nn3 alter constraint nn3_f1 inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 22536f17dd741f0b56e120d4 | ALTER TABLE has_volatile ALTER COLUMN col5 TYPE float8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 22acbcba76880e47a1a456f2 | -- attach the indexes; parents stay invalid alter index idxpart1_expr_idx attach partition idxpart11_expr_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 23be1e20f2c1221081970a08 | ALTER TABLE temporal_fk_mltrng2mltrng ADD CONSTRAINT temporal_fk_mltrng2mltrng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_mltrng (id, PERIOD valid_at) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 240d5230d4b20080d78546b0 | alter table inh_pp1 alter column f1 set not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 24b47074060cb4aa1b6508fd | -- test ALTER TABLE ADD COLUMN ALTER TABLE gtestnn_parent ADD COLUMN c int NOT NULL GENERATED ALWAYS AS (nullif(f1, 14) + nullif(f2, 10)) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 24c59f6dc91cf4b1bd0ee16b | ALTER TABLE gtest27 DROP COLUMN x, ALTER COLUMN a TYPE bigint, ALTER COLUMN b TYPE bigint, ADD COLUMN x bigint GENERATED ALWAYS AS ((a + b) * 2) VIRTUAL NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 26133be347c7f8a8deaa82bf | ALTER TABLE notnull_tbl1 ALTER COLUMN a SET NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 273b221d3011d17cc4b09d6e | -- constraints other than not-null are not supported alter table inh_nn1 alter constraint inh_nn1_f1_check inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 278a4248af1547f87f258264 | ALTER TABLE r1 ADD c int GENERATED ALWAYS AS (a * 100) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2790268378dc16ad5e95a2ab | ALTER TABLE ONLY list_parted3 DROP CONSTRAINT list_parted3_a_not_null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 28221787bd8889a6ad488a94 | -- -- partitioned FK referenced updates CASCADE -- ALTER TABLE temporal_partitioned_fk_mltrng2mltrng DROP CONSTRAINT temporal_partitioned_fk_mltrng2mltrng_fk, ADD CONSTRAINT temporal_partitioned_fk... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2895a4c47f606e97d3c4ec01 | -- error ALTER TABLE gtest25 ADD COLUMN x int GENERATED ALWAYS AS (z * 4) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 28e6bed1a0505cff09d482d0 | -- error ALTER TABLE gtestnn_parent ADD COLUMN c int NOT NULL GENERATED ALWAYS AS (nullif(f1, 13) + nullif(f2, 5)) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 29737b96fe94f04b1e9a17bf | ALTER TABLE notnull_tbl1 ADD NOT NULL a NOT VALID, ADD NOT NULL b NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2a0ec8383b0fdbee7b4cc843 | ALTER TABLE fk_notpartitioned_fk ALTER CONSTRAINT fk_notpartitioned_fk_a_b_fkey2 ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2a292f5bf6ad80f9acb80a69 | ALTER TABLE temporal_fk_rng2rng ADD CONSTRAINT temporal_fk_rng2rng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_rng ON UPDATE NO ACTION |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2a693129b2595e497062a5c0 | alter table inh_cc2 no inherit inh_cc1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2acbae57e289b99748160eab | ALTER TABLE ctl_table ALTER COLUMN b SET STORAGE MAIN |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2b7dac41b1e039ffc7ee83d0 | -- omit COLUMN ALTER TABLE test_add_column DROP IF EXISTS c6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2bf309323b734a0722eae7cb | ALTER TABLE notnull_chld0 ADD CONSTRAINT nn_chld0 NOT NULL a not valid |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2d31ecbd6f8bb8b0f57a14e4 | ALTER TABLE temporal3 DROP COLUMN valid_at |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2d6a551690fe66999082ec47 | alter table inh_pp1 alter column f1 drop not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2dea23fa2eb1840be13c743e | ALTER TABLE cnn_pk ADD CONSTRAINT cnn_primarykey PRIMARY KEY USING INDEX cnn_uq |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2e7eb0fd5f2866514ab2ed81 | ALTER TABLE temporal_fk_mltrng2mltrng ALTER CONSTRAINT temporal_fk_mltrng2mltrng_fk DEFERRABLE INITIALLY DEFERRED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 2e9cab523d73531ae65571b5 | ALTER FOREIGN TABLE IF EXISTS doesnt_exist_ft1 ADD c11 integer |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 305bfd07992f3bb65b0233d0 | alter index idxpart_expr_idx attach partition idxpart2_expr_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 30eae89d36c4b02d6d6a8b46 | ALTER TABLE vac_truncate_test RESET (vacuum_truncate) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 31387fef237b77474e2b5e52 | alter table constr_parent2 add not null a not valid |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 31e15803d78d7790a8652903 | ALTER TABLE unique_tbl ALTER CONSTRAINT unique_tbl_i_key ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 340eeb212108e3950ce43916 | ALTER TABLE ctl_stats3_parent DROP COLUMN b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 34641e008d4c18d2ab84d98a | ALTER TABLE fk_partitioned_fk_3 ATTACH PARTITION fk_partitioned_fk_3_1 FOR VALUES FROM (2000,2000) TO (3000,3000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 34ecbccfdf12debb9356a48b | ALTER TABLE atnotnull1 ADD COLUMN b INT, ADD NOT NULL b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 363a64a468e34341856e530a | -- -- range PK: test with existing rows -- ALTER TABLE temporal_rng DROP CONSTRAINT temporal_rng_pk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 372472c8d4df55f5cdd7d9b4 | ALTER TABLE atnnparted VALIDATE CONSTRAINT dummy_constr |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3a9cd422a95a76e7303fea33 | -- error ALTER TABLE notnull_tbl1 ADD CONSTRAINT nn NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3b0cd93132b9f821fab2903c | ALTER TABLE test_replica_identity3 ALTER COLUMN id DROP NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3b476cbee2da81c62f57099c | ALTER TABLE temporal3 ADD COLUMN valid_at daterange, ADD CONSTRAINT temporal3_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3c0240f62e94b2be99910336 | ALTER TABLE temporal_fk2_rng2rng ADD CONSTRAINT temporal_fk2_rng2rng_fk FOREIGN KEY (parent_id1, parent_id2, PERIOD valid_at) REFERENCES temporal_rng2 (id1, id2, PERIOD valid_at) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3d0334c33cf9a80f2769a439 | ALTER TABLE testpub_gencol REPLICA IDENTITY USING index testpub_gencol_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3d199242bdd35eafde4ec8c6 | alter table part_abc attach partition part_abc_1 for values in (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3d3f5b7ed3b7d9730369ede2 | -- Changing it back to ENFORCED will recreate the necessary FK triggers -- that are deferrable and initially deferred ALTER TABLE FKTABLE ALTER CONSTRAINT fktable_fk_fkey ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3d666f721930c97f41776b3b | -- test a self-referential FK ALTER TABLE fk_partitioned_pk ADD CONSTRAINT selffk FOREIGN KEY (a, b) REFERENCES fk_partitioned_pk NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3da0e1c87fb3b79f6f52ebb0 | ALTER TABLE temporal_fk_rng2rng ALTER CONSTRAINT temporal_fk_rng2rng_fk DEFERRABLE INITIALLY DEFERRED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 3dcc0a7e98b81d54bd97469a | ALTER TABLE fk_partitioned_pk_2 VALIDATE CONSTRAINT selffk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 40171ad8ce4d016811e27563 | ALTER TABLE ctl_stats4_parent DROP COLUMN b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 41ea983a45ad6b4088060d07 | alter table cnn_uq add unique using index cnn_uq_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 43291babf079b179bf8db2bc | -- cannot set column as generated-as-identity if it has an invalid not-null ALTER TABLE notnull_tbl1 ALTER COLUMN a ADD GENERATED ALWAYS AS IDENTITY |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 451d0194dbc823e5ef602865 | -- -- multirange PK: test with existing rows -- ALTER TABLE temporal_mltrng DROP CONSTRAINT temporal_mltrng_pk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 48f95258ac52a76138a58e62 | ALTER TABLE ONLY notnull_tbl6 ALTER b DROP NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 49f11d482196f20ddb785daa | -- DROP NOT NULL gets rid of both the attnotnull flag and the constraint itself ALTER TABLE notnull_tbl1 ALTER a DROP NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4a05fb3c4e0e639be729567b | -- allowed to merge enforced constraint with parent's not enforced constraint alter table p1_c1 add constraint inh_check_constraint5 check (f1 < 10) enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4b9c855bccee740d11dd9a0a | ALTER TABLE atnnpart1 ADD CONSTRAINT another_constr NOT NULL id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4bfa29fd196ccdc0a721217f | ALTER FOREIGN TABLE agg_bad OPTIONS (ADD log_verbosity 'silent') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4cae1aa9d5af98658396f8b0 | -- -- partitioned FK referenced updates CASCADE -- ALTER TABLE temporal_partitioned_fk_rng2rng DROP CONSTRAINT temporal_partitioned_fk_rng2rng_fk, ADD CONSTRAINT temporal_partitioned_fk_rng2rng_fk ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4d7f053da45acdc6ae93fd4f | -- fails on existing row ALTER TABLE gtest20a ADD COLUMN c float8 DEFAULT random() CHECK (b < 61) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4dac7d086116478a17cd72c5 | -- omit COLUMN ALTER TABLE test_add_column ADD IF NOT EXISTS c6 integer |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4dbef5b2e9f2e3df42dbe157 | -- cannot add primary key on a column with an invalid not-null ALTER TABLE notnull_tbl1 ADD PRIMARY KEY (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4e435ac6f2c8d6791aafb932 | -- error - generated column "b" must be published explicitly as it is -- part of the REPLICA IDENTITY. ALTER TABLE testpub_gencol REPLICA IDENTITY FULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4f402d401a31c18493ad2246 | ALTER TABLE gtest24at ADD COLUMN b gtestdomain1 GENERATED ALWAYS AS (a * 2) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 4f801b6f5d679c7169d23b23 | alter table p1 add constraint inh_check_constraint7 check (f1 < 10) enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 519d6ffae284162848387e28 | ALTER TABLE has_volatile ADD col7 int GENERATED ALWAYS AS (55) stored |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 519e0ea0701176ec67557ccd | alter table p1 add constraint inh_check_constraint8 check (f1 < 10) enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5258e224a534d54d52c307ad | ALTER TABLE ONLY list_parted3 ADD PRIMARY KEY (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5321baeb76416f00d64749a1 | ALTER TABLE ctlt1 ADD CONSTRAINT cc CHECK (length(b) > 100) NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 54b23e4ee4ac98229489cc1f | ALTER TABLE fk_r DROP CONSTRAINT fk_r_p_id_p_jd_fkey_1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 57707efcb155720e1e649dd5 | ALTER TABLE comment_test ALTER COLUMN id SET DATA TYPE int COLLATE "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 57f3996ed0811c829cafa806 | -- Validate the constraint ALTER TABLE fk_partitioned_fk VALIDATE CONSTRAINT fk_partitioned_fk_a_b_fkey |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 59137ef36743829e8557d3de | alter table p1_c1 inherit p1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5943bfa4e1c4c6e45eaa6780 | -- Ensure that the virtual generated columns in ALTER COLUMN TYPE USING expression are expanded alter table gtest32 alter column e type bigint using b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5a9c025c018f95e89b6357a4 | ALTER TABLE temporal_rng3 DROP CONSTRAINT temporal_rng3_pk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5aade7a14ebbc423376e3a4c | -- dropping the NO INHERIT constraint allows this to work ALTER TABLE ATACC2 DROP CONSTRAINT a_is_not_null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5b61e13592b0abf64c0e4405 | ALTER TABLE temporal3 ADD CONSTRAINT temporal3_uq UNIQUE USING INDEX idx_temporal3_uq |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5b7064b650193f8b57bfe25c | ALTER TABLE inh_nn_lvl1 ADD PRIMARY KEY (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5c0c4cd11f45706503d398e7 | ALTER TABLE comment_test ALTER COLUMN id SET DATA TYPE x |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5c44d98009cf0811fac98f1f | -- change child constraint ALTER TABLE fk_partitioned_fk_2 ALTER CONSTRAINT fk_part_con ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5d1ddaaa547310ff0f60d507 | -- remove constraint from cc2: no dice, it's inherited alter table cc2 alter column a2 drop not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5de1ec9196b8e15757722adf | ALTER TABLE notnull_tbl3 ALTER A DROP NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 5e021a1f5ec7c6f533dfccee | ALTER TABLE notnull_tbl1 ALTER CONSTRAINT nntbl1_a NO INHERIT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 6033ec9ee0d5ec1cb578da09 | ALTER FOREIGN TABLE ft1 ADD c11 integer |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 61b3d703548c0d83e58b3002 | -- but it's OK when the identity is FULL ALTER TABLE test_replica_identity3 REPLICA IDENTITY FULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 61c80e86413f9f387952f6fc | -- error ALTER TABLE gtest25 ADD COLUMN c int DEFAULT 42, ADD COLUMN x int GENERATED ALWAYS AS (c * 4) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 633d32e11c011b4f4fd46a6c | alter table p1_c1 add constraint inh_check_constraint8 check (f1 < 10) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 63ea10d1160017d03e0b5fed | -- this must be rejected to avoid self-inclusion issues: alter type two_ints add attribute c two_ints_multirange |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 64ebfca5dc6dcb2c0237fad7 | -- Changing the constraint to NOT ENFORCED drops the associated FK triggers ALTER TABLE FKTABLE ALTER CONSTRAINT fktable_fk_fkey NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 653564a7c1420347e430acb4 | alter table inh_child no inherit inh_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 661b245b78484ccf768feb76 | ALTER TABLE gtest25 ALTER COLUMN d SET DATA TYPE float8, ADD COLUMN y float8 GENERATED ALWAYS AS (d * 4) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 661e1b42cf7d559167c93144 | -- ALTER column SET NOT NULL validates an invalid constraint (but this fails -- because of rows with null values) ALTER TABLE notnull_tbl1 ALTER a SET NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 663512011f79791a856b1372 | ALTER TABLE notnull_tbl2 ALTER a DROP NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 675b3e52d837ce78688fed33 | alter table p1 add constraint inh_check_constraint9 check (f1 < 10) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 67b41ec7ebd0ce811dd64324 | ALTER TABLE ONLY notnull_tbl5 DROP CONSTRAINT ann |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 6c03824af775e5f45e023075 | ALTER TABLE temporal3 ADD CONSTRAINT temporal3_pk PRIMARY KEY USING INDEX idx_temporal3_uq |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 6dcd4929513a1b071f812d81 | -- It's possible to alter the column types this way: ALTER TABLE gtest27 DROP COLUMN x, ALTER COLUMN a TYPE bigint, ALTER COLUMN b TYPE bigint, ADD COLUMN x bigint GENERATED ALWAYS AS ((a + b) * 2)... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 6f89d5897f725689748a04de | ALTER TABLE temporal_fk_rng2rng ADD CONSTRAINT temporal_fk_rng2rng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_rng ON DELETE RESTRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 702a068bc4d403a5e941d1c3 | ALTER TABLE temporal3 DROP COLUMN valid_thru |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 7036bb12df4b14afe53184b0 | ALTER TABLE inh_nn_parent ADD CONSTRAINT nna NOT NULL a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 7049801cfc1e21e3a268b641 | ALTER TABLE notnull_tbl1_child2 INHERIT notnull_tbl1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 704c4a1d8df86926b27fc69c | ALTER FOREIGN TABLE IF EXISTS doesnt_exist_ft1 DROP c11 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 704d905358d9d5501f0c7197 | ALTER TABLE notnull_tbl1 DROP CONSTRAINT notnull_tbl1_b_not_null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 70a126bddb1db507a2591b92 | ALTER TABLE notnull_tbl1 DROP CONSTRAINT nntbl1_a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 71249aa70fcd6673c87dd74b | alter table inh_child inherit inh_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 72fc8736d6467824f7cbb7e9 | alter table p1_c1 add constraint inh_check_constraint4 check (f1 < 10) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 746a19b9bce6b5b62ee2ab0c | ALTER TABLE test_replica_identity5 ALTER b SET NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 74a16a00b52cd468b396c7c2 | alter table inh_nn1 alter constraint inh_nn1_pkey inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 753b2c3fc2d93cb476cd5c11 | ALTER TABLE notnull_tbl1 ATTACH PARTITION notnull_tbl1_2 FOR VALUES IN (3,4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 75a0e73616b311ed96d038f2 | ALTER TABLE temporal3 ALTER COLUMN valid_at DROP NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 762f79420be3eafbeeaa54fa | alter table inh_nn2 inherit inh_nn1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 7790ffe0d97c082407041f95 | alter table p1 add constraint inh_check_constraint4 check (f1 < 10) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 792bfa83144c849366cced48 | ALTER TABLE ONLY pp_nn ADD PRIMARY KEY (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 7b1247df07f05b13ad231a2f | ALTER TABLE notnull_inhchild ADD CONSTRAINT nn1 NOT NULL i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 7b6bb21a5b040723be849834 | ALTER TABLE pg_toast.pg_toast_2615 SET (fillfactor = '90') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 7d5bcd83c78da7f68afcba5e | ALTER TABLE gtest20c ADD CONSTRAINT whole_row_check CHECK (gtest20c IS NOT NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 7e8ef9066d0620c524107103 | -- the not-valid state of the child constraint will be ignored here. alter table p1 add constraint inh_check_constraint10 check (f1 < 10) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 7f15f9edb5af164ba7030c9e | -- doesn't exist in referenced table ALTER TABLE fk_partitioned_fk_2 ADD FOREIGN KEY (a, b) REFERENCES fk_notpartitioned_pk NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 809d8f0f51bd87e39c1e8559 | ALTER FOREIGN TABLE IF EXISTS doesnt_exist_ft1 DROP COLUMN no_column |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 81fec91e6288b91b4ef2ba41 | ALTER TABLE gtest21ax ADD CONSTRAINT cc NOT NULL b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 83d905100c7541b2ca8410ac | ALTER TABLE atnnparted ADD CONSTRAINT dummy_constr NOT NULL id NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 86623fa2a5a0390ffcb27702 | ALTER TABLE fk_partitioned_fk_3_1 ADD FOREIGN KEY (a, b) REFERENCES fk_notpartitioned_pk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 86c9a75bb873bf9cd933ab18 | ALTER TABLE pp_nn_1 ADD CONSTRAINT nn NOT NULL a NO INHERIT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 87d49b1d8fee2fc8000b7f01 | ALTER TABLE fk_partitioned_fk ADD CONSTRAINT fk_partitioned_fk_a_b_fkey FOREIGN KEY (a, b) REFERENCES fk_notpartitioned_pk NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 8a2b5b6a35cb6d0c5e471337 | ALTER TABLE temporal_fk_mltrng2mltrng ADD CONSTRAINT temporal_fk_mltrng2mltrng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_mltrng (id, PERIOD valid_at) ON UPDATE NO ACTION |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 8ade8c3f13ea097754bc35b9 | -- -- partitioned FK referenced deletes SET NULL -- -- -- partitioned FK referenced updates SET DEFAULT -- ALTER TABLE temporal_partitioned_fk_rng2rng ALTER COLUMN parent_id SET DEFAULT '[-1,-1]', ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 8b3062f171ea3aa0506bd286 | ALTER TABLE notnull_child_upg ADD CONSTRAINT nn NOT NULL a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 8b66ab8343d94baa9f931148 | ALTER TABLE regular_table DETACH PARTITION any_name FINALIZE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 8c854a0f491e6016674decb0 | alter table inh_child1 no inherit inh_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 8d915d158baf2ba6280b7287 | ALTER TABLE temporal_fk_mltrng2mltrng ADD CONSTRAINT temporal_fk_mltrng2mltrng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_mltrng (id, PERIOD valid_at) ON UPDATE RESTRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 8ed6cd09189ed1da6078fec5 | --error ALTER TABLE pp_nn_1 VALIDATE CONSTRAINT nn1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 8f45a571a8cecf3f2cef3308 | alter table t2 alter column z drop not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 903ef34fc2b1323e7a36448f | -- nope ALTER TABLE notnull_tbl1_child2 ADD NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9133c0d1e995c5c1320077c3 | -- Make the column NOT NULL and ensure we remove the redundant column alter table t2 alter column z set not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 914703b53eb8e2996ea25b92 | ALTER TABLE temporal_fk_rng2rng ADD CONSTRAINT temporal_fk_rng2rng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_rng (id, PERIOD valid_at) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9377e59a84775a9e3862a287 | alter table inh_nn1 alter constraint inh_nn1_f1_fkey inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 93eff720b27b163eb9f4e8f3 | alter table p1_c1 add constraint inh_check_constraint6 check (f1 < 10) enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 940c7e8897836825ee27b563 | alter table inh_nn4 inherit inh_nn2, inherit inh_nn1, inherit inh_nn3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9496de36a39b4a3993eb1571 | ALTER TABLE fk_partitioned_fk ALTER CONSTRAINT fk_partitioned_fk_a_b_fkey ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 94bafb8c5482cbbf46002d73 | ALTER TABLE notnull_tbl1 ADD CONSTRAINT nn_parent NOT NULL a not valid |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 95014ba9b6c16943f3448d73 | alter table inh_parent add constraint inh_parent_fk foreign key (a) references inh_parent (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 956a6f1973ac2c1de6111650 | ALTER TABLE notnull_tbl1 ADD CONSTRAINT notnull_con NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9579aa03f89dfd8242b5303e | -- -- partitioned FK referenced deletes CASCADE -- -- -- partitioned FK referenced updates SET NULL -- ALTER TABLE temporal_partitioned_fk_mltrng2mltrng DROP CONSTRAINT temporal_partitioned_fk_mltr... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 96f2eaa6b750d5accdeb01e2 | -- A constraint that's NO INHERIT can be dropped without damaging children alter table inh_nn1 drop constraint inh_nn1_f1_not_null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 981aea3a7d4dce87e2576179 | ALTER TABLE FKTABLE ALTER CONSTRAINT fk_con NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 99952a2e70945905f935b1da | -- Modifying other attributes of a constraint should not affect its enforceability, and vice versa ALTER TABLE FKTABLE ADD CONSTRAINT fk_con FOREIGN KEY(ftest1, ftest2) REFERENCES PKTABLE NOT VALID... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 99c29c7f48328ec96cc4e03e | ALTER TABLE notnull_tbl1_upg ADD CONSTRAINT nn NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9b1ffa3f12df2aa96ef0c1e1 | -- fails on existing row -- table rewrite cases ALTER TABLE gtest20a ADD COLUMN c float8 DEFAULT random() CHECK (b < 50) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9c454c2b30f9ae6777898575 | ALTER TABLE notnull_tbl3 ADD b int, ADD CONSTRAINT pk PRIMARY KEY (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9c572e54f5c3716bd8343112 | ALTER TABLE temporal_fk_mltrng2mltrng DROP CONSTRAINT temporal_fk_mltrng2mltrng_fk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9c9c892c12311282842c63cd | ALTER TABLE foo_parted ATTACH PARTITION foo_part_d2 FOR VALUES IN (4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9d9872ce93721df0aa913cfc | -- remove from pp1, should succeed alter table pp1 alter column f1 drop not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9e04b79998c033cdd582994b | ALTER TABLE fk_partitioned_fk ALTER CONSTRAINT fk_partitioned_fk_a_b_fkey NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9e073e4dd9811fbdaf4fbd38 | alter table p1 add constraint inh_check_constraint3 check (f1 > 0) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9f8ee0a181ad1b9034d172a8 | ALTER FOREIGN TABLE ft1 ADD COLUMN IF NOT EXISTS c6 integer |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9faf5dcf18430aa79143d181 | alter table cnn_uq add unique (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a0062d2a7f36a7a023d3c40d | ALTER TABLE test_replica_identity5 REPLICA IDENTITY USING INDEX test_replica_identity5_a_b_key |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a186a0d5f0cdc2d3714513c4 | ALTER TABLE has_volatile ADD col5 int GENERATED ALWAYS AS (tableoid::int + col2) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a1adad7c436f7d92fe8f9540 | ALTER TABLE gtest_tableoid ADD COLUMN c regclass GENERATED ALWAYS AS (tableoid) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a2db0b60d64b1173f39a41b1 | -- but using a different constraint name is not allowed ALTER TABLE notnull_tbl1 ADD CONSTRAINT nn NOT NULL a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a33e215bef80733a3acd4501 | alter table inh_nn1 alter constraint inh_nn1_f1_not_null inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a364b125a34dc530de348acf | ALTER TABLE temporal_mltrng ADD CONSTRAINT temporal_mltrng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a53840d757210314bb0cba62 | ALTER TABLE temporal_fk_rng2rng ALTER COLUMN valid_at TYPE daterange USING daterange(lower(valid_at)::date, upper(valid_at)::date) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a5c4cbcb1fb6d90ab05d9371 | alter table pp1 alter f1 set not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a90b77f90b96b95b6943ebdc | ALTER TABLE notnull_part1_upg ATTACH PARTITION notnull_part1_2_upg FOR VALUES IN (3,4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a95a78986607636e497ca8fe | ALTER TABLE foo_parted ATTACH PARTITION foo_part_d1 FOR VALUES IN (3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a972c645f4744e3eda6cd86d | -- fails ALTER TABLE unlogged1 SET UNLOGGED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | a99461f2e03d8a9d92bc8625 | ALTER TABLE test_replica_identity5 DROP CONSTRAINT test_replica_identity5_pkey |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | aa4870d01a8ae1e81d5acccb | ALTER TABLE test_replica_identity5 ALTER b DROP NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | aac7b9da3a9e2b743f0d4ef3 | -- remove constraint from cc1, should succeed alter table cc1 alter column a2 drop not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | ac90b987fb42dbbac4748c69 | ALTER TABLE notnull_tbl1 ADD CONSTRAINT nntbl1_a NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | ad22cba290238275ce7cc4f6 | -- should fail because of duplicate referenced columns: ALTER TABLE temporal_fk_rng2rng ADD CONSTRAINT temporal_fk_rng2rng_fk2 FOREIGN KEY (parent_id, PERIOD parent_id) REFERENCES temporal_rng (id,... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | ad4e7709a37b31a7ec7612db | alter table part_abc add d int |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | ad7b4692c8492a69b0fe9ac3 | ALTER TABLE ONLY notnull_tbl5 ALTER b DROP NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | ae1c9e7d2cded1c879d31c7f | ALTER TABLE fk_notpartitioned_fk ADD CONSTRAINT fk_notpartitioned_fk_a_b_fkey FOREIGN KEY (a, b) REFERENCES fk_partitioned_pk NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | aeab454b756f85bc6fc0d6cc | -- inh_child1 should have not null constraint alter table inh_child1 inherit inh_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | afcb4b2f9c2a83f3c57de0b3 | ALTER TABLE pp_nn_1 ADD CONSTRAINT nn NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b00a731098108bcfc499d9e3 | -- ALTER CONSTRAINT NO INHERIT should work on top-level constraints alter table inh_nn1 alter constraint inh_nn1_f1_not_null no inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b00db4ca5108a4f768ec42f6 | ALTER FOREIGN TABLE IF EXISTS doesnt_exist_ft1 ADD COLUMN IF NOT EXISTS c6 integer |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b023832199e29669a483d567 | ALTER TABLE temporal_fk_rng2rng ADD CONSTRAINT temporal_fk_rng2rng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_rng ON DELETE SET NULL ON UPDATE SET NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b1b94501b997bea3300eec22 | ALTER TABLE fk_partitioned_fk_2 ADD CONSTRAINT fk_partitioned_fk_a_b_fkey FOREIGN KEY (a, b) REFERENCES fk_notpartitioned_pk NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b3355931d7524216733e7bdd | ALTER TABLE temporal_fk_rng2rng ADD CONSTRAINT temporal_fk_rng2rng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b3360e83ab31f44f2ef3c8b8 | ALTER TABLE t ADD COLUMN j int |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b3c13fbaf6c796cd149403f5 | alter table inh_nn_parent add not null a no inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b3d28a3311d6af9857ea7cf3 | -- succeeds ALTER TABLE attmp3 VALIDATE CONSTRAINT b_greater_than_ten_not_enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b474c154cb01b958a79379bd | --ok -- SET EXPRESSION supports not null constraint ALTER TABLE gtest21ax ALTER COLUMN b SET EXPRESSION AS (nullif(a, 1)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b4c878a4e194b7a722d6b116 | ALTER TABLE gtest25 ADD COLUMN x int GENERATED ALWAYS AS (b * 4) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b5b79595276e2a69db417239 | ALTER FOREIGN TABLE agg_bad OPTIONS (SET reject_limit '2') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b704e4f7404ea84c227e2bb6 | ALTER TABLE temporal_fk_rng2rng ALTER COLUMN parent_id SET DEFAULT '[-1,-1]', ADD CONSTRAINT temporal_fk_rng2rng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_rng ON DELETE SET DE... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b7831adc966f966c3e12a309 | -- Enforceability also changes the validate state, as data validation will be -- performed during this transformation. ALTER TABLE FKTABLE ALTER CONSTRAINT fk_con ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b8a8efdcc16c8706b5e55114 | alter table inh_parent add constraint inh_parent_excl exclude ((1) with =) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | b94d59bf591c9cb9196fdc87 | -- named NOT NULL constraint alter table cc1 add column a2 int constraint nn not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | bb4a09fe660ea08e0c564454 | ALTER TABLE fk_partitioned_fk_1 ADD FOREIGN KEY (a, b) REFERENCES fk_notpartitioned_pk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | bbfca31b24fe274efe154db3 | alter table inh_child2 no inherit inh_parent2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | bc845f94c5cf4831ce511459 | -- change NO INHERIT status of inherited constraint: no dice, it's inherited alter table cc2 add not null a2 no inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | bca6bf4385beeb641639812b | ALTER INDEX gin_check_idx SET (fastupdate = false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | beac01c79c98d677cf79c884 | ALTER TABLE fktable ALTER CONSTRAINT fktable_fk_fkey NO INHERIT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | bfec250d0add6cbb4be0f119 | ALTER TABLE ctl_table ADD CONSTRAINT foo CHECK (b = 'text') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | c31ed7af4cad8dd01bfbaa75 | alter table inh_child2 alter column f1 set not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | c35ae23a6b60a168d9eea4fc | ALTER TABLE temporal_rng3 DROP CONSTRAINT temporal_rng3_uq |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | c3997bc6c8d56f782f7e1aa4 | alter table constr_child validate constraint constr_parent_a_not_null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | c3ca66159f44a0afb30de1e2 | -- should fail, missing NOT NULL constraint alter table inh_child2 inherit inh_child1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | c4058bb7449ca41162ce33ec | -- can't override ALTER TABLE ATACC1 ADD CONSTRAINT ditto NOT NULL a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | c75ac7a8df9cc65b9075bc84 | -- this should work alter table renameColumn add column x int check (x > 0) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | c7ab33bac89d1e8a96d655c1 | ALTER TABLE notnull_inhparent ALTER i SET NOT NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | c7ce37a6cb2cd3149be29758 | ALTER TABLE fk_partitioned_fk_3 ADD FOREIGN KEY (a, b) REFERENCES fk_notpartitioned_pk NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | c8622a537ce1a8ccdfed3e4d | -- Reverting it back to ENFORCED will result in failure because constraint validation will be triggered, -- as it was previously in a valid state. ALTER TABLE FKTABLE ALTER CONSTRAINT fktable_ftest... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | caec240e30f6e298188000ec | alter table p1 add constraint inh_check_constraint6 check (f1 < 10) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | ccf768dcfce1a239d1fd3597 | ALTER FOREIGN TABLE agg_bad OPTIONS (ADD reject_limit '1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | cd5931a7f105a0a7212a827e | ALTER TABLE test_tsvector SET (parallel_workers = 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | cd5e3bdf111057ed424641a6 | ALTER TABLE ref ALTER CONSTRAINT ref_f1_f2_fkey_1 DEFERRABLE INITIALLY DEFERRED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | cd712fe63372085985c061f6 | ALTER TABLE gtest24ata ALTER COLUMN b TYPE gtestdomain1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d01009f6b97192cc905aab45 | --error ALTER TABLE notnull_chld0 DROP CONSTRAINT nn_chld0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d0a547c455e00f85e294fc8e | ALTER TABLE fk_partitioned_fk_6 ATTACH PARTITION fk_partitioned_fk_6_1 FOR VALUES IN (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d145170c3b7ba138f99fda3e | ALTER TABLE has_volatile ALTER COLUMN col5 TYPE numeric |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d2251e1184bb31cc108a6e1e | ALTER TABLE pp_nn_1 ADD CONSTRAINT nn1 NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d2b6bac461bc6093d9b87d49 | ALTER TABLE notnull_tbl1 INHERIT notnull_chld0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d5231864c811f25839b647c6 | ALTER TABLE cnn_pk ADD CONSTRAINT cnn_primarykey PRIMARY KEY (b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d5296fbf49f916c984a67134 | -- but reverse is not allowed alter table p1_c1 add constraint inh_check_constraint7 check (f1 < 10) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d586b00f9204fda83e76246c | ALTER TABLE temporal3 ADD COLUMN valid_at daterange, ADD CONSTRAINT temporal3_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d63618514484f0d27915bf31 | ALTER TABLE notnull_tbl1 ATTACH PARTITION notnull_tbl1_3 FOR VALUES IN (NULL,5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d64bec5a84483a4ac576deaf | ALTER TABLE temporal_rng3 ADD CONSTRAINT temporal_rng3_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d6875c6a51fdb665f0c8b6ee | ALTER TABLE list_parted ATTACH PARTITION part_fail FOR VALUES IN (2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d6f25e593fb67c2079f8a727 | ALTER TABLE FKTABLE ALTER CONSTRAINT fk_con DEFERRABLE INITIALLY DEFERRED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d6ff511c971abeaf1bce26ed | -- VALIDATE CONSTRAINT scans the table ALTER TABLE notnull_tbl1 VALIDATE CONSTRAINT nn |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d740bdf024208bfc9f6472f7 | alter table constr_child2 validate constraint constr_parent2_a_not_null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d8c3f540acb77df6dae93529 | ALTER TABLE temporal3 DROP COLUMN valid_at CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | d952999c60a543a6617024af | ALTER TABLE pp_nn ATTACH PARTITION pp_nn_1 FOR VALUES IN (NULL,5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | dabddb74f2623bf417ca75b8 | -- -- partitioned FK referenced deletes CASCADE -- -- -- partitioned FK referenced updates SET NULL -- ALTER TABLE temporal_partitioned_fk_rng2rng DROP CONSTRAINT temporal_partitioned_fk_rng2rng_fk... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | db5ea3c3501c35204c4a642a | ALTER TABLE testjsonb SET (parallel_workers = 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | db64ec2334f6dbb67fab04ad | -- -- partitioned FK referenced deletes SET NULL -- -- -- partitioned FK referenced updates SET DEFAULT -- ALTER TABLE temporal_partitioned_fk_mltrng2mltrng ALTER COLUMN parent_id SET DEFAULT '[0,1... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | dba4d2a9263b4e82b25feac9 | ALTER TABLE atnnpart1 ADD PRIMARY KEY (id) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | dbba17f1866801cd77b4f892 | ALTER TABLE notnull_part1_3_upg add CONSTRAINT nn3 NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | dbbae83ff739842cbf00653c | -- try to drop a nonexistant constraint alter table inh_nn1 alter constraint foo inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | dccac0246aaa8fcf541744b7 | ALTER TABLE notnull_tbl1_3 add CONSTRAINT nn3 NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | de99144a7e1a8ab536dd5be5 | --table rewrite won't validate invalid constraint ALTER TABLE notnull_tbl1 ADD column d float8 default random() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | dfaf51924c8ab5a6617f6bd3 | ALTER TABLE temporal_rng ADD CONSTRAINT temporal_rng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | e0113d5010bcb340b272ed55 | -- error ALTER TABLE gtestnn_parent ADD COLUMN c int NOT NULL GENERATED ALWAYS AS (nullif(f1, 4) + nullif(f2, 6)) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | e1c61e5c7258fd8c4945aa6e | ALTER TABLE notnull_tbl1 ADD CONSTRAINT foobar NOT NULL a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | e1d819345898d2836a0c5939 | -- ERROR -- on_error, log_verbosity and reject_limit tests ALTER FOREIGN TABLE agg_bad OPTIONS (ADD on_error 'ignore') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | e207880d7f626258a3c8965b | ALTER TABLE test_add_column ADD c6 integer |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | e58cc6960966c696a77d7cf1 | ALTER TABLE ONLY notnull_tbl6 DROP CONSTRAINT ann |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | e7fda49144b0bd2b12f930a8 | ALTER TABLE notnull_inhparent ADD CONSTRAINT nn NOT NULL i NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | e84098148cc3d0491d94556e | --now ok -- parents and child not-null will all be validated. ALTER TABLE notnull_tbl1 VALIDATE CONSTRAINT nn_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | e887911d735bb9cc81946bc3 | alter table p1_c1 add constraint inh_check_constraint3 check (f1 > 0) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | ea04f7b86fd3cb9784e6e2d0 | alter table constr_parent add not null a not valid |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | ea7ccae00c8980648021a8ea | alter table cc3 no inherit cc2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | eaca3ca57172d0acda441afe | ALTER TABLE has_volatile ALTER COLUMN col1 SET DATA TYPE float8, ADD COLUMN col6 float8 GENERATED ALWAYS AS (col1 * 4) VIRTUAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | ef181a9c0e0f7ea5d400e442 | alter index idxpart_expr_idx attach partition idxpart1_expr_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | efec3493910630d8a78d1c30 | ALTER TABLE temporal_fk_rng2rng ADD CONSTRAINT temporal_fk_rng2rng_fk FOREIGN KEY (parent_id, PERIOD valid_at) REFERENCES temporal_rng ON DELETE CASCADE ON UPDATE CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | f1a51da1b1f364c9fbfe97f8 | ALTER TABLE temporal3 ALTER COLUMN valid_at TYPE tstzrange USING tstzrange(lower(valid_at), upper(valid_at)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | f1c5bd0ed2bd9569fc2c671d | ALTER TABLE temporal_mltrng3 ADD CONSTRAINT temporal_mltrng3_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | f318db23984d00fd50b675df | -- Can change enforceability and deferrability together ALTER TABLE FKTABLE ALTER CONSTRAINT fk_con NOT ENFORCED NOT DEFERRABLE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | f31b1a061345c0e94a212a0f | alter table cnn_pk add primary key (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | f528f1bae131d62b4a0738ac | ALTER TABLE gtest25 ADD COLUMN b int GENERATED ALWAYS AS (a * 2) VIRTUAL, ALTER COLUMN b SET EXPRESSION AS (a * 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | f635ebcc747c6c85b3333c9a | -- error ALTER TABLE gtestnn_parent ALTER COLUMN f3 SET EXPRESSION AS (nullif(f1, 2) + nullif(f2, 11)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | f64203351c54f46ab7f4bb27 | ALTER TABLE unique_tbl ALTER CONSTRAINT unique_tbl_i_key NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | f950d97b5bd831ed0917f5f8 | alter table p1 add constraint inh_check_constraint5 check (f1 < 10) not enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | fb6093628d03b0d9e0d31126 | alter table inh_nn1 -- test multicommand alter table while at it alter constraint inh_nn1_f1_not_null inherit, alter constraint inh_nn1_f1_not_null no inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | fc9e733f289135904bf23d98 | ALTER TABLE notnull_part1_upg ADD CONSTRAINT notnull_con NOT NULL a NOT VALID |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | fd8268882b0e1ab08b1a280e | ALTER TABLE fk_notpartitioned_fk VALIDATE CONSTRAINT fk_notpartitioned_fk_a_b_fkey |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | fe7f771bbb15028584cf3eb5 | alter table p1_c1 add constraint inh_check_constraint10 check (f1 < 10) not valid enforced |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | fe98762f7a5d241996f44dbd | ALTER TABLE ATACC2 INHERIT ATACC1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_TYPE_STMT | ad47ecc2003e91f9faafa17e | -- Switch type to use typanalyze function that always returns false. ALTER TYPE int_custom SET (ANALYZE = int_custom_typanalyze_false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_USER_MAPPING_STMT | 1171d6336f3aefdaf9ec6922 | ALTER USER MAPPING FOR public SERVER fdtest OPTIONS (ADD oauth_client_id 'myID') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_USER_MAPPING_STMT | 2439b4088c15fa8e7df88211 | ALTER USER MAPPING FOR public SERVER testserver1 OPTIONS (ADD oauth_client_id 'myID') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_USER_MAPPING_STMT | 9bb50f4e25b2f3cfec568b79 | ALTER USER MAPPING FOR public SERVER testserver1 OPTIONS (ADD oauth_issuer 'https://example.com') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_ALTER_USER_MAPPING_STMT | f9a46643cb73c83a3031250c | ALTER USER MAPPING FOR public SERVER fdtest OPTIONS (ADD oauth_issuer 'https://example.com') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CLOSE_PORTAL_STMT | e48d8167537f191de4d18183 | CLOSE foocur |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | 11ea15496c79bb15392f01fe | COMMENT ON CONSTRAINT noinh_con_copy_b_not_null ON noinh_con_copy IS 'not null b' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | 20f13bc0922141049778d093 | COMMENT ON ROLE regress_hasprivs IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | 3e1ba0c8f169f87bdebb6892 | COMMENT ON TRIGGER before_ins_stmt_trig ON main_table IS 'right' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | 5c41e182ec10e8a38f8625fb | COMMENT ON ROLE regress_hasprivs IS 'add the comment back' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | 5ec9614174206a3f298c4397 | COMMENT ON CONSTRAINT ctlt2_c_not_null ON ctlt2 IS 't2_c_not_null' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | 982f88c7307861d4d5aea881 | COMMENT ON ROLE regress_hasprivs IS '' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | ac41bd38a7ac14bc1eddd580 | COMMENT ON INDEX six IS '' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | aca6c17a86bc3d15abd142a1 | COMMENT ON CONSTRAINT id_notnull_constraint ON comment_test IS 'NOT NULL constraint of comment_test' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | c95391ee67cf943339da9d78 | COMMENT ON CONSTRAINT constr_parent2_a_not_null ON constr_parent2 IS 'this constraint is invalid' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | dd1ce9751ffe10465adf16db | COMMENT ON CONSTRAINT constr_parent2_a_not_null ON constr_child2 IS 'this constraint is valid' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | e9e65be2ee0154b5f354aa65 | COMMENT ON CONSTRAINT noinh_con_copy_c_not_null ON noinh_con_copy IS 'not null c no inherit' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | ef3ea496c755e3812512b177 | COMMENT ON COLUMN ctl_table.b IS 'Column b' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | f0c015e0b2d466fee59ee41b | COMMENT ON TRIGGER before_ins_stmt_trig ON main_table IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | f29feef8f0ba526dcba191e8 | -- Test comments COMMENT ON TRIGGER no_such_trigger ON main_table IS 'wrong' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMMENT_STMT | f3a40852abb572ecbfd907f3 | COMMENT ON INDEX six IS 'add the comment back' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMPOSITE_TYPE_STMT | 6f6d83837db29e642e88fcf7 | -- A unique index proves uniqueness only under its own opfamily. When the -- GROUP BY's eqop comes from a different opfamily with looser equality, -- rows the index regards as distinct can collapse... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COMPOSITE_TYPE_STMT | 77511ad1eb4e3e5793c41f94 | CREATE TYPE stats_import.complex_type AS ( a integer, b real, c text, d date, e jsonb) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COPY_STMT | 1475c728aa1794e583fd35ba | -- Generate COPY FROM report with PIPE, with some skipped tuples. copy tab_progress_reporting from stdin(on_error ignore) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COPY_STMT | 2ff6b47ecda07e755810cd52 | copy copytest2(test) from stdin |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COPY_STMT | 36bf0bd279e5f38736075f82 | COPY (SELECT 1 UNION SELECT 2) TO stdout |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COPY_STMT | 434a02676f44fe8035e084f7 | COPY copytest_mv(id) TO stdout WITH (header) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_COPY_STMT | 8f4f3ef49a411ec2f564a7e3 | copy copytest_foreign_table from stdin (freeze) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 0f385652a867e96c2baca731 | create domain d_fail int4 collate "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 103c06014c892461d8f69982 | CREATE DOMAIN constraint_enforced_dom AS int |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 34200b1141f40bde1e02b50b | CREATE DOMAIN constraint_not_enforced_dom AS int CONSTRAINT the_constraint CHECK (value > 0) NOT ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 495665e12d30f738f6959927 | create domain d_fail as int4 constraint cc check (values > 1) no inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 6af7db6ecb23b3f356806c80 | create domain d_fail int4 DEFAULT 3 + 'h' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 6b571de89a86073ac21b3038 | create domain d_fail as int4 not null null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 74d6a4a237726fbbf7dbd1d1 | create domain d_fail as int4 PRIMARY key |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 7cf47a080d4b3bb178be3310 | create domain d_fail as int4 not null default 3 default 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 82ea7bb2ae08a8f2bdf322f7 | create domain d_fail as int4 constraint cc generated by default as identity |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 840846424c4d55fd4de15bfd | -- -- test PRIMARY KEY and UNIQUE constraints' interaction with domains -- -- range over domain: CREATE DOMAIN int4_d as integer check (value <> 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 8afd3aa139349389493d91f8 | create domain d_fail as int4 constraint cc check (values > 1) deferrable |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 8bf49de34752f743f40e27d0 | create domain d_fail as int4 not null no inherit |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | 94856a738778dea0578a6bb9 | -- disallow duplicated not-null constraints create domain int_domain1 as int constraint nn1 not null constraint nn2 not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | a3a6769566fea267d4dbec33 | -- -- Explicit enforceability specification not allowed --- CREATE DOMAIN constraint_enforced_dom AS int CONSTRAINT the_constraint CHECK (value > 0) ENFORCED |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | ad58ccaa274db9afe8772781 | create domain d_fail as anyelement |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | ba4a7a3b4cc8da80f5c36ab8 | -- domain over range: CREATE DOMAIN int4range_d AS int4range CHECK (VALUE <> '[10,11)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | c0f6844cedb79812fc979924 | create domain d_fail as int constraint cc REFERENCES this_table_not_exists(i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | cc5448e6f9108f3e0d4d56f8 | -- some error cases create domain d_fail as no_such_type |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_DOMAIN_STMT | d91ac261693670fb3f297432 | create domain d_fail as int4 unique |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ENUM_STMT | 2016c8a8388b111c9d6f9ece | -- only CREATE TYPE AS types may be used CREATE TYPE tt_enum_type AS ENUM ('a') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ENUM_STMT | 2a31affb1a4845c7d47047e2 | -- enum check create type rainbow as enum ('r','o','g','b','i','v') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FDW_STMT | 2f8f789d038490b5b7e12d91 | create foreign data wrapper copytest_wrapper |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FDW_STMT | f516560de4cb734dde87eeba | -- -- CREATE FOREIGN TABLE LIKE -- CREATE FOREIGN DATA WRAPPER ctl_dummy |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_SERVER_STMT | 3a95979154149aa121273717 | create server copytest_server foreign data wrapper copytest_wrapper |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_SERVER_STMT | b41cddbb7dc74bd13111c78c | CREATE SERVER ctl_s0 FOREIGN DATA WRAPPER ctl_dummy |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_TABLE_STMT | 124d9df0f94d88d8e599e45e | -- ERROR CREATE FOREIGN TABLE tbl () SERVER file_server OPTIONS (log_verbosity 'unsupported') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_TABLE_STMT | 1a14d6dd1894aa28f789f6f4 | -- ERROR CREATE FOREIGN TABLE tbl () SERVER file_server OPTIONS (reject_limit '1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_TABLE_STMT | 6af60af75522916a68cce710 | -- Test INCLUDING ALL -- INDEXES, IDENTITY, COMPRESSION, STORAGE are not copied. CREATE FOREIGN TABLE ctl_foreign_table2(LIKE ctl_table INCLUDING ALL) SERVER ctl_s0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_TABLE_STMT | 7e9c80d7285f0eaca4b7a544 | create foreign table grem1 ( a int, b int generated always as (a * 2) stored, c int generated always as (a * 3) virtual ) server loopback options(table_name 'gloc1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_TABLE_STMT | 86dadbfb759a9f7b745242f8 | -- ERROR CREATE FOREIGN TABLE tbl () SERVER file_server OPTIONS (on_error 'unsupported') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_TABLE_STMT | b7ec58e2aa99697e9263ac2c | CREATE FOREIGN TABLE remote_backend_pid (pid int) SERVER loopback OPTIONS (table_name 'my_backend_pid') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_TABLE_STMT | e7c11c955e6bc78d14a270b9 | create foreign table copytest_foreign_table (a int) server copytest_server |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_TABLE_STMT | ee0a5da5e13955dc942c3bac | -- ERROR CREATE FOREIGN TABLE tbl () SERVER file_server OPTIONS (on_error 'ignore', reject_limit '0') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FOREIGN_TABLE_STMT | f826908ed93a7299da1db989 | -- ERROR CREATE FOREIGN TABLE tbl () SERVER file_server OPTIONS (format 'binary', on_error 'ignore') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 024733832f291f4722e5c08f | -- Runtime pruning on MERGE using a stable function create function stable_one() returns int as $$ begin return 1; end; $$ language plpgsql stable |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 02dbefd7cc76b85574885b88 | -- fail - user-defined functions are not allowed CREATE FUNCTION testpub_rf_func2() RETURNS integer IMMUTABLE AS $$ BEGIN RETURN 123; END; $$ LANGUAGE plpgsql |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0552434987a5074fada371db | CREATE FUNCTION pg_buffercache_evict_relation( IN regclass, OUT buffers_evicted int4, OUT buffers_flushed int4, OUT buffers_skipped int4) AS 'MODULE_PATHNAME', 'pg_buffercache_evict_relation' LANGU... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0643a068e3069497190a7abb | CREATE FUNCTION cursor_fetch() RETURNS int AS $$ res = plpy.cursor("select fname, lname from users") assert len(res.fetch(3)) == 3 assert len(res.fetch(3)) == 1 assert len(res.fetch(3)) == 0 assert... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 066152bd88ad3ede8cbd02a3 | CREATE FUNCTION buffer_call_terminate_io(buffer int, for_input bool, succeed bool, io_error bool, release_aio bool) RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0bffaba48462d7babc1c0a92 | -- check behavior when returning setof composite create function returnssetofholes() returns setof has_hole language plpgsql as $$ declare r record; h has_hole; begin return next h; r := (1,2); h :... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0dd0187cdf4f14b6fe24a843 | -- -- pg_get_logical_snapshot_info() -- CREATE FUNCTION pg_get_logical_snapshot_info(IN filename text, OUT state text, OUT xmin xid, OUT xmax xid, OUT start_decoding_at pg_lsn, OUT two_phase_at pg_... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0e2fdbdcbfef3c3f0d56fbc6 | -- UPDATE on view with INSTEAD OF trigger CREATE FUNCTION joinview_upd_trig_fn() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE NOTICE 'UPDATE: % -> %', old, new; UPDATE foo SET f1 = new.f1, f3... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 0ee16d60771f62d36864b897 | -- cursor parameter name can match plpgsql variable or unreserved keyword create function namedparmcursor_test9(p1 int) returns int4 as $$ declare c1 cursor (p1 int, p2 int, debug int) for select c... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 107efe578a7daa18c9122f2a | CREATE FUNCTION gbt_bool_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 10fe4f3f91f1759c3c157dfb | CREATE FUNCTION gbt_time_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 16c927b3d8e3631180323117 | CREATE FUNCTION cursor_fetch_next_empty() RETURNS int AS $$ res = plpy.cursor("select fname, lname from users where false") assert len(res.fetch(1)) == 0 try: next(res) except StopIteration: pass e... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 16e872a343648744c644da54 | create function replaceme(text) returns text as $p$ spi_exec { create or replace function replaceme(text) returns text as $$ return "$1 fum" $$ language pltcl; } spi_exec {select replaceme('foe') a... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 17590a56a8bd26708c567907 | CREATE FUNCTION explain_filter(text) RETURNS SETOF text LANGUAGE plpgsql AS $$ DECLARE ln text; BEGIN FOR ln IN EXECUTE $1 LOOP ln := regexp_replace(ln, 'Relation OIDs:( \\m\\d+\\M)+', 'Relation OIDs:... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 1a5756bdb707113250fb582e | CREATE OR REPLACE FUNCTION regexp_split_to_array(string citext, pattern citext, flags text) RETURNS TEXT[] AS $$ SELECT pg_catalog.regexp_split_to_array( $1::pg_catalog.text, $2::pg_catalog.text, C... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 1b4f3a38630586a7f60ec1ae | -- Try again with an equality function that treats NULLs as equal to 0. create or replace function myinteq(myint, myint) returns bool as $$ begin if $1 is null and $2 is null then return false; els... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 2474f943c067ada4d84e3b01 | CREATE FUNCTION casttesttype_eq(casttesttype, casttesttype) returns boolean language sql immutable as $$ SELECT true $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 2516a6e5b2110acc66054a60 | CREATE FUNCTION buffer_call_start_io(buffer int, for_input bool, nowait bool) RETURNS pg_catalog.bool STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 26fc8aeea0fc3753cf341b68 | CREATE FUNCTION batch_end() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 2c56f4ab988ff5f8e0e9c746 | CREATE FUNCTION handle_release_last() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 2d67bcd767932f3e5bd9b471 | CREATE FUNCTION gbt_cash_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 2e3895d6f9a768c3db5b0e7e | CREATE FUNCTION gbt_varbit_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 2f5e7ace17e17cb62dc297d4 | CREATE FUNCTION int_custom_lt(int_custom, int_custom) RETURNS boolean AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 30c715eb515b7876ff5ad816 | CREATE OR REPLACE FUNCTION regexp_split_to_table(string citext, pattern citext, flags text) RETURNS SETOF TEXT AS $$ SELECT pg_catalog.regexp_split_to_table( $1::pg_catalog.text, $2::pg_catalog.tex... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 37a2ffbc5ab759838dbba6ea | CREATE FUNCTION create_and_insert() RETURNS VOID LANGUAGE sql AS $$ create table ddl_test (f1 int); insert into ddl_test values (1.2); $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 387fd16a26ab081ecda5adcf | CREATE FUNCTION test1 (int) RETURNS int LANGUAGE SQL AS '' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 38829560611a75ebd1aa38cf | -- -- injection_points_stats_fixed() -- -- Reports fixed-numbered statistics for injection points. CREATE FUNCTION injection_points_stats_fixed(OUT numattach int8, OUT numdetach int8, OUT numrun in... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 3af8cd0aee1ad419cb73e3f1 | create or replace function explain_analyze_inc_sort_nodes(query text) returns jsonb language plpgsql as $$ declare elements jsonb; element jsonb; matching_nodes jsonb := '[]'::jsonb; begin execute ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 3c30397ce6ff3732aa3b2a8b | CREATE FUNCTION postgres_fdw_get_connections ( IN check_conn boolean DEFAULT false, OUT server_name text, OUT user_name text, OUT valid boolean, OUT used_in_xact boolean, OUT closed boolean, OUT re... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 3d03a9d30ac81e2a6c496e60 | -- -- injection_points_stats_drop() -- -- Drop all statistics of injection points. -- CREATE FUNCTION injection_points_stats_drop() RETURNS void AS 'MODULE_PATHNAME', 'injection_points_stats_drop' ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 3e77e1731a8d56124aa72b81 | CREATE FUNCTION int_custom_cmp(int_custom, int_custom) RETURNS integer AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 4090bcc833704215943ab7cd | CREATE OR REPLACE FUNCTION json_strip_nulls(target json, strip_in_arrays boolean DEFAULT false) RETURNS json LANGUAGE INTERNAL STRICT IMMUTABLE PARALLEL SAFE AS 'json_strip_nulls' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 4267f8495294c6894286c3d1 | CREATE FUNCTION int_custom_le(int_custom, int_custom) RETURNS boolean AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 440f7ccd654949559279d19f | CREATE FUNCTION handle_get_release() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 458c94e4df63c731d0acc518 | CREATE FUNCTION gbt_float4_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 492ebe805884ba63a0f373f6 | CREATE OR REPLACE FUNCTION regexp_matches(string citext, pattern citext) RETURNS SETOF TEXT[] AS $$ SELECT pg_catalog.regexp_matches( $1::pg_catalog.text, $2::pg_catalog.text, 'i' ); $$ LANGUAGE SQ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 4cb89b6f936312ff64225240 | CREATE FUNCTION int_custom_ne(int_custom, int_custom) RETURNS boolean AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 4f93d851d929e61f6ca42cf6 | create or replace function returnssetofholes() returns setof has_hole language plpgsql as $$ begin return query select 1, 2.0; -- fails end$$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 517426076523cb5e95913b00 | CREATE FUNCTION explain_merge(query text) RETURNS SETOF text LANGUAGE plpgsql AS $$ DECLARE ln text; BEGIN FOR ln IN EXECUTE 'explain (analyze, timing off, summary off, costs off, buffers off) ' \|\|... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 522fa4e09707eee17d1419fe | -- -- injection_points_stats_numcalls() -- -- Reports statistics, if any, related to the given injection point. -- CREATE FUNCTION injection_points_stats_numcalls(IN point_name TEXT) RETURNS bigint... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5b5e276ec65b45b8817fd356 | create or replace function explain_analyze_without_memory(query text) returns table (out_line text) language plpgsql as $$ declare line text; begin for line in execute 'explain (analyze, costs off,... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5b64317ee1c59c24c893f72d | CREATE FUNCTION composite_f(a integer[], out x integer, out y integer) returns record as $$ begin x = a[1]; y = a[2]; end; $$ language plpgsql |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5ba6477480f65f9d956f815d | CREATE FUNCTION gbt_bytea_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5cdc77038dbad22107654ff6 | CREATE FUNCTION functest_srf0() RETURNS SETOF int LANGUAGE SQL AS $$ SELECT i FROM generate_series(1, 100) i $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5e56c3a23271111ea1a6ad62 | -- test FOR-over-cursor create or replace function forc01() returns void as $$ declare c cursor(r1 integer, r2 integer) for select * from generate_series(r1,r2) i; c2 cursor for select * from gener... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 5f6348c854f31e74e5b2394a | -- mb<->wchar conversions CREATE FUNCTION test_encoding(encoding text, description text, input bytea) RETURNS VOID LANGUAGE plpgsql AS $$ DECLARE prefix text; len int; wchars int[]; round_trip byte... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 604646ffee856352707b9987 | -- Functions CREATE FUNCTION func_stats(a text DEFAULT 'a_data', b text DEFAULT lower('b_data')) RETURNS text AS $$ SELECT $1::text \|\| '_' \|\| $2::text; $$ LANGUAGE SQL SET work_mem = '256kB' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6153fc1c76f216a506ced1ce | CREATE OR REPLACE FUNCTION regexp_replace(string citext, pattern citext, replacement text, flags text) returns TEXT AS $$ SELECT pg_catalog.regexp_replace( $1::pg_catalog.text, $2::pg_catalog.text,... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 61c4c051d3ea625ca1560ce1 | CREATE FUNCTION my_other_func(int) RETURNS int LANGUAGE SQL AS $$ SELECT $1 + 1 $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 629a7ad31a1ac0bcb54cf549 | CREATE FUNCTION gbt_uuid_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 64aeb51d76ce73041b2ba5d4 | CREATE FUNCTION consume_xids_until(targetxid xid8) RETURNS xid8 VOLATILE PARALLEL UNSAFE STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 64cf7f76f0a962bf359ee31d | CREATE FUNCTION wait_for_backend_termination(int) RETURNS void AS $$ BEGIN WHILE (SELECT count(*) FROM pg_stat_activity WHERE pid = $1) > 0 LOOP PERFORM pg_stat_clear_snapshot(); END LOOP; END $$ L... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 66deb76f4faa347df7e5f467 | CREATE FUNCTION inj_io_short_read_detach() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6705f0ad7ee1899627927f28 | CREATE FUNCTION alter_and_insert() RETURNS VOID LANGUAGE sql AS $$ alter table ddl_test alter column f1 type numeric; insert into ddl_test values (1.2); $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6774aec1bdecee1aa87cc88b | create function explain_parallel_sort_stats() returns setof text language plpgsql as $$ declare ln text; begin for ln in explain (analyze, timing off, summary off, costs off, buffers off) select * ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 67af7c57a0bb01bd4891a24e | CREATE FUNCTION gbt_oid_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6ac996da4d0aae7d35cb15ac | CREATE OR REPLACE FUNCTION test_read_multixact(xid) RETURNS VOID AS 'MODULE_PATHNAME', 'test_read_multixact'LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6e27c7c15d2b1a9bdfedbb97 | CREATE FUNCTION int_custom_gt(int_custom, int_custom) RETURNS boolean AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6e4950cba7f124c47424a649 | -- -- Comparison functions for int_custom -- -- These are required to create a btree operator class, which is needed -- for the type to be usable in extended statistics objects. -- CREATE FUNCTION ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6ec72a4151024b6afd795fad | create function trap_timeout() returns void as $$ begin begin perform pg_sleep(10); exception when others then raise notice 'caught others: %', sqlerrm; when query_canceled then raise notice 'nyeah... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 70210458bbf052970aa0012a | CREATE FUNCTION next_after_close() RETURNS int AS $$ res = plpy.cursor("select fname, lname from users") res.close() try: next(res) except ValueError: pass else: assert False, "ValueError not raise... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 702bbac734b5803e7eabb864 | CREATE FUNCTION gbt_inet_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 70e9da7a90d8e96d721c6196 | create function explain_memoize(query text, hide_hitmiss bool) returns setof text language plpgsql as $$ declare ln text; begin for ln in execute format('explain (analyze, costs off, summary off, t... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 71086bd2bd8f294d0eeffb42 | CREATE FUNCTION test_null_ordered_named_pair() RETURNS ordered_named_pair AS $$ declare v ordered_named_pair; begin return v; end $$ LANGUAGE plpgsql |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 7109a17e5fa01d1060cdd85a | CREATE FUNCTION gbt_numeric_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 7319509a86e0065790aefa6b | CREATE FUNCTION gbt_float8_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 739107243a1e98b077303a7a | -- Add a trigger to catch and print the contents of the catalog view -- pg_stat_progress_copy during data insertion. This allows to test -- the validation of some progress reports for COPY FROM whe... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 74d59477c58db821c14d92b9 | CREATE OR REPLACE FUNCTION regexp_matches(string citext, pattern citext, flags text) RETURNS SETOF TEXT[] AS $$ SELECT pg_catalog.regexp_matches( $1::pg_catalog.text, $2::pg_catalog.text, CASE WHEN... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 7965689919067ee90ba40897 | -- Dummy function used for expression evaluations. -- Note that this function does not use a SQL-standard function body on -- purpose, so as external statistics can be loaded from it. CREATE OR REP... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 7b81a272c00fd74a0240ee74 | CREATE FUNCTION grow_rel(rel regclass, nblocks int) RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 7f24c74c77e23fef8168d1d3 | -- -- Test partitioning planner code -- -- Helper function which can be used for masking out portions of EXPLAIN -- ANALYZE which could contain information that's not consistent on all -- platforms... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 7f7d21bd0e97c6bbdf3fd7b5 | CREATE OR REPLACE FUNCTION regexp_split_to_array(string citext, pattern citext) RETURNS TEXT[] AS $$ SELECT pg_catalog.regexp_split_to_array( $1::pg_catalog.text, $2::pg_catalog.text, 'i' ); $$ LAN... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8012a1704edb41131d208ba4 | -- -- injection_points_cached() -- -- Executes the action attached to the injection point, from local cache. -- CREATE FUNCTION injection_points_cached(IN point_name TEXT, IN arg TEXT DEFAULT NULL)... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 80deffa333e2c6a61c4b7e62 | CREATE FUNCTION test_dsa_allocate(int, int, int) RETURNS pg_catalog.void AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 81379d8ebd5989331b329a66 | -- Parallel append -- Parallel queries won't necessarily get as many workers as the planner -- asked for. This affects not only the "Workers Launched:" field of EXPLAIN -- results, but also row cou... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 813ed13cbc5838d07ab45563 | create function ttdummy () returns trigger language plpgsql as $$ begin return new; end $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 84fafc19f06df5039b8b2325 | CREATE FUNCTION handle_get() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8589937af6ccaf2e602f3f31 | CREATE FUNCTION rw_view1_trig_fn() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' THEN INSERT INTO base_tbl VALUES (NEW.a, NEW.b); NEW.c1 = 'Trigger Const1'; RETURN NEW; ELSIF TG_OP = 'UPDATE' THE... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 860a7e33d7a9ab4fed27d730 | CREATE FUNCTION read_rel_block_ll( rel regclass, blockno int, nblocks int DEFAULT 1, wait_complete bool DEFAULT true, batchmode_enter bool DEFAULT false, smgrreleaseall bool DEFAULT false, batchmod... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8b934bf9c3a0564c4bee6c87 | CREATE FUNCTION gbt_macad8_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8ca4fbbd42e45a487399ab63 | -- -- Typanalyze function that returns false -- CREATE FUNCTION int_custom_typanalyze_false(internal) RETURNS boolean AS 'MODULE_PATHNAME' LANGUAGE C STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 906e2586ecca54e99b3c514e | CREATE OR REPLACE FUNCTION regexp_split_to_table(string citext, pattern citext) RETURNS SETOF TEXT AS $$ SELECT pg_catalog.regexp_split_to_table( $1::pg_catalog.text, $2::pg_catalog.text, 'i' ); $$... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 97e642628884bb2dad604d42 | /* * Batchmode related functions */ CREATE FUNCTION batch_start() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 994fa7b97fdf46409634b175 | CREATE OR REPLACE FUNCTION regexp_replace(string citext, pattern citext, replacement text) returns TEXT AS $$ SELECT pg_catalog.regexp_replace( $1::pg_catalog.text, $2::pg_catalog.text, $3, 'i'); $... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 9af73bd02f2e8c6eccc384cd | CREATE OR REPLACE FUNCTION jsonb_strip_nulls(target jsonb, strip_in_arrays boolean DEFAULT false) RETURNS jsonb LANGUAGE INTERNAL STRICT IMMUTABLE PARALLEL SAFE AS 'jsonb_strip_nulls' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 9c56a2edb034fc344c93f93b | create function whoami() returns trigger language plpgsql as $$ begin raise notice 'I am %', current_user; return null; end; $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | a26cca5e70bdc1658e8d1347 | CREATE FUNCTION int_custom_out(int_custom) RETURNS cstring AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | a2a06273b8cf55c7f6cb37fc | create function tcls1.somefunc(int) returns int as $$ return [expr $1 * 2] $$ language pltcl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | a34fce3c237a8eee0caff70e | CREATE FUNCTION gbt_macaddr_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | a4260a77285f4dd227a16bd3 | /* Now redefine */ CREATE FUNCTION pg_stat_statements(IN showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel bool, OUT queryid bigint, OUT query text, OUT plans int8, OUT total_plan_time f... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | a93fe3dd13ff811363e2c024 | /* * Handle related functions */ CREATE FUNCTION handle_get_and_error() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | af37a00593646c8745cd2f3b | CREATE FUNCTION handle_get_twice() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | b00222237c47e31d0d0c5e28 | CREATE FUNCTION test1 (anyelement) RETURNS anyarray LANGUAGE SQL AS '' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | b12532012ff94537a656a8e5 | CREATE FUNCTION pg_buffercache_evict( IN int, OUT buffer_evicted boolean, OUT buffer_flushed boolean) AS 'MODULE_PATHNAME', 'pg_buffercache_evict' LANGUAGE C PARALLEL SAFE VOLATILE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | b8da38f3daff38007a453ade | create or replace function test_pg_index_toast_func (a int, b int[]) returns bool as $$ select true $$ language sql immutable |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | bb10c5a5b431478c5502b509 | CREATE FUNCTION gbt_bpchar_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | bb14aec0d3a5bafc8f3e1112 | CREATE FUNCTION my_erroneous_func(int) RETURNS int LANGUAGE SQL AS $$ SELECT $1 + , 1 $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | bc57476a1518e0dd433b8127 | -- Add translate_cmptype functions CREATE FUNCTION gist_translate_cmptype_btree(int) RETURNS smallint AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | bceb2a6651bfc803d3e7f233 | CREATE FUNCTION gbt_int8_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | c357b116ed200314ada23999 | CREATE FUNCTION gbt_date_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | c4cf2b741913c7868b474b2e | CREATE FUNCTION invalidate_rel_block(rel regclass, blockno int) RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | c6588ea88ac13d50b7bc05dd | CREATE FUNCTION buffer_create_toy(rel regclass, blockno int4) RETURNS pg_catalog.int4 STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | cbbb1addfdd2b8b7eec8937c | -- make sure the current user is restored after error create or replace function whoami() returns trigger language plpgsql as $$ begin raise notice 'I am %', current_user; perform 1 / 0; return nul... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | cc4abc1cc28e87120bf14571 | CREATE FUNCTION part_hashint4_error(value int4, seed int8) RETURNS int8 LANGUAGE SQL STRICT IMMUTABLE PARALLEL SAFE AS $$ SELECT value + seed + random()::int/0 $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | ccd31a6547cda443eff7a42f | CREATE FUNCTION gbt_intv_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d084db7c1d5684671646c797 | CREATE OR REPLACE FUNCTION test_create_multixact() RETURNS xid AS 'MODULE_PATHNAME', 'test_create_multixact' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d11b854c9614862e8e19acdc | create function hashint8alias1(int8alias1) returns int strict immutable language internal as 'hashint8' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d288d30c417dc19874faba1f | create function tcl_error(out a int, out b int) as $$returm 1$$ language pltcl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d89453e01925ba2208c831f5 | CREATE FUNCTION gbt_ts_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d9a891c3e24fcc9e67a32748 | CREATE FUNCTION modify_rel_block(rel regclass, blockno int, zero bool DEFAULT false, corrupt_header bool DEFAULT false, corrupt_checksum bool DEFAULT false) RETURNS pg_catalog.void STRICT AS 'MODUL... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | d9ba952af53e76345acc59c2 | CREATE FUNCTION gbt_int2_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | da8847979ea9a23dcb7012b9 | CREATE FUNCTION test_setof_as_set(count integer, content text) RETURNS SETOF text AS $$ s = set() for i in range(count): s.add(content * (i + 1) if content is not None else None) return s $$ LANGUA... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | dc2f6b0696e93f625d73f47a | create function make_bogus_matview() returns trigger as $$ begin create materialized view transition_test_mv as select * from new_table; return new; end $$ language plpgsql |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | def05eef83325cae40905d99 | -- -- Typanalyze function that returns invalid stats -- CREATE FUNCTION int_custom_typanalyze_invalid(internal) RETURNS boolean AS 'MODULE_PATHNAME' LANGUAGE C STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e0138ce49867824cf6534a74 | create function explain_sq_limit() returns setof text language plpgsql as $$ declare ln text; begin for ln in explain (analyze, summary off, timing off, costs off, buffers off) select * from (selec... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e12adc429f0344e1a8f36753 | CREATE FUNCTION gbt_int4_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e19c1000d0659ff476966b8b | create function tcls2.somefunc(int) returns int as $$ return [expr $1 * 3] $$ language pltcl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e3915962318f99bfe196e97d | CREATE FUNCTION gbt_enum_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e3d63efcaed33ec93a29b315 | -- should fail CREATE OR REPLACE FUNCTION joinview_upd_trig_fn() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE NOTICE 'UPDATE: % -> %', old, new; UPDATE foo SET f1 = new.f1, f3 = new.f3, f4 = ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e4ff51fdd407453089fbaebb | CREATE FUNCTION int_custom_ge(int_custom, int_custom) RETURNS boolean AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | e591e73a189f0c9e9965fb0b | CREATE FUNCTION inj_io_reopen_detach() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | edd967dd25988fada14f458a | /* * Injection point related functions */ CREATE FUNCTION inj_io_short_read_attach(result int) RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f124d0e4ca296f657afa37cf | CREATE FUNCTION gbt_text_sortsupport(internal) RETURNS void AS 'MODULE_PATHNAME' LANGUAGE C IMMUTABLE PARALLEL SAFE STRICT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f4d9653e62a03d8adb50e9cb | CREATE OR REPLACE FUNCTION regexp_match(string citext, pattern citext, flags text) RETURNS TEXT[] AS $$ SELECT pg_catalog.regexp_match( $1::pg_catalog.text, $2::pg_catalog.text, CASE WHEN pg_catalo... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f631258e5160a4f21d9769f0 | CREATE FUNCTION inj_io_reopen_attach() RETURNS pg_catalog.void STRICT AS 'MODULE_PATHNAME' LANGUAGE C |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f7ac45cd6ad8bcb494ccece8 | -- -- injection_points_run() -- -- Executes the action attached to the injection point. -- CREATE FUNCTION injection_points_run(IN point_name TEXT, IN arg TEXT DEFAULT NULL) RETURNS void AS 'MODULE... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f93b90cf21f0b05d0dfc7595 | CREATE FUNCTION pg_buffercache_evict_all( OUT buffers_evicted int4, OUT buffers_flushed int4, OUT buffers_skipped int4) AS 'MODULE_PATHNAME', 'pg_buffercache_evict_all' LANGUAGE C PARALLEL SAFE VOL... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | faba33c89f8399ad047e263e | -- -- injection_points_load() -- -- Load an injection point already attached. -- CREATE FUNCTION injection_points_load(IN point_name TEXT) RETURNS void AS 'MODULE_PATHNAME', 'injection_points_load'... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | fbfce51c10b8028a67d8f016 | CREATE FUNCTION cursor_mix_next_and_fetch() RETURNS int AS $$ res = plpy.cursor("select fname, lname from users order by fname") assert len(res.fetch(2)) == 2 item = next(res) assert item['fname'] ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | ffda77ff789cc22807cadd80 | -- Now make the equal function return false when given two NULLs create or replace function myinteq(myint, myint) returns bool as $$ begin if $1 is null and $2 is null then return false; else retur... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_OP_CLASS_STMT | c6132012ffbe596f82e4bd00 | CREATE OPERATOR CLASS part_test_int4_ops_bad FOR TYPE int4 USING hash AS FUNCTION 2 part_hashint4_error(int4, int8) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_OP_CLASS_STMT | ec11c51de8e33d2ec1a03f91 | -- -- Btree operator class for int_custom -- -- This is required for the type to be usable in extended statistics objects, -- for attributes and expressions. -- CREATE OPERATOR CLASS int_custom_ops... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_POLICY_STMT | 1ee2b4904a325121b8f0c0f2 | CREATE POLICY p0 ON r1 USING (b * 10 = c) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_POLICY_STMT | 3ff79482b4efef2e4b884db3 | CREATE POLICY p1 ON r1 AS RESTRICTIVE USING (b > 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_POLICY_STMT | 4e13ec1d4bb05742be173678 | create policy p1 on rls_t for select to regress_rls_alice using (c = current_setting('rls_test.blah')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_POLICY_STMT | e9351c233689e14f8a66503d | CREATE POLICY p2 ON r1 AS RESTRICTIVE USING ((SELECT c) < 400) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_RANGE_STMT | 360814f99cc93e4eed406af0 | -- error CREATE TYPE gtestdomain1range AS range (subtype = gtestdomain1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_RANGE_STMT | 9d8478b55cf49b7edef59861 | create type mytype as range (subtype=int4, multirange_type_name=mr_sch.mr_type) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_RANGE_STMT | a2f1deea4490b33d934efdb1 | CREATE TYPE int4_d_range as range (subtype = int4_d) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | 10c50dccb0627e2dc34073ed | CREATE ROLE regress_grantor2 ROLE regress_grantor1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | 170df89fbb1ee8dbadc11811 | CREATE ROLE regress_pg_logicalinspect |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | 23ae2e0dc11df073f5b1512b | -- SET statements. -- These use two different strings, still they count as one entry. CREATE ROLE regress_stat_set_1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | 31fc9de3781d23a25900b57f | -- -- CREATE TYPE checks for CREATE on multirange schema -- create role regress_mr |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | 6253dfc60ea236f6d7d28b7b | CREATE ROLE regress_stats_superuser SUPERUSER |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | 674cbb99850b82b5091651c9 | create role regress_fn_owner |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | 6acc1172b8c68b27a96af0ab | CREATE ROLE regress_grantor3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | 7aa85f679b9a39044711e4fa | CREATE ROLE regress_stat_set_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | a301ba6387a22be960416235 | ------ ---- Test pg_buffercache_evict* functions ------ CREATE ROLE regress_buffercache_normal |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | bad2ae6fd88d9eb8a70f0b05 | CREATE ROLE regress_passwd10 PASSWORD 'SCRAM-SHA-256$000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | cfb21a2a306295660d1cba9c | -- Test who runs deferred trigger functions -- setup create role regress_caller |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_ROLE_STMT | d00e00edad408063965574a1 | -- grantor selection CREATE ROLE regress_grantor1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 3c4255e627549f5bb0363138 | -- search_path with various schemas and temporary tables CREATE SCHEMA pgss_schema_1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 7409c1ddd903a49f93b68f71 | create schema tcls2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 744e2d3ad297fc298c42ad71 | -- keep these tests aligned with generated_stored.sql CREATE SCHEMA generated_virtual_tests |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 845f7091e17bc42f47d0e1ae | create schema tcls1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | 9e988110dc80ad4e1d36c6a8 | create schema mr_sch |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | a65fc46b409824ff8c6f84fd | CREATE SCHEMA stats_import |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | cc58ea4f7284239b7adb9429 | -- keep these tests aligned with generated_virtual.sql CREATE SCHEMA generated_stored_tests |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SCHEMA_STMT | ee8bce82af490880ebb5623b | CREATE SCHEMA pgss_schema_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SEQ_STMT | 4d2b9b10849220e114bc3a4f | CREATE SEQUENCE stats_import.testseq |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_SEQ_STMT | c0d6558cba2251214cc0556d | create sequence aitest_seq increment 10 start 0 minvalue 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 060c9d81dd013a88f156725a | CREATE STATISTICS tst on (z) from ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 2c015beafafbce43ce1d1624 | CREATE STATISTICS ctl_stats4_stat ON a, c FROM ctl_stats4_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 3075452c3460c2495b5f9853 | -- statistics without a less-than operator not supported CREATE STATISTICS tst (ndistinct) ON w from ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 4e43ec181a1ca9eed67145ba | -- Extended statistics with an attribute that cannot be analyzed. -- This includes all statistics kinds. CREATE STATISTICS test_stats ON data, id FROM test_table |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 601506393cc4a963d9f6205f | CREATE STATISTICS ctl_table_stat ON a,b FROM ctl_table |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 6286742cb59f0750d11b52d3 | CREATE STATISTICS tst (ndistinct) ON z from ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 72690aa2737db7a32160a15c | CREATE STATISTICS tst (ndistinct) ON xmin from ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 7f3ea467753c54c48fe02644 | -- statistics on system column not allowed CREATE STATISTICS tst on tableoid from ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 845bfa3cb1ce41a542c7381d | -- The ndistinct extended statistics on (x, y, z) provides more reliable value -- of bucket size. CREATE STATISTICS extstat_sb_2 (ndistinct) ON x, y, z FROM sb_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | 8865741671ae7d2c6c7726a0 | CREATE STATISTICS t_b_c_stat (mcv) ON b, c FROM bitmap_split_or |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | a30982b22b3720a0ebb8843b | CREATE STATISTICS ctl_stats3_stat ON a, c FROM ctl_stats3_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | bb245b2fe1a0144bca82eb9c | -- Extended statistics with an expression that cannot be analyzed. CREATE STATISTICS test_stats ON func_int_custom(data), (id) FROM test_table |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | c3308bfe386fb737618f67b0 | CREATE STATISTICS t_a_b_stat (mcv) ON a, b FROM bitmap_split_or |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | cc7097265b3b87ee8878eb0e | CREATE STATISTICS tst on (tableoid) from ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | d36eb3d07453e7018f5d31ce | CREATE STATISTICS tst on (z+1) from ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | d515d4fceef55ebd2a9a07fd | CREATE STATISTICS tst on z from ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STATS_STMT | e7a609ea10f3e01d3c260e3c | CREATE STATISTICS tst on (tableoid::int+1) from ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 00ee8f968f6c9946229d8e8e | -- -- Tests for VACUUM ONLY / ANALYZE ONLY on inheritance tables -- CREATE TABLE only_inh_parent (a int primary key, b TEXT) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0230f86bcbd345ed2246020b | create table idxpart1 partition of idxpart for values from (0) to (500) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 02631199fd4a6bfe08fddcba | CREATE TABLE testpub_rf_tbl7 (id int PRIMARY KEY, x int, y int GENERATED ALWAYS AS (x * 111) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 02f7e9a73462b5a1bcb5e9c2 | -- partitioned table have not-null, then the partitions can not be NOT NULL NOT VALID. CREATE TABLE pp_nn (a int, b int, NOT NULL a) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 03032588c811be17f73f9431 | -- An inheritance child table gets the constraint, but it's valid CREATE TABLE notnull_tbl1_child (a int, b int) INHERITS (notnull_tbl1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0373dac26c5f4f3a3bee1365 | -- (parent_id, valid_at) REFERENCES [implicit] -- FOREIGN KEY part should specify PERIOD CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4range, CONSTRA... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 042fbed578eece2f0c999251 | CREATE TABLE r1 (a int, b int GENERATED ALWAYS AS (a * 10) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 052446778ffd0dc01156e4b4 | -- PK with a non-range column: CREATE TABLE temporal_rng ( id int4range, valid_at TEXT, CONSTRAINT temporal_rng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 053b5fabda5b418861d235e9 | -- references to other generated columns, including self-references CREATE TABLE gtest_err_2a (a int PRIMARY KEY, b int GENERATED ALWAYS AS (b * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 064a257f99323f3d9fa23696 | CREATE TABLE emp1 (id SERIAL PRIMARY KEY NOT NULL, code int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 069a2f83ea372a1dc4793349 | create table inh_nn_child2() inherits (inh_nn_parent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 06b13d7a75646f066add5cd4 | -- error -- composite type dependencies CREATE TABLE gtest31_1 (a int, b text GENERATED ALWAYS AS ('hello') VIRTUAL, c text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0717b82e3622221a390e6eb8 | create table inh_p2(f1 int not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0733919cda4791348118bd11 | CREATE TABLE gtest_part_key (f1 date NOT NULL, f2 bigint, f3 bigint GENERATED ALWAYS AS (f2 * 2) VIRTUAL) PARTITION BY RANGE ((gtest_part_key)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 079f5ee5eefc4bd6c419a0fd | CREATE TABLE ctlt2 (c text NOT NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 082e174eb1d5752b2c45b92d | CREATE TABLE cnn_pk_child () INHERITS (cnn_pk) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 083072c01339908c963b3de5 | -- -- FK between partitioned tables: ranges -- CREATE TABLE temporal_partitioned_rng ( id int4range, valid_at daterange, name text, CONSTRAINT temporal_paritioned_rng_pk PRIMARY KEY (id, valid_at W... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 09078424ea3b0a1bcdbcc646 | -- virtual CREATE TABLE testpub_gencol (a INT, b INT GENERATED ALWAYS AS (a + 1) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0c6ff797980e615be5b23936 | create temp table p (a int, b int) partition by range (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0cdf7e5eab525404bd986066 | -- Numeric type, implicit cast is squashed CREATE TABLE test_squash_numeric (id int, data numeric(5, 2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0d416f7d0076808d087a22a2 | CREATE TEMP TABLE e (id1 int, id2 int, PRIMARY KEY(id1, id2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0d6d30b322fd66bddc7a11bd | create table inh_parent2(d int, e int, b int, primary key (d, b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0df4f7cd18bcb8d3cd8e7c74 | CREATE TABLE tbl_phv(x int, y int PRIMARY KEY) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0e00fb264067f58c91df7458 | CREATE TABLE tp2 PARTITION OF temporal_partitioned_mltrng FOR VALUES IN ('[0,1)', '[2,3)', '[4,5)', '[6,7)', '[8,9)', '[10,11)', '[12,13)', '[14,15)', '[16,17)', '[18,19)', '[20,21)', '[22,23)', '[... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0f308b99b0fdf0518de433e5 | -- -- test a range with both a PK and a UNIQUE constraint -- CREATE TABLE temporal3 ( id int4range, valid_at daterange, id2 int8range, name TEXT, CONSTRAINT temporal3_pk PRIMARY KEY (id, valid_at W... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0fbab787e53f3b5a3fde603a | create table notnull_tbl_fail (a int primary key constraint foo not null no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0fdf426946071b424866f6ef | CREATE TABLE notnull_tbl4_lk (LIKE notnull_tbl4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 0feebbcac33bab8a19bbafcd | -- Check bitmap scan can consider similar OR arguments separately without -- grouping them into SAOP. CREATE TABLE bitmap_split_or (a int NOT NULL, b int NOT NULL, c int NOT NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 101feea5b65d7c2d6a7a126b | -- Ensure that virtual generated columns in constraint expressions are expanded create table gtest33 (a int, b int generated always as (a * 2) virtual not null, check (b > 10)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 10e2897aebdf18f7a4e2fd4f | -- error CREATE TABLE gtest23b (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL REFERENCES gtest23a (x)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 117d17ee0c04f9fc543339d2 | create table part_abc_3_1 partition of part_abc_3 for values from (minvalue) to (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 11f710dcb5b3b017dfb6d893 | CREATE TABLE grantor_test3 () |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 12b7f3199f0490558b0cd41b | CREATE TABLE fk_partitioned_fk (b int, a int) PARTITION BY RANGE (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1332a561e4517f4b8b01bf3b | -- works: PERIOD for both referenced and referencing CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT temporal_fk_rng2rng_pk PRIMARY KEY (id, val... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 137e8cc51661164506e89e57 | -- with a UNIQUE constraint: CREATE TABLE temporal3 ( id int4range, valid_at daterange, CONSTRAINT temporal3_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 13f6d59072512bf0e489c299 | CREATE TABLE tab_with_flag ( id INT PRIMARY KEY, is_flag SMALLINT) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1448e965a493560245f82bf2 | CREATE TABLE tfkp1 PARTITION OF temporal_partitioned_fk_mltrng2mltrng FOR VALUES IN ('[1,2)', '[3,4)', '[5,6)', '[7,8)', '[9,10)', '[11,12)', '[13,14)', '[15,16)', '[17,18)', '[19,20)', '[21,22)', ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 158443d57ee8cce978919994 | CREATE TABLE noinh_con_copy1 (LIKE noinh_con_copy INCLUDING CONSTRAINTS INCLUDING COMMENTS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 15c8ae88e239a75842523122 | CREATE TEMP TABLE stats_temp(i int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 16001e99d52f0dc0a521aee2 | create table notnull_tbl_fail (like notnull_tbl1, constraint foo2 not null a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 16c4cda0453f54ab75bc1764 | create table notnull_tbl_fail (a serial constraint foo not null, constraint bar not null a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 16dbdbad5d7448b1697a7a21 | -- LIKE must respect NO INHERIT property of constraints CREATE TABLE noinh_con_copy (a int CHECK (a > 0) NO INHERIT, b int not null, c int not null no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 16f8cf6b92ad13e2477b963a | create table inh_child (f1 int not null no inherit, f2 int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1745f788da459665b100ec02 | --\\d gtest23b --INSERT INTO gtest23b VALUES (1); -- ok --INSERT INTO gtest23b VALUES (5); -- error --ALTER TABLE gtest23b ALTER COLUMN b SET EXPRESSION AS (a * 5); -- error --ALTER TABLE gtest23b A... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 175043373072d464651559c7 | create temp table tbl_rs(a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1871894becca75884ed0c626 | -- Different number of attributes, mapping types CREATE TABLE pgss_schema_1.tab_search_diff_1 (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1901e722050be4fece30c49a | -- Core must test WITHOUT OVERLAPS -- with an int4range + daterange, -- so here we do some simple tests -- to make sure int + daterange works too, -- since that is the expected use-case. CREATE TAB... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 198becc0a73088bb92bfde00 | -- Ensure partitions are scanned for null values when adding a PK create table cnn2_parted(a int) partition by list (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 19a2f9a175c64c68a3353ff3 | -- using tableoid is allowed CREATE TABLE gtest_tableoid ( a int PRIMARY KEY, b bool GENERATED ALWAYS AS (tableoid = 'gtest_tableoid'::regclass) VIRTUAL ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 19b5aec4bcd7ab0607cee669 | CREATE TABLE pagg_tab4_p2 PARTITION OF pagg_tab4 FOR VALUES IN ('B', 'A') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 19f436f8259457b2a7263298 | -- Can't modify inheritability of inherited constraints create table inh_nn2 () inherits (inh_nn1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 19fe076e23d025991ea160dd | create table inh_nn3 (f4 float) inherits (inh_nn2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1ac101cc2bb38517a5cb63f9 | CREATE TABLE inh_nn3 (a int not null, b int, not null a no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1ae97db2fbfc1843c8f70ea6 | CREATE TABLE pagg_tab6 (c text collate case_insensitive, b text collate case_insensitive) PARTITION BY LIST (b collate case_insensitive) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1b154b373897620aefa9dadc | CREATE TABLE shared_pg_buffercache() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1d399ebbc1f1f331e66bf21f | CREATE TABLE INSERT_TBL (x INT DEFAULT nextval('insert_seq'), y TEXT DEFAULT '-NULL-', z INT DEFAULT -1 * currval('insert_seq'), CONSTRAINT INSERT_TBL_CON CHECK (x >= 3 AND y <> 'check failed' AND ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1f03ffd6eab51f49b0cc234d | create table notnull_tbl_fail (a serial, constraint foo not null a, constraint bar not null a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1f0be52ded51a12f8e9f533a | -- with mismatched PERIOD columns: -- (parent_id, PERIOD valid_at) REFERENCES (id, valid_at) -- REFERENCES part should specify PERIOD CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1f35a3305e47c9fe067a7beb | CREATE TABLE gtest24 (a int PRIMARY KEY, b gtestdomain1 GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 1f5f50a29ff15da67224734e | create temp table p1 partition of p for values from (0) to (10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 202d0390549e77243e776b68 | CREATE TABLE gtest_child PARTITION OF gtest_parent ( f3 WITH OPTIONS GENERATED ALWAYS AS (f2 * 2) VIRTUAL ) FOR VALUES FROM ('2016-07-01') TO ('2016-08-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2164ba8bc2288cbbc270065e | CREATE TEMP TABLE rescan_bhs (a INT) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 217c0aa496cd4e37dea92b23 | -- Partitioned table with no partitions create table idxpart2 partition of idxpart for values from (1000) to (2000) partition by range (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2194160e0257f3b7fc98d949 | -- NOT NULL NO INHERIT CREATE TABLE ATACC1 (a int, NOT NULL a NO INHERIT) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 22855f1069d95232e3362327 | -- with inferred PK on the referenced table: -- (parent_id, PERIOD valid_at) REFERENCES [implicit] CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4rang... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 22fd61558cce9a0f71a63bdc | -- (parent_id, valid_at) REFERENCES (id, PERIOD valid_at) -- FOREIGN KEY part should specify PERIOD CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4ran... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 231334c209391774d373898c | CREATE TABLE ATACC3 (a int) INHERITS (ATACC2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 236f77a70e6d4332e17210bc | CREATE TABLE list_parted3_1 PARTITION OF list_parted3 FOR VALUES IN (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2455f0fa4f5774a8960a568e | CREATE TABLE sj_t4 (id serial, a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 246cd6f49451395889037483 | create table tuplesest_parted2 partition of tuplesest_parted for values from (100) to (200) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 24f2c4b43cf2c54402b24ebb | create table notnull_tbl_fail (a int not null no inherit primary key) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2572046c5e095a74621ee3b9 | -- -- Tests using psql pipelining -- CREATE TABLE psql_pipeline(a INTEGER PRIMARY KEY, s TEXT) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 25d61a6a0ad92bdf9b7056c5 | -- not null not valid with partitions CREATE TABLE atnnparted (id int, col1 int) PARTITION BY LIST (id) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2655cc558fe5d4586b82160b | -- Inherit test for pg_upgrade CREATE TABLE notnull_parent_upg (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 26de2801335fa406ce0e17b5 | CREATE TABLE gtest0 (a int PRIMARY KEY, b int GENERATED ALWAYS AS (55) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 27317d15da02bcf8839a13d0 | create table inh_nn4 () inherits (inh_nn1, inh_nn2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 284008c43030891b944a1b78 | create table inh_cc1 (f2 text, f3 int) inherits (inh_pp1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 29e08850e510f6dbc1d24bbb | -- Ensure that EXCLUDED.<virtual-generated-column> in INSERT ... ON CONFLICT -- DO UPDATE is expanded to the generation expression, both for plain and -- partitioned target relations. create table ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2a17969d8d985092d2582a10 | CREATE TABLE gtest_err_2b (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL, c int GENERATED ALWAYS AS (b * 3) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2a663121c9ba9d22f3cca89d | --ok CREATE TABLE notnull_part1_1_upg PARTITION OF notnull_part1_upg FOR VALUES IN (1,2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2c6ff9c0484e20c2c4282c01 | -- Partition table test, for pg_upgrade CREATE TABLE notnull_part1_upg (a int, b int) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2c7d36d0edafe02694d95eec | CREATE TABLE pgss_schema_2.tab_search_same (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2c973546f9256f0cf5ce93bc | -- can't drop not-null in primary key CREATE TABLE notnull_tbl2 (a INTEGER PRIMARY KEY) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2d188fc4ba4dc9a9a588ddcd | create table constr_parent3 (a int not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2d7c1e7b46ca5eb59bcda4b4 | -- NOT VALID and NOT ENFORCED foreign key on a non-partitioned table -- referencing a partitioned table CREATE TABLE fk_partitioned_pk (a int, b int, PRIMARY KEY (a, b)) PARTITION BY RANGE (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2e642fae9f3ad006f51a0e8f | -- Can't create a FK with a mismatched range type CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at int4range, parent_id int4range, CONSTRAINT temporal_fk_rng2rng_pk2 PRIMARY KEY (id, valid... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 2ef4128bb2922698ceb13980 | -- generated NOT NULL constraint names must not collide with explicitly named constraints CREATE TABLE two_not_null_constraints ( col integer NOT NULL, CONSTRAINT two_not_null_constraints_col_not_n... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 30187eeee02a0229471afe4f | -- EXPLAIN - all-level tracking. CREATE TABLE test_table (x int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 30518955ebb8946981e6e9a0 | -- UNIQUE with no columns just WITHOUT OVERLAPS: CREATE TABLE temporal_rng3 ( valid_at daterange, CONSTRAINT temporal_rng3_uq UNIQUE (valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3088ba274d3cdffc1eaaeaaa | CREATE TABLE stats_import.test_clone ( LIKE stats_import.test ) WITH (autovacuum_enabled = false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 30fd3a4d5c9426837c22eebd | CREATE TABLE test12fk (a int, b text COLLATE case_insensitive REFERENCES test12pk (x) ON UPDATE CASCADE) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3154cfd860371f9d8808bd68 | -- statistics on virtual generated column not allowed CREATE TABLE ext_stats_test1 (x int, y int, z int GENERATED ALWAYS AS (x+y) VIRTUAL, w xid) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 325e1cbe78cd9f4fafc85963 | CREATE TABLE grantor_test1 () |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 326e33ba740d6a2731dbc654 | -- ok now -- not-null constraint with partitioned table CREATE TABLE gtestnn_parent ( f1 int, f2 bigint, f3 bigint GENERATED ALWAYS AS (nullif(f1, 1) + nullif(f2, 10)) VIRTUAL NOT NULL ) PARTITION ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 337308a13100d2928663beab | create temp table p2 partition of p for values from (10) to (20) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 337fe29b3aefb75e96f017c6 | create table phv_boolpart_f partition of phv_boolpart for values in (false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 33b4b4d5ff6ea572bb5c1593 | -- cannot have default/identity and generated CREATE TABLE gtest_err_5a (a int PRIMARY KEY, b int DEFAULT 5 GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 33f22a31d11c1d9fd4cb4bae | CREATE TABLE "gin_check_multicolumn"(a text[], b text[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 34609735fc694365f3de2b97 | -- enforceability cannot be specified or set for unique constraint CREATE TABLE UNIQUE_EN_TBL(i int UNIQUE ENFORCED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 346df8ed7b7344878b9e94ea | create table notnull_tbl_fail (a int primary key, not null a no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 34950ad62e88c9118cdf2fe2 | CREATE TEMPORARY TABLE test_temp(a int not null unique, b TEXT not null, cnt int not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 34cb78453aa5e95389f8bdb5 | -- (parent_id, valid_at) REFERENCES (id, valid_at) -- both should specify PERIOD: CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4range, CONSTRAINT tem... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 35c8478ceb4fc9171ffbbbb8 | -- triggers CREATE TABLE gtest26 ( a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 35d7674f057dee7a61c5cb07 | CREATE TABLE daucus PARTITION OF vegetables FOR VALUES IN ('daucus') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 36a48f183333de6dfa1698b8 | -- violates constraint -- also check with table constraint syntax CREATE TABLE gtest21ax (a int PRIMARY KEY, b int GENERATED ALWAYS AS (nullif(a, 0)) VIRTUAL, CONSTRAINT cc NOT NULL b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 36a7b2af597a3319f6300b26 | -- Leave these tables around, for pg_upgrade testing -- test that removing inheritance of NOT NULL NO INHERIT works correctly create table inh_parent (f1 int not null no inherit, f2 int not null no... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3738862f52ae0209068eb544 | -- =================================================================== -- test generated columns -- =================================================================== create table gloc1 ( a int, b... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 38234eebcd779a434bf4a35d | CREATE TABLE gtest24r (a int PRIMARY KEY, b gtestdomain1range GENERATED ALWAYS AS (gtestdomain1range(a, a + 5)) STORED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 387a12d2c8e86d16694cef6c | -- NOT NULL NO INHERIT create table inh_nn_parent(a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 38e9aa611b3746e85b078372 | -- ok CREATE TABLE gtestxx_4 (b int GENERATED ALWAYS AS (a * 2) VIRTUAL, a int NOT NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 39229377cc9b6d10cd11f283 | CREATE TABLE stats_import.part_parent ( i integer ) PARTITION BY RANGE(i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 396a49a99cfbfbe2d94ffce1 | CREATE TEMP TABLE id_alw2 (i int GENERATED ALWAYS AS IDENTITY) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 39af52dcb9b87a4c9484e661 | -- -- Verify that transition tables can't be used in, eg, a view. -- create table my_table (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 39b2b98c10b6dbe944261a63 | -- test update CREATE TABLE gtest3 (a int, b int GENERATED ALWAYS AS (a * 3) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 39bc12329f1fc8a58d99dcfa | -- (parent_id, valid_at) REFERENCES (id, PERIOD valid_at) -- FOREIGN KEY part should specify PERIOD CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRA... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 39dcb5d75fa793e93dcd6140 | CREATE TABLE notnull_part1_3_upg (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 39e7acc809f16aaaf50ad680 | create table tuplesest_tab (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3a472feecd1a09c565844a73 | -- error cases: create table notnull_tbl_fail (a serial constraint foo not null constraint bar not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3aa4428c4fc4445df9d63298 | CREATE TABLE notnull_tbl3 (a INTEGER NOT NULL, CHECK (a IS NOT NULL)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3abb8e66f158e4941a08cd44 | CREATE TABLE hashagg_ij(x INTEGER) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3b3f24f5210e3dce90a061a1 | CREATE TABLE foo_part_d2 (b float8, c text, a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3b47ad80bcf0b79613301353 | CREATE TABLE pagg_tab5_p1 PARTITION OF pagg_tab5 FOR VALUES IN ('a', 'b') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3bb5b9013d3ba1134114f8c5 | create table inh_parent_2(f2 text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3bfc1c638ece59a5343e830d | -- -- test PARTITION BY for ranges -- -- temporal PRIMARY KEY: CREATE TABLE temporal_partitioned ( id int4range, valid_at daterange, name text, CONSTRAINT temporal_paritioned_pk PRIMARY KEY (id, va... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3c4151fe72c2245bfcd02fd0 | CREATE TABLE foo_part_s2 PARTITION OF foo_parted FOR VALUES IN (2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3c717dab21eb7c0d4b339afd | -- ok CREATE TABLE gtest20b (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3e4ba346c232e08e7f61f9f9 | CREATE TABLE gtest_err_7b (a int PRIMARY KEY, b int GENERATED ALWAYS AS (row_number() OVER (ORDER BY a)) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3e8dd9b821a04fe553198705 | -- UNIQUE with two columns plus a range: CREATE TABLE temporal_rng3 ( id1 int4range, id2 int4range, valid_at daterange, CONSTRAINT temporal_rng3_uq UNIQUE (id1, id2, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3ea4bb15ebf79c03104e9942 | create temp table t(i int primary key) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3ee2ba18c0ff4e0c814d56c4 | -- PK in inheriting table: CREATE TABLE temporal_rng ( id int4range, valid_at daterange ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3f13399d53ab17cd856a0073 | create table phv_boolpart_t partition of phv_boolpart for values in (true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3f22c3068c3c1767410fb4c1 | CREATE TEMP TABLE temp_t (id int) ON COMMIT DROP |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 3fd5f8d3df0c9a3c4fd06c8e | -- substring fetches a slice of a toasted value; unused tail of that slice is -- an incomplete char (bug #19406) CREATE TABLE toast_3b_utf8 (c text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 403de828d7dfee16aa865521 | --INSERT INTO gtest22b VALUES (2); --INSERT INTO gtest22b VALUES (2); -- indexes CREATE TABLE gtest22c (a int, b int GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 413b60008b41103b0423f76d | create table idxpart2 partition of idxpart for values from (500) to (1000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 416012564b2d66072cdd595f | create table inh_cc2(f4 float) inherits(inh_pp1,inh_cc1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 417e39b9e9776928e4b9a7da | CREATE TABLE "gin_check_jsonb"("j" jsonb) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 424d4522f5ee76385ac11bf2 | CREATE TABLE gtest12 (a int PRIMARY KEY, b int, c int GENERATED ALWAYS AS (gf1(b)) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 42742e2389f76d5ee8743480 | -- PK with one column plus a range: CREATE TABLE temporal_rng ( -- Since we can't depend on having btree_gist here, -- use an int4range instead of an int. -- (The rangetypes regression test uses th... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 42d3e82c0d737db4e2af3bd9 | CREATE TEMP TABLE id_alw3 (i int GENERATED ALWAYS AS IDENTITY) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 43aa6cfc077691a3afa8cfe4 | -- Two scalar columns: CREATE TABLE temporal_fk2_rng2rng ( id int4range, valid_at daterange, parent_id1 int4range, parent_id2 int4range, CONSTRAINT temporal_fk2_rng2rng_pk PRIMARY KEY (id, valid_at... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 446904857b71048ceea8907b | CREATE TABLE distinct_on_tbl (x int, y int, z int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 457d57022f6b5e44f0ca28e5 | -- error CREATE TABLE gtest24ata (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 458875b3c7eaf8b9d01b33b6 | -- (parent_id, PERIOD valid_at) REFERENCES (id) CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4range, CONSTRAINT temporal_fk_mltrng2mltrng_pk PRIMARY ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 45c0475e8ad4ee4c81d9f7b4 | CREATE TABLE gtest_parent (f1 date NOT NULL, f2 bigint, f3 bigint GENERATED ALWAYS AS (f2 * 2) VIRTUAL) PARTITION BY RANGE (f1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 46317e28d3b10e1e9f52b0c2 | CREATE TABLE notnull_tbl1 (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 465d13d3aa35adf242953396 | CREATE TABLE bmscantest (a int, b int, t text) WITH (autovacuum_enabled = false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 468e2928e7348622939e7647 | CREATE TABLE inh_nn4 (a int not null no inherit, b int, not null a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 46dea46c8290eba894849c98 | -- Check that we have the correct tuples estimate for an appendrel create table tuplesest_parted (a int, b int, c float) partition by range(a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 471defae079fa9bd21722fd9 | -- (parent_id, valid_at) REFERENCES (id, valid_at) -- both should specify PERIOD: CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT temporal_fk_rn... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4739d98fcdacd158ecd502c4 | CREATE TABLE pgss_schema_2.tab_search_diff_2 (a text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 47939518464a7a0705c5f13c | -- (parent_id) REFERENCES (id, PERIOD valid_at) CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4range, CONSTRAINT temporal_fk_mltrng2mltrng_pk PRIMARY ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 487646f37e0d1e8751f99f56 | -- test that inhcount is updated correctly through multiple inheritance create table inh_pp1 (f1 int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 48abffc59c7607cf40a3419e | CREATE TEMP TABLE id_alw4 (i int GENERATED ALWAYS AS IDENTITY) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 48ae818ed664c518903c7a11 | -- (parent_id) REFERENCES (id, PERIOD valid_at) CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT temporal_fk_rng2rng_pk PRIMARY KEY (id, valid_at... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 48bfbe7c81dbe910b0c290dd | CREATE TABLE sj_t3 (id serial, a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 496b1aa9b2acd52129915a07 | CREATE TABLE notnull_tbl6_1 PARTITION OF notnull_tbl6 FOR VALUES IN (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 49d7257d75ee6c18e240397d | CREATE TABLE temporal_fk2_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id1 int4range, parent_id2 int4range, CONSTRAINT temporal_fk2_mltrng2mltrng_pk PRIMARY KEY (id, valid_at WITHO... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 49e1399273872881609ca001 | -- Create table with NOT NULL INVALID constraint, for pg_upgrade. CREATE TABLE notnull_tbl1_upg (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4a399c73cc209a0f60106b8e | CREATE TABLE notnull_inhchild (i int) INHERITS (notnull_inhparent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4a44d3d51e502142496ad392 | CREATE TABLE notnull_tbl4_cld3 (PRIMARY KEY (a) DEFERRABLE, CONSTRAINT a_nn NOT NULL a) INHERITS (notnull_tbl4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4a9823c8f21880cb37df736a | CREATE TABLE ctl_stats4_parent (a int, b int, c int, d int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4b0374fcf0e3a08d4c2f2572 | -- check storage of generated columns -- stored create table test9s (a int not null, b int generated always as (a * 2) stored) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4dbf418a32b6b3eeda4b9bbd | -- (parent_id) REFERENCES [implicit] CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT temporal_fk_rng2rng_pk PRIMARY KEY (id, valid_at WITHOUT OV... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4e92676646463908eaa708f2 | CREATE TABLE notnull_tbl4_lk2 (LIKE notnull_tbl4 INCLUDING INDEXES) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4e9332be68d4529979495299 | -- Try a partition with an invalid constraint and create a PK on the parent. CREATE TABLE pp_nn (a int) PARTITION BY HASH (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4efdc6bedd24a1f34d139f74 | CREATE TABLE gtestc (f2 int GENERATED ALWAYS AS (f1+1) VIRTUAL) INHERITS(gtestp) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4f9edd393fc16a092ea41cbe | CREATE TABLE fk_partitioned_fk_3_1 (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4fa098173a2c345e1c84865f | CREATE TABLE fk_partitioned_pk_3 PARTITION OF fk_partitioned_pk FOR VALUES FROM (2000,2000) TO (3000,3000) PARTITION BY RANGE (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 4fc1aa7e6c980bcf6800cfb1 | -- -- Simple Lists -- CREATE TABLE test_squash (id int, data int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5086a2f548641535514a8f08 | CREATE TABLE tfkp1 partition OF temporal_partitioned_fk_rng2rng FOR VALUES IN ('[1,2)', '[3,4)', '[5,6)', '[7,8)', '[9,10)', '[11,12)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5098bc9eefcb5e76be5b71bc | CREATE TABLE temporal_fk2_rng2rng ( id int4range, valid_at daterange, parent_id1 int4range, parent_id2 int4range, CONSTRAINT temporal_fk2_rng2rng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS), CON... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 514d7e89f69e888e6817c7c3 | create table part_abc_2 (a int, c bool, b text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 51807c655e270ad276fbb2f0 | -- Test case where the child constraint is invalid, the grandchild constraint -- is valid, and the validation for the grandchild should be skipped when a -- valid constraint is applied to the top p... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 530357c2bb121535095a7765 | -- Inheritance test tables for pg_upgrade create table constr_parent (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 53542f7e120210062fb9cbc6 | create table inh_multiparent() inherits(inh_p1, inh_p2, inh_p3, inh_p4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 54e16d438fde5fde06b6b9da | CREATE TABLE inh_nn2 (a int not null no inherit) INHERITS (inh_nn1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 558fe90fd329eb744e4b22ba | -- -- range UQ: test with existing rows -- CREATE TABLE temporal_rng3 ( id int4range, valid_at daterange ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 55cddc8ce8054ae32327709d | -- PK with two columns plus a multirange: CREATE TABLE temporal_mltrng2 ( id1 int4range, id2 int4range, valid_at datemultirange, CONSTRAINT temporal_mltrng2_pk PRIMARY KEY (id1, id2, valid_at WITHO... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 55e887b32cfb850b754fe059 | -- -- test the expansion of virtual generated columns -- -- these tests are specific to generated_virtual.sql -- create table gtest32 ( a int primary key, b int generated always as (a * 2), c int g... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 575c90e3e1f84170fe8f6867 | -- ok -- index constraints CREATE TABLE gtest22a (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a / 2) VIRTUAL UNIQUE) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 57671bcd3ec4e83180f96364 | CREATE TABLE grantor_test2 () |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 577d2035651fe869a11b48c1 | CREATE TABLE foo_part_d1 (c text, a int, b float8) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5817bf2341f3c4c6b64555c4 | CREATE TABLE pgss_do_util_tab_1 (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 587062f74290a5e602a74b41 | -- error CREATE TABLE gtestxx_3 (a int NOT NULL, b int GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 590141143dc37f4cf072cd0c | -- Some casting expression are simplified to Const CREATE TABLE test_squash_jsonb (id int, data jsonb) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5a1c0c20f9fe63202bcfdf73 | CREATE TABLE gtest4 ( a int, b double_int GENERATED ALWAYS AS ((a * 2, a * 3)) VIRTUAL ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5a3ab6890b669a1a07bbd344 | create table constr_child3 () inherits (constr_parent2, constr_parent3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5a511d7bf583f59e099570c5 | CREATE TABLE gtest24nn (a int, b gtestdomainnn GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5ade8adaf0dee8cba2a77b42 | CREATE TABLE pagg_tab5_p2 PARTITION OF pagg_tab5 FOR VALUES IN ('c', 'd') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5af526a068f1d649276463fe | -- error CREATE TABLE gtest_child (f1 date NOT NULL, f2 bigint, f3 bigint GENERATED ALWAYS AS (f2 * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5ca661aa233eca5f20fcbe5b | -- ALTER TABLE ... ALTER COLUMN ... DROP EXPRESSION CREATE TABLE gtest29 ( a int, b int GENERATED ALWAYS AS (a * 2) VIRTUAL ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5cc562f6b524429d9e6b7558 | create temp table t (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5d8731c1f99295b90b2d18d2 | CREATE TABLE test_like_gen_1 (a int, b int GENERATED ALWAYS AS (a * 2) STORED, c int GENERATED ALWAYS AS (a * 3) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5e4dea8de9ec2845e6c39f04 | -- -- multirange UQ: test with existing rows -- CREATE TABLE temporal_mltrng3 ( id int4range, valid_at datemultirange ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5e82a06b7c1b847f9b210d48 | create table notnull_tbl_fail (a serial not null no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5fd0fd37c2184c747ed119e9 | create table defer_trig (id integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 5fde49274c4359417963b7cc | -- fails on existing row -- check with whole-row reference CREATE TABLE gtest20c (a int, b int GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 615696421db16718ed933b43 | CREATE TABLE brintest_expr (n int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 62462cfa16a1c761e082aec4 | -- generation expression must be immutable CREATE TABLE gtest_err_4 (a int PRIMARY KEY, b double precision GENERATED ALWAYS AS (random()) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6304101c4315c863d02306aa | create table inh_child3() inherits(inh_child1, inh_child2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6357fac6256ef505d548e266 | CREATE TABLE pagg_tab6_p1 PARTITION OF pagg_tab6 FOR VALUES IN ('a', 'b') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 63e4d5d00915f833a018ef29 | -- -- Test ALTER CONSTRAINT SET [NO] INHERIT -- create table inh_nn1 (f1 int not null no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 655ef8247fa959d4ce87f658 | -- Runtime pruning on UPDATE using WITH CHECK OPTIONS and RETURNING create table part_abc (a int, b text, c bool) partition by list (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 659bf230c44fa1d51240adfe | -- Foreign key CREATE TABLE temporal_fk_rng2rng ( id integer, valid_at daterange, parent_id integer, CONSTRAINT temporal_fk_rng2rng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS), CONSTRAINT tempor... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 65ad46e0bf9c13069a64fe7e | -- Can't have two constraints with the same name CREATE TABLE notnull_tbl2 (a INTEGER CONSTRAINT blah NOT NULL, b INTEGER CONSTRAINT blah NOT NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 65c363e3d01f4041b04f8e91 | CREATE TABLE temporal_partitioned_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT temporal_partitioned_fk_rng2rng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS), CONS... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 65c8981d7e5e3e4ae823dabc | CREATE TABLE gtest_err_7d (a int PRIMARY KEY, b int GENERATED ALWAYS AS (generate_series(1, a)) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 66bb752f9b54ea550c1409fd | -- As above, but create the primary key using a UNIQUE index CREATE TABLE cnn_pk (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 66e81f4bd92b82f4e5a68859 | CREATE TABLE notnull_tbl1 (a int, b int) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 67a87b54494d3fcfae728e7e | -- null values CREATE TABLE gtest2 (a int PRIMARY KEY, b int GENERATED ALWAYS AS (NULL) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 67d6025c5f231537aea03284 | -- LIKE INCLUDING GENERATED and dropped column handling CREATE TABLE gtest28a ( a int, b int, c int, x int GENERATED ALWAYS AS (b * 2) VIRTUAL ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6875a7ce24d8079f5aa42e1e | CREATE TABLE temporal_rng3 ( id int4range, valid_at textrange2, CONSTRAINT temporal_rng3_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 68ac618b0be94f6b403bab33 | -- -- Similarly, check the merging of existing constraints; a parent constraint -- marked as NOT ENFORCED can merge with an ENFORCED child constraint, but the -- reverse is not allowed. -- create t... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 68b4dad14a3dd64f88a80e31 | -- check that recursive CTE processing doesn't rewrite a CTE more than once -- (must not try to expand GENERATED ALWAYS IDENTITY columns more than once) CREATE TEMP TABLE id_alw1 (i int GENERATED A... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 69ca5a904453105dad3a0c1a | create table inh_nn3 () inherits (inh_nn2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 69d5d5b66bbe221d0ef9f594 | create table inh_multiparent2 (a int not null, f1 int) inherits(inh_p3, inh_multiparent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6a41eebf830b0046394a2f75 | CREATE TABLE trigger_test_generated ( i int, j int GENERATED ALWAYS AS (i * 2) STORED, k int GENERATED ALWAYS AS (i * 3) VIRTUAL ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6af1dbe6a45328f9cfbba82e | CREATE TABLE stats_import.test( id INTEGER PRIMARY KEY, name text, comp stats_import.complex_type, arange int4range, tags text[] ) WITH (autovacuum_enabled = false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6ba6d816e6d359f28c97cc5d | -- Can't create a FK with a mismatched multirange type CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at int4multirange, parent_id int4range, CONSTRAINT temporal_fk_mltrng2mltrng_pk2 ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6bc49d17958371a1089fe70e | -- Test the 'publish_generated_columns' parameter as 'none' and 'stored' for -- different scenarios with/without generated columns in column lists. CREATE TABLE gencols (a int, gen1 int GENERATED A... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6bc4a7f133f393ee37714f30 | CREATE TABLE grouping_unique (x integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6c7cfe972b3f2b4218ca7988 | CREATE TABLE testpub_tbl5 (a int PRIMARY KEY, b text, c text, d int generated always as (a + length(b)) stored, e int generated always as (a + length(b)) virtual ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6cff52d0e16f0c6f1c7ae988 | CREATE TABLE only_inh_child () INHERITS (only_inh_parent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6d2bb965126275fa5a92e9ff | CREATE TABLE tp2 PARTITION OF temporal_partitioned FOR VALUES IN ('[3,4)', '[4,5)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6dc3d8cca742bf2a4a478502 | -- test MERGE CREATE TABLE gtestm ( id int PRIMARY KEY, f1 int, f2 int, f3 int GENERATED ALWAYS AS (f1 * 2) VIRTUAL, f4 int GENERATED ALWAYS AS (f2 * 2) VIRTUAL ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6e2fb0470d34eb99d58986d4 | -- constraints with different enforceability can be merged by marking them as ENFORCED create table p1_c3() inherits(p1, p1_c1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6f1e5b937a8904cbed13989a | CREATE TABLE gtest3a (a text, b text GENERATED ALWAYS AS (a \|\| '+' \|\| a) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 6f5e84b000a8b84fb0be39ca | -- virtual create table test9v (a int not null, b int generated always as (a * 2) virtual) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 70e61d42d806be54ce022264 | CREATE TABLE gtest12 (a int PRIMARY KEY, b int, c int GENERATED ALWAYS AS (gf1(b)) STORED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 71335784f6e175fc41aa2841 | create table p1_c2(f1 int constraint inh_check_constraint4 check (f1 < 10)) inherits(p1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7156cada28822bfa4f749e1f | CREATE TABLE notnull_inhgrand () INHERITS (notnull_inhparent, notnull_inhchild) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 717201029c3f559e03106cc5 | create table inh_child3 (like inh_parent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 71e9101f7b0ba15930c56028 | CREATE TABLE notnull_tbl1_2(a int, CONSTRAINT nn2 NOT NULL a, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 72ee7ddfa13d2bb440677e41 | -- This should fail because pg_buffercache_evict_relation() doesn't accept -- local relations CREATE TEMP TABLE temp_pg_buffercache() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 73830606ec6c379715dfda0a | CREATE TABLE fk_notpartitioned_fk (b int, a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7495b432dcdc890ab45e298d | create table idxpart11 partition of idxpart1 for values from (0) to (500) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 749c26e5c548927b1caa2be8 | CREATE TABLE test12fk (a int, b text COLLATE case_insensitive REFERENCES test12pk (x) ON UPDATE NO ACTION) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 759bebc856b455d247360b81 | create table part_abc_3_3 partition of part_abc_3 for values from (100) to (maxvalue) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 76e651025b1f0e66722b0d2e | -- (parent_id) REFERENCES [implicit] CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4range, CONSTRAINT temporal_fk_mltrng2mltrng_pk PRIMARY KEY (id, va... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 77701306d524fe30bf294873 | -- OK when the partition key collation is same as that of the join columns CREATE TABLE pagg_tab5 (c text collate case_insensitive, b text collate case_insensitive) PARTITION BY LIST (c collate cas... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 787ac5c48ad3026961570963 | create table inh_child (a int primary key) inherits (inh_parent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7970319354d5f405fed31754 | CREATE TABLE tp2 partition OF temporal_partitioned_rng FOR VALUES IN ('[2,3)', '[4,5)', '[6,7)', '[8,9)', '[10,11)', '[12,13)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7a0b4a3170d58348125d40b8 | --INSERT INTO gtest22a VALUES (2); --INSERT INTO gtest22a VALUES (3); --INSERT INTO gtest22a VALUES (4); CREATE TABLE gtest22b (a int, b int GENERATED ALWAYS AS (a / 2) VIRTUAL, PRIMARY KEY (a, b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7a389b5b996d06ae15ee7dd2 | create table inh_p4(f1 int not null, f3 text not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7a38ad345b9f616861b5631e | CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4range, CONSTRAINT temporal_fk_mltrng2mltrng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS), CONSTRAINT ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7bd08d90369c0bc2729287f5 | CREATE TABLE gtest21ax (a int PRIMARY KEY, b int GENERATED ALWAYS AS (nullif(a, 0)) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7c063b2ff2e97f1c90ce8386 | CREATE TABLE tp1 partition OF temporal_partitioned_rng FOR VALUES IN ('[1,2)', '[3,4)', '[5,6)', '[7,8)', '[9,10)', '[11,12)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7cbd68a5da9c3bb0b9fdbbfd | create table sl(a int, b int, c int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7cde34477138d8ebbdc69b7e | CREATE TABLE stats_import.part_child_1 PARTITION OF stats_import.part_parent FOR VALUES FROM (0) TO (10) WITH (autovacuum_enabled = false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7ddb70d7bf456493023a4443 | -- Attaching a child with a NOT VALID constraint. CREATE TABLE fk_partitioned_fk_2 (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7e7f7f34f8517dc4afdd1987 | CREATE TABLE pt(i int) PARTITION BY hash (i part_test_int4_ops_bad) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7e8aba4ad3a05661f331018f | -- fails on existing row -- check with whole-row reference CREATE TABLE gtest20c (a int, b int GENERATED ALWAYS AS (a * 2) STORED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7f05d6e0bb3fc781b1305272 | -- no PK from INHERITS: CREATE TABLE temporal_rng2 () INHERITS (temporal_rng) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7f0e7e802b774c2d78e643d5 | create table inh_nn4 (f5 int, f4 float, f2 text, f3 int, f1 int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 7fbb65ae718d0f3596e3d8d7 | CREATE TABLE temporal_partitioned_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4range, CONSTRAINT temporal_partitioned_fk_mltrng2mltrng_pk PRIMARY KEY (id, valid_at WITHOU... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 80bb0ceb624f00a857076421 | create table inh_child1 () inherits (inh_parent1, inh_parent2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 80e0909c66d08223a8130cf0 | create table constr_parent2 (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 80f583b26f835f0ae4cbfe9f | create table sj (a int unique, b int, c int unique) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 80f592cc8e0ef23a4fcd1ee5 | CREATE TABLE tfkp2 PARTITION OF temporal_partitioned_fk_mltrng2mltrng FOR VALUES IN ('[0,1)', '[2,3)', '[4,5)', '[6,7)', '[8,9)', '[10,11)', '[12,13)', '[14,15)', '[16,17)', '[18,19)', '[20,21)', '... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 81500b98978b84ab972f7eea | -- (parent_id, valid_at) REFERENCES [implicit] -- FOREIGN KEY part should specify PERIOD CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT tempora... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 81b6fcfef2808d6275f09f8d | -- LIKE ... INCLUDING STATISTICS with dropped columns in the parent, -- so stxkeys attnums are not contiguous. CREATE TABLE ctl_stats3_parent (a int, b int, c int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 81eb6d1ae3fb5b4829fbe226 | CREATE TABLE ATACC1 (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 82f9722a38eb4fdd57bdf6c3 | -- error CREATE TABLE gtest_normal_child (a int, b int GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 835700db54fdb2d028e78daa | -- Ensure that virtual generated columns work with WHERE CURRENT OF create table gtest_cursor (id int primary key, a int, b int generated always as (a * 2) virtual) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 838dc07ba7773c2a7b762169 | create table part_abc_3 partition of part_abc for values in (3, 4) partition by range (d) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 839c75623ef83c8f749d54a7 | CREATE TABLE gtestnn_child PARTITION OF gtestnn_parent FOR VALUES FROM (1) TO (5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 83f513d466f4a32ae5025868 | -- Test cross-partition updates and attribute mapping CREATE TABLE foo_parted (a int, b float8, c text) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 84ab5757266eed290cd559ce | -- Adding a PK at the top level of a hierarchy should cause all descendants -- to be checked for nulls, even past a no-inherit constraint CREATE TABLE inh_nn_lvl1 (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 85e7ded12b17c43741e055df | create table test_t (c text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 85f173318ba7d3831e91f522 | CREATE TABLE fk_partitioned_fk_2 (b int, a int, CONSTRAINT fk_part_con FOREIGN KEY (a, b) REFERENCES fk_notpartitioned_pk ON UPDATE CASCADE ON DELETE CASCADE NOT ENFORCED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8776a8f1668f7d1a5607897e | -- inherits gen expr CREATE TABLE gtest_child2 PARTITION OF gtest_parent ( f3 WITH OPTIONS GENERATED ALWAYS AS (f2 * 22) VIRTUAL -- overrides gen expr ) FOR VALUES FROM ('2016-08-01') TO ('2016-09-... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8844a72a76ea4a8c197bd8dd | -- Same number of attributes, different types CREATE TABLE pgss_schema_1.tab_search_diff_2 (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 88c55978b68461e612f7fe7c | create table gtest34p (id int primary key, a int, c int generated always as (a * 10) virtual) partition by range (id) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 88e5f6d05b9670864cc5bff4 | create table notnull_tbl_fail (a int, primary key(a), not null a no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8927d48345ea1e3f26b4e305 | create table cnn_part1 partition of cnn2_parted for values in (1, null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8968ebaa06370308e8a539eb | -- -- A unique index can prove functional dependency for GROUP BY column -- removal only if its per-column collation agrees on equality with -- the GROUP BY column's collation. An index built under... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8af14ac0326e21347f950493 | -- including storage and comments CREATE TABLE ctlt1 (a text CHECK (length(a) > 2) ENFORCED PRIMARY KEY, b text CHECK (length(b) > 100) NOT ENFORCED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8b0e70f3f4f22fb3f011c39b | -- Negative scenarios for alter constraint .. inherit. create table inh_nn1 (f1 int check(f1 > 5) primary key references inh_nn1, f2 int not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8b46d1c859610eaee48f9fe8 | -- Test schema-qualified table name in RETURNING list CREATE TABLE public.tt(a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8b7ce3eca976b01106b0911c | create temp table t_opf (a t_rec not null, b text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8bbc308824b769b972100337 | CREATE TABLE inh_nn1 (a int not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8cfcaefb288e542c099b0c9e | create table inh_child2(f1 int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8d64c4422580336e1b6f9cc4 | CREATE TABLE gtest11 (a int PRIMARY KEY, b int, c int GENERATED ALWAYS AS (b * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8df4d1c1f9ba226248335b41 | CREATE TABLE distinct_tbl (x int, y int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8e540423eb843e2fed46835e | CREATE TABLE gtest1 (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8ed68ddc6ed7cc3d06d07a78 | CREATE TABLE ctl_stats4_child (LIKE ctl_stats4_parent INCLUDING STATISTICS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8f0977eadab46d7d5fad40db | CREATE TABLE fk_partitioned_fk_6_1 PARTITION OF fk_partitioned_fk_6 FOR VALUES IN (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8f520d87c9f19a65c3207bc7 | create table inh_nn2 (f2 text, f3 int) inherits (inh_nn1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 8f8f299ea2fb68027dd30a16 | CREATE TABLE tp1 PARTITION OF temporal_partitioned_mltrng FOR VALUES IN ('[1,2)', '[3,4)', '[5,6)', '[7,8)', '[9,10)', '[11,12)', '[13,14)', '[15,16)', '[17,18)', '[19,20)', '[21,22)', '[23,24)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 905d2ec0d39a98876e504849 | create table tbl_nocom(a int8, b int8alias1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 928f73b400948a5ad439ba87 | CREATE TEMP TABLE tab_search_same (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 935554754dc123a04f48c4d0 | -- test child table with inherited columns and -- with explicitly specified not null constraints create table inh_parent_1(f1 int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 93de891b8c1a96a46fa0e44b | -- -- Tests for ANALYZE ONLY / VACUUM ONLY on partitioned tables -- CREATE TABLE only_parted (a int, b text) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 94472e065213cb6603ddba4c | CREATE TABLE gtestm ( a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) STORED ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 95013c88bbf0536f59f74949 | -- fail, as partitioned tables don't allow NO INHERIT constraints CREATE TABLE noinh_con_copy1_parted (LIKE noinh_con_copy INCLUDING ALL) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 95626d956689562cc3c3bb71 | create table notnull_tbl_fail (a int generated by default as identity, constraint foo not null a no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 97d4265e093e8d92362c98b3 | CREATE TABLE gtest_child3 (f1 date NOT NULL, f2 bigint, f3 bigint GENERATED ALWAYS AS (f2 * 33) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 97ff049b56693280f54d43f2 | CREATE TABLE gtest_err_7c (a int PRIMARY KEY, b int GENERATED ALWAYS AS ((SELECT a)) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 986a561c7e399ea1bd020e8f | CREATE TABLE gtest24r (a int PRIMARY KEY, b gtestdomain1range GENERATED ALWAYS AS (gtestdomain1range(a, a + 5)) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 98ae53a53c5c9d3a1d719305 | -- PK with USING INDEX (not possible): CREATE TABLE temporal3 ( id int4range, valid_at daterange ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 98b04bdd27b38119223c82b7 | create table part_abc_1 (b text, a int, c bool) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9925f63620918d64f64b3693 | -- Test invalid not null on inheritance table. CREATE TABLE notnull_inhparent (i int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 99b9c329bc9f41f6d6001634 | -- ALTER .. NO INHERIT works for invalid constraints CREATE TABLE notnull_tbl1 (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 99bab07b6372501100870c99 | CREATE TABLE temporal_rng4 ( id int4range, valid_at int4_d_range, CONSTRAINT temporal_rng4_pk PRIMARY KEY(id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 99e496693ca8b122cac1af12 | CREATE TABLE ctl_stats3_child (LIKE ctl_stats3_parent INCLUDING STATISTICS) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 99e8f4d0eb0f8b4814fc3a2a | -- temporal UNIQUE: CREATE TABLE temporal_partitioned ( id int4range, valid_at daterange, name text, CONSTRAINT temporal_paritioned_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) ) PARTITION BY LIST (id) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 99f6b866f05c42c4c55156e9 | CREATE TABLE pgss_parallel_tab (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9a035f17a15a6c0e4feece0b | create table gtest34p_1 partition of gtest34p for values from (1) to (100) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9b85219de7d172439b824b4f | -- Verify that constraint names and NO INHERIT are properly considered when -- multiple constraint are specified, either explicitly or via SERIAL/PK/etc, -- and that conflicting cases are rejected.... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9c3fb667aafdb9a40b638b1c | -- -- FK between partitioned tables: multiranges -- CREATE TABLE temporal_partitioned_mltrng ( id int4range, valid_at datemultirange, name text, CONSTRAINT temporal_paritioned_mltrng_pk PRIMARY KEY... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9c4f79c6961dab888d7518a1 | -- it's not possible to override a no-inherit constraint with an inheritable one CREATE TABLE ATACC2 (a int, CONSTRAINT a_is_not_null NOT NULL a NO INHERIT) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9c59af8673f49d47e7e447c5 | create table p1(f1 int constraint p1_a_check check (f1 > 0) enforced) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9c83a33e946975738f064f46 | CREATE TABLE notnull_tbl4_cld2 (PRIMARY KEY (a) DEFERRABLE) INHERITS (notnull_tbl4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9e21a590791821fc8f4d7d34 | -- -- test deinherit procedure -- -- deinherit inh_child1 create table inh_child3 () inherits (inh_child1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9e3eb0b8679a6a8aaf6bcb76 | CREATE TABLE sj_t1 (id serial, a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9e7e72ac85b1cf7d35e1be21 | --INSERT INTO gtest23a VALUES (1, 11), (2, 22), (3, 33); CREATE TABLE gtest23x (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL REFERENCES gtest23a (x) ON UPDATE CASCADE) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9f38a97826312f3cee5252a2 | create temp table t_append (a int not null, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | 9fddf5520285a53104acd6dd | CREATE TABLE notnull_tbl5_child () INHERITS (notnull_tbl5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a05a4b354f24fdae31edc338 | CREATE TABLE ATACC1 (a int, NOT NULL a NO INHERIT) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a07170bc70025fc36632361b | create table notnull_tbl_fail (a serial constraint foo not null no inherit constraint foo not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a0c2c47a9974c95b0fc1196e | --INSERT INTO gtest24nn (a) VALUES (4); -- ok --INSERT INTO gtest24nn (a) VALUES (NULL); -- error -- using user-defined type not yet supported CREATE TABLE gtest24xxx (a gtestdomain1, b gtestdomain... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a117b51ddf67d39f04f94689 | CREATE TABLE foo_part_s1 PARTITION OF foo_parted FOR VALUES IN (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a2449a4a238be71746083630 | create table tuplesest_parted1 partition of tuplesest_parted for values from (0) to (100) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a2af7e42bc28607a0eed9ae5 | CREATE TABLE vegetables (id serial, name text, genus text) PARTITION BY LIST (genus) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a2e0735d6610110e15a0f225 | -- virtual generated columns CREATE TABLE t5 ( a int, b text collate "C", c text collate "C" GENERATED ALWAYS AS (b COLLATE case_insensitive) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a2f66fb5fa2ae207e5f2826f | -- UNIQUE with a non-range column: CREATE TABLE temporal_rng3 ( id int4range, valid_at TEXT, CONSTRAINT temporal_rng3_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a3ee9913ccf03e464782c9c0 | CREATE TABLE only_parted1 PARTITION OF only_parted FOR VALUES IN (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a541f07ee5b11ee6f34f663a | CREATE TABLE notnull_tbl1_chld () INHERITS (notnull_tbl1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a5642f71465e7b8619901b4e | -- simple column reference for varlena types CREATE TABLE gtest_varlena (a varchar, b varchar GENERATED ALWAYS AS (a) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a589fb1ff40ecfb0d1a8ba91 | -- check that NOT NULL NO INHERIT cannot be merged to a normal NOT NULL CREATE TABLE part_fail (a int NOT NULL NO INHERIT, b char(2) COLLATE "C", CONSTRAINT check_a CHECK (a > 0) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a637e8071924008ec1ecb691 | -- ... but be sure that the immutability test is accurate CREATE TABLE gtest2 (a int, b text GENERATED ALWAYS AS (a \|\| ' sec') VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a6e39f7bad1794847051512f | -- Test the same constraint name for different columns in different parents create table inh_parent1(a int constraint nn not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a703a0b4443bb81982ffdc61 | create table notnull_tbl_fail (a int generated by default as identity not null no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | a8f6fdf68309bdb9892b2a1a | create table notnull_tbl_fail (a serial, constraint foo not null a no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ab17b28dd8793eac34b7f772 | CREATE TABLE inh_nn_parent (a int, NOT NULL a NO INHERIT) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ab82ac0033708c82928bf2bd | -- Attaching a child table with the same valid foreign key constraint. CREATE TABLE fk_partitioned_fk_1 (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | acc5db5a96d85882421f5a28 | CREATE TABLE ctl_table(a int PRIMARY KEY, b varchar COMPRESSION pglz, c int GENERATED ALWAYS AS (a * 2) STORED, d bigint GENERATED ALWAYS AS IDENTITY, e int DEFAULT 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | adc3d32c7acdebe11f549246 | -- can't drop NOT NULL from under an invalid PK CREATE TABLE list_parted3 (a int NOT NULL) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | adefabf69b4121f25e7eca88 | -- we leave these tables around for purposes of testing dump/reload/upgrade -- generated columns in partition key (not allowed) CREATE TABLE gtest_part_key (f1 date NOT NULL, f2 bigint, f3 bigint G... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | af8b11b24b23da842d0d9b94 | CREATE UNLOGGED TABLE unlogged1 (a int) PARTITION BY RANGE (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b008166733f3fd8ced5b272c | create table inh_parent2(b int constraint nn not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b01cb9198531ffb942a95bdc | -- stored CREATE TABLE testpub_gencol (a INT, b INT GENERATED ALWAYS AS (a + 1) STORED NOT NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b03ff5e107ed65dc63f48b64 | CREATE TABLE pagg_tab4 (c text collate case_insensitive, b text collate case_insensitive) PARTITION BY LIST (b collate "C") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b08f677ad977bfcd3a2652ab | -- -- test inherit/deinherit -- create table inh_parent(f1 int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b0e6c822bf542957c709f8ed | -- Bigint, implicit cast is squashed CREATE TABLE test_squash_bigint (id int, data bigint) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b1d14b184e2108fe1fe61ff5 | CREATE TABLE of_tt_enum_type OF tt_enum_type |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b1d9fe4a684f02afe9c355d9 | CREATE TABLE pagg_tab6_p2 PARTITION OF pagg_tab6 FOR VALUES IN ('c', 'd') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b1e0d4fc97854f34314fb798 | create table phv_part_1 partition of phv_part for values in (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b2480bfeb9a1da85f920175b | CREATE TABLE regress_encoding(good text, truncated text, with_nul text, truncated_with_nul text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b2acbcdd65c89eb8ce0a07d3 | -- ok (currently not supported) CREATE TABLE gtest20a (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b3685ad731412214ab9ef263 | -- PK with a range column/PERIOD that isn't there: CREATE TABLE temporal_rng ( id INTEGER, CONSTRAINT temporal_rng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b4caa89770201cac7d3b71b0 | CREATE TABLE test4nfd (a int, b text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b4fc6c11b561f4c91c439850 | -- Check it for a partitioned table, too CREATE TABLE gtest31_1 (a int, b text GENERATED ALWAYS AS ('hello') VIRTUAL, c text) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b59ac750c94e7d6011e698ea | CREATE TABLE gtest_child3 PARTITION OF gtest_parent ( f3 GENERATED ALWAYS AS (f2 * 2) VIRTUAL -- error ) FOR VALUES FROM ('2016-09-01') TO ('2016-10-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b66466101ecbfb9a0518c9ec | CREATE TABLE vac_tab_auto(i int, j text) WITH (autovacuum_enabled=false, vacuum_index_cleanup=auto, toast.vacuum_index_cleanup=auto) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b80dfd5b6ac482a04efc67c4 | create table cc2 (f4 float) inherits (pp1,cc1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b846b884c31073d65d25f61b | -- Add range column and the PK at the same time CREATE TABLE temporal3 ( id int4range ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b8c0bdb0fde6d33ab3f92c3f | CREATE TABLE p1 PARTITION OF pt FOR VALUES WITH (modulus 4, remainder 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | b9d27fa68d753dee70c793c7 | -- Same attributes. CREATE TABLE pgss_schema_1.tab_search_same (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ba6590bb21fd815b53c96f3a | -- error CREATE TABLE gtest1_y (b int GENERATED ALWAYS AS (x + 1) VIRTUAL) INHERITS (gtest1, gtesty) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ba6bba2fb66b609d21c0967c | -- various prohibited constructs CREATE TABLE gtest_err_7a (a int PRIMARY KEY, b int GENERATED ALWAYS AS (avg(a)) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | baf1a7324e368e185b2673d0 | -- error CREATE TABLE gtestx (x int, b int GENERATED ALWAYS AS (a * 22) VIRTUAL) INHERITS (gtest1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | bafecbc3127d386377dfd68b | CREATE TABLE temporal_mltrng ( id int4range, valid_at datemultirange) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | bb2b5cb69145dd247c4b54bb | CREATE TABLE temporal_rng2 ( CONSTRAINT temporal_rng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) ) INHERITS (temporal_rng) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | bd2459e0e281e832d51b6713 | CREATE TABLE gtestnn_childdef PARTITION OF gtestnn_parent default |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | bd734abb4e199421d07d8667 | -- columns in regular and LIKE inheritance should be marked not-nullable -- for primary keys, even if those are deferred CREATE TABLE notnull_tbl4 (a INTEGER PRIMARY KEY INITIALLY DEFERRED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | bdbb43215cfd2f0b356a253b | -- Test row-level locks held by prepared transactions CREATE TABLE pxtest_rowlock (id int PRIMARY KEY, data text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | be2095e95816865f2d96c428 | -- invalid reference CREATE TABLE gtest_err_3 (a int PRIMARY KEY, b int GENERATED ALWAYS AS (c * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | be2a23ea95afc309fe9b5fda | -- -- Check that operands wrapped in PlaceHolderVars are matched to partition -- keys, allowing partition pruning to occur. PlaceHolderVars can be -- introduced when a subquery's output is used wit... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | beace66a930c87b5ed1b5869 | CREATE TABLE test_pg_unicode_fast ( t TEXT COLLATE PG_UNICODE_FAST ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c02d94eae333a480fef859e8 | CREATE TABLE gtest_part_key (f1 date NOT NULL, f2 bigint, f3 bigint GENERATED ALWAYS AS (f2 * 2) VIRTUAL) PARTITION BY RANGE ((f3)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c05ab0477099082beea4fd1c | create table inh_child1() inherits(inh_parent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c0a5d97f1c7584661b18b1ed | -- error CREATE TABLE gtest23x (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL REFERENCES gtest23a (x) ON DELETE SET NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c194637bdbeb411841ce85f0 | -- with mismatched PERIOD columns: -- (parent_id, PERIOD valid_at) REFERENCES (id, valid_at) -- REFERENCES part should specify PERIOD CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at dater... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c1d3f869b2fa36a724587dcc | -- PK with two columns plus a range: CREATE TABLE temporal_rng2 ( id1 int4range, id2 int4range, valid_at daterange, CONSTRAINT temporal_rng2_pk PRIMARY KEY (id1, id2, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c2d1fc08b20ae31d7973f93d | -- with a UNIQUE constraint: CREATE TABLE temporal_mltrng3 ( id int4range, valid_at datemultirange, CONSTRAINT temporal_mltrng3_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c35f6dfb2c6122a502d9863d | -- -- FuncExpr -- -- Verify multiple type representation end up with the same query_id CREATE TABLE test_float (data float) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c3e03dd9248c9e2ab897243b | create table aitest ( price_id int4, price_val int4, price_on int4 ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c4ea21032686d6dbbf7d44c0 | -- should fail because of duplicate referenced columns: CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4range, CONSTRAINT temporal_fk_mltrng2mltrng_pk ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c52ca309f0e8916b208b28c4 | CREATE TABLE UNIQUE_NOTEN_TBL(i int UNIQUE NOT ENFORCED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c570683c94bc4c48c1ff5bc7 | -- No validation is done on the encoding itself, just the length to avoid -- overruns, so some of the byte sequences below are bogus. They cover -- all code branches, server encodings only for now.... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c69048246d2146dba9da6a87 | CREATE TABLE gtest21b (a int, b int GENERATED ALWAYS AS (nullif(a, 0)) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c6ba178ac0ab9e4817bde074 | create table constr_child (a int) inherits (constr_parent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c6ee23eb2070cae65f3bfe5f | CREATE TABLE gtestm ( a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c792c602e99f48b0595a7dee | create table inh_nn2 (f2 text, f3 int, f1 int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c7c341cd35bd80d8b15eb529 | CREATE TABLE sj_t2 (id serial, a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c7dc066b1a2757a4096c559b | -- Unique constraints don't give raise to not-null constraints, however. create table cnn_uq (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c9ba4b6005ee0bdfa35d8d04 | --INSERT INTO gtest24r (a) VALUES (4); -- ok --INSERT INTO gtest24r (a) VALUES (6); -- error CREATE TABLE gtest24at (a int PRIMARY KEY) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | c9ea5b1928269ae88ff9b8ce | create table cc3 () inherits (pp1,cc1,cc2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ca0931c0e321910d26189d45 | create table inh_p3(f2 int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ca419b195f370672ebcf4524 | -- drop column behavior CREATE TABLE gtest10 (a int PRIMARY KEY, b int, c int GENERATED ALWAYS AS (b * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | cab8f16b50ebba2f0b7942b6 | CREATE TABLE pp_nn_1(a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | cb38b88d73ef32470b54930a | -- This tests the issue described in match_pattern_prefix(). In the -- absence of that check, the case_insensitive tests below would -- return no rows where they should logically return one. CREATE... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | cbd1e51b3e3f8005e41c761c | create table notnull_tbl_fail (a int constraint foo not null, constraint foo not null a no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | cc3aeaaad316c83f82a40acb | CREATE TABLE tfkp2 partition OF temporal_partitioned_fk_rng2rng FOR VALUES IN ('[2,3)', '[4,5)', '[6,7)', '[8,9)', '[10,11)', '[12,13)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | cc50f50895a77cdbd4fded3b | -- UNIQUE with a range column/PERIOD that isn't there: CREATE TABLE temporal_rng3 ( id INTEGER, CONSTRAINT temporal_rng3_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | cc70c2bf47a31c00860009bd | create table inh_child1(f1 int not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ce3375571878e238b49562b8 | -- Test multiple parents with overlapping primary keys create table inh_parent1(a int, b int, c int, primary key (a, b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ce54b69fd44049185d9a3552 | create table inh_nn_child() inherits (inh_nn_parent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ce6db2b90152a2a56bb67ffc | -- BooleanTest: IS TRUE with PHV-wrapped boolean partition key create table phv_boolpart (a bool, b text) partition by list (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ce888a14e1915217b67206c0 | -- verify constraints created for NOT NULL clauses CREATE TABLE notnull_tbl1 (a INTEGER NOT NULL NOT NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ceb31057dfeec029696590fa | -- error -- foreign key actions -- Some of the behaviors are most easily visible with a -- case-insensitive collation. CREATE TABLE test12pk (x text COLLATE case_insensitive PRIMARY KEY) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | cec1585fdd4198bb6e1cf24c | CREATE TABLE inh_nn_lvl3 (CONSTRAINT foo NOT NULL a NO INHERIT) INHERITS (inh_nn_lvl2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | cf3229553ad5288af4b5403b | create table p1_c1(f1 int constraint p1_a_check check (f1 > 0) not enforced) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | cf4ffcf7c0bfde53dfd94d6b | CREATE TABLE inh_nn_lvl2 () INHERITS (inh_nn_lvl1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d03b40c04944ed9f9dddae4a | CREATE TABLE notnull_tbl4_lk3 (LIKE notnull_tbl4 INCLUDING INDEXES, NOT NULL a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d07847f7c9151129e7a57689 | create table p1_c1(f1 int constraint p1_a_check check (f1 > 0) enforced) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d0ecf4c70d6866a8998ad1d7 | -- NOT NULL NO INHERIT is not possible on partitioned tables CREATE TABLE ATACC1 (a int NOT NULL NO INHERIT) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d1005d5b7e36cb98bbe1d394 | CREATE TABLE fk_partitioned_pk_1 PARTITION OF fk_partitioned_pk FOR VALUES FROM (0,0) TO (1000,1000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d100ccca9c5f69980aa01c4c | -- should fail -- ... but not UNIQUE. CREATE TEMP TABLE z2 (b TEXT, UNIQUE(aa, b)) inherits (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d2107e8ba4e93fac426f59c9 | CREATE TABLE pp_nn_1 PARTITION OF pp_nn FOR VALUES WITH (MODULUS 2, REMAINDER 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d246ee02e315a785908572d2 | -- test handling of subqueries in grouping sets create temp table gstest5(id integer primary key, v integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d247cbf959ca99231c66d615 | CREATE TABLE notnull_tbl4_cld () INHERITS (notnull_tbl4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d2a49e0b6393702f8c6b86ee | create table part_abc_log (action text, a int, b text, c bool) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d2bea679267cb3f0467e7b3e | CREATE TABLE inh_grandchild () INHERITS (inh_parent, inh_child) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d2bfe21c23d262da957211d2 | CREATE TABLE pgss_do_util_tab_2 (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d36ea8dea58a5b128c5dcc72 | CREATE TABLE gtest11 (a int PRIMARY KEY, b int, c int GENERATED ALWAYS AS (b * 2) STORED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d3cbeb5c53a9866293350eaf | CREATE TABLE gtest_rule_log (op text, old_b int, new_b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d4e3076dcc940e699809b778 | CREATE TABLE gtest_part_key (f1 date NOT NULL, f2 bigint, f3 bigint GENERATED ALWAYS AS (f2 * 2) VIRTUAL) PARTITION BY RANGE ((gtest_part_key is not null)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d57532a6233d3aad7aa28ebb | -- fails -- not-null constraints CREATE TABLE gtest21a (a int PRIMARY KEY, b int GENERATED ALWAYS AS (nullif(a, 0)) VIRTUAL NOT NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d5b1512a3aa692b4fd6910ef | CREATE TABLE gtest_part_key (f1 date NOT NULL, f2 bigint, f3 bigint GENERATED ALWAYS AS (f2 * 2) VIRTUAL) PARTITION BY RANGE ((f3 * 3)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d75616e1433f2e78ec2c5ec5 | CREATE TABLE gtesty (x int, b int GENERATED ALWAYS AS (x * 22) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d78a2491b3709a00754e216e | -- -- test ALTER TABLE ADD CONSTRAINT -- CREATE TABLE temporal_fk_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id int4range, CONSTRAINT temporal_fk_mltrng2mltrng_pk PRIMARY KEY (id... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | d84bf270d5ebf3273c988c15 | -- PK from LIKE: CREATE TABLE temporal_rng2 (LIKE temporal_rng INCLUDING ALL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | da725a480d910dd4c51d370a | --ok CREATE TABLE notnull_tbl1_1 PARTITION OF notnull_tbl1 FOR VALUES IN (1,2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | dac193fd2a6dc709863a9195 | CREATE TABLE "gin_check"("Column1" int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | dae3a59313474436ac76369e | CREATE TABLE t (i int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | dbbc95b52575103a3c93b9b7 | -- check constraints CREATE TABLE gtest20 (a int PRIMARY KEY, b int GENERATED ALWAYS AS (a * 2) VIRTUAL CHECK (b < 50)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | dd85529a4aae2ec5dd24f6a3 | -- Disallow specifying conflicting NO INHERIT flags for the same constraint CREATE TABLE inh_nn1 (a int primary key, b int, not null a no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | de03a64a259f36b47ce9b1a3 | create table p1_fail(f1 int constraint inh_check_constraint2 check (f1 < 10) not enforced) inherits(p1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | de66d708d58beed805f340d6 | -- a whole-row var is a self-reference on steroids, so disallow that too CREATE TABLE gtest_err_2c (a int PRIMARY KEY, b int GENERATED ALWAYS AS (num_nulls(gtest_err_2c)) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ded39a7b855d912c8d9ba157 | create table phv_boolpart_null partition of phv_boolpart default |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | dff51a4d6884da1204ed7f0f | create table idxpart1 partition of idxpart for values from (0) to (1000) partition by range (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e074329dc758bf903a03af66 | CREATE TABLE NE_CHECK_TBL (x int, CONSTRAINT CHECK_CON CHECK (x > 3) NOT ENFORCED) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e08628ea6ba70869993c0001 | CREATE TABLE FKTABLE ( ftest1 int CONSTRAINT fktable_ftest1_fkey REFERENCES PKTABLE MATCH FULL ON DELETE CASCADE ON UPDATE CASCADE NOT ENFORCED, ftest2 int ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e0886c127791921070ecd908 | create table phv_part_null partition of phv_part for values in (null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e0ab98bee5d2f4ad0ae7d6e1 | create table constr_child2 () inherits (constr_parent2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e182309d7401dc09eda3dad3 | -- PK with one column plus a multirange: CREATE TABLE temporal_mltrng ( id int4range, valid_at datemultirange, CONSTRAINT temporal_mltrng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e1cc04d4f7d8b3ef01b7f63e | -- UNIQUE with one column plus a range: CREATE TABLE temporal_rng3 ( id int4range, valid_at daterange, CONSTRAINT temporal_rng3_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e1dcebcb5495187b5585830d | -- but not allowed if the child constraint is explicitly asked to be NOT ENFORCED create table p1_fail(f1 int constraint inh_check_constraint6 check (f1 < 10) not enforced) inherits(p1, p1_c1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e1f15d40c842c36f816285ab | -- with inferred PK on the referenced table: -- (parent_id, PERIOD valid_at) REFERENCES [implicit] CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAI... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e1fe3b8df79ea8347a2e9346 | -- -- test input parser -- -- PK with no columns just WITHOUT OVERLAPS: CREATE TABLE temporal_rng ( valid_at daterange, CONSTRAINT temporal_rng_pk PRIMARY KEY (valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e25787eb3dc8cb720778d49c | create table part_abc_3_2 partition of part_abc_3 for values from (1) to (100) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e335af3e818f66cb412474e2 | -- -- test ALTER TABLE ADD CONSTRAINT -- CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT temporal_fk_rng2rng_pk PRIMARY KEY (id, valid_at WITHOU... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e406695eedf682f7c9a1b217 | -- (parent_id, PERIOD valid_at) REFERENCES (id) CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT temporal_fk_rng2rng_pk PRIMARY KEY (id, valid_at... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e4528cc72c68368616e3d934 | -- fail CREATE TABLE unlogged1 (a int) PARTITION BY RANGE (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e47ae50454ece6ee7ab06543 | -- Check that comments on constraints and indexes are not lost at ALTER TABLE. CREATE TABLE comment_test ( id int, constraint id_notnull_constraint not null id, positive_col int CHECK (positive_col... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e47e59b71cd3f8e9a5abaa1b | create table inh_child (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e4a7761caa9d465ce2b3a87b | CREATE TABLE fk_partitioned_fk_6 (a int, FOREIGN KEY (a) REFERENCES fk_partitioned_pk_6, FOREIGN KEY (a) REFERENCES fk_partitioned_pk_6 ) PARTITION BY LIST (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e5398ba17626423297b5cbb2 | CREATE TABLE brassica PARTITION OF vegetables FOR VALUES IN ('brassica') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e5c65e358766767815457117 | CREATE TABLE notnull_child_upg () INHERITS (notnull_parent_upg) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e66e0d70c956e5494b20742e | create table inh_child(f1 int not null, f2 text not null) inherits(inh_parent_1, inh_parent_2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e67b8776ebb89f8b8eca2777 | CREATE TABLE gtest30 ( a int, b int GENERATED ALWAYS AS (a * 2) VIRTUAL ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e70486a7dc1578785611f636 | CREATE TABLE guid3 ( id SERIAL, guid_field UUID ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e83aa79050a0692616b19a36 | -- test parallel build with immutable function. CREATE TABLE btree_test_expr (n int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | e978595754e4a8ac25c2f1ff | CREATE TABLE atnnpart1 (col1 int, id int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ea571862393694db79c38964 | CREATE TABLE gtest_err_5b (a int PRIMARY KEY, b int GENERATED ALWAYS AS identity GENERATED ALWAYS AS (a * 2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ea80d5435d59ef80dafcda06 | create table inh_pp1 (f1 int not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | eaef8e7bb7600776de548775 | -- As above, but create the primary key ahead of time CREATE TABLE cnn_pk (a int, b int, CONSTRAINT cnn_primarykey PRIMARY KEY (b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ecb79adc45b38230070226fb | CREATE TABLE pgss_schema_2.tab_search_diff_1 (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | edb266c4f21efffdbb03aba7 | CREATE TABLE notnull_chld0 (a int, CONSTRAINT nn_chld0 NOT NULL a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | ee7e4229f4e79ad3945f23bf | CREATE TABLE test_squash_cast (id int, data casttesttype) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | eefa45aeb1044b94d77e73ea | create table phv_part_2 partition of phv_part for values in (2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | efc15ba6a0b9fab8d614e905 | CREATE TABLE test12fk (a int, b text COLLATE case_insensitive REFERENCES test12pk (x) ON UPDATE RESTRICT) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f02e46e66b68170250f3cc7d | -- INSERT/DELETE on zero column table CREATE TABLE zerocol() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f07f7927e3da8d754b4e84dc | create table inh_child (a int not null no inherit) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f1a6e9d65a6619c145a3467a | -- test that indexing commands work with TOASTed values in pg_index create table test_pg_index_toast_table (a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f281f308214e06e5a2f71f53 | CREATE TABLE notnull_tbl1_3(a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f285d892b81cb0c3e3ce61bb | CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT temporal_fk_rng2rng_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS), CONSTRAINT temporal_fk_rng2r... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f2b45c2e8f2d8853d786b3d0 | -- test multi layer inheritance tree create table inh_p1(f1 int not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f2e1f7873987c237d4235341 | CREATE TABLE temporal_rng4 ( id int4range, valid_at int4range_d, CONSTRAINT temporal_rng4_pk UNIQUE (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f3293c3ca6098fed4f63b02a | -- Test a not-null addition that must walk down the hierarchy CREATE TABLE inh_parent () |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f359b02c0eb6b8e811402118 | -- composite function with row expansion create table test_composite(x integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f3754c878a69cb83a6673369 | CREATE TABLE tp1 PARTITION OF temporal_partitioned FOR VALUES IN ('[1,2)', '[2,3)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f40ac9f71ec415ad1b0d5e23 | create table inh_child2 () inherits (inh_parent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f453cc1eadeb42899a050cf8 | CREATE TABLE temporal_rng3 ( id int4range, valid_at textrange2, CONSTRAINT temporal_rng3_uq UNIQUE (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f5dbab1e94af53336b470adc | CREATE TABLE gtest_normal_child (a int, b int GENERATED ALWAYS AS (a * 2) VIRTUAL) INHERITS (gtest_normal) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f6102b841f09f858f040000b | CREATE TABLE pagg_tab4_p1 PARTITION OF pagg_tab4 FOR VALUES IN ('a', 'b') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f6a895a966f2fe2d3e3d907a | CREATE TABLE ctlt1_inh (LIKE ctlt1 INCLUDING CONSTRAINTS INCLUDING COMMENTS) INHERITS (ctlt1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f6e1f6cfb6e8b2a1e864e6fb | -- reference to system column not allowed in generated column -- (except tableoid, which we test below) CREATE TABLE gtest_err_6a (a int PRIMARY KEY, b bool GENERATED ALWAYS AS (xmin <> 37) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f73b7e3f25466afa6dc11a53 | CREATE TEMP TABLE tab_search_diff_1 (a int, b int, c int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f814dc46cf0df1d3262819b4 | -- don't interfere with other types of constraints create table inh_parent (a int primary key) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f8ef96376a1e0994ef86c9a4 | CREATE TABLE fk_partitioned_pk_2 PARTITION OF fk_partitioned_pk FOR VALUES FROM (1000,1000) TO (2000,2000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f903d1068b9888f00ecc4a67 | create table inh_nn3 (f4 float, constraint nn3_f1 not null f1 no inherit) inherits (inh_nn1, inh_nn2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | f985f79f2b82b792e8c4f0a7 | CREATE TABLE "gin_check_text_array"("Column1" text[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fa1f844798a27e98eec99b92 | CREATE TABLE fk_partitioned_pk_3_1 PARTITION OF fk_partitioned_pk_3 FOR VALUES FROM (2000) TO (2100) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | faa5de77b2c674d14da4a21a | CREATE TEMP TABLE tab_search_diff_2 (a bigint) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fb88c0ad676e02e37f040f22 | -- should fail because of duplicate referenced columns: CREATE TABLE temporal_fk_rng2rng ( id int4range, valid_at daterange, parent_id int4range, CONSTRAINT temporal_fk_rng2rng_pk PRIMARY KEY (id, ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fb93b0630f40d3db1b7a7a35 | create table sk (a int, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fbe0a758612651c9e97e47ff | -- Create a table with the int_custom type CREATE TABLE test_table ( id int, data int_custom ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fc86251ead4ac2affa7f4764 | -- -- test multi inheritance tree -- create table inh_parent(f1 int not null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fccaf1e428bd91f7506a7faa | CREATE TABLE gtest_child3 PARTITION OF gtest_parent ( f3 GENERATED ALWAYS AS (f2 * 2) STORED -- error ) FOR VALUES FROM ('2016-09-01') TO ('2016-10-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fd1a6173589088a121d7e122 | CREATE TABLE gtestxx_1 (a int NOT NULL, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fd2b6142898435903e222fe1 | CREATE TABLE inh_child (i int) INHERITS (inh_parent) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fdb2ff9cf785cac0a4a28429 | create table inh_child() inherits (inh_parent1, inh_parent2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fdc059ddf9e83ca9ef1f10c8 | -- Also try inheritance added after table creation CREATE TABLE notnull_tbl1_child2 (c int, b int, a int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fdedcc6dbb6b49a2749c07b9 | CREATE TABLE notnull_part1_2_upg (a int, CONSTRAINT nn2 NOT NULL a, b int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fdf983696a9f77268b467920 | -- -- test changing the PK's dependencies -- CREATE TABLE temporal3 ( id int4range, valid_at daterange, CONSTRAINT temporal3_pk PRIMARY KEY (id, valid_at WITHOUT OVERLAPS) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fe8853e630eb99534adadcb4 | -- Two scalar columns: CREATE TABLE temporal_fk2_mltrng2mltrng ( id int4range, valid_at datemultirange, parent_id1 int4range, parent_id2 int4range, CONSTRAINT temporal_fk2_mltrng2mltrng_pk PRIMARY ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_STMT | fea3d9d59a64f137f2e64e25 | CREATE TABLE gtest28 OF gtest_type (f1 WITH OPTIONS GENERATED ALWAYS AS (f2 *2) VIRTUAL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | 29dcc5b03e739e2bf90aee42 | -- Tests for COPY TO with materialized views. -- COPY TO should fail for an unpopulated materialized view -- but succeed for a populated one. CREATE MATERIALIZED VIEW copytest_mv AS SELECT 1 AS id ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | 29e3d7bf87c61aa237e6007a | CREATE MATERIALIZED VIEW pgss_materialized_view_2 AS SELECT * FROM generate_series(1, 5) as id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | 4cf1d58e45058bfaca9d2f26 | -- -- Extended statistics on sb_2 (x, y, z) improve a bucket size estimation, -- and the optimizer may choose hash join. -- CREATE TABLE sb_1 AS SELECT gs % 10 AS x, gs % 10 AS y, gs % 10 AS z FROM... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | b69f6005cecbf7de211bc324 | CREATE TABLE sb_2 AS SELECT gs % 49 AS x, gs % 51 AS y, gs % 73 AS z, 'abc' \|\| gs AS payload FROM generate_series(1, 1e4) AS gs |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | c7fdffe301f509e3956379c3 | CREATE MATERIALIZED VIEW pgss_materialized_view AS SELECT * FROM generate_series(1, 5) as id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | cbfdd2e978e7351fb298e6f7 | CREATE TEMPORARY TABLE pgss_ctas_3 AS SELECT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | f241f27d0b7e917ff899a060 | CREATE TEMPORARY TABLE pgss_ctas_1 AS SELECT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | 2999eead6f1a087437f80041 | create trigger check_fkeys2_fkey_restrict after delete or update on fkeys2 for each row execute procedure check_foreign_key (1, 'restrict', 'pkey23', 'fkeys', 'fkey3') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | 3ee3b86e08c186425b24f915 | create trigger aiserial before insert or update on aitest for each row execute procedure autoinc (price_on, aitest_seq) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | 3ef781f39bcf383629577929 | CREATE TRIGGER gtest12_01 BEFORE INSERT OR UPDATE ON gtest26 FOR EACH ROW EXECUTE PROCEDURE gtest_trigger_func() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | 517dc1aa0516dd305b55bf51 | create trigger check_pkeys_fkey_cascade after delete or update on pkeys for each row execute procedure check_foreign_key (2, 'cascade', 'pkey1', 'pkey2', 'fkeys', 'fkey1', 'fkey2', 'fkeys2', 'fkey2... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | 5f7079b76d39f115d91a821f | create constraint trigger whoami after insert on defer_trig deferrable initially deferred for each row execute function whoami() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | 692c4689074d8c49cc7e3401 | create trigger check_fkeys_pkey2_exist after insert or update on fkeys for each row execute function check_primary_key ('fkey3', 'fkeys2', 'pkey23') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | 6cfe81c2e3ca55048dbb505b | CREATE TRIGGER joinview_upd_trig INSTEAD OF UPDATE ON joinview FOR EACH ROW EXECUTE FUNCTION joinview_upd_trig_fn() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | 8fcb78dc5402ba30d28031da | create trigger make_bogus_matview after insert on my_table referencing new table as new_table for each statement execute function make_bogus_matview() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | 9b0619d62246cb2eb88b1d3e | create trigger check_fkeys2_pkey_exist after insert or update on fkeys2 for each row execute procedure check_primary_key ('fkey21', 'fkey22', 'pkeys', 'pkey1', 'pkey2') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | b9be32189958de09ab29df7b | CREATE TRIGGER gtest12_03 BEFORE INSERT OR UPDATE ON gtest26 FOR EACH ROW EXECUTE PROCEDURE gtest_trigger_func() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | bd16fe9ee071f0e5be207e0c | CREATE TRIGGER gtest12_02 BEFORE INSERT OR UPDATE ON gtest26 FOR EACH ROW EXECUTE PROCEDURE gtest_trigger_func4() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_CREATE_TRIG_STMT | fa40b93429bbc924464c44d0 | create trigger check_fkeys_pkey_exist after insert or update on fkeys for each row execute function check_primary_key ('fkey1', 'fkey2', 'pkeys', 'pkey1', 'pkey2') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEALLOCATE_STMT | 45cc7ceea7f56ab267897c1b | deallocate update_part_abc_view |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEALLOCATE_STMT | a8ba6dc2df4da352b61a2d43 | DEALLOCATE get_nnconstraint_info |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEALLOCATE_STMT | d7f7e681cd8bc82c24d348cf | DEALLOCATE p1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DECLARE_CURSOR_STMT | 0d248cbffb0b9968a39ac1a4 | declare curs cursor for select * from gtest_cursor order by id for update |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DECLARE_CURSOR_STMT | 128738924da59b26662abc92 | DECLARE FOOCUR CURSOR FOR SELECT * from stats_track_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | 1d5ec1e4b1608f860ac20e88 | CREATE OPERATOR <= ( LEFTARG = int_custom, RIGHTARG = int_custom, FUNCTION = int_custom_le, COMMUTATOR = >=, NEGATOR = >, RESTRICT = scalarlesel, JOIN = scalarlejoinsel ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | 2022e57787fe7c042ca655ec | -- -- Test builtin "C" -- CREATE COLLATION regress_builtin_c ( provider = builtin, locale = 'C') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | 20c3c04973e8cf7ef7873b2d | CREATE OPERATOR = ( leftarg = casttesttype, rightarg = casttesttype, procedure = casttesttype_eq, commutator = =) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | 43bf43a133b109b588b87be1 | -- -- The int_custom type definition -- -- This type is identical to int4 in storage, and is used in subsequent -- tests to have different properties. -- CREATE TYPE int_custom ( INPUT = int_custom... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | 49d136825436e68b3c673de2 | CREATE OPERATOR <> ( LEFTARG = int_custom, RIGHTARG = int_custom, FUNCTION = int_custom_ne, COMMUTATOR = <>, NEGATOR = =, RESTRICT = neqsel, JOIN = neqjoinsel ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | 6cb3ae2fe61653baff0c6313 | CREATE OPERATOR < ( LEFTARG = int_custom, RIGHTARG = int_custom, FUNCTION = int_custom_lt, COMMUTATOR = >, NEGATOR = >=, RESTRICT = scalarltsel, JOIN = scalarltjoinsel ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | 77aefdbff725dc24bfc91190 | create type xfloat8 (input = xfloat8in, output = xfloat8out, like = no_such_type) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | 80af574ba5bc8a202ab0210e | -- fails CREATE COLLATION regress_pg_unicode_fast ( provider = builtin, locale = 'PG_UNICODE_FAST') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | 9260e10af3d5aff4f2c0f4ac | -- -- Test PG_UNICODE_FAST -- CREATE COLLATION regress_pg_unicode_fast ( provider = builtin, locale = 'unicode') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | b7797fdf7b4cfa055132d926 | -- Operators for int_custom, for btree operator class CREATE OPERATOR = ( LEFTARG = int_custom, RIGHTARG = int_custom, FUNCTION = int_custom_eq, COMMUTATOR = =, NEGATOR = <>, RESTRICT = eqsel, JOIN... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | bf7e27ff43f7acf8d67751f6 | CREATE OPERATOR > ( LEFTARG = int_custom, RIGHTARG = int_custom, FUNCTION = int_custom_gt, COMMUTATOR = <, NEGATOR = <=, RESTRICT = scalargtsel, JOIN = scalargtjoinsel ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | c42636aa948671d3cfddc64a | CREATE TEXT SEARCH CONFIGURATION evttrig_tscfg (COPY = pg_catalog.simple) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DEFINE_STMT | c62345b72f424e05a80a79bc | CREATE OPERATOR >= ( LEFTARG = int_custom, RIGHTARG = int_custom, FUNCTION = int_custom_ge, COMMUTATOR = <=, NEGATOR = <, RESTRICT = scalargesel, JOIN = scalargejoinsel ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 003c97e6d20b85ca6118bebf | -- fix only idxpart1's index, leave idxpart2's still invalid delete from idxpart1 where b = 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 023175223497d27f3c99918a | DELETE FROM temporal_rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 05feb1f9bd89d61bf62d7300 | DELETE FROM temporal_mltrng WHERE id = '[5,6)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 079878ac9845ccd7a5b2680b | DELETE FROM pt WHERE false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 09c35ec9f7e202e2eba537fa | -- fix the index on the leaf partition delete from idxpart11 where b = 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 11bb25ff64a606e2d296eed8 | DELETE FROM temporal_partitioned_rng WHERE id = '[5,6)' AND valid_at = daterange('2018-02-01', '2018-03-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 16ebc45ee46c96d965817332 | DELETE FROM foo_parted RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 252c604a27d06fa7b3722cc0 | DELETE FROM temporal_mltrng3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 291f16cff039f2d3709285b0 | DELETE FROM temporal_mltrng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 2e67634f61f2d0ef22acbdf7 | -- error DELETE FROM gtest27 WHERE a IS NULL AND b IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 2f17df4b4330ba96750d6c39 | -- -- test with rows already -- DELETE FROM temporal_fk_mltrng2mltrng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 4c0da97a53fcc7bb87b32b9b | DELETE FROM temporal_rng WHERE id = '[5,6)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 5173ef3dd152f68baf5ce555 | DELETE FROM foo WHERE f1 = 5 RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 56fceca7b810cc618fa15157 | -- -- test with rows already -- DELETE FROM temporal_fk_rng2rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 603c6c0667396ff92000fbd9 | -- a PK delete that fails because both are referenced: DELETE FROM temporal_mltrng WHERE id = '[5,6)' AND valid_at = datemultirange(daterange('2018-01-01', '2018-02-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 701dd533cd06d12c8b2eb8a0 | DELETE FROM temporal_rng3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 734d590e25c1a81d6e442be0 | -- then delete the objecting FK record and the same PK update succeeds: DELETE FROM temporal_fk_rng2rng WHERE id = '[3,4)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 8923b30c965162fbf5a64e1a | DELETE FROM zerocol RETURNING old.tableoid::regclass, old.ctid, new.tableoid::regclass, new.ctid, ctid, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 8e168bcbf39e6cf4c48eca1a | DELETE FROM temporal_rng WHERE id = '[5,6)' AND valid_at = daterange('2018-02-01', '2018-03-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 9bca4d6388d975b0e35092b3 | delete from gtest_cursor where current of curs |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | 9d6383467103f7ad485c073a | -- a PK delete that fails because both are referenced: DELETE FROM temporal_rng WHERE id = '[5,6)' AND valid_at = daterange('2018-01-01', '2018-02-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | ae2098a0c49108a4f28fa63b | DELETE FROM temporal_mltrng WHERE id = '[5,6)' AND valid_at = datemultirange(daterange('2018-02-01', '2018-03-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | be4862223983e0e532465817 | DELETE FROM rw_view2 WHERE a=3 RETURNING old.*, new.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | c0c5fabbfd3fa7563eb882e4 | -- should fail: DELETE FROM temporal_partitioned_rng WHERE id = '[5,6)' AND valid_at = daterange('2018-01-01', '2018-02-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | cdf8661c2688e74b0d3a3a55 | delete from inh_nn2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | d81804b991f2de2f0213c7ee | DELETE FROM temporal_partitioned_mltrng WHERE id = '[5,6)' AND valid_at = datemultirange(daterange('2018-02-01', '2018-03-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | e204add43e6bcd933b1b1df3 | -- should fail: DELETE FROM temporal_partitioned_mltrng WHERE id = '[5,6)' AND valid_at = datemultirange(daterange('2018-01-01', '2018-02-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | e554413eaa24250b0bd8424b | -- can't be pushed down DELETE FROM ft2 WHERE c1 % 10 = 6 AND c1 < 40 RETURNING old.c1, c4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | f532854579973dab5f547267 | DELETE FROM foo WHERE f1 = 4 RETURNING old.*,new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DELETE_STMT | f8e74caaa66dbf07d58a5dbf | DELETE FROM foo WHERE f1 = 5 RETURNING (SELECT max(old.f4 + x) FROM generate_series(1, 10) x) old_max, (SELECT max(new.f4 + x) FROM generate_series(1, 10) x) new_max |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DO_STMT | 52f599a4bc2e007118dd9675 | DO $$BEGIN EXECUTE format( 'ALTER DATABASE %I RESET role', current_catalog); END$$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DO_STMT | 58fe8a94be8841b329cbf78e | -- After terminating the remote backend, since the connection is closed, -- "closed" should be TRUE, or NULL if the connection status check -- is not available. Despite the termination, remote_back... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DO_STMT | 6f9bea6d8978fe4a430116fa | DO $$BEGIN EXECUTE format( 'ALTER DATABASE %I SET session_authorization = regress_session_user', current_catalog); END$$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DO_STMT | 90039d3c73f5670acc62b067 | DO $$ DECLARE BEGIN EXECUTE 'CREATE TABLE pgss_do_table (id INT); DROP TABLE pgss_do_table'; EXECUTE 'SELECT a FROM pgss_do_util_tab_1; SELECT a FROM pgss_do_util_tab_2'; END $$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DO_STMT | 92096698c47548112d2bad74 | -- Note the extra semicolon at the end of the query. DO $$ DECLARE BEGIN EXECUTE 'CREATE TABLE pgss_do_table (id INT); DROP TABLE pgss_do_table;'; EXECUTE 'SELECT a FROM pgss_do_util_tab_1; SELECT ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DO_STMT | c3f12192b6443f4a4f370480 | do $$ begin perform pgp_sym_decrypt(dearmor(' -----BEGIN PGP MESSAGE----- jA0EBwMCXLc8pozB10Fg0jQBVUID59TLvWutJp0j6eh9ZgjqIRzdYaIymFB8y4XH vu0YlJP5D5BX7yqZ+Pry7TlDmiFO =rV7z -----END PGP MESSAGE---... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DO_STMT | cc3a0691c71c9932c0012c50 | do $$ declare a int[] := array[1,2,3]; begin -- test scenarios for optimization of updates of R/W expanded objects a := array_append(a, 42); -- optimizable using "transfer" method a := a \|\| a[3]; -... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DO_STMT | f07b7b534bf5b063dcc9576b | DO $$BEGIN EXECUTE format( 'ALTER DATABASE %I RESET session_authorization', current_catalog); EXECUTE format( 'ALTER DATABASE %I SET role = regress_current_user', current_catalog); END$$ |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_ROLE_STMT | 05f3d61c66f38abcfece1fb8 | drop role regress_caller |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_ROLE_STMT | 092916f64b3165ef5e98a7b9 | DROP ROLE regress_stats_superuser |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_ROLE_STMT | 0ad136efa295221b2a46add6 | DROP ROLE regress_buffercache_normal |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_ROLE_STMT | 11d684892b8c2c05bede7f99 | DROP ROLE regress_stat_set_1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_ROLE_STMT | 514a1361c98189d1594b962f | DROP ROLE regress_pg_logicalinspect |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_ROLE_STMT | af8ce36df6b13e14916f5b4c | drop role regress_fn_owner |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_ROLE_STMT | b4cd3a71977b184e916272b5 | DROP ROLE regress_stat_set_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_ROLE_STMT | d6707667925ce693de84b5f5 | drop role regress_mr |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_ROLE_STMT | eab37b7d63099b9b3038a227 | DROP ROLE regress_grantor1, regress_grantor2, regress_grantor3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 01224e08cd47358bb57dbdd3 | DROP TABLE temporal_rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 028c39614d8c01f9eed44a8f | drop type mytype |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 03d912eed186afc09487ac04 | DROP TABLE fk_partitioned_fk, fk_notpartitioned_pk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 044b8de6031283e6056c6eeb | drop table notnull_tbl1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 05383946a060ecda83459e1f | drop table phv_boolpart |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 0af3df59d3b06b9b77af8de7 | DROP TABLE pagg_tab6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 0b7b50891ec27ab1093a9e3a | -- null bound is okay DROP TABLE temporal_rng4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 0cce200b6081d21d8e0a1fc1 | DROP TABLE guid1, guid2, guid3 CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 0f26e9e7ad585d9857894afa | -- Two scalar columns DROP TABLE temporal_rng2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 0f9169289e85b00143cb3177 | DROP TABLE gin_check_jsonb |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 1072496f4b163682e24a0349 | -- -- test FOREIGN KEY, multirange references multirange -- -- test table setup DROP TABLE temporal_mltrng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 1296cdacc095f74f03343718 | drop table inh_parent, inh_child, inh_child2, inh_child3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 14103a2711e42dd1d4841e96 | DROP TABLE inh_nn_parent cascade |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 157a07f4ffe6e33352a317bb | DROP FUNCTION brintest_func() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 16bf28a2e7c08af8c38942bc | -- Clean up DROP FUNCTION test_pglz_compress |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 17e36619a16e769492a5529c | -- cleanup DROP TABLE list_parted, list_parted2, range_parted, list_parted3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 187f4391f53da5ee17a88bfe | DROP FUNCTION test_wchars_to_text |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 18e070e67d992fed76a553e6 | DROP TABLE ctl_stats4_child |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 1a2020be018fe6584d9ec5e0 | drop table rls_t, test_t |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 1aadc89399c7815ce0a3bd48 | DROP TABLE test_squash_bigint |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 1e397e2f2cf86d0a1e5f4214 | -- cleanup DROP FUNCTION test_temp_pin(int, int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 1e49f688268149b112f9e21d | DROP TABLE gtest_rule |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 21146095dd035d5e005c87a3 | DROP TABLE gin_check_text_array |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 2247063bc93ab9546a7f5775 | DROP SCHEMA stats_import CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 23e47aad18a96e384a8e79e7 | DROP TABLE gencols |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 242c3a5ea320d97292e4f856 | -- Ensure we don't use a partial index as proof of functional dependency drop index t2_z_uidx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 25121e0db296d31bb7b529d4 | DROP TABLE ctl_stats3_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 2824367c6eac22ed05aec822 | DROP TABLE encoding_tests |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 28ca4738d98c0763f7afa03b | DROP TABLE notnull_tbl1, notnull_chld0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 28d81d7cf0feed4eeb3d043e | DROP TABLE test_pg_unicode_fast |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 2ba8f2c5adb19b8896e80e17 | DROP TABLE test_table |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 2c0221008ff9d8b4024b494f | DROP TABLE gtest_rule_log |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 2cd89ef23c4f8a757774e870 | DROP FUNCTION pg_buffercache_evict(integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 2cdc5b34d94253afd6e0feae | DROP TABLE vac_tab_auto |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 2f3bafa85cb63303ea0d1a51 | DROP TABLE notnull_tbl1, notnull_tbl1_chld |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 327de34ee75006c07fa27eba | --ok DROP TABLE pp_nn |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 33c4a2e2732985323fba1b81 | drop table inh_parent, inh_child, inh_grandchild |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 363b88217160698b14fed460 | DROP TABLE test_composite |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3a45aff013a65b99849e3f8a | -- rule returns NEW DROP RULE rw_view1_upd_rule ON rw_view1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3ad16796c3040f8aaee8316f | drop table inh_parent, inh_child1, inh_child2, inh_child3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3b04f92c45fa9e22c227630c | DROP SCHEMA pgss_schema_1 CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3c1f21d6801463d9cc4d872b | DROP VIEW my_backend_pid |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3d3adf96bcb54af445b1e9b8 | DROP PUBLICATION pub2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3d9e57e01dc5aaea46643605 | DROP COLLATION regress_builtin_c |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3dc4ac13151f9a192aab1823 | DROP TABLE test_temp |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3dfaa19b6edb9aefb6d8bce5 | -- -- partitioned FK referenced deletes SET DEFAULT -- DROP TABLE temporal_partitioned_fk_mltrng2mltrng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3e8b4ae5265a4ab59cd6d45d | drop table gtest_cursor |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 3f337c11c2e040c153a824c9 | DROP TABLE fk_notpartitioned_fk, fk_partitioned_pk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 418a1179d5dd16e46e05e470 | DROP FUNCTION test_text_to_bytea |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 41e448b8bf6c4e138781182f | DROP TABLE part_fail |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 4224ed90d9f915ca42f2d8b8 | -- Cleanup DROP FUNCTION func_int_custom |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 427a56cdde75bb6ab5f3305c | DROP TABLE pxtest_rowlock |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 447f22928077ca02d3313160 | --DROP FUNCTION gf1(int); -- fail DROP TABLE gtest11 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 459c02a135fc639b598323fa | DROP INDEX pht1_c_idx CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 47cce219c8fef9f06bca1512 | DROP TABLE only_parted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 4a44c6fae60b2d77dd7d58c2 | DROP TABLE test_squash_numeric |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 4bbf40f1a37bb3f26f02c150 | drop table cnn_pk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 511a01984f42d2e7609334ea | DROP TABLE temp_pg_buffercache |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 5385d6928c20403f3016ffb5 | -- clean up drop table defer_trig |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 5414fc13015dff317261ca5b | DROP TABLE IF EXISTS tbl_phv |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 543ec64642d7288fcb4b71db | DROP PUBLICATION testpub8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 558e5402c3e6aeadcfc69af3 | DROP DOMAIN constraint_enforced_dom |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 56040be1a4d601290bf61479 | drop type t_rec |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 5b0e433d1cfa9d4d0927db46 | DROP TABLE ctl_stats4_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 5e1bcafe36fc7d3851b3eb97 | drop table gtest32 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 5e9300a6e50dab725ae7a2fd | DROP TABLE groupby_collation_t |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 6027d8b1328bd45831010cb7 | DROP FUNCTION btree_test_func() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 60d265275d2ddebaeaa5205c | drop table cnn2_parted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 612f1108972afee3032fb3ea | DROP TABLE pagg_tab5 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 616e6a9b9c96364eb60f8d8e | DROP TABLE ctl_table |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 641ec58d1f21c19c430f0917 | DROP FOREIGN TABLE remote_backend_pid |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 6a0a4b18ef9ba30c538297fa | DROP FUNCTION explain_mask_costs(text, bool, bool, bool, bool) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 6aaaaa5143df78002d56d57b | DROP MATERIALIZED VIEW copytest_mv |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 6bb2d0fd9451056884ace2b8 | drop function test_pg_index_toast_func |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 6c1159a74d129c07cdb75a71 | DROP FUNCTION test_text_to_wchars |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 6c737fe24d1c2a8b0c781ea9 | drop table gtest34 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 6db62ae7ef9b8bd8e3f1d3c9 | drop function make_bogus_matview() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 6ea1f10b8ce03f1868faad33 | DROP TABLE notnull_inhparent, notnull_inhchild, notnull_inhgrand |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 718a7ac1afb08ad91a8a931a | drop table phv_part |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 7372f1f572721612395bff69 | DROP INDEX t_b_partial_2_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 746fc08228e793dfe3be7c1c | DROP RULE joinview_u ON joinview |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 74854c739337504b7dff1c6d | DROP TABLE notnull_tbl2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 7999113e77f60a3c86d9dbc3 | DROP FOREIGN DATA WRAPPER ctl_dummy CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 79e2889d82764332dcf3d49b | -- also drops inh_child table drop table inh_parent_1 cascade |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 7e11406f982c669a024769b9 | DROP RULE sj_del_rule ON sj CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 83dd760b2c4261860499e782 | DROP TABLE test_squash_jsonb |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 848fe7b94e15016a104e8de2 | DROP PUBLICATION testpub_ins_trunct |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 8552c0737fcec7b7864a5b14 | DROP TABLE temporal_fk_mltrng2mltrng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 8577806f32433a6e960f323f | DROP SCHEMA pgss_schema_2 CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 867447455ff879aef12fe305 | DROP TABLE copy_encoding_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 878b411bd8e78e4f331fcb54 | DROP FUNCTION wait_for_backend_termination(int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 8877ee56233ac9103a3ee840 | drop index test_pg_index_toast_index |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 8b78b039c089511bad7bf6b1 | DROP INDEX sj_fn_idx, sj_temp_idx1, sj_temp_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 8cff66575302aebf192e7c00 | DROP FUNCTION test_mblen_func |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 8e3651de80260d6a501d9e72 | drop table tuplesest_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 8f11c2c297a99dc33aa3a167 | DROP TABLE ctl_stats3_child |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 9021b21ca96617d72b9a5e8a | DROP TABLE bitmap_split_or |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 930c7023c01daa32a0b5c6d3 | DROP TABLE temporal_partitioned_mltrng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 93103d72bf677bfd91dbd0b4 | DROP TABLE testpub_rf_tbl1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 9413a889ccd93d192b75dddc | drop table inh_nn1, inh_nn2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 94eb8b8b06ea9adc5a3d7f44 | DROP TABLE brintest_expr |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 9686f8c5db3b60dbd4eed1a3 | DROP TABLE two_not_null_constraints |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 98f71b17e5ba29beadceb40f | DROP TABLE temporal_partitioned |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 99e007fb20fdf561f2aade98 | DROP TABLE sb_1, sb_2 CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 9a1ffd5edbd5016e47cdaa52 | DROP TABLE temporal_rng3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 9ba807af808ee7692ab5a6ed | drop table test_pg_index_toast_table |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 9c1f1e40b8acb43eeda96097 | DROP TABLE ext_stats_test1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | 9fec927fe351acb88faf71d7 | DROP TABLE testpub_gencol |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | a208b79c34b047b06a1c4e85 | DROP FUNCTION test_bytea_to_text |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | a4fc55a2bcdc50527dad8ac6 | drop table p1, p1_c1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | a5880747a5cd284ce581d11b | DROP TABLE btree_test_expr |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | a758fc9e7f8c4ee870280599 | drop function explain_analyze(text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | a7c4af317ac105f6b8c6b982 | DROP TABLE notnull_tbl1, notnull_tbl1_child, notnull_tbl1_child2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | b02a5bedcf4066f777e09429 | /* Then we can drop it */ DROP FUNCTION postgres_fdw_get_connections () |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | b51e15543a28c0f68843382a | DROP TABLE tab_search_same, tab_search_diff_1, tab_search_diff_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | b6e423bf82d3f69771b35a9c | DROP TABLE only_inh_parent CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | b7aa81f9c6d193b0dacf8d96 | drop index concurrently test_pg_index_toast_index |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | b9bee3bd37e8cdc610c70e6c | DROP TABLE distinct_on_tbl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | b9c7e147dc012e1bbdd22175 | DROP TABLE shared_pg_buffercache |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | bc09aec729bc01dc22edaaf5 | drop table inh_nn1, inh_nn2, inh_nn3, inh_nn4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | bcc7b4c1aadde6c62e65cd95 | drop table inh_parent cascade |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | bd55a7c9242a298845f76746 | drop function whoami() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | bd73b6eca0033d6f67180f52 | DROP TABLE temporal_mltrng3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | bfae2d34ae17fabdb244d0d9 | DROP TABLE gin_check_multicolumn |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c274cb51ea8655f989883460 | drop table inh_nn1, inh_nn2, inh_nn3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c27ebefa328a1d98d73057e8 | drop table inh_parent_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c2bdddde32de45a0fe1c5458 | drop table test9v |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c3595746af642634ec81904d | DROP TABLE toast_4b_utf8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c3cb5d6b0dc83cad93fc359d | DROP TABLE inh_nn_lvl1, inh_nn_lvl2, inh_nn_lvl3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c55cc1c137bc1bb5685e5ce2 | DROP TABLE testpub_rf_tbl7 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c578a53bc58b2f5e9a836b32 | -- not a composite type at all DROP TYPE tt_enum_type |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c6b5603b1e2d922d33109a41 | DROP TABLE grouping_unique |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c7a1fc0248b85b5293955d2f | drop view part_abc_view |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | c9ded187f6d923bb987ce811 | DROP TABLE test_replica_identity |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | cacd14b1e33cd043f668ceb3 | DROP TABLE pgss_parallel_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | cb2f753291a7b2d57fc90879 | DROP TABLE test_squash_cast CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | cc0058319044b0bc984193f4 | DROP FUNCTION test_fdw_handler() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | cdb015f39d8bf64508629802 | DROP EXTENSION pg_logicalinspect |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | cdc31b0786d0e56637ed84b7 | DROP TABLE grantor_test1, grantor_test2, grantor_test3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | ce72c3590304d624c6b0b030 | DROP TABLE distinct_tbl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | cf3330f30b7b4f40136bb12b | --error DROP TABLE gtest21ax |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | d052601396250c4e1f058307 | DROP TABLE tab_with_flag |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | d2787d53f8f62e7cd458d4c8 | DROP TABLE temporal3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | d35ee598ddca6e80be7a623a | DROP EXTENSION test_custom_types |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | d7a6c7d7babed53d708798f3 | DROP INDEX t_b_partial_1_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | d84ac21d3e148ae0c86ba028 | DROP TABLE temporal_partitioned_rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | d85e9ee9818b1461af21cdf5 | DROP PUBLICATION pub_gencol |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | d9068c5c6717c24469e476b4 | DROP TABLE public.tt |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | d93ce97225651f4ceb186893 | drop table gtest34p |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | d9eb15601913c18790fd3720 | DROP TABLE hashagg_ij |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | daddbe4b5669d8824a5da3de | DROP TABLE gin_check |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | db0e8e4f7b384cae2865e405 | DROP TABLE zerocol |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | db8ff49514aeb0fa5a9a3359 | DROP TABLE IF EXISTS inh_nn1, inh_nn2, inh_nn3, inh_nn4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | dc798e22e8fb92f07dd20adc | DROP RULE gtest_rule_ins ON gtest_rule |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | ddd3def9293f5dd4e3de9045 | DROP FUNCTION test_pglz_decompress |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | dfcda14a86e4c8452703fb1a | drop schema mr_sch |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | e0ccf16aa82abce99e47b419 | -- -- cleanup -- DROP TABLE test_squash |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | e1d4c8fa05c99a39ea89f164 | DROP TABLE stats_temp |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | e3a4a9ac92ba5eb96d07bca9 | -- Two scalar columns DROP TABLE temporal_mltrng2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | e52fc208f26431aa6ddfb7fd | DROP STATISTICS test_stats |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | e7e5eb274ec3b3ec85c18725 | DROP TABLE test_replica_identity5 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | e7fe315c585daf3e9a5a46b9 | DROP TABLE pagg_tab4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | ea3092e09a326d74a2eab318 | drop function rls_f(text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | ea79ca0a296e59c8c2d22222 | drop table test9s |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | ece476e8f9117727fa55a828 | DROP FOREIGN TABLE ctl_foreign_table1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | ed8d8c314df74e25ce95925d | drop table t_opf |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | ee9060c3cd663cea89956e0f | DROP TABLE regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | eeda8ede32dc748765391616 | -- fail DROP TABLE gtest11, gtest12 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | ef5282df1eb2bba76ee5184e | DROP FUNCTION composite_f |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | efabee1d764a45da5b0154ac | drop table tuplesest_parted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | f0aa4478b087b141d3fb7b30 | DROP TABLE foo_parted CASCADE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | f0c80bd26a991c753fbe762a | DROP FUNCTION test_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | f13a2c8e5ffa797bb9109060 | drop table inh_p1, inh_p2, inh_p3, inh_p4 cascade |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | f53a4ebabc1441aa67b570cc | DROP TABLE temporal_fk_rng2rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | f7a036f450aa3547ffe380fc | drop table gtest33 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | f8da631bce33f07f4283262d | DROP TABLE test_float |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | fb2384c9d76cf07e6dade710 | -- no updates here DROP TABLE test12pk, test12fk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | fb36176a897ed9ac347e3d7c | DROP FUNCTION test_valid_server_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | fb89267727fafa38a9b16933 | DROP FOREIGN TABLE ctl_foreign_table2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | fca447fa568cede14675d451 | DROP TABLE pgss_do_util_tab_1, pgss_do_util_tab_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | fcfb011be574d954b094be74 | DROP RULE gtest_rule_upd ON gtest_rule |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_DROP_STMT | fd2a784f86abc7f5bd24cc7e | -- -- partitioned FK referenced deletes SET DEFAULT -- DROP TABLE temporal_partitioned_fk_rng2rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | 3d573a7439198bc4eee824a7 | execute update_part_abc_view (1, 'd') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | 405520e43fdb946274cd691b | execute update_part_abc_view (2, 'a') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | 4fbc6bb602ca7c0b8d63ae40 | EXECUTE get_nnconstraint_info('{constr_parent2, constr_child2}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | 5adacf39b1725b22272fb79a | EXECUTE get_nnconstraint_info('{notnull_tbl1, notnull_chld0}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | 7dc9ac9c6ee9bf9e78fe31d6 | EXECUTE get_nnconstraint_info('{notnull_tbl1_child, notnull_tbl1}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | 7f219d4d3359afc005ce7878 | EXECUTE get_nnconstraint_info('{constr_parent3, constr_child3}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | 850abaa09765f574fa5a6fe9 | EXECUTE get_nnconstraint_info('{notnull_part1_upg, notnull_part1_1_upg, notnull_part1_2_upg, notnull_part1_3_upg}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | 852097201871e2f29c1fe6e7 | execute update_part_abc_view (3, 'a') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | 8a60137161c8b009ab563f4b | EXECUTE get_nnconstraint_info('{notnull_tbl1_copy}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | a019cb926557fd0d65bc6842 | EXECUTE p1(1, 2, 3, 4, 5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | b2fb19f7f9d01e08f3354c97 | -- now ok EXECUTE get_nnconstraint_info('{notnull_tbl1}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | b5022ee1b9f2c4906196ff5c | EXECUTE get_nnconstraint_info('{constr_parent, constr_child}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | c81217d14d669151dfebe709 | EXECUTE get_nnconstraint_info('{notnull_tbl1, notnull_tbl1_1, notnull_tbl1_2, notnull_tbl1_3}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | cc5c907e393f14ba6a90cc38 | -- error EXECUTE get_nnconstraint_info('{notnull_inhparent, notnull_inhchild, notnull_inhgrand}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXECUTE_STMT | e7eae7b015c4bf1e6eaadb9d | EXECUTE get_nnconstraint_info('{notnull_tbl1_child2}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 004c697bff1c65c6c6ada8c0 | EXPLAIN (verbose, costs off) UPDATE foo SET f4 = 100 WHERE f1 = 5 RETURNING (SELECT old.f4 = new.f4), (SELECT max(old.f4 + x) FROM generate_series(1, 10) x) old_max, (SELECT max(new.f4 + x) FROM ge... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 00958a883a7f02bfef6288f0 | explain (costs off) select * from sj p join sj q on p.a = q.a left join sj r on p.a + q.a = r.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 023c039b9af3018dcb926f40 | EXPLAIN (COSTS OFF) EXECUTE test(NULL, 3.14, '-1.5') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 02782b885a1a680d80568029 | EXPLAIN (verbose, costs off) DELETE FROM foo WHERE f1 = 5 RETURNING (SELECT max(old.f4 + x) FROM generate_series(1, 10) x) old_max, (SELECT max(new.f4 + x) FROM generate_series(1, 10) x) new_max |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 02adf3ab2217a99658c72e2b | EXPLAIN (COSTS OFF) SELECT 1, 2, 3, 4, 5 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 02ead5d3ebfcaeadc7590035 | explain (analyze, costs off, summary off, timing off, buffers off) select * from stable_qual_pruning where a = any(array['2010-02-01', '2020-01-01']::timestamptz[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 02f9444de44e20111e3d2185 | EXPLAIN (COSTS OFF, VERBOSE) SELECT 1 FROM tbl_phv t1 LEFT JOIN (SELECT 1 extra, x, y FROM tbl_phv tl) t3 JOIN (SELECT y FROM tbl_phv tr) t4 ON t4.y = t3.y ON true WHERE t3.extra IS NOT NULL AND t3... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 0407fd4fae6e266041bd2dc0 | EXPLAIN (ANALYZE, TIMING OFF, COSTS OFF, SUMMARY OFF, BUFFERS OFF) SELECT * FROM brin_date_test WHERE a = '2023-01-01'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 046d52a0124475fc95b10184 | EXPLAIN (COSTS OFF) INSERT INTO stats_track_tab VALUES ((1), (2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 0532965819a2f2b9c080ccae | explain (analyze, costs off, summary off, timing off, buffers off) execute ab_q1 (1, 2, 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 05ff5a568b9e2ea9fb98e0ad | EXPLAIN (COSTS OFF) SELECT count(*) FROM tenk1 t1 WHERE t1.thousand = 42 OR t1.thousand = (SELECT t2.tenthous FROM tenk1 t2 WHERE t2.thousand = t1.tenthous + 1 LIMIT 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 068d594b0fcf6d3122f43600 | explain (analyze, costs off, summary off, timing off, buffers off) execute ab_q2 (2, 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 07b84dea706d75a60af553f4 | explain (verbose, costs off) select generate_series(1, a) as g, a+b as ab from (values (1, 1), (2, 2)) as t (a, b) group by rollup(a, ab) order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 08af710df5870ad30882d715 | explain (verbose, costs off) select * from (select k from (select i, coalesce(i, j) as k from (select i from t union all select 0) join (select 1 as j limit 1) on i = j) right join (select 2 as x) ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 09cadbeef8b1fae9abf13768 | -- Ensure that left-join is not removed EXPLAIN (COSTS OFF) SELECT t1.* FROM test3cs t1 LEFT JOIN (SELECT DISTINCT x FROM test3cs) t2 ON t1.x = t2.x COLLATE case_insensitive ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 0a74238f535d75608a6fab0f | explain (costs off) select * from tbl_rs t1 join lateral (select * from tbl_rs t2 where t2.a in (select t1.a+t3.a from tbl_rs t3) and t2.a < 5) on true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 0aa9163755e2a6e9f80f0a99 | explain (costs off) select p.b from sj p join sj q on p.a = q.a group by p.b having sum(p.a) = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 0be37950d0b2947bf228a669 | EXPLAIN (COSTS OFF) SELECT DISTINCT ON (y, x) x, y FROM (SELECT * FROM distinct_on_tbl ORDER BY x) s |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 0ced90bd227e53ea15b44aaf | -- No OR-clause groupings should happen, and there should be no clause -- permutations in the filtering conditions we could see in the EXPLAIN. EXPLAIN (COSTS OFF) SELECT * FROM tenk1 WHERE unique1... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 0f7cda4832f4757fe5ae5989 | explain (costs off) select * from sj t1 join sj t2 on t1.a = t2.a and t1.b = t2.b join sj t3 on t2.a = t3.a and t2.b + 1 = t3.b + 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 10e361c79a1c232843a81a4e | explain (costs off) with t as ( merge into part_abc_view pt using (select stable_one() + 1 as pid) as q join part_abc_2 pt2 on (q.pid = pt2.a) on pt.a = stable_one() + 2 when not matched then inser... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 115401580c759fe0c8d0d0aa | explain (verbose, costs off) select ss1.d1 from tenk1 as t1 inner join tenk1 as t2 on t1.tenthous = t2.ten inner join int8_tbl as i8 left join int4_tbl as i4 inner join (select 64::information_sche... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 11ba591d13a60c361facb088 | EXPLAIN (COSTS OFF) SELECT ten FROM onek WHERE unique1 IN (VALUES (1), (2) LIMIT 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 11dfb8fb839e6d135bed0bf3 | EXPLAIN (COSTS OFF) SELECT count(*) FROM emp1 c1, emp1 c2, emp1 c3 WHERE c1.id=c2.id AND c1.id*c2.id=c3.id*c3.id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 11e8d2ec249b5802134beae7 | explain (verbose, costs off) select * from generate_series(1,10) t1(id) left join lateral (select t1.id as t1id, t2.id from emp1 t2 join emp1 t3 on t2.id = t3.id) on true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1214e9851761e4c9872a1b3a | explain (costs off) merge into part_abc_view pt using (select stable_one() + 1 as pid) as q join part_abc_2 pt2 on (q.pid = pt2.a) on pt.a = stable_one() + 2 when not matched then insert values (1,... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1281895c6fc18cc663ca8183 | explain (analyze, timing off, summary off, costs off, buffers off) select count(*) from tenk1, tenk2 where tenk1.hundred > 1 and tenk2.thousand=0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 12bda1942b3a921028d26044 | -- -- Forwards scan RowCompare quals whose row arg has a NULL that ends scan -- explain (costs off) SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE proname >= 'abs' AND (proname, proar... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 15bf6de64417cd8809bd2427 | -- As above but try ordering the columns differently to ensure we get the -- same result. explain (costs off) select x,y,z from t2 group by z,x,y |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 15e9ac669938e874033a0efb | explain (costs off) select t1.a from gtest32 t1 left join gtest32 t2 on t1.a = t2.a where coalesce(t2.b, 1) = 2 or t1.a is null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 16117f9f7eda8036cd4b06fa | EXPLAIN (COSTS OFF) SELECT FROM sb_1 LEFT JOIN sb_2 ON (sb_2.x=sb_1.x) AND (sb_1.x=sb_2.x) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1667b7c0e20703efc360a284 | EXPLAIN (COSTS OFF) UPDATE sj sq SET b = 1 FROM sj as sz WHERE sq.a = sz.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1674169ca15a3999d977fdcf | explain (costs off) select * from (values (1)) x left join (select coalesce(y.q1, 1) from int8_tbl y right join sj j1 inner join sj j2 on j1.a = j2.a on true) z on true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 182e8b87e645ff505f44d49e | EXPLAIN (COSTS OFF) WITH a AS (SELECT 4) SELECT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 188c0d1d6741ec963eccfe5f | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE TABLE selinto_schema.tbl_nodata2 (a) AS SELECT generate_series(1,3) WITH NO DATA |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 18a7d30afa947ee68c5dd617 | explain (costs off) SELECT unique1 FROM tenk1 WHERE unique1 IS NULL AND unique1 IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 19188b0424f36943ce5d65c6 | EXPLAIN (COSTS OFF) SELECT t4.* FROM (SELECT t1.*, t2.a AS a1 FROM sj t1, sj t2 WHERE t1.b = t2.b) AS t3 JOIN sj t4 ON (t4.a = t3.a) WHERE t3.a1 = 42 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1a3e3d0787839c901f342105 | explain (analyze, costs off, summary off, timing off, buffers off) select * from boolp where a = (select value from boolvalues where value) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1ad85e46421a2bd1513205a4 | explain (costs off) select t1.a, (select a from sj where a = t2.a and a = t1.a) from sj t1, sj t2 where t1.a = t2.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1c09a4009c097c81127ebcdc | EXPLAIN (analyze, timing off, summary off, costs off, buffers off) SELECT * FROM tenk1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1c1752252b6eb07c4352111c | EXPLAIN (COSTS OFF) SELECT n2.a FROM sj n1, sj n2 WHERE n1.a <> n2.a AND n2.a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1d771a11a1fa78c1870f23c9 | EXPLAIN (RANGE_TABLE, COSTS OFF) INSERT INTO vegetables (name, genus) VALUES ('broccoflower', 'brassica') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 1e3f5ba5bb6a821e7a9f71ce | -- Skip array redundancy (pair of redundant low_compare inequalities) explain (costs off) SELECT thousand, tenthous FROM tenk1 WHERE thousand > -1 and thousand >= 0 AND tenthous = 3000 ORDER BY tho... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 228d7b27961cd8ee2cd5b317 | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = 2 AND j2.a = 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 23497ae805b9cb04df8b466b | -- Ensure that semijoin is not reduced to innerjoin EXPLAIN (COSTS OFF) SELECT * FROM test3cs t1 WHERE EXISTS (SELECT 1 FROM (SELECT DISTINCT x FROM test3cs) t2 WHERE t1.x = t2.x COLLATE case_insen... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 23a7a456e12825731cfd93d9 | EXPLAIN (COSTS OFF) SELECT count(*) FROM emp1 c1, emp1 c2, emp1 c3 WHERE c1.id=c3.id AND c1.id*c3.id=c2.id*c2.id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 23bd587159d85daa1fdd1e62 | explain (costs off) select f1 from int4_tbl union all (select unique1 from tenk1 union select unique2 from tenk1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 25ee142d188c40e16d93aa32 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) SELECT * FROM local_tbl t1 LEFT JOIN (SELECT *, (SELECT count(*) FROM async_pt WHERE a < 3000) FROM async_pt WHERE a < 3000) t2 ON... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2637fbb6aac2508533373d73 | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = 2 AND j1.c = 3 AND j2.a = 2 AND 3 = j2.c |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 26ff1f6d10febe3c4658fd2c | -- otherwise we need to wrap the PHVs explain (verbose, costs off) select ss2.* from int8_tbl t1 left join (int8_tbl t2 left join (select coalesce(q1) as x, * from int8_tbl t3) ss1 on t2.q1 = ss1.q... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2719448bfc3d88d17e995e3e | -- VtA transformation for a composite argument is not supported EXPLAIN (COSTS OFF) SELECT * FROM onek WHERE (unique1,ten) IN (VALUES (1,1), (20,0), (99,9), (17,99)) ORDER BY unique1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 271f161c9c76d2802832ba3d | EXPLAIN (COSTS OFF) SELECT 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2743a5b2f1ebc19de10e2136 | EXPLAIN (COSTS OFF) SELECT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 276cfaf1a4ea05546b0a5002 | -- Test run-time partition pruning with an initplan explain (analyze, costs off, summary off, timing off, buffers off) select * from ab where a = (select max(a) from lprt_a) and b = (select max(a)-... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 280c0ce6cbd7acff1e220865 | -- Ensure MergeAppend behaves correctly when no subplans match explain (analyze, costs off, summary off, timing off, buffers off) execute mt_q1(35) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 28b3e115267f8972c4551b0a | explain (verbose, costs off) select * from t t1 left join (select 1 as x, * from t t2(i2)) t2ss on t1.i = t2ss.i2 left join t t3(i3) on false left join t t4(i4) on t4.i4 > t2ss.x |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 28f9946b6e099816c2711c4a | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a*j1.a = 1 AND j2.a*j2.a = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 29200c94b9ceb0a947342b32 | -- Positive: deterministic collation in GROUP BY: always safe to push, even if -- HAVING uses a nondeterministic collation EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3cs GROUP BY x HAVING x = ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2932d52d49a6bbb3b8373064 | -- -- partial hash index -- EXPLAIN (COSTS OFF) SELECT * FROM hash_i4_heap WHERE seqno = 9999 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 29e53bd6e42c5b3b24877dd7 | -- Ensure that left-join is not removed EXPLAIN (COSTS OFF) SELECT t1.* FROM test3cs t1 LEFT JOIN test3cs t2 ON t1.x = t2.x COLLATE case_insensitive ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 29e821548848f9905f4ea52c | -- Ensure pruning works using a stable function containing no Vars explain (analyze, costs off, summary off, timing off, buffers off) select * from list_part where a = list_part_fn(1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2a435bae4684b4dc4e3681a8 | explain (costs off) select a, b, count(*) from gstest2 group by grouping sets ((a), (b)) having false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2acda403a0ee12b5e1e04ca8 | -- When there are multiple supporting unique indexes and the GROUP BY contains -- columns to cover all of those, ensure we pick the index with the least -- number of columns so that we can remove m... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2afad48756d2095a6d453aaf | explain (verbose, costs off) select t3.a from sj t1 join sj t2 on t1.a = t2.a join lateral (select * from (select t1.a offset 0) offset 0) t3 on true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2b04fe7a10864bde5d8d7681 | explain (costs off) select 1 from (sk k1 join sk k2 on k1.a = k2.a) join (sj j1 join sj j2 on j1.a = j2.a) on j2.b = k1.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2bf7159a5d6b3888c851f57f | -- -- Check bitmap index path planning -- EXPLAIN (COSTS OFF) SELECT * FROM tenk1 WHERE thousand = 42 AND (tenthous = 1 OR tenthous = 3 OR tenthous = 42 OR tenthous = 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2c1dd0066fd3970b5073e433 | EXPLAIN (COSTS OFF) SELECT * FROM pht1 p1 JOIN pht1 p2 USING (c) LIMIT 1000 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2df95d9570b2f9d45b90ca26 | EXPLAIN (COSTS OFF) EXECUTE test(NULL, 3.14, NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2e0ae55dc0313ecacae1138b | EXPLAIN (verbose, costs off) UPDATE ft2 SET c3 = 'bar' FROM ft4 INNER JOIN ft5 ON (ft4.c1 = ft5.c1) WHERE ft2.c1 > 1200 AND ft2.c2 = ft4.c1 RETURNING old, new, ft2, ft2.*, ft4, ft4.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2e637c2dd90251e994a5802e | explain (costs off) select * from ( select t1.*, t2.a as ax from sj t1 join sj t2 on (t1.a = t2.a and t1.c * t1.c = t2.c + 2 and t2.b is null) ) as q1 left join (select t3.* from sj t3, sj t4 where... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2eba3daa778e3f02de030dc6 | explain (costs off) select * from (select a, b from phv_boolpart) t where a is true group by grouping sets (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 2f457bf35af87f5ea989374e | -- Skip array preprocessing increments "thousand > -1" to "thousand >= 0" explain (costs off) SELECT thousand, tenthous FROM tenk1 WHERE thousand > -1 AND tenthous IN (1001,3000) ORDER BY thousand ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 3037705dbd77bc936818ebb7 | EXPLAIN (COSTS OFF) SELECT count(*) FROM tenk1, tenk2 WHERE tenk1.hundred = 42 AND (tenk2.thousand = 42 OR tenk2.thousand = 41 OR tenk2.tenthous = 2) AND tenk2.hundred = tenk1.hundred |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 30902a3a71e24b366b26fc54 | -- Positive: conflicting collation but no grouping expression reference EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING current_setting('server_version') = 'abc' COLLATE case_... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 31f84c39cd40bfdf76550e98 | explain (analyze, costs off, summary off, timing off, buffers off) execute mt_q1(25) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 3266594ee19b28389b560a77 | EXPLAIN (COSTS OFF) SELECT DISTINCT y, x FROM distinct_tbl ORDER BY y |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 332f92286044bda46c82425a | explain (verbose, costs off) select * from int8_tbl t1 left join (select coalesce(t2.q1 + x, 0) from int8_tbl t2, lateral (select t3.q1 as x from int8_tbl t3, lateral (select t2.q1, t3.q1 offset 0)... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 337596ac0fb1d3c687a14a9b | explain (verbose, costs off) select t1.a from t t1 left join t t2 on t1.a = t2.a join t t3 on true where exists (select 1 from t t4 join t t5 on t4.b = t5.b join t t6 on t5.b = t6.b where t1.a = t4... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 34824b8d538377cb24eb3810 | explain (verbose, costs off) select 1 from (select x.* from sj x, sj y where x.a = y.a) q, lateral generate_series(1, q.a) gs(i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 34d12f56cf3f1018b2345e0a | explain (costs off) select a.* from tenk1 a where exists (select 1 from tenk1 b where a.unique1 = b.unique2 group by b.unique1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 3517a874ba9f964ec575ca32 | EXPLAIN (COSTS OFF) SELECT count(*) FROM emp1 c1, emp1 c2, emp1 c3 WHERE c3.id=c2.id AND c3.id*c2.id=c1.id*c1.id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 358972e90b42ddd0dbb1ea81 | -- Negative: function applied to grouped column with conflicting collation EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING upper(x) = 'ABC' COLLATE case_sensitive |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 3659b473914020ee1abb49b4 | -- All pruned. explain (verbose, costs off) execute update_part_abc_view (3, 'a') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 3726a786c51a091a29e4ee54 | EXPLAIN (COSTS OFF) WITH t1 AS (SELECT * FROM emp1) UPDATE emp1 SET code = t1.code + 1 FROM t1 WHERE t1.id = emp1.id RETURNING emp1.id, emp1.code, t1.code |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 3a5dcfa059701218a84de2d8 | -- OpExpr with RelabelType: PHV wrapped around a casted column explain (costs off) select * from (select a::oid as x, b from phv_part) t where x::int = 1 group by grouping sets (x, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 3bc1b3ec640d34d481071de1 | EXPLAIN (COSTS OFF) SELECT COUNT(*) FROM onek t1 LEFT JOIN tenk1 t2 ON (t2.thousand = t1.tenthous OR t2.thousand = t1.thousand) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 3c006f5e5388657ceb1f246d | explain (costs off) select * from p t1 where exists (select 1 from p t2 where t1.a = t2.a and t1.a = 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 403f185f88694598b6d5fe6c | EXPLAIN (COSTS OFF) SELECT * FROM onek t1, lateral (SELECT * FROM onek t2 WHERE t2.ten IN (values (t1.ten), (1))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 404bef89ac6a6fff5ec1bd38 | EXPLAIN (COSTS OFF) SELECT c1.code FROM emp1 c1 LEFT JOIN emp1 c2 ON c1.id = c2.id WHERE c2.id IS NOT NULL EXCEPT ALL SELECT c3.code FROM emp1 c3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 40da6e905df664c907d34a6d | -- test pushdown of non-degenerate HAVING clause that does not reference any -- columns that are nullable by grouping sets explain (costs off) select a, b, count(*) from gstest2 group by grouping s... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 421cde5cac336c9fd7a473d3 | EXPLAIN (COSTS OFF) -- VtA allows NULLs in the list SELECT ten FROM onek WHERE sin(two)+four IN (VALUES (sin(0.5)), (NULL), (2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 43c6a114cace72874337fa3a | explain (verbose, costs off) select null::int[] union all select null::int[] union all select null::bigint[] |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 444cd1506f5927ef1fce0772 | explain (verbose, costs off) select 1 from emp1 t1 left join ((select 1 as x, * from emp1 t2) s1 inner join (select * from emp1 t3) s2 on s1.id = s2.id) on true where s1.x = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 451dc2fec7169240855c1603 | -- Positive: function with same collation as GROUP BY EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING upper(x) = 'ABC' COLLATE case_insensitive |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 455d16292d136cfbb69e21ce | explain (costs off) select t1.unique1,t2.unique1 from tenk1 t1 inner join tenk1 t2 on t1.two = t2.two and t1.unique1 = (select min(unique1) from tenk1 where t2.unique1=unique1) where t1.unique1 < 1... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 467c8840df1401966d84ed6d | explain (costs off) select a, b from (values (1, 1), (2, 2)) as t (a, b) where a = b group by grouping sets((a, b), (a)) order by a, b nulls first |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 46b010db56e00d0c89e7cc6f | EXPLAIN (COSTS OFF) WITH a AS (SELECT 4) UPDATE stats_track_tab SET x = 1 WHERE x = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 46ce4c5625971d10c33d3f25 | EXPLAIN (COSTS OFF) SELECT DISTINCT y, x FROM (SELECT * FROM distinct_tbl ORDER BY x) s |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4737df5d7a487b698892e2e4 | EXPLAIN (RANGE_TABLE, COSTS OFF) SELECT * FROM vegetables WHERE genus = 'daucus' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4761cf25de6e158d4093c67f | -- Ensure that nullingrel bits are propagated into the generation expressions explain (costs off) select sum(t2.b) over (partition by t2.a), sum(t2.c) over (partition by t2.a), sum(t2.d) over (part... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4792e95ba01148a30229a361 | explain (costs off) select * from ec0 m join ec0 n on m.ff = n.ff join ec1 p on m.ff + n.ff = p.f1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 479f0fe61277086daed53b49 | -- Negative: OR with a conflicting clause: must stay in HAVING EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING x = 'abc' COLLATE case_sensitive OR x = 'def' COLLATE case_sensi... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 487315adcfad5844b1d78e4c | -- test handling of expressions nullable by grouping sets explain (costs off) select distinct on (a, b) a, b from (values (1, 1), (2, 2)) as t (a, b) where a = b group by grouping sets((a, b), (a))... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 48ff6c14aee930e16e487d70 | EXPLAIN (COSTS OFF) SELECT DISTINCT y, x FROM distinct_tbl limit 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 49e7cbe402fb64ca17f862a0 | explain (verbose, costs off) select * from sl t1, sl t2 where t1.b = t2.b and t2.a = 3 and t1.a = 3 and t1.c IS NOT NULL and t2.c IS NOT NULL and t2.b IS NOT NULL and t1.b IS NOT NULL and t1.a IS N... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4a0717b5d23a02df1e3914f4 | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND (j1.a*j1.a) = (EXTRACT(DOW FROM current_timestamp(0))/15 + 3)::int AND (EXTRACT(DOW FROM current_timestamp(0))/15 + 3)::int = (j... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4a1f5f7323e55b7b39be457b | EXPLAIN (COSTS OFF) WITH a AS (select 4) SELECT 1 UNION SELECT 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4aa56d14e7dee460a47b27e3 | EXPLAIN (COSTS OFF) (SELECT 1, 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4af0e351f05c4f03288ce8f3 | explain (costs off) select * from (select 1::int as id) as lhs full join (select dummy_source.id from (select null::int as id) as dummy_source left join (select a.id from a where a.id = 42) as sub ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4b9eed26655f0cb78121191b | -- Ensure Params that evaluate to NULL properly prune away all partitions explain (analyze, costs off, summary off, timing off, buffers off) select * from listp where a = (select null::int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4bd4926ecc72fdf76ce2c89f | -- VtA is not allowed with subqueries EXPLAIN (COSTS OFF) SELECT ten FROM onek t WHERE unique1 IN (VALUES (0), ((2 IN (SELECT (3)))::integer) ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4c6abe54e34e666c2ff62782 | explain (verbose, costs off) select t3.a from sj t1 join sj t2 on t1.a = t2.a join lateral (select t1.a offset 0) t3 on true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4f48281388564ef21c5e95ec | -- Skip array redundancy (pair of redundant high_compare inequalities) explain (costs off) SELECT thousand, tenthous FROM tenk1 WHERE thousand < 3 and thousand <= 2 AND tenthous = 1001 ORDER BY tho... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 4fe0c899b3b36773289e82ab | explain (costs off) select * from tenk1 a, tenk1 b where exists(select * from tenk1 c where b.twothousand = c.twothousand and b.fivethous <> c.fivethous) and a.tenthous = b.tenthous and a.tenthous ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 508de991a8b46854bb3cb6f9 | explain (analyze, costs off, summary off, timing off, buffers off) select * from tbl1 inner join tprt on tbl1.col1 = tprt.col1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 511d19cc34aebbc7d1bd5802 | EXPLAIN (COSTS OFF) SELECT c.unique1,c.ten FROM tenk1 c JOIN onek a USING (ten) WHERE c.ten IN (VALUES (1), (2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 5281ba350454aed19a610dde | EXPLAIN (COSTS OFF) SELECT * FROM tenk1 WHERE thousand = 42 AND (tenthous = 1::int2 OR tenthous::int2 = 3::int8 OR tenthous = 42::int8) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 54f45e36e9220e05bd3a81e5 | -- Both partitions allowed by IN clause, then both excluded again by <> clauses. explain (analyze, costs off, summary off, timing off, buffers off) execute q1 (1,2,2,1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 55fed00ad4993599de9d124f | EXPLAIN (COSTS OFF) SELECT t1.a, t1.c, t2.b, t2.c FROM prt1 t1, prt2 t2 WHERE t1.a = t2.a AND t1.a = t2.b ORDER BY t1.a, t2.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 56a0c1ee493937cb643ac8ac | EXPLAIN (COSTS OFF) WITH a AS (SELECT 4) MERGE INTO stats_track_tab USING (SELECT id FROM generate_series(1, 10) id) ON x = id WHEN MATCHED THEN UPDATE SET x = id WHEN NOT MATCHED THEN INSERT (x) V... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 57790694577be5e03a079a11 | explain (costs off) select * from ec0 m join ec0 n on m.ff = n.ff join ec1 p on p.f1::int8 = (m.ff + n.ff)::int8alias1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 588ea2c4551d90386a8c81c5 | -- OR clauses in the 'unique1' column are grouped, so clause permutation -- occurs. W e can see it in the 'Recheck Cond': the second clause involving -- the 'unique1' column goes just after the fir... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 58a6d70b315ab39de5c5e3b7 | explain (analyze, costs off, summary off, timing off, buffers off) select * from stable_qual_pruning where a = any(array['2000-02-01', localtimestamp]::timestamp[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 58b286e1426ecf0ba570a3e8 | -- otherwise we need to wrap the strict expressions explain (verbose, costs off) select t1.q1, x from int8_tbl t1 left join (int8_tbl t2 left join lateral (select t2.q1+1 as x, * from int8_tbl t3) ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 59a7e5587fe918b35186ffc1 | explain (verbose, costs off) select t4.a from sj t1 join sj t2 on t1.a = t2.a join lateral (select t3.a from sj t3, (select t1.a) offset 0) t4 on true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 59dc098bbd06d874de9da1de | explain (analyze, costs off, summary off, timing off, buffers off) select * from tbl1 join tprt on tbl1.col1 = tprt.col1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 5b362f03ec873b63b2f8b66a | EXPLAIN (COSTS OFF) SELECT count(*) FROM pagg_tab GROUP BY c ORDER BY c LIMIT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 5c4b7102f9b10657570e709c | -- Positive: simple-CASE form with matching collation, safe to push EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING (CASE x WHEN 'abc' COLLATE case_insensitive THEN true ELSE ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 5c69addd765871c823b193fe | explain (costs off) select x, y from (select t1.unique1 as x, t1.unique2 as y from tenk1 t1, tenk1 t2) as t where x = 1 group by grouping sets (x, y) order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 5d2af7f220a1fa7849d57c32 | explain (costs off) select * from sj p, sj q where p.a = q.a and p.b = 1 and q.b = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 5dfce4442334334aa5ef4efe | -- RETURNING OLD and NEW from subquery EXPLAIN (verbose, costs off) INSERT INTO foo VALUES (5, 'subquery test') RETURNING (SELECT max(old.f4 + x) FROM generate_series(1, 10) x) old_max, (SELECT max... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 5f65de4679cfa84d7c5f9bbc | EXPLAIN (COSTS OFF) SELECT * FROM tenk1 WHERE thousand = 42 AND (tenthous = 1 OR tenthous = 3 OR tenthous = 42 OR tenthous IS NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 61da513e0676de9b99095e75 | EXPLAIN (COSTS OFF) SELECT COUNT(*) FROM tab_with_flag WHERE (is_flag IS NULL OR is_flag = 0) AND id IN (SELECT id FROM tab_with_flag WHERE id IN (2, 3)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 61ea2b79f2445e9965a953c9 | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND 1 = j1.a AND j2.a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6336edcbd6a1484b7a977bd1 | EXPLAIN (COSTS OFF) SELECT COUNT(*) FROM tenk1 t1, tenk1 t2 WHERE t2.thousand = t1.tenthous OR t2.thousand = t1.unique1 OR t2.thousand = t1.unique2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 637948178851259826b72fa7 | explain (analyze, costs off, summary off, timing off, buffers off) execute ab_q1 (2, 4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 63d1e01954a3464e140e885d | explain (analyze, costs off, summary off, timing off, buffers off) select * from listp where a = (select 2) and b <> 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 67b85bc403229bdfbabc6779 | explain (costs off) select * from emp1 t1 inner join emp1 t2 on t1.id = t2.id left join emp1 t3 on t1.id > 1 and t1.id < 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 67db033bfda12fd4e00ccea0 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE TABLE selinto_schema.tbl_withdata2 (a) AS SELECT generate_series(1,3) WITH DATA |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 698ac0f2d87e5ae92441ac53 | -- VtA doesn't support LIMIT, OFFSET, and ORDER BY clauses EXPLAIN (COSTS OFF) SELECT ten FROM onek WHERE unique1 IN (VALUES (1), (2) OFFSET 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 69945017f68fcf1f5375ad9a | -- Ensure the xy_1 subplan is not pruned. explain (analyze, costs off, summary off, timing off, buffers off) execute ab_q6(1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6a6ace1e1a1943e55c89519f | EXPLAIN (COSTS OFF) SELECT DISTINCT ON (y, x) x, y FROM distinct_on_tbl ORDER BY y |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6b133fe4d0919831fb9539e2 | -- VtA is not allowed with non-constant expressions EXPLAIN (COSTS OFF) SELECT ten FROM onek t WHERE unique1 IN (VALUES (0), (unique2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6b525303472863aedb7cd199 | EXPLAIN (COSTS OFF) SELECT ten FROM onek WHERE unique1 IN (VALUES (1), (2) ORDER BY 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6cc9edfde39b369e9e8e545d | -- -- Backwards scan RowCompare qual whose row arg has a NULL that affects our -- initial positioning strategy -- explain (costs off) SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE pr... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6d09b7d19b2452b499b1fd34 | explain (analyze, costs off, summary off, timing off, buffers off) select * from tbl1 join tprt on tbl1.col1 > tprt.col1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6d7aea4fb9cf48228acc42d0 | explain (verbose, costs off) select t1.a from sj t1 where t1.b in ( select t2.b from sj t2 join sj t3 on t2.c=t3.c) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6e0255614ba5a0d27cc6e32c | -- Constant expressions are simplified EXPLAIN (COSTS OFF) SELECT ten FROM onek WHERE sin(two ) +four IN (VALUES (sin(0.5)), (2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6ec1ac978cf9176f4ab285c4 | -- Single partition should be scanned. explain (analyze, costs off, summary off, timing off, buffers off) execute part_abc_q1 (1, 2, 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6f66bd17e292e6e1ea6ca860 | -- Ensure pruning does not take place when the function has a Var parameter explain (analyze, costs off, summary off, timing off, buffers off) select * from list_part where a = list_part_fn(a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 6fe14574ef02b16a1c8a8da9 | -- error EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE MATERIALIZED VIEW IF NOT EXISTS matview_ine_tab AS SELECT 1 / 0 WITH NO DATA |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 714850ce5e3d71dda6478b65 | EXPLAIN (COSTS OFF) (SELECT 1, 2, 3, 4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 71a73b7b9fdb0b99ebd781af | EXPLAIN (ANALYZE, TIMING OFF, COSTS OFF, SUMMARY OFF, BUFFERS OFF) SELECT * FROM brin_interval_test WHERE a = '30 years'::interval |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 725a2ece86bdbe5803db4b92 | -- ok EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE MATERIALIZED VIEW matview_ine_tab AS SELECT 1 / 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 72e918ab64f497bf493d206c | EXPLAIN (COSTS OFF) SELECT * from onek WHERE unique1 in (VALUES(1200::bigint), (1)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 73478bf232e7541da6ee8a38 | explain (costs off) select * from sj t1, sj t2, sj t3 where t1.a = t1.b and t1.b = t2.b and t2.b = t2.a and t1.b = t3.b and t3.b = t3.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 738f3c970c47bc80f220e993 | explain (verbose, costs off) select grouping((select t1.v from gstest5 t2 where id = t1.id)), (select t1.v from gstest5 t2 where id = t1.id) as s, case when grouping((select t1.v from gstest5 t2 wh... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 764203cc5361e81fadc7dcff | explain (costs off) select * from sj t1 left join lateral (select t1.a as t1a, * from sj t2) s on true where t1.a = s.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 771433de2d3ad6b05dd04e78 | -- ok EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE MATERIALIZED VIEW matview_ine_tab AS SELECT 1 / 0 WITH NO DATA |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 77c3265b92cfa4366129c2b8 | -- DELETE has OLD, but not NEW EXPLAIN (verbose, costs off) DELETE FROM foo WHERE f1 = 5 RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 77c50021cc6ef81174ff8138 | -- -- A DISTINCT / GROUP BY / set-op on a subquery does not prove uniqueness -- under a different collation, so the planner must not use such a proof for -- any optimization. -- -- Ensure that we d... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 790d889f30872117faefcb6b | -- Negative: simple-CASE form with conflicting WHEN comparison collation EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING (CASE x WHEN 'abc' COLLATE case_sensitive THEN true EL... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 791d34e9df298874eb5f793b | -- -- Backwards scan RowCompare qual whose row arg has a NULL that ends scan -- explain (costs off) SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE (proname, proargtypes) > ('abs', NUL... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7a82047e9679b348ea752d60 | -- test handling of SRFs with grouping sets explain (verbose, costs off) select generate_series(1, a) as g from (values (1, 1), (2, 2)) as t (a, b) group by rollup(g) order by 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7a9327742045dc360bfa6e8f | -- Test run-time partition pruning with UNION ALL parents explain (analyze, costs off, summary off, timing off, buffers off) select * from (select * from ab where a = 1 union all select * from ab) ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7ce056c88f49deac20cc8580 | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = 2 AND j2.a = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7cefa036771065b81e28c5a5 | EXPLAIN (COSTS OFF) SELECT * FROM tenk1 WHERE tenthous = 1::numeric OR tenthous = 3::int4 OR tenthous = 42::numeric |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7d009b298db86d2eb747185a | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) UPDATE tidscan SET id = -id WHERE CURRENT OF c RETURNING * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7d39dd104d5841e5ee457fe5 | EXPLAIN (COSTS OFF) SELECT * FROM emp1 t1 INNER JOIN emp1 t2 ON t1.id = t2.id LEFT JOIN emp1 t3 ON t1.code = 1 AND (t2.code = t3.code OR t2.code = 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7d77b74c14283f0e18caf3db | EXPLAIN (COSTS OFF) SELECT ten FROM onek t WHERE unique1 IN (VALUES (0), ((2 IN (SELECT unique2 FROM onek c WHERE c.unique2 IN (VALUES (sin(0.5)), (2))))::integer)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7d8106e5890666facc25e102 | EXPLAIN (COSTS OFF) UPDATE stats_track_tab SET x = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7dd9e0a2b25a823ffd41a63e | -- VtA causes the whole expression to be evaluated as a constant EXPLAIN (COSTS OFF) SELECT ten FROM onek t WHERE 1.0::integer IN ((VALUES (1), (3))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7e83dfa34751f83eb6c86954 | explain (verbose, costs off) select 1 from (select y.* from sj x, sj y where x.a = y.a) q, lateral generate_series(1, q.a) gs(i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7eb179013b3f5d3fb00340f2 | EXPLAIN (COSTS OFF) SELECT COUNT(*) FROM guid1 WHERE guid_field = '3f3e3c3b-3a30-3938-3736-353433a2313e' OR guid_field = '11111111111111111111111111111111' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7f24f0287c9d9b4f49b2acfd | -- -- Performs a recheck of > key following array advancement on previous (left -- sibling) page that used a high key whose attribute value corresponding to -- the > key was -inf (due to being trun... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 7f47f1bcb6cee9bd74441030 | explain (costs off) select not a from (values(true)) t(a) group by rollup(not a) having not not a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8002f45e630a7b35984518fa | -- ensure initplan params properly prune partitions explain (analyze, costs off, summary off, timing off, buffers off) select * from ma_test where a >= (select min(b) from ma_test_p2) order by b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 800e521d902f7e70ff190f5f | -- Ensure that outer-join removal functions correctly after the propagation of nullingrel bits explain (costs off) select t1.a from gtest32 t1 left join gtest32 t2 on t1.a = t2.a where coalesce(t2.... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 81bdce7e14dc7312670df6cd | EXPLAIN (COSTS OFF) SELECT a1.a FROM sj a1,sj a2 WHERE (a1.a=a2.a) FOR UPDATE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 83210264f2a81bc0f369db02 | EXPLAIN (COSTS OFF) SELECT count(*) FROM tenk1 WHERE hundred = 42 AND (thousand < 42 OR thousand < 99 OR 43 > thousand OR 42 > thousand) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8452897aa5887daa382be49a | explain (costs off) select distinct on (a, b+1) a, b+1 from (values (1, 0), (2, 1)) as t (a, b) where a = b+1 group by grouping sets((a, b+1), (a)) order by a, b+1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 862b1f72b12215017d908087 | explain (costs off) select * from sj x join sj y on x.a = y.a left join int8_tbl z on y.a = z.q1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 87141992dce74beede40c7e6 | -- Try with no matching partitions. explain (analyze, costs off, summary off, timing off, buffers off) execute q1 (0,0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8786e1b0ecd8656f5be74bc4 | -- Negative: inner function has conflicting collation, even though outer -- operator's collation matches GROUP BY due to a COLLATE override EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 87e22330b304efc9655f4ea4 | explain (costs off, analyze on, timing off, summary off, buffers off) select * from onek2 where unique2 = 11 and stringu1 = 'ATAAAA' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 88c5b5cd25f158cd7b5120c3 | -- Ensure run-time pruning works on the nested Merge Append explain (analyze on, costs off, timing off, summary off, buffers off) select * from rangep where b IN((select 1),(select 2)) order by a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 890368b90768b49199e5eb2a | -- INSERT has NEW, but not OLD EXPLAIN (verbose, costs off) INSERT INTO foo VALUES (4) RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 89160e0067fdd15c3306ddfd | EXPLAIN (COSTS OFF) SELECT * FROM tenk1 WHERE thousand = 42 AND (tenthous = 1::int2 OR tenthous = 3::int8 OR tenthous = 42::int8) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 895c7918e6a492cc017d40f7 | -- Column b must NOT be dropped: under case_insensitive on a, 'foo' and -- 'FOO' would merge, but they have distinct b values. EXPLAIN (COSTS OFF) SELECT a, b FROM groupby_collation_t GROUP BY a, b... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 89a3946c49737d67bdf47ef3 | -- check ScalarArrayOp cases explain (analyze, costs off, summary off, timing off, buffers off) select * from stable_qual_pruning where a = any(array['2010-02-01', '2020-01-01']::timestamp[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8ade7dcb8ca9d97e282f773b | EXPLAIN (COSTS OFF) SELECT t1.unique1 FROM tenk1 t1 LEFT JOIN (SELECT *, 42 AS phv FROM tenk1 t2) ss ON t1.unique2 = ss.unique2 WHERE ss.unique1 = ss.phv AND t1.unique1 < 100 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8b7f7117c8be93ab74c997f3 | explain (verbose, costs off) select * from (select tattle(3, ten) as v, count(*) from tenk1 where unique1 < 3 group by 1) ss where ss.v |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8c84c0f01d08197d6cff93ae | explain (verbose, costs off) select * from emp1 t1 join emp1 t2 on t1.id = t2.id left join lateral (select t1.id as t1id, * from generate_series(1,1) t3) s on true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8c89b6bfa3d51e2583404871 | explain (costs off) SELECT id FROM btree_tall_tbl WHERE id = 55 ORDER BY t, id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8c94aa1be60ce89cbe3577b2 | -- Same with set-op EXPLAIN (VERBOSE, COSTS OFF) SELECT * FROM test1cs t1, (SELECT x FROM test3cs UNION SELECT x FROM test3cs) t2 WHERE t1.x = t2.x COLLATE case_insensitive ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8d57bdb97388d164ae7df8e4 | explain (costs off) select a, count(*) from gstest2 group by grouping sets ((a), ()) having false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8dcb12b604ece11a7b710949 | EXPLAIN (COSTS OFF) (SELECT 1, 2, 3) UNION SELECT 3, 4, 5 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8e7279e136817fb6dd03e841 | explain (costs off) SELECT a.* FROM a LEFT JOIN b ON a.id = b.id LEFT JOIN e ON e.id1 = a.b_id AND b.c_id = e.id2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8e7720ed2b26e7c52e2dace7 | explain (costs off) select * from tbl_nocom t1 full join tbl_nocom t2 on t2.a = t1.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8e7ad3dbea8a834bf861e0e9 | EXPLAIN (COSTS OFF) DELETE FROM sj |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8ebd398cd2f278f6963636c7 | EXPLAIN (COSTS OFF) WITH a AS (SELECT 4) INSERT INTO stats_track_tab VALUES ((1)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 8ee8558c35b11a09f3f35994 | EXPLAIN (COSTS OFF) SELECT * FROM tenk1 WHERE thousand = 42 AND (tenthous = 1::numeric OR tenthous = 3::int4 OR tenthous = 42::numeric) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 90b2e8df1cea7ca781244faa | -- UPDATE on view with rule EXPLAIN (verbose, costs off) UPDATE joinview SET f3 = f3 + 1 WHERE f3 = 57 RETURNING old.*, new.*, *, new.f3 - old.f3 AS delta_f3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 91c02cbc32087e7a79b57e15 | explain (costs off) select * from tenk1 a join tenk1 b on (a.unique1 < 20 or a.unique1 = 3 or a.unique1 = 1 and b.unique1 = 2) or ((a.unique2 = 3 or a.unique2 = 7) and b.hundred = 4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 92670ede3b163f9fa334d13f | -- should get a dummy Result, not a seq scan explain (costs off) select * from gtest33 where b < 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 93037359b297b24bb3e7f8de | explain (analyze, costs off, summary off, timing off, buffers off) select * from stable_qual_pruning where a = any(null::timestamptz[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 930a79b79cddce6cab59e57c | EXPLAIN (COSTS OFF) SELECT count(*) FROM btg t1 JOIN btg t2 ON t1.w = t2.w AND t1.x = t2.x AND t1.z = t2.z GROUP BY t1.w, t1.z, t1.x |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 942eac50d61a8e7549a89220 | EXPLAIN (COSTS OFF) SELECT * FROM tenk1 WHERE thousand = 42 AND (tenthous = 1::int2 OR tenthous::int2 = 3::int8 OR tenthous::int2 = 42::int8) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 945e8183c8002392f796a6cb | explain (analyze, costs off, summary off, timing off, buffers off) select * from boolp where a = (select value from boolvalues where not value) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 94eb345a4889a88242ccb1fe | explain (costs off) select * from t t1, t t2 where exists (select 1 from t t3 where t1.a = t3.a and t2.b = t3.b and t3.a = 1 and t3.b = 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 96987a907c2bbab24ab9934a | -- error EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE MATERIALIZED VIEW IF NOT EXISTS matview_ine_tab AS SELECT 1 / 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 96b1e955d7bd5483c452e8a6 | EXPLAIN (COSTS OFF) INSERT INTO stats_track_tab VALUES ((1)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 96c35db4426fe30cd0a7d046 | explain (costs off) select p.* from sj p, sj q where q.a = p.a and q.b = q.a - 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 98512066b32189a6bd41f8fb | EXPLAIN (verbose, costs off) UPDATE ft2 SET c2 = c2 + 400, c3 = c3 \|\| '_update7b' WHERE c1 % 10 = 7 AND c1 < 40 RETURNING old.*, new.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 986884b29c53d5bb459e911d | EXPLAIN (COSTS OFF) SELECT * FROM onek WHERE unique1 IN (VALUES(1200), (1)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 98a617ac3573d0920a1a1492 | -- otherwise we need to wrap the Vars explain (verbose, costs off) select t1.q1, x from int8_tbl t1 left join (int8_tbl t2 left join lateral (select t2.q2 as x, * from int8_tbl t3) ss on t2.q2 = ss... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9a015694eb1433f3e6c08971 | explain (analyze, costs off, summary off, timing off, buffers off) execute ab_q3 (2, 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9a154203ad36a75fc152bc32 | EXPLAIN (COSTS OFF) SELECT count(*) FROM tenk1 LEFT JOIN tenk2 ON tenk1.hundred = 42 AND (tenk2.thousand = 42 OR tenk2.thousand = 41 OR tenk2.tenthous = 2) AND tenk2.hundred = tenk1.hundred |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9a1a4c52faead1470e329982 | EXPLAIN (COSTS OFF) SELECT * FROM bitmap_split_or WHERE (a = 1 OR a = 2) AND b = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9a9cdf53d994f3ec1956343d | -- Makes B-Tree preprocessing deal with unmarking redundant keys that were -- initially marked required (test case relies on current row compare -- preprocessing limitations) explain (costs off) SE... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9aaac55b773098b33254569e | explain (costs off) SELECT unique1 FROM tenk1 WHERE unique1 = ANY(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9b5c1be186c9910cbfb684cc | -- VtA shouldn't depend on the side of the join probing with the VALUES expression. EXPLAIN (COSTS OFF) SELECT c.unique1,c.ten FROM tenk1 c JOIN onek a USING (ten) WHERE a.ten IN (VALUES (1), (2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9b6177fcf4ff3e971249129a | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9cee76571b8f812cd50750ce | -- should get a dummy Result, not a seq scan explain (costs off) select * from gtest33 where b is null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9d06050408fa3e3d18b63b13 | explain (costs off) select * from emp1 t1 where exists (select * from emp1 t2 where t2.id = t1.code and t2.code > 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9d0bd7bc6de50d99d1868b9b | explain (costs off) select * from (select 1::int as id) as lhs full join (select dummy_source.id from (select 2::int as id) as dummy_source left join (select a.id from a) as sub on sub.id = dummy_s... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9e2aa809305bd43dd952bfb0 | EXPLAIN (COSTS OFF) SELECT COUNT(*) FROM guid1 WHERE guid_field <> '11111111111111111111111111111111' OR guid_field <> '3f3e3c3b-3a30-3938-3736-353433a2313e' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9e825656731d3224681e0f05 | EXPLAIN (COSTS OFF) SELECT * FROM bitmap_split_or t1, bitmap_split_or t2 WHERE t1.a = t2.b OR t1.a = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9ef9d9aec15377436a661749 | -- OpExpr: PHV-wrapped operand matched via equal() explain (costs off) select * from (select a, b from phv_part) t where a = 1 group by grouping sets (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 9f2a6e4d6004ab6e3badf06b | -- Positive: AND of two safe clauses, both can be pushed EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING x = 'abc' COLLATE case_insensitive AND length(x) > 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a1e9668b286be6579ec73d41 | explain (costs off) SELECT thousand, tenthous FROM tenk1 WHERE thousand > 995 and tenthous in (998, 999) ORDER BY thousand desc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a217abd3067f55b0482e4fed | explain (costs off) select x, y from (select unique1::oid as x, unique2 as y from tenk1) as t where x::integer = 1 group by grouping sets (x, y) order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a252b2475a931a944d4f6487 | explain (costs off) select * from sj t1 join lateral (select * from sj tablesample system(t1.b)) s on t1.a = s.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a443bbe82806d37399e5ddd6 | explain (verbose, costs off) execute update_part_abc_view (2, 'a') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a452e4d6710cb4e99914d25d | EXPLAIN (verbose, costs off) INSERT INTO foo VALUES (4, 'conflict'), (5, 'ok') ON CONFLICT (f1) DO UPDATE SET f2 = excluded.f2\|\|'ed', f3 = -1 RETURNING WITH (OLD AS o, NEW AS n) o.tableoid::regclas... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a53505cf8a72dc87bdf2c94a | -- test that parallel nestloop join is not generated if the inner path is -- not parallel-safe explain (costs off) select * from tenk1 t1 left join lateral (select t1.unique1 as x, * from tenk2 t2 ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a5dbdf4c64357e45a60ea068 | explain (costs off) select * from (select * from tenk1 order by four) t1 join tenk1 t2 on t1.four = t2.four and t1.two = t2.two order by t1.four, t1.two limit 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a699b54380168c47a0dbb715 | EXPLAIN (RANGE_TABLE) SELECT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a6ddda454894744eda296bd9 | -- lateral references for PHVs can also escape being wrapped if the -- referenced rel is under the same lowest nulling outer join explain (verbose, costs off) select ss2.* from int8_tbl t1 left joi... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a71ec2a22983048870d2ede8 | explain (costs off) select min(a) over (partition by a order by a) from part_abc where a >= stable_one() + 1 and d <= stable_one() union all select min(a) over (partition by a order by a) from part... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a801bfbb05b158142f29c9f4 | explain (costs off) select * from emp1 t1 left join (select coalesce(t3.code, 1) from emp1 t2 left join (emp1 t3 join emp1 t4 on t3.id = t4.id) on true) on true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a80761090546e246c65fc205 | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND 2 = j1.a AND j1.c = 3 AND j2.a = 1 AND 3 = j2.c |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a866ede2653e8a1fbcebbb38 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE MATERIALIZED VIEW matview_schema.mv_nodata2 (a) AS SELECT generate_series(1, 10) WITH NO DATA |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a8703603758f898e1555203a | EXPLAIN (COSTS OFF) SELECT * FROM bitmap_split_or WHERE a = 1 AND (b = 1 OR b = 2) AND c = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a9139447162e89f75d83e118 | EXPLAIN (COSTS OFF) SELECT ten FROM onek t WHERE unique1 IN (VALUES (0), ((2 IN (SELECT unique2 FROM onek c WHERE c.unique2 = t.unique1))::integer)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | a9695ddc4872824ff90eec0c | EXPLAIN (DEBUG) SELECT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ab27ce70ccf9ed63343803ca | -- Test HAVING-to-WHERE pushdown with nondeterministic collations. -- When a HAVING clause uses a different collation than the GROUP BY's -- nondeterministic collation, it must not be pushed to WHE... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ad443aaf91ac99dfe3875e46 | -- -- test for bug #19106: interaction of WITH with aggregates -- -- the initial fix for #19055 was too aggressive and broke this case explain (verbose, costs off) with a as ( select id from (value... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | adadc10605d6edb6e9cb685d | EXPLAIN (COSTS OFF) DELETE FROM stats_track_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ae2faafd9b465b043c962e13 | explain (analyze, costs off, summary off, timing off, buffers off) execute ps2(1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ae8e8086c02c4f5bcad6b8cc | EXPLAIN (COSTS OFF) SELECT unique1, stringu1 FROM onek WHERE stringu1::text IN (VALUES('RFAAAA'), ('VJAAAA')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | af2d0b7d001e61c83da4f73f | EXPLAIN (COSTS OFF) SELECT count(*) FROM tenk1 JOIN tenk2 ON tenk1.hundred = 42 AND (tenk2.thousand = 42 OR tenk2.thousand = 41 OR tenk2.tenthous = 2) AND tenk2.hundred = tenk1.hundred |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | afd58d15a7aa80ece879e3ad | explain (costs off) select * from sj t1, sj t2 where t1.a = t1.b and t1.b = t2.b and t2.b = t2.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b07969f6e909801a2dd4ea5f | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE MATERIALIZED VIEW matview_schema.mv_withdata2 (a) AS SELECT generate_series(1, 10) WITH DATA |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b1572b0e051e26ac5ece5523 | EXPLAIN (COSTS OFF) SELECT * FROM sj_t1 JOIN ( SELECT sj_t2.id AS id FROM sj_t2 WHERE EXISTS ( SELECT TRUE FROM sj_t3,sj_t4 WHERE sj_t3.a = 1 AND sj_t3.id = sj_t2.id ) ) t2t3t4 ON sj_t1.id = t2t3t4... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b201d5113b438234c4b5e122 | explain (costs off) select * from (select a as x from sj where false) as q1, (select a as y from sj where false) as q2 where q1.x = q2.y |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b2785ff6c3a36b33e7494e51 | EXPLAIN (verbose, costs off) UPDATE joinview SET f3 = f3 + 1, f4 = 7 WHERE f3 = 58 RETURNING old.*, new.*, *, new.f3 - old.f3 AS delta_f3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b370bc9bed1b05b5b0e7c7df | EXPLAIN (COSTS OFF) SELECT DISTINCT ON (y, x) x, y FROM distinct_on_tbl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b610b98e410beb79dfc4ed13 | -- A case containing a UNION ALL with a non-partitioned child. explain (analyze, costs off, summary off, timing off, buffers off) select * from (select * from ab where a = 1 union all (values(10,5)... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b675f99f24e8ed711cfc67cc | EXPLAIN (verbose, costs off) DELETE FROM ft2 WHERE c1 % 10 = 6 AND c1 < 40 RETURNING old.c1, c4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b6db84aaaa65680fe040fd76 | EXPLAIN (COSTS OFF) SELECT * FROM rescan_bhs t1 LEFT JOIN rescan_bhs t2 ON t1.a IN (SELECT a FROM rescan_bhs t3 WHERE t2.a > 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b7479062a19843710202b461 | EXPLAIN (COSTS OFF) SELECT 1 UNION SELECT 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b93a1770650c0d729a3ab557 | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND (j1.a = 1 OR j2.a = 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b978d5bceff51ae1c6cd0fe8 | EXPLAIN (COSTS OFF) SELECT t1.a, t1.c, t2.b, t2.c FROM prt1_l t1, prt2_l t2 WHERE t1.a = t2.a AND t1.a = t2.b AND t1.c = t2.c ORDER BY t1.a, t2.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | b9fbd4f4fa73b261979d685b | explain (analyze, costs off, summary off, timing off, buffers off) select * from stable_qual_pruning where a = any(array['2000-02-01', '2010-01-01']::timestamptz[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ba09615cbf79aa024db6191f | EXPLAIN (COSTS OFF) SELECT * FROM onek WHERE unique1 IN (VALUES(10000), (2), (389), (1000), (2000), (10029)) ORDER BY unique1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ba637ba01d94e3a58e5d9890 | EXPLAIN (COSTS OFF) SELECT count(*) FROM tenk1 WHERE thousand = 42 AND (tenthous = 1 OR tenthous = 3) OR thousand = 41 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | bbc4b03a2d9b629c179b7943 | -- -- Test VALUES to ARRAY (VtA) transformation -- -- VtA transformation for joined VALUES is not supported EXPLAIN (COSTS OFF) SELECT * FROM onek, (VALUES('RFAAAA'), ('VJAAAA')) AS v (i) WHERE one... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | bc36734ca230eb45b75198b7 | EXPLAIN (COSTS OFF) SELECT count(*) FROM tenk1 WHERE hundred = 42 AND (thousand = 42 OR thousand = 41 OR thousand = 99 AND tenthous = 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | bc9fe026091f85218cb11657 | explain (analyze, costs off, summary off, timing off, buffers off) select * from tbl1 inner join tprt on tbl1.col1 > tprt.col1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | bcc7d786cdbc2f74ec9bf31b | -- -- Forwards scan RowCompare qual whose row arg has a NULL that affects our -- initial positioning strategy -- explain (costs off) SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE (pr... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | bd08327d9850fd9637f4474d | explain (costs off) select * from tuplesest_tab join (select b from tuplesest_parted where c < 100 group by b) sub on tuplesest_tab.a = sub.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | bdec2925c7e7e4c41a9f1a01 | explain (costs off) select a, b from t_opf group by a, b order by b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | be086d05920e521440d4e4cd | explain (costs off) select 1 from (sk k1 join sk k2 on k1.a = k2.a) join (sj j1 join sj j2 on j1.a = j2.a) on j1.b = k1.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | becfe3fda3940e959619966f | EXPLAIN (COSTS OFF) VALUES (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | bf49bb2be8e135fa24649921 | -- test pushdown of degenerate HAVING clause explain (costs off) select count(*) from gstest2 group by grouping sets (()) having false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c0cb4f2234654c9f60c0d263 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) DECLARE foocur CURSOR FOR SELECT * FROM stats_track_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c22e475d8a7dbc3b9703b318 | EXPLAIN (COSTS OFF) MERGE INTO stats_track_tab USING (SELECT id FROM generate_series(1, 10) id) ON x = id WHEN MATCHED THEN UPDATE SET x = id WHEN NOT MATCHED THEN INSERT (x) VALUES (id) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c2eda5eaa689ac126aa28549 | explain (analyze, costs off, summary off, timing off, buffers off) execute ab_q1 (2, 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c30b0a00609eb3e69cca0e31 | explain (costs off) select a, b, row_number() over (order by a, b nulls first) from (values (1, 1), (2, 2)) as t (a, b) where a = b group by grouping sets((a, b), (a)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c4623be16f47627af121ec53 | EXPLAIN (COSTS OFF) (TABLE test_table) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c4e988037c46291cb79cff23 | explain (analyze, costs off, summary off, timing off, buffers off) execute q1 (2,2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c5077e3d9ac2530d18691bb3 | explain (costs off) select 1 as one group by rollup(one) order by one nulls first |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c5568b651abddb535107e691 | -- Only the unpruned partition should be shown in the list of relations to be -- updated explain (verbose, costs off) execute update_part_abc_view (1, 'd') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c5bb0f785c41be1ec0ed020c | -- Same with GROUP BY EXPLAIN (VERBOSE, COSTS OFF) SELECT * FROM test1cs t1, (SELECT x FROM test3cs GROUP BY x) t2 WHERE t1.x = t2.x COLLATE case_insensitive ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c66c9e4015cf139753459f35 | explain (costs off) SELECT unique1 FROM tenk1 WHERE (thousand, tenthous) > (NULL, 5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c6c64acb8c1ba51a06d27f57 | explain (costs off) SELECT id FROM btree_tall_tbl WHERE id = 55 ORDER BY t DESC, id DESC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c70f6e1d49501f74701b3cc6 | -- All pruned. explain (costs off) merge into part_abc_view pt using (select stable_one() + 2 as pid) as q join part_abc_1 pt1 on (q.pid = pt1.a) on pt.a = pt1.a when matched then delete returning ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c75bd1e5dd85cbe5e03a0050 | EXPLAIN (COSTS OFF) WITH a AS (SELECT 4) DELETE FROM stats_track_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c7de71f7b1f26a3ecd2633a2 | explain (costs off) select * from tenk1 t1 where exists (select 1 from tenk1 t2 where fivethous = t1.fivethous) and t1.fivethous < 5 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c889023b1c433ee22ecec6da | EXPLAIN (ANALYZE, TIMING OFF, COSTS OFF, SUMMARY OFF, BUFFERS OFF) SELECT * FROM brin_timestamp_test WHERE a = '1900-01-01'::timestamp |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c8b680829e344613811a5782 | -- Both partitions allowed by IN clause, but one disallowed by <> clause explain (analyze, costs off, summary off, timing off, buffers off) execute q1 (1,2,2,0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c938047eecf01d4660856bd5 | EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3cs GROUP BY x HAVING x = 'abc' COLLATE case_insensitive ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | caac259341ab413259a5a71f | -- -- check that an upper-level qual is not pushed down if it references a grouped -- Var whose underlying expression contains SRFs -- explain (verbose, costs off) select * from (select generate_se... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | cb285c74eb8e90a9370006b5 | explain (costs off) merge into part_abc_view pt using (select stable_one() as pid) as q join part_abc_1 pt1 on (q.pid = pt1.a) on pt.a = pt1.a when matched then delete returning pt.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | cb507ad3e47de1b5d313bff1 | explain (costs off) select * from int8_tbl intersect select q2, q1 from int8_tbl order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | cba34864cdd2399d53ebdc23 | -- Mixed AND: conflicting clause stays in HAVING, safe clause pushed to WHERE EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING x = 'abc' COLLATE case_sensitive AND length(x) > 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | cc3ad79b534c9975306b1408 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) SELECT * FROM local_tbl, async_pt WHERE local_tbl.a = async_pt.a AND local_tbl.c = 'bar' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | cc86a7362fd4277a6566ddb0 | EXPLAIN (COSTS OFF) SELECT 1 AS c1 FROM sl sl1 LEFT JOIN (sl AS sl2 NATURAL JOIN sl AS sl3) ON sl2.bool_col LEFT JOIN sl AS sl4 ON sl2.bool_col |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | cc89c2d55dbb35a9cac9a832 | EXPLAIN (COSTS OFF) SELECT COUNT(*) FROM guid1 WHERE guid_field <= '22222222-2222-2222-2222-222222222222' OR guid_field <= '11111111111111111111111111111111' OR guid_field <= '3f3e3c3b-3a30-3938-37... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ccc725dc91ec9645ae76ed54 | -- ScalarArrayOpExpr: IN clause with PHV-wrapped operand explain (costs off) select * from (select a, b from phv_part) t where a in (1, null) group by grouping sets (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ce7b29595cd357d3d5cfb9e8 | EXPLAIN (COSTS OFF) SELECT DISTINCT ON (y, x) x, y FROM (select * from distinct_on_tbl order by x, z, y) s ORDER BY y, x, z |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | cee78d80b72501604a18ae8c | EXPLAIN (COSTS OFF) CREATE TEMPORARY TABLE pgss_explain_ctas AS SELECT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | cf5a9945a2b063b801647e59 | explain (costs off) select * from sj x join sj y on x.a = y.a left join int8_tbl z on x.a = z.q1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d0242ae95eee77e85598f2ba | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) SELECT * FROM async_pt t1 WHERE t1.b === 505 LIMIT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d09f61d88f287970e4a7fc3b | EXPLAIN (COSTS OFF) SELECT count(*) FROM tenk1 WHERE hundred = 42 AND (thousand = 42 OR thousand = 99 OR tenthous < 2) OR thousand = 41 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d11c332852a1c04fb31a1874 | EXPLAIN (COSTS OFF) SELECT FROM sb_1 LEFT JOIN sb_2 ON (sb_2.x=sb_1.x) AND (sb_1.x=sb_2.x) AND (sb_1.y=sb_2.y) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d2cf51c39798d5db2020faeb | EXPLAIN (COSTS OFF) SELECT t1.c, count(t2.c) FROM pagg_tab3 t1 JOIN pagg_tab4 t2 ON t1.c = t2.c AND t1.c = t2.b GROUP BY 1 ORDER BY t1.c COLLATE "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d3447fcbda4e528920171632 | EXPLAIN (COSTS OFF) SELECT DISTINCT y, x FROM distinct_tbl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d3b3f59df84102c43baef36e | EXPLAIN (COSTS OFF) SELECT count(*) FROM tenk1, tenk2 WHERE tenk1.hundred = 42 AND (tenk2.thousand = 42 OR tenk1.thousand = 41 OR tenk2.tenthous = 2) AND tenk2.hundred = tenk1.hundred |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d47d62967c41dc56e196b387 | EXPLAIN (COSTS OFF) TABLE stats_track_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d494fc41cd54e8f3bdf74952 | -- Recursive evaluation of constant queries is not yet supported EXPLAIN (COSTS OFF) SELECT * FROM onek WHERE unique1 IN (SELECT x * x FROM (VALUES(1200), (1)) AS x(x)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d4b082a7795e465458a7f337 | EXPLAIN (COSTS OFF) DELETE FROM stats_track_tab WHERE x = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d4b74b36af72a4dc721a6404 | explain (costs off) select * from sj p where exists (select * from sj q where q.a = p.a and q.b < 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d521896b16cecdf75ef0d26d | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = (EXTRACT(DOW FROM current_timestamp(0))/15 + 3)::int AND (EXTRACT(DOW FROM current_timestamp(0))/15 + 3)::int = j2.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d59fe512f35b79bba4c17e1f | -- test handling of expressions that should match lower target items explain (costs off) select a < b and b < 3 from (values (1, 2)) t(a, b) group by rollup(a < b and b < 3) having a < b and b < 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d5c7b734e8b24c3003c3abdb | EXPLAIN (ANALYZE, TIMING OFF, COSTS OFF, SUMMARY OFF, BUFFERS OFF) SELECT * FROM brin_timestamp_test WHERE a = '2023-01-01'::timestamp |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d5e0442dd910e4d0d4b8062d | explain (costs off) select * from sl t1, sl t2 where t1.a = t2.a and t1.b = 1 and t2.b = 2 and t1.c IS NOT NULL and t2.c IS NOT NULL and t2.b IS NOT NULL and t1.b IS NOT NULL and t1.a IS NOT NULL a... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d705c78857ea386ab013c77f | EXPLAIN (COSTS OFF) SELECT * FROM pht1 p1 JOIN pht1 p2 USING (c) LIMIT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d7c634aece4dc82026139b8a | -- comparison against a stable value requires run-time pruning explain (analyze, costs off, summary off, timing off, buffers off) select * from stable_qual_pruning where a < localtimestamp |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | d9beeb646d879bd1ba7f13e9 | EXPLAIN (COSTS OFF) SELECT COUNT(*) FROM tenk1 WHERE stringu1 = 'TVAAAA' OR stringu1 = 'TVAAAB' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | da25dd4f7b754513584ae4d5 | -- UPDATE has OLD and NEW EXPLAIN (verbose, costs off) UPDATE foo SET f4 = 100 WHERE f1 = 5 RETURNING old.tableoid::regclass, old.ctid, old.*, old, new.tableoid::regclass, new.ctid, new.*, new, old... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | da6078c5e54531a4b9478ec5 | explain (verbose, costs off) select * from int8_tbl i8 inner join (select (select true) as x from int4_tbl i4, lateral (select i4.f1 as y limit 1) ss1 where i4.f1 = 0) ss2 on true right join (selec... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | dc0392622d272de60e87308d | -- timestamp < timestamptz comparison is only stable, not immutable explain (analyze, costs off, summary off, timing off, buffers off) select * from stable_qual_pruning where a < '2000-02-01'::time... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | dc48a80f4a2dc98019609f85 | -- Ensure we don't remove any columns from the GROUP BY for a unique -- index on a NULLable column. explain (costs off) select y,z from t2 group by y,z |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | dc554d95eb445dcf5772d698 | explain (verbose, costs off) select grouping((select t1.v from gstest5 t2 where id = t1.id)), (select t1.v from gstest5 t2 where id = t1.id) as s from gstest5 t1 group by grouping sets(v, s) order ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | dc62a8a2f3f28c5abaf96d8a | explain (verbose, costs off) select * from int8_tbl i8 inner join (select (select true) as x from int4_tbl i4, lateral (select 1 as y limit 1) ss1 where i4.f1 = 0) ss2 on true right join (select fa... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | dc7288c93022b07a26e230c7 | -- Ensure pruning does not take place when the expression contains a Var. explain (analyze, costs off, summary off, timing off, buffers off) select * from list_part where a = list_part_fn(1) + a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | dcfef6a1da7fc1fd442fbbc1 | EXPLAIN (ANALYZE, TIMING OFF, COSTS OFF, SUMMARY OFF, BUFFERS OFF) SELECT * FROM brin_date_test WHERE a = '1900-01-01'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | dd7e50e64816894170c20bb4 | EXPLAIN (COSTS OFF) (VALUES (1, 2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | dd917ce58544b335829bde53 | EXPLAIN (COSTS OFF) SELECT unique1, stringu1 FROM onek WHERE stringu1::name IN (VALUES('RFAAAA'), ('VJAAAA')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | dee96486f27ec5fbf291b4c1 | explain (analyze, costs off, summary off, timing off, buffers off) select * from stable_qual_pruning where a = any(array['2000-02-01', '2010-01-01']::timestamp[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e04ee342645d7b9a5a966b43 | -- Negative: nested CASE with collation conflict EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING (CASE WHEN (CASE x WHEN 'abc' COLLATE case_sensitive THEN 1 ELSE 0 END) = 1 TH... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e09205d2a67d755172242fed | EXPLAIN (DEBUFF) SELECT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e0ec7eef79ed8e45a390a282 | explain (costs off) select * from sl t1, sl t2 where t1.a = t2.a and t1.b = 1 and t2.b = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e14c3b1b8c737e10449934e3 | -- this will do a remote seqscan, causing unstable result order, so sort EXPLAIN (verbose, costs off) WITH cte AS ( UPDATE ft2 SET c3 = 'bar' WHERE postgres_fdw_abs(c1) > 2000 RETURNING * ) SELECT ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e2cfe46690021a315ee3038b | explain (verbose, costs off) select * from gtest32 t group by grouping sets (a, b, c, d, e) having c = 20 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e4cb6124804d74f28c9f31e2 | explain (costs off) select 1 from emp1 full join (select * from emp1 t1 join emp1 t2 join emp1 t3 on t2.id = t3.id on true where false) s on true where false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e50aabddbd96ce3209df982e | EXPLAIN (COSTS OFF) INSERT INTO stats_track_tab VALUES (1), (2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e7e95d77e99acc3c8bd85d37 | explain (analyze, costs off, summary off, timing off, buffers off) select * from mc3p where a < 3 and abs(b) = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e8520ae81308d8fb06164a71 | explain (costs off) select * from tenk1 t1, tenk2 t2 where t1.two > t2.two |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e8c565037b2b2629864cb6fe | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) SELECT * FROM async_pt |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | e9ba788ef4526d8f1af8b61e | EXPLAIN (verbose, costs off) DELETE FROM foo WHERE f1 = 4 RETURNING old.*,new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | eb1daf656f63656be408cff1 | EXPLAIN (COSTS OFF) UPDATE stats_track_tab SET x = 1 WHERE x = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | eb6597633e8cbde93db4eb42 | EXPLAIN (ANALYZE, TIMING OFF, COSTS OFF, SUMMARY OFF, BUFFERS OFF) SELECT * FROM brin_interval_test WHERE a = '-30 years'::interval |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ec3520c7670a25a80650471c | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a*j1.a = 1 AND j2.a*j2.a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ec5283bbd08a0b0d816cc332 | EXPLAIN (COSTS OFF) EXECUTE test(42, 3.14, '-1.5') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ed3f308e7e62db53c07fdf1d | -- Negative: collation conflict inside a RowCompareExpr EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING ROW(x, 1) < ROW('ABC' COLLATE case_sensitive, 1) ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ede5e9ac2bb9243511acb533 | -- lateral references for simple Vars can escape being wrapped if the -- referenced rel is under the same lowest nulling outer join explain (verbose, costs off) select t1.q1, x from int8_tbl t1 lef... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ee036b0bb6574d8bea92ac13 | EXPLAIN (COSTS OFF) SELECT t1.c, count(t2.c) FROM pagg_tab5 t1 JOIN pagg_tab6 t2 ON t1.c = t2.c AND t1.c = t2.b GROUP BY 1 ORDER BY t1.c COLLATE "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ee2e00b71e89d4aa6a728116 | -- NullTest: IS NULL with PHV-wrapped operand explain (costs off) select * from (select a, b from phv_part) t where a is null group by grouping sets (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ef5a525a990a7191c13a4323 | explain (analyze, costs off, summary off, timing off, buffers off) execute mt_q1(15) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ef7944daac862b692193f3c0 | -- -- A unique index under one collation does not prove uniqueness under -- another, so the planner must not use such a proof for any optimization. -- -- Ensure that we do not use inner-unique join... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ef950da004acdc9eca764e70 | explain (costs off) select x, y from (select unique1 as x, unique2 as y from tenk1) as t where x = 1 group by grouping sets (x, y) order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f04b8fc31a8cf02273dc34ab | explain (verbose, costs off) select t1.a, s.a from t_append t1 left join t_append t2 on t1.a = t2.b join lateral ( select t1.a as a union all select t2.a as a ) s on true where s.a is not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f10edd3eb30860e998f2b5e6 | explain (costs off) SELECT q.val FROM b LEFT JOIN ( SELECT (q1.z IS NOT NULL) AS val FROM b LEFT JOIN ( SELECT (t1.b_id IS NOT NULL) AS z FROM a t1 LEFT JOIN a t2 USING (id) ) AS q1 ON true ) AS q ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f258bda23606224c55141db4 | EXPLAIN (VERBOSE, COSTS OFF) SELECT * FROM emp1 e1, emp1 e2 WHERE e1.id = e2.id AND e2.code <> e1.code |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f2ca901eb74310508121870a | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND 2 = j2.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f32b9fc1a65d8f8460b8f0c9 | explain (costs off) select a, b, count(*) from gstest2 group by rollup(a), b having b > 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f3561c58a291e09e2c0d47b5 | -- During hash join estimation, the number of distinct values on each column -- is calculated. The optimizer selects the smallest number of distinct values -- and the largest hash bucket size. The ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f35c486d2b2249699b1be68f | -- Ensure that the generation expressions are wrapped into PHVs if needed explain (verbose, costs off) select t2.* from gtest32 t1 left join gtest32 t2 on false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f3a3e7c9301536b6d730ea04 | -- strict expressions containing variables of rels under the same lowest -- nulling outer join can escape being wrapped explain (verbose, costs off) select t1.q1, x from int8_tbl t1 left join (int8... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f42167da48dd3eaf50021331 | -- Ensure output list looks sane when the MergeAppend has no subplans. explain (analyze, verbose, costs off, summary off, timing off, buffers off) execute mt_q2 (35) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f432930c671d1163ab2f86c3 | EXPLAIN (COSTS OFF) SELECT * FROM (SELECT n2.a FROM sj n1, sj n2 WHERE n1.a <> n2.a) q0, sl WHERE q0.a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f4888f16f9d14ed26e620085 | explain (analyze, costs off, summary off, timing off, buffers off) select * from tbl1 join tprt on tbl1.col1 < tprt.col1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f548a367b250370002fd6a5e | EXPLAIN (COSTS OFF) SELECT * FROM pht1 p1 JOIN pht1 p2 USING (c) LIMIT 100 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f5b04b789ec7c2accec37b27 | explain (analyze, costs off, summary off, timing off, buffers off) execute q1 (1,1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f633167e0e326bd041f8bbe4 | explain (costs off) SELECT unique1 FROM tenk1 WHERE unique1 = ANY('{NULL,NULL,NULL}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f66be201bd3df19e4c901268 | explain (analyze, costs off, summary off, timing off, buffers off) execute ps1(1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f7d1fbaee85f47fa92903d4a | EXPLAIN (COSTS OFF) SELECT * FROM rls_tbl WHERE a <<< 1000 or a <<< 900 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f80b67ca8dbd0d2212aad254 | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND (j1.a*j1.c/3) = (random()/3 + 3)::int AND (random()/3 + 3)::int = (j2.a*j2.c/3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | f816ff6be05305f1ceef62c3 | EXPLAIN (COSTS OFF) -- Should use NestLoop with parameterised inner scan SELECT x.id, y.id FROM fract_t x LEFT JOIN fract_t y USING (id) ORDER BY x.id DESC LIMIT 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fa18931d6f4468068c95c019 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) SELECT 100 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fa246bd3bb2f44d091060a58 | explain (analyze, costs off, summary off, timing off, buffers off) execute ab_q1 (2, 2, 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fb5d86a8361634f761577332 | EXPLAIN (COSTS OFF) SELECT * FROM tenk1 WHERE thousand = 42 AND (tenthous = 1 OR tenthous = (SELECT 1 + 2) OR tenthous = 42) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fc490862a19c43be04438744 | explain (costs off) select * from sj t1, sj t2 where t1.a = t2.c and t1.b is not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fc6ab7b45dd32790fcc5c63a | EXPLAIN (COSTS OFF) SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = 1 AND j2.a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fd47eae64c6603b215dfae19 | -- -- Add coverage of RowCompare quals whose row omits a column ("proargtypes") -- that's after the first column, but before the final column. The scan's -- initial positioning strategy must become... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fdfb3ee06a7fddee9d5df5d4 | -- Positive: same collation, safe to push HAVING to WHERE EXPLAIN (COSTS OFF) SELECT x, count(*) FROM test3ci GROUP BY x HAVING x = 'abc' COLLATE case_insensitive |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fe37392654fbd854cace4c5e | EXPLAIN (VERBOSE, COSTS OFF) SELECT * FROM ft1, ft4, ft5, local_tbl WHERE ft1.c1 = ft4.c1 AND ft1.c1 = ft5.c1 AND ft1.c2 = local_tbl.c1 AND ft1.c1 < 100 AND ft5.c1 < 100 FOR UPDATE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | fee2d79a456d4e80628f08d7 | -- Ensure that semijoin is not reduced to innerjoin EXPLAIN (COSTS OFF) SELECT * FROM test3cs t1 WHERE EXISTS (SELECT 1 FROM test3cs t2 WHERE t1.x = t2.x COLLATE case_insensitive) ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_EXPLAIN_STMT | ff2dd42b05fe8b64a34be476 | -- Ensure that self-join is not removed EXPLAIN (COSTS OFF) SELECT * FROM test3cs t1, test3cs t2 WHERE t1.x = t2.x COLLATE case_insensitive ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_FETCH_STMT | 17b025ad4e32510c4bf792c7 | FETCH NEXT FROM c_3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_FETCH_STMT | 580b262e7bee7a1c58b7e21b | FETCH FORWARD 1 FROM foocur |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_FETCH_STMT | cad17b750ecb2c2bac84f646 | fetch 1 from curs |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_ROLE_STMT | 1339d57dbe34a3da19acc554 | GRANT pg_read_server_files TO regress_pg_logicalinspect |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_ROLE_STMT | 35295f14c0cf8428beb01dfa | GRANT regress_current_user TO regress_authenticated_user_db_sr |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_ROLE_STMT | 44ec1922891e8a99d7c25ba9 | GRANT pg_read_all_stats TO regress_stats_user2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_ROLE_STMT | d6a08ca4b19b16bf27c1dd18 | GRANT regress_session_user TO regress_authenticated_user_db_ssa |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 04e09dfa474ec205c5899fb5 | REVOKE EXECUTE ON FUNCTION pg_get_aios() FROM PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 0e3a46412c18c3a0953a7722 | -- Don't want these to be available to public. REVOKE ALL ON FUNCTION pg_buffercache_numa_pages() FROM PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 126a417578caaed12ee102f6 | REVOKE EXECUTE ON FUNCTION pg_get_logical_snapshot_info(text) FROM PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 17b72f198d2bc906bc589535 | REVOKE EXECUTE ON FUNCTION pg_stat_have_stats(text, oid, int8) FROM public |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 27b180b250e18a132ead5225 | GRANT EXECUTE ON FUNCTION pg_get_logical_snapshot_info(text) TO pg_read_server_files |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 2ba7f58c2a438263134e0931 | GRANT EXECUTE ON FUNCTION pg_buffercache_numa_pages() TO pg_monitor |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 2ebfe074ef2e032aa86e9806 | GRANT SELECT (a, c), INSERT ON gtest12 TO regress_user11 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 325c5e3b58ecee3a06d20e88 | REVOKE ALL ON FUNCTION gin_index_check(regclass) FROM PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 3ab5660d04d74f6d8784e671 | GRANT SELECT ON pg_shmem_allocations_numa TO pg_read_all_stats |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 3d4f6e6b27c4bbad27ad5b12 | REVOKE EXECUTE ON FUNCTION pg_ls_summariesdir() FROM public |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 4779c74dcbe5c5b0126e7e41 | REVOKE EXECUTE ON FUNCTION pg_get_shmem_allocations_numa() FROM PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 49e792a10ab0378563d16272 | REVOKE EXECUTE ON FUNCTION pg_stat_reset_backend_stats(integer) FROM public |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 4ca61769e9460e0c7c1089ab | GRANT SELECT (a, c) ON gtest11 TO regress_user11 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 6ade9ea6a36a2de7182568fa | grant select on rls_t to regress_rls_alice |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 6d7e24f7312ec4ba7804d431 | REVOKE ALL ON pg_shmem_allocations_numa FROM PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 75c060b883ec6cc67b55f5c7 | GRANT SELECT, UPDATE ON grantor_test3 TO regress_grantor2 WITH GRANT OPTION |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 888ceb21fe29611bd3261d78 | GRANT SELECT, UPDATE ON grantor_test1 TO regress_grantor3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 9998e396c47fe0b7fe83231c | GRANT SELECT ON pg_buffercache_numa TO pg_monitor |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | 9c7ed694375233b3042b22e4 | REVOKE EXECUTE ON FUNCTION pg_get_logical_snapshot_meta(text) FROM PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | a32b11615c5960a512b91f90 | GRANT SELECT, UPDATE ON grantor_test3 TO regress_grantor3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | b353048c499a149885de3e67 | GRANT USAGE ON SCHEMA generated_virtual_tests TO PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | bf077282e7148817e0a033b6 | REVOKE ALL ON pg_buffercache_numa FROM PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | caf6592e1e89480fadb5a489 | grant create on schema mr_sch to regress_mr |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | cc5594715a39f90046d06939 | GRANT EXECUTE ON FUNCTION pg_get_logical_snapshot_meta(text) TO pg_read_server_files |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | d2f601badd0a61d7e7dc27b4 | grant insert on defer_trig to public |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | d7f721f2c4ce266d2ee524ef | GRANT EXECUTE ON FUNCTION pg_get_aios() TO pg_read_all_stats |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | da91e35b6ea35eb1971ddb58 | GRANT EXECUTE ON FUNCTION pg_ls_summariesdir() TO pg_monitor |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | e001dea684d064156b76e25d | GRANT SELECT ON grantor_test2 TO regress_grantor1 WITH GRANT OPTION |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | e4a38bd6860d2a5e0c8fa9d7 | GRANT USAGE ON SCHEMA generated_stored_tests TO PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | ee5a4580257ac8fc812f3659 | GRANT SELECT, UPDATE ON grantor_test2 TO regress_grantor3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | f134a68ada04b15cb5c42a4d | grant select on test_t to regress_rls_alice |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | f9ca80f7b80f3466adfb038b | GRANT SELECT ON pg_aios TO pg_read_all_stats |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | fc00215e4b8a5de02b1525c6 | REVOKE ALL ON pg_aios FROM PUBLIC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_GRANT_STMT | ffa6b7ec4ebcde3d436b1e17 | GRANT EXECUTE ON FUNCTION pg_get_shmem_allocations_numa() TO pg_read_all_stats |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 084df11debcf52c986aea00d | create unique index cnn_uq_idx on cnn_uq (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 0fc82f0c35013c3186cc011b | CREATE INDEX hash_i4_partial_index ON hash_i4_heap USING hash (seqno) WHERE seqno = 9999 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 106b5e2ac763ed8e283b6619 | CREATE INDEX part_parent_i ON stats_import.part_parent(i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 108f19ee4d3f79df55972500 | CREATE INDEX brintest_expr_idx ON brintest_expr USING brin (brintest_func()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 10d1bfcbb375f86adbbf060f | create index concurrently on idxpart1 ((a/b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 14ebb7cd58c9842114e5e589 | CREATE INDEX idx_temporal3_uq ON temporal3 USING gist (id, valid_at) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 1a664b3eb0cfa1386b744871 | create index on sk(a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 20daa49ca0d3ed1b9a8e9e94 | CREATE INDEX gin_check_text_array_idx on "gin_check_text_array" USING GIN("Column1") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 22d437086149ab88d6b71ddd | create unique index on sl(a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 2bf04ad7802981c3151980a5 | CREATE INDEX ctl_table_a_key ON ctl_table(a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 33d8c2fa31594212ccd23384 | CREATE INDEX t_b_c_idx ON bitmap_split_or (b, c) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 34b4b50a12dca2c76f071826 | CREATE INDEX distinct_tbl_x_y_idx ON distinct_tbl (x, y) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 472e442f6f9dd0eee44076d2 | CREATE UNIQUE INDEX testpub_gencol_idx ON testpub_gencol (b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 4dd849c979f3b0cee01d9e9d | CREATE INDEX "gin_check_jsonb_idx" on gin_check_jsonb USING GIN("j" jsonb_path_ops) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 4de14243885c7442ad436e30 | CREATE UNIQUE INDEX sj_temp_idx1 ON sj(a,b,c) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 4e1ac8ddb14cff27c5e325e8 | CREATE INDEX ON rescan_bhs (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 50e9caadf39e4e8c956c54b4 | CREATE INDEX gin_check_idx on "gin_check" USING GIN("Column1") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 53dc7153073d7009e45e4b8d | create unique index t2_z_uidx on t2(z) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 5b10067084affc7ecb2f4c12 | create index on only idxpart1 ((a/b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 5b9317aeb3dbca21057300c5 | CREATE UNIQUE INDEX sj_temp_idx ON sj(a,b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 5bbd48a362366fbc20ee08cc | CREATE INDEX pht1_c_idx ON pht1(c) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 60ba0bbd8d3c7939587d2174 | CREATE INDEX t_b_partial_2_idx ON bitmap_split_or (b) WHERE a = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 619e925c79428376efb70ce4 | CREATE UNIQUE INDEX test_replica_identity5_a_b_key ON test_replica_identity5 (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 633c2af48a590b35e361da76 | CREATE INDEX "gin_check_multicolumn_idx" on gin_check_multicolumn USING GIN(a,b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 6b5fcb9b6eeaa717c14f6533 | CREATE UNIQUE INDEX ON groupby_collation_t (a COLLATE "C") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 73db8b12498062efa1de91ca | CREATE INDEX tbl_phv_idx ON tbl_phv(x) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 8bc5a3d1c83fea657660a49d | CREATE INDEX is_odd_clone ON stats_import.test_clone(((comp).a % 2 = 1)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 8e02f9145a72d2cb9e10948c | create index concurrently on idxpart11 ((a/b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 91611c2f5f8391c6a7f3cc3b | CREATE UNIQUE INDEX ON sj_t2 USING btree (id) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | 9b8ddb637ce86006cc45b948 | CREATE INDEX ON vegetables (id) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | a367d128b9fd52d0d83fd95a | CREATE INDEX distinct_on_tbl_x_y_idx ON distinct_on_tbl (x, y) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | a490a7078dcadef4e3fc1e4e | CREATE UNIQUE INDEX idx_temporal3_uq ON temporal3 (id, valid_at) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | a64842d9dde103df34dbce3e | CREATE UNIQUE INDEX ON emp1((id*id)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | aa63cd33989f7693105b6245 | CREATE INDEX test_i ON stats_import.test(id) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | aed1cf50f18edaa361ec1f1d | create unique index t2_z_uidx on t2(z) nulls not distinct |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | b3fb55957cdb3cabb8d78de4 | CREATE INDEX CONCURRENTLY jidx ON testjsonb USING gin (j jsonb_path_ops) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | bdd1db69e7471718ef5fe17f | CREATE INDEX idx_test_is_flag ON tab_with_flag (is_flag) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | be0abc57f1bbf3ddea5179db | -- create parent indexes create index on only idxpart ((a/b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | c9c80b982fcec7d495fe0c91 | CREATE INDEX t_b_partial_1_idx ON bitmap_split_or (b) WHERE a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | cb1966fbe8fe869d6837dd3d | CREATE UNIQUE INDEX cnn_uq ON cnn_pk (b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | cc672d4e4f687eeea4c6014f | create index t2_z_uidx on t2 (z) where z > 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | cdc64c8f20b7cf626a55ff6a | -- INSERT ... ON CONFLICT ... UPDATE has OLD and NEW CREATE UNIQUE INDEX foo_f1_idx ON foo (f1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | ddd7718be3126dbccec29626 | CREATE UNIQUE INDEX sj_fn_idx ON sj((a * a)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | e27c217120c9007f010d7e23 | CREATE INDEX is_odd ON stats_import.test(((comp).a % 2 = 1)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | e79b480b555acffe08649c87 | create unique index on t_opf (a record_image_ops) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | e972a61ec70d0fa6b13ecf48 | create index on only idxpart2 ((a/b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | f0de1fad6b58d8157921a918 | create index concurrently on idxpart2 ((a/b)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | f761cea9ea5a3e2fcdef0886 | CREATE UNIQUE INDEX ON sj_t3 USING btree (a,id) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | f8ec5cc11452dbae93b58bf7 | CREATE INDEX t_a_b_idx ON bitmap_split_or (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | f946cb670288705837f9389b | -- A case with nested MergeAppend with its own PartitionPruneInfo. create index on part_abc (a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INDEX_STMT | fe776dad4259e622a5d7a367 | CREATE INDEX btree_test_expr_idx ON btree_test_expr USING btree (btree_test_func()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 00a792d3d5656cfe3600b36d | INSERT INTO r1 VALUES (1), (2), (4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 02acea6bf9784633e6e36b9d | -- date matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 031ed5ebe8ef97dae47d32a7 | insert into phv_part values (1, 'one'), (2, 'two'), (null, 'null') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 037fec4b3ed3ee77d4b788bb | -- overlaps INSERT INTO temporal_rng4 VALUES ('[1,2)', '[1,13)'), ('[1,2)', '[20,23)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 039cdb8829453da69c397047 | -- ok INSERT INTO gtest21b (a) VALUES (2), (0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 03b759ef7c02fb40bbf42006 | INSERT INTO gtest24r (a) VALUES (4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 05233b910f26aa21d5560f5f | INSERT INTO temporal_partitioned_mltrng (id, valid_at) VALUES ('[5,6)', datemultirange(daterange('2018-02-01', '2018-03-01'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 0566c327725a9ca455093afc | -- error -- test not-null checking during table rewrite INSERT INTO gtest27 (a, b) VALUES (NULL, NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 064c0d4111525af53f7ca870 | INSERT INTO temporal_rng (id, valid_at) VALUES ('[2,3)', daterange('2018-01-01', '2018-01-05')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 094fe4ff6f3bd06bd473477f | -- date matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT ON CONSTRAINT temporal_rng_pk DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 09b9015ab09c2201aef14830 | insert into my_table values (42) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 0a8d5a52ff6b08e1874bc338 | insert into tuplesest_parted select i%200, i%300, i%400 from generate_series(1, 1000)i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 0af867e8bf72634c3b6975e0 | INSERT INTO foo VALUES (4, 'conflict'), (5, 'ok') ON CONFLICT (f1) DO UPDATE SET f2 = excluded.f2\|\|'ed', f3 = -1 RETURNING WITH (OLD AS o, NEW AS n) o.tableoid::regclass, o.ctid, o.*, n.tableoid::r... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 0b6f4dc8c1d91e44a0f0c75a | INSERT INTO temporal_partitioned_fk_rng2rng (id, valid_at, parent_id) VALUES ('[3,4)', daterange('2000-01-01', '2000-02-15'), '[3,4)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 0ca3c06543d27065a1ff0c85 | -- same key, doesn't overlap: INSERT INTO temporal_rng VALUES (1, '[2001-01-01,2002-01-01)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 0ec895da749dc0be78347432 | -- with a conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng3_uq DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 0f6adc996c3f8f77711d39fb | insert into gtest34p values (1, 7) on conflict (id) do update set a = excluded.c returning * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 0ff5b046bb005213a18a9ee9 | -- Should fail p1 INSERT INTO r1 VALUES (0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 100675b885975b4b2de7f7d6 | -- id matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT ON CONSTRAINT temporal3_uq DO UPDATE SET id = EXCLUDED.id + '[... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1014e579086305953cbbfc25 | INSERT INTO pxtest_rowlock VALUES (1, 'test data') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 10468fc03b79f1b895612fac | INSERT INTO temporal_partitioned_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[3,4)', datemultirange(daterange('2000-01-01', '2000-02-15')), '[3,4)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 106dd52d83bae5eb21014218 | -- with a conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT ON CONSTRAINT temporal3_uq DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 10c431142d79dd6862c70e54 | -- check the error messages INSERT INTO gtestnn_parent VALUES (2, 2, default), (3, 5, default), (14, 12, default) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 11ef7f31285b7097c013de86 | -- now it should work: INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2018-02-03', '2018-03-03'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 11f657316fa47772381096d5 | INSERT INTO temporal_partitioned_rng (id, valid_at) VALUES ('[5,6)', daterange('2016-01-01', '2016-02-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 121b9792b026891f4c3ffed7 | INSERT INTO temporal_partitioned_rng (id, valid_at, name) VALUES ('[1,2)', daterange('2000-01-01', '2000-02-01'), 'one'), ('[1,2)', daterange('2000-02-01', '2000-03-01'), 'one'), ('[2,3)', daterang... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 12bdbf8f072df9a4132f3e7f | -- (1.0) and (1.00) are bytewise distinct but logically equal as records; -- the index admits both, but GROUP BY a (default record_ops) would merge -- them, so b must be retained as a grouping key.... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1494fd76bbf285b8adcc54ff | INSERT INTO foo DEFAULT VALUES RETURNING WITH (old AS x, new AS x) * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 17af1678f0f00b7e5d0cb3f8 | insert into gtest34 values (1, 5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 19931ed6241e203e6d3116af | -- id matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng3_uq DO NO... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 19f1ea57a4b6bcfb4ce49f57 | -- violates domain INSERT INTO temporal_rng4 VALUES ('[1,2)', '[1,13)'), ('[1,2)', '[2,13)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1aeb095a748f2dec3ed9f34a | -- a PK update shrinking the referenced range but still valid: -- There are two references: one fulfilled by the first pk row, -- the other fulfilled by both pk rows combined. INSERT INTO temporal_... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1ce27df81ac99a7d9cde12fe | -- id matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1cf6b6f0486f4408d23ba7df | INSERT INTO gtest21ax (a) VALUES (0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1e59094035930d5367d3a00a | insert into aitest values (1, 1, null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1e5cd04ab9f0eed0c290d207 | -- ok INSERT INTO gtest24r (a) VALUES (6) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1e66d67b2d5a54c87d41e18d | insert into tuplesest_tab select i, i from generate_series(1, 100)i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1f2ea85f187f319a8e427044 | INSERT INTO foo_parted VALUES (1, 17.1, 'P1'), (2, 17.2, 'P2'), (3, 17.3, 'P3'), (4, 17.4, 'P4') RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 1f7bbe29b2bcf4800a53c451 | INSERT INTO temporal_rng (id, valid_at) VALUES ('[3,4)', NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 20abe55bb9eb1deff7ee7aaf | -- id matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 21788c2ebfcbf208e0d59fd6 | -- okay: INSERT INTO temporal_rng3 (id, valid_at) VALUES ('[1,2)', daterange('2018-01-02', '2018-02-03')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 21991ac693f393d3f53113a9 | -- date matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXC... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 21f47f476c3d85a6cd05211f | insert into part_abc values (2, 'c', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 22459e16e401eb8f992f98bc | insert into p values (1, 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 23cbd4100abccff88ed00c2e | insert into gtest34 values (1, 3) on conflict (id) do update set a = 999 where excluded.c > 20 returning * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 2721a8faa792e31ceac71375 | INSERT INTO temporal_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[1,2)', datemultirange(daterange('2018-01-15', '2018-02-01')), '[1,2)'), ('[2,3)', datemultirange(daterange('2018-01-15', '2... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 288d49e9690de01de9784cb6 | INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2018-01-01', '2018-01-05')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 28a2a3aa77bc7e79515bc9f1 | -- okay spanning two parent records: INSERT INTO temporal_fk_rng2rng VALUES (2, '[2000-01-01,2002-01-01)', 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 28d375a10f0d6bc4cb9e30da | insert into t_append values (2, 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 2abf1c54bb8862fced9f03f5 | -- overlaps but different key: INSERT INTO temporal_rng VALUES (2, '[2000-01-01,2001-01-01)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 2c7c03bfbb8654665cbba925 | -- id matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 2d75b75b74c150536d97ebb4 | -- with a conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLUDED.id + '[2,3)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 2e0a97d958ba05f9ace27a9c | -- same string in different normal forms INSERT INTO test6 VALUES (1, U&'zy\\00E4bc') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 2e9ca933c994943b140b7519 | -- a PK update that loses time from both ends, but is still valid: INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2018-01-01', '2018-03-01'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 305317c7b01de61017e8e22f | INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2018-01-02', '2018-02-03'))), ('[1,2)', datemultirange(daterange('2018-03-03', '2018-04-04'))), ('[2,3)', datem... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 309bbbea5c0ea179661de319 | -- okay INSERT INTO temporal_fk_rng2rng VALUES (1, '[2000-01-01,2001-01-01)', 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 30ec6cc50bbb88e69acc5880 | -- -- test ON UPDATE/DELETE options -- -- test FK referenced updates CASCADE INSERT INTO temporal_rng (id, valid_at) VALUES ('[6,7)', daterange('2018-01-01', '2021-01-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3213cd996a06d235ae5dc78f | INSERT INTO temporal_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[5,6)', datemultirange(daterange('2018-01-15', '2018-02-01')), '[2,3)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 32599444de808c7a351f8164 | insert into idxpart2 values (501, 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 33fe7c21973c8f117332b2d4 | INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[3,4)', NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 35eb438248307602a887f6f0 | -- date matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT ON CONSTRAINT temporal_rng_pk DO UPDATE SET id = EXCLUDED... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 36d4988cbed3f07817d6678b | -- A PK update sliding the edge between two referenced rows: INSERT INTO temporal_rng (id, valid_at) VALUES ('[6,7)', daterange('2018-01-01', '2018-02-01')), ('[6,7)', daterange('2018-02-01', '2018... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 37275d2afd6cc99f5696920f | INSERT INTO test_pg_c_utf8 VALUES ('abc DEF 123abc'), ('ábc sßs ßss DÉF'), ('ǄxxǄ ǆxxǅ ǅxxǆ'), (U&'Λλ 1a \\FF11a'), ('ȺȺȺ'), ('ⱥⱥⱥ'), ('ⱥȺ') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 396f165443b82ad598ea3b2e | INSERT INTO temporal3 (id, valid_at, id2, name) VALUES ('[1,2)', daterange('2000-01-01', '2010-01-01'), '[7,8)', 'foo'), ('[2,3)', daterange('2000-01-01', '2010-01-01'), '[9,10)', 'bar') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3976ab72a7aac0653cb1ce01 | INSERT INTO temporal_partitioned (id, valid_at, name) VALUES ('[1,2)', daterange('2000-01-01', '2000-02-01'), 'one'), ('[1,2)', daterange('2000-02-01', '2000-03-01'), 'one'), ('[3,4)', daterange('2... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3a0bc8df54702c85426d9932 | INSERT INTO temporal_partitioned_mltrng (id, valid_at) VALUES ('[5,6)', datemultirange(daterange('2018-01-01', '2018-02-01'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3a3245c838733bcae5d0d741 | -- okay INSERT INTO temporal_rng4 VALUES ('[1,2)', '[30,)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3cd82ed80ae63e46de5d85d3 | INSERT INTO distinct_tbl SELECT i%10, i%10 FROM generate_series(1, 1000) AS i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3cf6387fe2e6df69785f4a17 | INSERT INTO temporal_rng (id, valid_at) VALUES ('[12,13)', daterange('2018-01-01', '2021-01-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3d33597b2a8eed130a4b4f2c | -- date matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3dcd0b8f2f644190365afb7d | insert into bytea_test_table values(decode('ffff','hex')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3e8f46cfdeb7795c74efe50b | INSERT INTO guid1 (guid_field) VALUES (uuidv7()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3fba356aa23657a6f310ad8b | -- key is missing INSERT INTO temporal_fk_rng2rng VALUES (3, '[2000-01-01,2001-01-01)', 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 3ffc4ddcb5d49fa70f514b0c | INSERT INTO temporal_rng (id, valid_at) VALUES ('[3,4)', daterange('2018-01-01', NULL)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 40438fa9439ccb921caa7e55 | WITH t4 AS (INSERT INTO id_alw4 DEFAULT VALUES RETURNING i) INSERT INTO id_alw3_view DEFAULT VALUES RETURNING i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 422a374906081e4c71f628ec | -- date matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng_pk DO NO... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4297d328818947a14d8a980e | INSERT INTO gin_check_jsonb values ('{"a":[["b",{"x":1}],["b",{"x":2}]],"c":3}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 42c9d95fec903800b18431e0 | INSERT INTO temporal_fk_rng2rng (id, valid_at, parent_id) VALUES ('[1,2)', daterange('2018-01-02', '2018-02-01'), '[1,2)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4307354f8d877ab9c2d5a247 | -- date matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLUDED.id + '[4,5)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 433015be1c8f03e9480e2e50 | -- id matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT ON CONSTRAINT temporal_rng_pk DO UPDATE SET id = EXCLUDED.i... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4391b02f8543dcc46bb3534b | INSERT INTO temporal_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[4,5)', datemultirange(daterange('2018-01-15', '2018-02-15')), '[6,7)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 439626ebeb9b07a2fe3fb7d4 | INSERT INTO hashagg_ij SELECT g FROM generate_series(1,5100) g |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4437a02148e36facdc5413fa | insert into rls_t values ('a'), ('b'), ('c'), ('d') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4513759c03c1c6854dad7803 | INSERT INTO temporal_fk_rng2rng (id, valid_at, parent_id) VALUES ('[4,5)', daterange('2018-01-01', '2021-01-01'), '[6,7)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 45800ccddc12ea34e158dbf7 | -- id matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLUD... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 467d87882740c7c967882e44 | INSERT INTO guid1 (guid_field) VALUES (uuidv7(INTERVAL '1 day')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 46ad1d5ca8bff7ce15388e7f | INSERT INTO temporal_rng (id, valid_at) VALUES (NULL, daterange('2018-01-01', '2018-01-05')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 47aebd8bfc6b2c2c1cf0e639 | INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2000-01-01', '2010-01-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 47c06270d573e815ca047a5a | INSERT INTO groupby_collation_t VALUES ('foo', 'X'), ('FOO', 'Y') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 48b6870adc735adbc6e78522 | -- date matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4919e9cc9a43d0f4f3b388c0 | -- a PK update shrinking the referenced multirange but still valid: -- There are two references: one fulfilled by the first pk row, -- the other fulfilled by both pk rows combined. INSERT INTO temp... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4963db9ca8ff1d402fbca55e | INSERT INTO bitmap_split_or (SELECT 1, 1, i FROM generate_series(1, 1000) i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4bc1f76c8d1a7c85c6d69db3 | INSERT INTO gtestm (a) SELECT g FROM generate_series(1, 10) g |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4c7c2baa292d26e0d0114942 | INSERT INTO vegetables (name, genus) VALUES ('carrot', 'daucus'), ('bok choy', 'brassica'), ('brocooli', 'brassica'), ('cauliflower', 'brassica'), ('cabbage', 'brassica'), ('kohlrabi', 'brassica'),... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4ce149361bae6a08f8139009 | -- id matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng3_uq DO UP... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4cfbce6e08d0d1cc4a689c01 | -- date matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4d13f771bff2ccc29593f4d9 | INSERT INTO temporal_rng (id, valid_at) VALUES ('[5,6)', daterange('2018-01-01', '2018-02-01')), ('[5,6)', daterange('2018-02-01', '2018-03-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4d9b741ff72d9a2845531b65 | INSERT INTO pt VALUES (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 4f4d855dc1784aa4e86e185c | INSERT INTO notnull_tbl1_3 values(NULL,1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 51b3e8a86e1b08e7a65229e1 | -- date matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng3_uq DO ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5262c75937ffe51b9b5266b7 | -- A PK update sliding the edge between two referenced rows: INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[6,7)', datemultirange(daterange('2018-01-01', '2018-02-01'))), ('[6,7)', datemultir... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5330566387b2d9c67620718d | -- ok INSERT INTO gtestnn_parent VALUES (1, 2, default) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 54ee42535fa948f93589e1d7 | INSERT INTO test12pk VALUES ('abc') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 567a7db3d54c5c440bda8e6f | -- a PK update that loses time from both ends, but is still valid: INSERT INTO temporal_rng (id, valid_at) VALUES ('[2,3)', daterange('2018-01-01', '2018-03-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 56c0e9b4f335a410b84d8767 | INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[3,4)', NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 56f1b6073343629d7259f435 | -- should fail: INSERT INTO temporal_partitioned_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[3,4)', datemultirange(daterange('2010-01-01', '2010-02-15')), '[1,2)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 56fbd6d454264d1ce5503607 | INSERT INTO temporal_partitioned_rng (id, valid_at) VALUES ('[5,6)', daterange('2018-02-01', '2018-03-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5718e90dfc4fec231f68bc67 | -- with a conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 57ae496b9292e26b16a52796 | INSERT INTO temporal_fk_rng2rng (id, valid_at, parent_id) VALUES ('[8,9)', daterange('2018-01-01', '2021-01-01'), '[12,13)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 57e677c0d9ffaf5c4ddd8034 | -- with a conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 591c5a22b64e2ec474446a76 | INSERT INTO pagg_tab4 (b, c) SELECT substr('abAB', (i % 4) + 1 , 1), substr('abAB', (i % 2) + 1 , 1) FROM generate_series(0, 11) i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5a78566bd312bc8e50d4ba12 | insert into part_abc values (1, 'b', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5af7ef0cec259776eeda6729 | -- with a conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng_pk DO UPDATE SET id =... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5b277b3ff314e5899974ccb1 | INSERT INTO temporal_partitioned_rng (id, valid_at) VALUES ('[5,6)', daterange('2018-01-01', '2018-02-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5b497b296bddc68f50a60bc6 | INSERT INTO emp1 VALUES (1, 1), (2, 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5b5f3f3ca922b72990369c09 | insert into defer_trig values (2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5ba676dd9c48aa45c79c350f | INSERT INTO guid3 (guid_field) SELECT uuidv7() FROM generate_series(1, 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5c490ac86162ce910c58766a | INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2018-03-03', '2018-04-04')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5e14eaf6b2c99c277c3bf0a3 | -- should fail: INSERT INTO temporal_rng VALUES (1, '[2000-06-01,2001-01-01)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 5f2c0f6eaca98bc36067be01 | INSERT INTO foo DEFAULT VALUES RETURNING WITH (old AS o, new AS n, new AS n) * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 61b1936fcf6d6f6c851d75c1 | -- violates constraint INSERT INTO gtest21b (a) VALUES (NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 624d1c17f343c2b392571ff0 | INSERT INTO temporal_partitioned_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[3,4)', datemultirange(daterange('2018-01-05', '2018-01-10')), '[5,6)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 62f4137d5b109e96d79d6bcc | -- test FK referenced updates SET DEFAULT INSERT INTO temporal_rng (id, valid_at) VALUES ('[-1,-1]', daterange(null, null)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 64e887d9449451779708212e | -- create invalid indexes on both children insert into idxpart1 values (1, 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 6540ae14ba9603d22311f524 | INSERT INTO NE_CHECK_TBL VALUES (6) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 66c87845a35235d1d2367dc6 | INSERT INTO notnull_part1_3_upg values(NULL,1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 66cf7065e2a27524465ffee5 | -- id matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 6737883b64bdd7a62035bea8 | INSERT INTO only_parted VALUES (1, 'a') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 67b249f65582bc2e1d4b6515 | INSERT INTO gtest20c VALUES (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 67d4d6f7c94f60907746adab | -- with a conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 689c408dacf96ba70bac989b | -- with a conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng3_uq DO UPDATE SET id... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 68bd347d066d3f1f10e147c5 | -- with a conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLUDED.id + '[2,3)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 699350368f2b5fbcd025fc49 | INSERT INTO gin_check select array_agg(100 + round(random()*255)) from generate_series(1, 100) as i group by i % 100 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 69b8e01a1142a3164aba332b | -- okay: INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2018-01-02', '2018-02-03')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 6c4eb915fca4b91d90726a4f | INSERT INTO test12fk VALUES (1, 'abc'), (2, 'ABC') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 6cccc5d7d4e1f83d3723b00b | INSERT INTO distinct_on_tbl SELECT i%10, i%10, i%10 FROM generate_series(1, 1000) AS i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 6dd767a7d0fa9e40400214f6 | insert into defer_trig values (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 6de62eb37ed97b6e6f1acb1f | INSERT INTO temporal_mltrng (id, valid_at) VALUES (NULL, datemultirange(daterange('2018-01-01', '2018-01-05'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 6e65617549fa1260f7b0b4ab | insert into gtest34p values (1, 5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 6efbeb563ce48dc057037d22 | -- date matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCL... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 710206d9c0e2309e357b127b | INSERT INTO NE_CHECK_TBL VALUES (4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7118c7cf7693c8b894c381ba | INSERT INTO fk_notpartitioned_fk VALUES(100,100), (1000,1000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7156064568b3895fb2454a50 | INSERT INTO temporal_fk_rng2rng (id, valid_at, parent_id) VALUES ('[3,4)', daterange('2018-01-05', '2018-01-10'), '[5,6)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 74a5504cf3b204d42ed3d326 | -- now it should work: INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2018-02-03', '2018-03-03')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7576ee7a85aca550f2ccc74c | INSERT INTO gtest11 VALUES (1, 10), (2, 20) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 778a1b3a78c31795e359517b | -- date matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT ON CONSTRAINT temporal3_uq DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 786c97550ec6d84ae856b387 | INSERT INTO foo VALUES (5, 'subquery test') RETURNING (SELECT max(old.f4 + x) FROM generate_series(1, 10) x) old_max, (SELECT max(new.f4 + x) FROM generate_series(1, 10) x) new_max |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 794d3b32982162dd0b41fda4 | INSERT INTO gtest_rule (a) VALUES (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 79538a379fc5b7575cf2fd3a | insert into test9s values (131584) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 798b6544ab2f759dde3f74fb | insert into aitest values (2, 2, 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 79ece799df929a5efe9c0687 | -- start bound violates domain INSERT INTO temporal_rng4 VALUES ('[1,2)', '[10,11)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7a0641f7ef411ec19e9d24ed | INSERT INTO guid1 (guid_field) VALUES (uuidv4()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7bb5f0dda084b0df37df7810 | INSERT INTO pagg_tab6 (b, c) SELECT substr('cdCD', (i % 4) + 1 , 1), substr('cdCD', (i % 2) + 1 , 1) FROM generate_series(0, 5) i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7bcac95df685350295921bfb | -- ok -- even an invalid not-null forbids new nulls INSERT INTO notnull_tbl1 VALUES (NULL, 4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7c920f6bad29580ce20062c6 | -- date matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLUDED.id + '[4,5)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7d92519e58f158618a998201 | -- date matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng3_uq DO ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7db698d576af292e9cd5d803 | -- with a conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLUDED.id + '[... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7e36b6fc41e2fd6cd3027302 | INSERT INTO temporal_partitioned_mltrng (id, valid_at, name) VALUES ('[1,2)', datemultirange(daterange('2000-01-01', '2000-02-01')), 'one'), ('[1,2)', datemultirange(daterange('2000-02-01', '2000-0... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7eb7bc78717112fd54b15f1e | INSERT INTO foo VALUES (1, 'xxx', 10, 20), (2, 'more', 42, 141), (3, 'zoo2', 57, 99) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 7f551dd32902aed4b43db5cb | insert into bytea_test_table values(decode('aaaa','hex')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 801ec1f5f7adbf84bd96ac2f | INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[3,4)', '{}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 802b4e220c5029106662b8c0 | insert into t_append values (1, 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 816c6b3c3f5077171c512010 | INSERT INTO temporal_mltrng3 (id, valid_at) VALUES (NULL, datemultirange(daterange('2018-01-01', '2018-01-05'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 81908bc76f5197eeded81b4a | INSERT INTO z2 VALUES (NULL, 'text') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 822c76ba91850ddbeecad38d | -- id matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 83ec5e2bb1ba0bfd3b3dd42e | insert into gtest34 values (1, 2) on conflict (id) do update set a = gtest34.c + excluded.c returning * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 849027400c48e2610b111822 | -- id matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT ON CONSTRAINT temporal3_uq DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8936e496f0d279f2204ed33c | INSERT INTO gin_check_text_array select array_agg(sha256(round(random()*300 + 300)::text::bytea)::text) from generate_series(1, 10000) as i group by i % 100 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 893975dc4eabbf2580ebe3f7 | INSERT INTO temporal_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[2,3)', datemultirange(daterange('2018-01-02', '2018-04-01')), '[1,2)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 899c47c495a1d3ed79d35262 | INSERT INTO regress_encoding VALUES ('café', 'caf' \|\| test_bytea_to_text('\\xc3'), 'café' \|\| test_bytea_to_text('\\x00') \|\| 'dcba', 'caf' \|\| test_bytea_to_text('\\xc300') \|\| 'dcba') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8ab6f9458b99433599be3027 | -- id matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8b45ca0b1f5268a9fb317cd6 | insert into gtest34 values (1, 7) on conflict (id) do update set a = excluded.c returning * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8bb3f61e68c92b54e1b62ce2 | INSERT INTO NE_CHECK_TBL VALUES (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8bb4229710e91c1b594b2427 | INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2018-01-01', '2018-01-05'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8c222b121255ab109a8e526d | INSERT INTO notnull_tbl1_upg VALUES (NULL, 1), (NULL, 2), (300, 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8cc9a1a513c853baeb5421b3 | -- Should fail p2 INSERT INTO r1 VALUES (4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8cf38af07d9fb6b49aed6832 | insert into emp1 values (2, 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8dc1808ce330bb508e944418 | INSERT INTO test_temp(a, b, cnt) VALUES (-2, '', 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8ed2f17d000b6dd5a38b1a8c | -- okay: INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2018-01-02', '2018-02-03'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 8f55d359ab4050b8a583da2f | -- a PK update that succeeds because the numeric id isn't referenced: INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[5,6)', datemultirange(daterange('2018-01-01', '2018-02-01'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 90a2b4a1a419562d33fa6481 | INSERT INTO gin_check_text_array select array_agg(sha256(round(random()*300)::text::bytea)::text) from generate_series(1, 100000) as i group by i % 10000 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 920314bc4a5d8e548477a921 | INSERT INTO temporal_rng3 (id, valid_at) VALUES ('[3,4)', daterange('2018-01-01', NULL)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9218906fd83281dcea84e4c0 | -- ok INSERT INTO gtest20c VALUES (NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 943554c78fb7f46a87543f49 | INSERT INTO temporal_rng4 VALUES ('[1,11)', '[9,10)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9449adff20f2ad2c73e56751 | -- with a conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9458ac31f3e0bf1fcf58382d | INSERT INTO grouping_unique (x) SELECT gs FROM generate_series(1,1000) AS gs |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 947087b1df5b0ef4db38f2ed | -- OK INSERT INTO r1 VALUES (3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 95087f8eebe7ccb80308173e | -- fail, leaves behind an invalid index on the leaf partition insert into idxpart11 values (1, 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 953ef6d00c32470c3536fc94 | -- with a conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng_pk DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 959d55616f536f1ef825af7e | insert into gstest5 select i, i from generate_series(1,5)i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 96b05eb312d5f087b0f03128 | INSERT INTO notnull_tbl1 VALUES (NULL, 1), (300, 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 97248449bed22c2dde958b7d | insert into cnn_part1 values (null) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 972cf04659ad55948beba478 | -- id matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLUDED.id + '[3,4)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 97747f77147b6a9609131bb4 | -- with a conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9780895603a02315e4af2845 | INSERT INTO test_temp SELECT generate_series(1, 10000) as id, repeat('a', 200), 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 97e61222301542f00d81d2f7 | INSERT INTO gin_check_multicolumn (a,b) values ('{a,c,e}','{b,d,f}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9839f55a170ccbac28239a4d | INSERT INTO test_table VALUES (1, '42'), (2, '100'), (3, '200') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 98696dd69ff538c2c644bdc7 | INSERT INTO e VALUES (0,0), (2,2), (3,1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9a57f564442116c44d4a8539 | INSERT INTO temporal_fk_rng2rng (id, valid_at, parent_id) VALUES ('[6,7)', daterange('2018-01-01', '2021-01-01'), '[9,10)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9a63d078f3f15800d20ac8f9 | insert into p values (10, 20) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9b05459857029a83727d6371 | -- with a conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT ON CONSTRAINT temporal_rng_pk DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9b19711263ae8527d96ab29a | -- doesn't match PK, but no error yet INSERT INTO fktable VALUES (2, 20) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9b8f9d40a2178f6d596cf5cf | -- not allowed INSERT INTO gtest12 VALUES (3, 30), (4, 40) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9c448d7792aec92124fb0280 | insert into aitest values (3, 3, 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9dacf16a8af30221adc5ce6f | INSERT INTO gin_check_jsonb values ('[[14,2,3]]') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9e8b1089ceb356d565919d90 | insert into btree_tall_tbl select g, NULL from generate_series(50, 60) g |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | 9fbce374d97a68d17cc78bda | INSERT INTO temporal_fk_rng2rng (id, valid_at, parent_id) VALUES ('[4,5)', daterange('2018-01-15', '2018-02-15'), '[6,7)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a118d52ddb8bf34247392e0e | INSERT INTO temporal_rng (id, valid_at) VALUES ('[3,4)', 'empty') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a190a98a83c27da4a6f10654 | insert into gtest_cursor values (1, 10), (2, 20), (3, 30) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a2db1f0b611147f2523f3c7e | -- id matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a2f56865904d7bbaece5d7c3 | -- date matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a3f08a6c9f580fcb536e909f | INSERT INTO temporal_rng3 (id, valid_at) VALUES ('[2,3)', daterange('2018-01-01', '2018-01-05')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a567c0313506a6f98ae1a8a2 | INSERT INTO public.tt VALUES (1, 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a68c264c7dc0c1222fc40f01 | INSERT INTO temporal_rng3 (id, valid_at) VALUES (NULL, daterange('2018-01-01', '2018-01-05')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a69dfed889c850ea2d513c08 | INSERT INTO bitmap_split_or (select i, 2, 2 FROM generate_series(1, 1000) i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a77516f1bc08cabf8b0fc408 | INSERT INTO pagg_tab6 (b, c) SELECT substr('abAB', (i % 4) + 1 , 1), substr('abAB', (i % 2) + 1 , 1) FROM generate_series(0, 5) i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a7b90e855c517c0245c79adb | -- test FK referenced updates SET NULL INSERT INTO temporal_rng (id, valid_at) VALUES ('[9,10)', daterange('2018-01-01', '2021-01-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | a92da251a5a56fc5ccbdfb4e | INSERT INTO temporal_rng VALUES (1, '[2000-01-01,2001-01-01)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | aa3109cfcafa3eb2cd1e3850 | insert into emp1 values (1, 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ab0bf77ab16a7d50e768b0d1 | INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2000-01-01', '2010-01-01'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ab20755facf04175e9333f5d | INSERT INTO temporal_rng3 (id, valid_at) VALUES ('[1,2)', daterange('2018-01-01', '2018-01-05')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | abb350491cc0431b710cf9f2 | INSERT INTO temporal_fk_rng2rng (id, valid_at, parent_id) VALUES ('[1,2)', daterange('2018-01-15', '2018-02-01'), '[1,2)'), ('[2,3)', daterange('2018-01-15', '2018-05-01'), '[1,2)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ac6098ad88ff6ee2b0fe7121 | INSERT INTO temporal_fk_rng2rng (id, valid_at, parent_id) VALUES ('[5,6)', daterange('2018-01-15', '2018-02-01'), '[2,3)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | acd4ea38b095619c66e9316d | insert into tbl_rs select i, i from generate_series(1,10)i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | acfb3c372fbb6ce812583081 | INSERT INTO stats_test SELECT 'serialize-toobig--1:'\|\|g.i FROM generate_series(1, 5000) g(i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ae587842d7742b8a5fd90b4f | -- key exist but is outside range INSERT INTO temporal_fk_rng2rng VALUES (4, '[2001-01-01,2002-01-01)', 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ae7ef96cea3b981fa6e62933 | -- id matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng_pk DO UPDA... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | af416f961becbeb1a5025b86 | -- with a conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT ON CONSTRAINT temporal_rng_pk DO UPDATE SET id = EXCLUDED.id + '[2,3)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | af888aa3f2e468cd32145fd0 | INSERT INTO foo DEFAULT VALUES RETURNING WITH (old AS o, new AS n, old AS o) * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b02b6e2194c58e03cc327653 | insert into gtest32 values (1), (2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b0f6780f5d786f1be49f3541 | INSERT INTO encoding_tests VALUES -- LATIN1, other single-byte encodings ('LATIN1', 'ASCII', 'a'), ('LATIN1', 'extended', '\\xe9'), -- EUC_JP, EUC_JIS_2004, EUR_KR (for the purposes of wchar convers... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b1a022a9ec1264ff747905e6 | -- key exist but is partly outside range INSERT INTO temporal_fk_rng2rng VALUES (5, '[2000-01-01,2002-01-01)', 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b1b3d36df2f751905c83a003 | INSERT INTO gtest12 VALUES (1, 10), (2, 20) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b1d82c1e3623e9aa5f43ccb7 | -- -- partitioned FK referencing inserts -- INSERT INTO temporal_partitioned_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[1,2)', datemultirange(daterange('2000-01-01', '2000-02-15')), '[1,2... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b2976e38d40496a488b76df3 | INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2018-01-01', '2018-01-05'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b2bd32b13bb1a9f024bfc590 | INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2018-01-01', '2018-01-05'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b653d30e725d4c22f54fb366 | INSERT INTO temporal_rng3 (id, valid_at) VALUES ('[1,2)', daterange('2018-03-03', '2018-04-04')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b7be225a261134ff1ec79fb0 | INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2018-03-03', '2018-04-04'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b877c25bab196706b0b71c3e | INSERT INTO tbl_phv (x, y) SELECT gs, gs FROM generate_series(1,100) AS gs |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b89215d69475ac9d5a3b170e | INSERT INTO foo VALUES (4) RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b8ad602f8daea84f75c3892b | INSERT INTO temporal_partitioned_mltrng (id, valid_at) VALUES ('[5,6)', datemultirange(daterange('2016-01-01', '2016-02-01'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b93eccb442ffadcae5c4e04a | INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2018-01-02', '2018-02-03')), ('[1,2)', daterange('2018-03-03', '2018-04-04')), ('[2,3)', daterange('2018-01-01', '2018-01-05')), ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | b97719a827bc01e509cdb4f0 | INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[3,4)', '{}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | bbd245cac6910981cea32675 | -- date matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT ON CONSTRAINT temporal3_uq DO UPDATE SET id = EXCLUDED.id + ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | bf1048f2f9be279079e1b861 | -- with a conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c14e1f2c376db89100177135 | -- with a conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c1677efa01cd3cafcd6b6368 | -- with a conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLUDED.id + '[2... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c27ba7ab4c49178fcc90b1d0 | INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[5,6)', datemultirange(daterange('2018-01-01', '2018-02-01'))), ('[5,6)', datemultirange(daterange('2018-02-01', '2018-03-01'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c329ee375fd94f859f521cb1 | -- end bound violates domain INSERT INTO temporal_rng4 VALUES ('[1,2)', '[1,13)'), ('[1,2)', '[2,5)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c35b4bcf9796f53b2f4a6ca8 | INSERT INTO test6 VALUES (2, U&'zy\\0061\\0308bc') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c62e77c202748e16d09b433b | INSERT INTO NE_CHECK_TBL VALUES (5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c6cba98c8cc347821246eb53 | -- okay: INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2018-01-02', '2018-02-03'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c82678c3a6681f9c9b355b57 | insert into inttest values (null), (0::myint), (1::myint) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c855ea1d7654c0fe5ca956e9 | INSERT INTO gin_check select array_agg(255 + round(random()*100)) from generate_series(1, 100) as i group by i % 100 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | c95d59a87329a01dc1ec3b97 | -- id matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | cc1d040a44c2599376f0ffcb | INSERT INTO toast_3b_utf8 VALUES (repeat(U&'\\2026', 4000)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | cd834449f6c9c032a0cba02e | insert into test9v values (131584) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | cd96a8020d7df9b446726aa6 | -- violates constraint INSERT INTO gtest21ax (a) VALUES (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ce87be54197005148234280f | insert into defer_trig values (4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ce937d94874a610875332802 | insert into defer_trig values (3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ceb20626fff477aa63c1c7b6 | -- -- partitioned FK referencing inserts -- INSERT INTO temporal_partitioned_fk_rng2rng (id, valid_at, parent_id) VALUES ('[1,2)', daterange('2000-01-01', '2000-02-15'), '[1,2)'), ('[1,2)', dateran... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | d026277d0c4b637f0e464d13 | INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2000-01-01', '2010-01-01'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | d12b79d791ed7684e1c1ddca | INSERT INTO fk_partitioned_pk VALUES(100,100), (1000,1000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | d2a5d85128cfbe75a62a1f43 | insert into sj values (1, null, 2), (null, 2, null), (2, 1, 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | d4f7d77b1a5d89dfde20fcbe | INSERT INTO t5 (a, b) values (1, 'D1'), (2, 'D2'), (3, 'd1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | d6cd2dd9fc467a493a21db04 | INSERT INTO only_inh_child(a,b) VALUES (1, 'aaa'), (2, 'bbb'), (3, 'ccc') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | d6de8c8a2c7546f61540f7f2 | -- date matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT (id, valid_at) DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | d78764afccfd62457a08f298 | INSERT INTO temporal_fk_rng2rng (id, valid_at, parent_id) VALUES ('[2,3)', daterange('2018-01-02', '2018-04-01'), '[1,2)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | d7c006cb52ec59d6746daad0 | with t as ( merge into part_abc_view pt using (select stable_one() + 1 as pid) as q join part_abc_2 pt2 on (q.pid = pt2.a) on pt.a = stable_one() + 2 when not matched then insert values (1, 'd', fa... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | d98c25e31c19b9d9eaaac09b | -- id matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLUDED.id + '[3,4)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | da2521d511bd9021abb7af05 | -- id matches but no conflict INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT (id, valid_at) DO UPDATE SET id = EXCLU... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | dabe84cbe9b631d691cec297 | INSERT INTO temporal_rng3 (id, valid_at) VALUES ('[3,4)', 'empty') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | dafd57086ef8882eca068aae | INSERT INTO rw_view2 VALUES (3, 'Row 3') RETURNING old.*, new.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | dcfe143b9c2ec99363d110ab | INSERT INTO ft2 (c1,c2,c3) VALUES (1101,201,'aaa'), (1102,202,'bbb'), (1103,203,'ccc') RETURNING old, new, old.*, new.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | dd598f28c76177d55ebad9ac | INSERT INTO fk_partitioned_fk_2 VALUES(1000, 1000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e081e3e1b197a3b7a46cebdb | INSERT INTO NE_CHECK_TBL VALUES (3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e17442acf2d428e423b41576 | insert into test_t values ('a'), ('b') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e1cc6478f1ccb592124b021b | INSERT INTO stats_import.test SELECT 1, 'one', (1, 1.1, 'ONE', '2001-01-01', '{ "xkey": "xval" }')::stats_import.complex_type, int4range(1,4), array['red','green'] UNION ALL SELECT 2, 'two', (2, 2.... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e2266143671c42706859bb4e | INSERT INTO temporal_partitioned_fk_rng2rng (id, valid_at, parent_id) VALUES ('[3,4)', daterange('2018-01-05', '2018-01-10'), '[5,6)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e2d95e02a4207399b3bc2ba0 | insert into inh_nn2 values(NULL, 'sample', 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e2dfa5674b842aedcd35fe20 | INSERT INTO test_temp(a, b, cnt) VALUES (-1, '', 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e334633136240ec5e9e1b01b | -- with a conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT ON CONSTRAINT temporal3_uq DO UPDATE SET id = EXCLUDED.id + '[2,3)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e56eea952023a82ce444fa5e | INSERT INTO NE_CHECK_TBL VALUES (2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e5bc5346ed01777d46058609 | -- date matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[2,3)', datemultirange(daterange('2005-01-01', '2006-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng_pk DO UP... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e70e283a7a68b0dfeede61f1 | -- date matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e7170823790f2f4f5f174460 | INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2018-01-01', '2018-01-05'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e72e8d2a45886cebf70da993 | INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2000-01-01', '2010-01-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e771a9fa8ada2be7b4798267 | INSERT INTO rescan_bhs VALUES (1), (2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e799c2a1ffde6ec194a0c453 | INSERT INTO gin_check_jsonb values ('[1,[14,2,3]]') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e935cb9cc9eff94fa046e0bb | -- id matches but no conflict INSERT INTO temporal_rng (id, valid_at) VALUES ('[1,2)', daterange('2010-01-01', '2020-01-01')) ON CONFLICT ON CONSTRAINT temporal_rng_pk DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e95b38c697d992cfc2cffaba | -- error INSERT INTO gtestnn_parent VALUES (2, 10, default) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | e9d13d1079038009017d1bd6 | INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[3,4)', datemultirange(daterange('2018-01-01', NULL))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ea6e5053c8cfb8c86c1fe6cd | INSERT INTO temporal_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[3,4)', datemultirange(daterange('2018-01-05', '2018-01-10')), '[5,6)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ec6b5dda493f7fd86ec5a9da | -- id matches but no conflict INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2010-01-01', '2020-01-01'))) ON CONFLICT ON CONSTRAINT temporal_mltrng_pk DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ec95c99f59fc57a20a41f051 | insert into gtest34p values (1, 2) on conflict (id) do update set a = gtest34p.c + excluded.c returning * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ed756049fe847f038bef1451 | -- date matches but no conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[2,3)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ee018360eb6475da991ea3a2 | INSERT INTO test4nfd VALUES (1, 'cote'), (2, 'côte'), (3, 'coté'), (4, 'côté') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | eebe1ba34b9c2720dfbb5c27 | insert into phv_boolpart values (true, 'yes'), (false, 'no'), (null, 'unknown') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f02c9885bb2666c120ab5d7f | INSERT INTO test_pg_unicode_fast VALUES ('abc DEF 123abc'), ('ábc sßs ßss DÉF'), ('ǄxxǄ ǆxxǅ ǅxxǆ'), (U&'Λλ 1a \\FF11a'), ('ȺȺȺ'), ('ⱥⱥⱥ'), ('ⱥȺ') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f036c9b473e1a9de1dcd2799 | INSERT INTO pagg_tab5 (b, c) SELECT substr('cdCD', (i % 4) + 1 , 1), substr('cdCD', (i % 2) + 1 , 1) FROM generate_series(0, 5) i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f03c71c9dad7357bc253ffb7 | INSERT INTO temporal_mltrng (id, valid_at) VALUES ('[3,4)', datemultirange(daterange('2018-01-01', NULL))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f0ed268cb824c4a96e1d9b61 | INSERT INTO gin_check select array_agg(round(random()*255) ) from generate_series(1, 100000) as i group by i % 10000 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f1e74c29c2922e583023fce9 | INSERT INTO sj VALUES (3, 1, 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f353e6227d8364eed9125e1f | INSERT INTO pagg_tab5 (b, c) SELECT substr('abAB', (i % 4) + 1 , 1), substr('abAB', (i % 2) + 1 , 1) FROM generate_series(0, 5) i |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f4bf04dd6bf8616c94ba7538 | INSERT INTO temporal_rng3 (id, valid_at) VALUES ('[3,4)', NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f61f8a4432e6e1efad46cf6d | -- a PK update that succeeds because the numeric id isn't referenced: INSERT INTO temporal_rng (id, valid_at) VALUES ('[5,6)', daterange('2018-01-01', '2018-02-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f79709725cca5409def23985 | -- error INSERT INTO gtestnn_parent VALUES (10, 11, default) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | f9dc1bb2a20042aa19610e6b | -- should fail: INSERT INTO temporal_partitioned_fk_rng2rng (id, valid_at, parent_id) VALUES ('[3,4)', daterange('2010-01-01', '2010-02-15'), '[1,2)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | fbb66ad1b58fe2bc9ba88f23 | INSERT INTO foo DEFAULT VALUES RETURNING WITH (new AS foo) * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | fcb9a4bb3c20e91107301450 | INSERT INTO temporal_mltrng3 (id, valid_at) VALUES ('[1,2)', datemultirange(daterange('2018-03-03', '2018-04-04'))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | fcbd1355054826277a76a789 | -- with a conflict INSERT INTO temporal3 (id, valid_at) VALUES ('[1,2)', daterange('2005-01-01', '2006-01-01')) ON CONFLICT DO NOTHING |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | fdd300c0613bd76e71f4444e | INSERT INTO temporal_fk_mltrng2mltrng (id, valid_at, parent_id) VALUES ('[1,2)', datemultirange(daterange('2018-01-02', '2018-02-01')), '[1,2)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_INSERT_STMT | ff45be2147ca8572ef2f616b | insert into t values (1, 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | 0e654b97e54c9dcb831677fa | MERGE INTO target t USING source AS s ON t.tid = s.sid WHEN MATCHED AND t.balance > s.delta THEN UPDATE SET balance = t.balance - s.delta WHEN MATCHED THEN UPDATE SET balance = 0 WHEN NOT MATCHED T... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | 2b338b23007ee6be20ba9e22 | merge into part_abc_view pt using (select stable_one() + 1 as pid) as q join part_abc_2 pt2 on (q.pid = pt2.a) on pt.a = stable_one() + 2 when not matched then insert values (1, 'd', false) returni... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | 3eb44afaf2645344d6dcea2a | MERGE INTO rw_view2 t USING (SELECT x, 'R'\|\|x FROM generate_series(0,3) x) AS s(a,b) ON t.a = s.a WHEN MATCHED AND t.a <= 1 THEN DELETE WHEN MATCHED THEN UPDATE SET b = s.b WHEN NOT MATCHED AND s.a... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | 4637bda801fae3ff53434b6f | merge into part_abc_view pt using (select stable_one() + 2 as pid) as q join part_abc_1 pt1 on (q.pid = pt1.a) on pt.a = pt1.a when matched then delete returning pt.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | 4ad7b2404673ef73229d6713 | MERGE INTO rw_view1 t USING (VALUES (0, 'ROW 0'), (1, 'ROW 1'), (2, 'ROW 2'), (3, 'ROW 3')) AS v(a,b) ON t.a = v.a WHEN MATCHED AND t.a <= 1 THEN UPDATE SET b = v.b WHEN MATCHED THEN DELETE WHEN NO... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | 5bb710560558f122565042f7 | MERGE INTO pa_target t USING (SELECT '2017-01-15' AS slogts, * FROM pa_source WHERE sid < 10) s ON t.tid = s.sid WHEN MATCHED THEN UPDATE SET balance = balance + delta, val = val \|\| ' updated by me... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | 5e59678e59556f47a679d5ca | MERGE INTO pa_target t USING pa_source s ON t.tid = s.sid AND t.tid = 1 WHEN MATCHED THEN UPDATE SET tid = tid + 1, balance = balance + delta, val = val \|\| ' updated by merge' RETURNING merge_actio... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | 65a91ac6dcf9bfe59c7bebd7 | MERGE INTO rw_view2 t USING (VALUES (3, 'R3'), (4, 'R4'), (5, 'R5')) AS v(a,b) ON aaa = v.a WHEN MATCHED AND aaa = 3 THEN DELETE WHEN MATCHED THEN UPDATE SET bbb = v.b WHEN NOT MATCHED THEN INSERT ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | 8e6b848ccb76b69855a0bc88 | MERGE INTO target t USING source AS s ON t.tid = s.sid WHEN NOT MATCHED BY SOURCE THEN DELETE WHEN NOT MATCHED BY TARGET THEN INSERT VALUES (s.sid, s.delta) RETURNING merge_action(), old, new, t.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | abc759f79b9ddbc17d12be04 | merge into part_abc_view pt using (select stable_one() as pid) as q join part_abc_1 pt1 on (q.pid = pt1.a) on pt.a = pt1.a when matched then delete returning pt.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | ac1ce1407240277deea9ce1b | MERGE INTO gtestm t USING gtestm AS s ON 2 * t.a = s.b WHEN MATCHED THEN DELETE RETURNING * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | c07600967fa9a80ad01473cd | with wcte as (insert into table1 values (45)) merge into table1 using (values (46)) as v(a) on table1.a = v.a when not matched then insert values (v.a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | c4fd26c999e1fb3e91f506fb | MERGE INTO pt t USING (VALUES (1, 'x'::text)) AS s(a, b) ON false WHEN MATCHED THEN UPDATE SET b = s.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | cfa77cc1a501fc31046f50dd | MERGE INTO rw_view2 t USING (VALUES (4, 'r4'), (5, 'r5'), (6, 'r6')) AS v(a,b) ON aaa = v.a WHEN MATCHED AND aaa = 4 THEN DELETE WHEN MATCHED THEN UPDATE SET bbb = v.b WHEN NOT MATCHED THEN INSERT ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | d83af339e507c41a5219ade1 | MERGE INTO rw_view2 t USING (SELECT x, 'r'\|\|x FROM generate_series(0,2) x) AS s(a,b) ON t.a = s.a WHEN MATCHED THEN UPDATE SET b = s.b WHEN NOT MATCHED AND s.a > 0 THEN INSERT VALUES (s.a, s.b) WHE... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | dcca5ddc9c2b11cfe7f012e1 | MERGE INTO sq_target t USING sq_source s ON tid = sid WHEN MATCHED AND tid >= 2 THEN UPDATE SET balance = t.balance + delta WHEN NOT MATCHED THEN INSERT (balance, tid) VALUES (balance + delta, sid)... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | f0e727c3f42883678cb4000e | MERGE INTO gtestm t USING (VALUES (1, 10), (2, 20)) v(id, f1) ON t.id = v.id WHEN MATCHED THEN UPDATE SET f1 = v.f1 WHEN NOT MATCHED THEN INSERT VALUES (v.id, v.f1, 200) RETURNING merge_action(), o... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_MERGE_STMT | f4b1b4dcbe7bf94f2eb0791e | MERGE INTO rw_view1 t USING (VALUES (0, 'R0'), (1, 'R1'), (2, 'R2'), (3, 'R3')) AS v(a,b) ON t.a = v.a WHEN MATCHED AND t.a <= 1 THEN UPDATE SET b = v.b WHEN MATCHED THEN DELETE WHEN NOT MATCHED BY... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_PREPARE_STMT | 9febf11a56d039f5dc508614 | PREPARE test_prepare_pgss AS select generate_series(1, 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_PREPARE_STMT | ba4c60e3798166bc91d29592 | prepare update_part_abc_view as update part_abc_view set b = $2 where a = $1 returning * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_PREPARE_STMT | ca4aeecba9910d81cc7230aa | -- VtA is supported for custom plans where params are substituted with -- constants. VtA is not supported with generic plans where params prevent -- us from building a constant array. PREPARE test ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_PREPARE_STMT | cc9f6a6cf261246b9b96d380 | PREPARE p1(int, int, int, int, int) AS SELECT * FROM test_squash WHERE id IN ($1, $2, $3, $4, $5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_PREPARE_STMT | f8fc95a48a51803e76295f6d | PREPARE p1(int, int, int, int, int) AS SELECT * FROM test_squash WHERE id = ANY(ARRAY[$1, $2, $3, $4, $5]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REFRESH_MAT_VIEW_STMT | 6740aa51c939a2169832ca06 | REFRESH MATERIALIZED VIEW pgss_materialized_view |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REFRESH_MAT_VIEW_STMT | 8e935bbdfebfa4022ca7641c | REFRESH MATERIALIZED VIEW copytest_mv |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 034c9c0e9d9f0f6ef13e6476 | REINDEX TABLE pg_toast.pg_toast_1262 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 0b172e04558f1a14bf730759 | reindex index concurrently test_pg_index_toast_index |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 2a65d4dcd78b3002d7206411 | -- no catalog index -- These are the toast table and index of pg_database. REINDEX TABLE CONCURRENTLY pg_toast.pg_toast_1262 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 3324964e229954b4276a3a6e | REINDEX (TABLESPACE regress_tblspace) TABLE CONCURRENTLY pg_toast.pg_toast_1262 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 383d62debafae47f0cf781a8 | reindex index concurrently idxpart11_expr_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 3d9942adce2594e1baa45992 | REINDEX (TABLESPACE regress_tblspace) INDEX CONCURRENTLY pg_toast.pg_toast_1262_index |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 48662c800d895cabda0285a1 | -- no catalog toast table REINDEX INDEX CONCURRENTLY pg_toast.pg_toast_1262_index |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 73b0949fad12186a89be0546 | reindex index concurrently idxpart1_expr_idx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 7e5d9ea896e961eb39d865e5 | reindex index test_pg_index_toast_index |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 8245589af6f6fc3976950c7b | -- toast relations, fail REINDEX (TABLESPACE regress_tblspace) INDEX pg_toast.pg_toast_1262_index |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | 97a9ad1acaaab32cfce38bc8 | REINDEX (TABLESPACE regress_tblspace) TABLE pg_toast.pg_toast_1262 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_REINDEX_STMT | dd30277f49ae5d04218e1547 | REINDEX INDEX pg_toast.pg_toast_1262_index |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_RENAME_STMT | 4f90ac02d1602c413d350b6e | -- substring needing last byte of its slice_size ALTER TABLE toast_3b_utf8 RENAME TO toast_4b_utf8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_RENAME_STMT | d9be204c01e944901e43d038 | ALTER TABLE temporal3 RENAME COLUMN valid_at TO valid_thru |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_RENAME_STMT | ed7b0d669739aefd2f9de265 | ALTER TABLE notnull_tbl4_lk3 RENAME CONSTRAINT notnull_tbl4_a_not_null TO a_nn |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0032b51571126ecbff801bfa | SELECT to_number(' ', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 004af9b7d14c32520265edb6 | SELECT COUNT(*) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY GROUPING SETS(b, ()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 005b8ba578ea5541af8dfe38 | select max(v) from bytea_test_table |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 00c9782e1fbaa593f27bf79c | SELECT count(*) FROM tab_search_diff_1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0158310877113ec1cda85842 | SELECT relname, relpages, reltuples, relallvisible, relallfrozen FROM pg_class WHERE oid = 'pg_temp.stats_temp'::regclass ORDER BY relname |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 016b2feb9898e180a0f61e0f | SELECT pg_get_logical_snapshot_info('') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 016c9b361cf14d6ce9124b7a | SELECT crypt('', '$6$Szzz0yzz') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 01a800d8d02aa33f8619248a | SELECT regexp_replace(with_nul, '^caf(.)$', '\\1') FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 023eff37adc9d348036f390c | SELECT query_id IS NOT NULL AS qid_set FROM pg_stat_activity WHERE pid = pg_backend_pid() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0248ed86b8f77ee4a7e49dc0 | SELECT gin_index_check('gin_check_idx') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 026bbb0ef67ee08509ec29b1 | SELECT x, count(*) FROM test3ci GROUP BY x HAVING upper(x) = 'ABC' COLLATE case_sensitive |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 028ca6eaf2e64f2f3918659f | -- false SELECT has_largeobject_privilege('regress_priv_user3', 2001, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 02eaec5f3e24f45178d152fb | -- trailing _ matches two codepoints that form one grapheme: SELECT U&'cb\\0061\\0308' LIKE U&'cb_' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 030244a1c1732b23ef42240c | SELECT encrypt( '\\x0011223344', '\\x000102030405060708090a0b0c0d0e0f101112131415161718191a1b', 'aes-cfb') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0335ab066eb95d0447493539 | -- true SELECT has_largeobject_privilege('regress_priv_user2', 1009, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 034e436c56d7bc6d9ecc728e | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', NULL, 'inherited', false::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 03894ca219669fccabf1585b | -- 0391 0345 03A3 0345 0391 -- properties SELECT 'xyz' ~ '[[:alnum:]]' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 03d6ef3eca659e1a6542e59f | select t1.q1, x from int8_tbl t1 left join (int8_tbl t2 inner join lateral (select t2.q2 as x, * from int8_tbl t3) ss on t2.q2 = ss.q1) on t1.q1 = t2.q1 order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 040c940f7cd1183481c4f636 | SELECT encrypt( '\\x00112233445566778899aabbccddeeff00', '\\x000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f', 'aes-cfb/pad:none') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 040d65e07d7845805ee7442b | -- not-existing large object SELECT has_largeobject_privilege(9999, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 042511683e795af816a420d4 | select jsonb '[1,2,3,{"b": [3,4,5]}]' @? 'lax $.*' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 042536ea083fbdf23b69452a | SELECT * FROM test_squash WHERE id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10) AND data IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 048034230a0dfd3ad491e83f | SELECT ((composite_f(array[1, 2]))).* FROM test_composite |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 04abe17927dfd9832850ae66 | select * from int8_tbl intersect select q2, q1 from int8_tbl order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 04e8849f36985571b06f9559 | -- trailing __ matches two codepoints that form one grapheme: SELECT U&'cb\\0061\\0308' LIKE U&'cb__' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 04fbf51957ebc1b8559df4f8 | -- (actually this matches because) SELECT U&'\\0308bc' = 'bc' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 04fe3738ba9158c37773f054 | SELECT * FROM test_setof_as_set(0, 'set') ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0540001e26abd0c02338f8b8 | SELECT t1.c, count(t2.c) FROM pagg_tab3 t1 JOIN pagg_tab4 t2 ON t1.c = t2.c AND t1.c = t2.b GROUP BY 1 ORDER BY t1.c COLLATE "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 058f0539fac9abad74e9a012 | SELECT * FROM test_squash WHERE id = ANY(ARRAY [1 + 1, 2 + 2, 3 + 3, 4 + 4, 5 + 5, 6 + 6, 7 + 7, 8 + 8, 9 + 9]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 05a42d79eae70832c38fff47 | SELECT a, split_part(b COLLATE ctest_nondet, U&'\\00E4b', 2) FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 05e1e8fd6c5d4929d2d6486a | SELECT to_char(1234.56::numeric, '99999V99') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0687a868175a49d58fe8754c | select make_timestamptz(1999, 12, 31, 24, 0, 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 06c7057a1eddef9854e39fe2 | SELECT count(*) FROM tab_search_diff_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0741a75dd9e669051120b80d | select explain_filter('explain (verbose) create table test_ctas as select 1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 074e2eb1f75229f011771425 | SELECT s.schemaname, s.tablename, s.attname, s.inherited, r.* FROM pg_catalog.pg_stats AS s CROSS JOIN LATERAL pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', s.tabl... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 07cf22349b2e270bf9968b07 | SELECT ts_headline('english', 'foo barbar', to_tsquery('english', 'foo'), 'StopSel=' \|\| repeat('x', 32768)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 08046b8f4850229acc1a403a | -- Non-strict checks SELECT injection_points_run(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0813d91dbfd3762e5cba4873 | -- non-ASCII characters are unchanged SELECT LOWER(U&'\\00C1' COLLATE regress_builtin_c) = U&'\\00C1' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 081d202e7e9b637dc33a3f99 | -- inner % matches b: SELECT U&'\\0061\\0308bc' LIKE U&'\\00E4%c' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 084f0143ff12f94792f423ed | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.21::real, 'most_common_freqs', '{0.1,0.2,... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0896f43c2d80c419ea7a7a61 | SELECT has_largeobject_privilege(1002, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 08ce86685dac5afe069f2e9c | SELECT * FROM temporal3 ORDER BY id, valid_at |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0931a18dbd7e8d5846b7589b | -- invalid short mb character = error SELECT length(truncated) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 093a5e0a4cd84b81beb9116b | select explain_filter('explain (analyze, buffers off) select * from int8_tbl i8') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0a0121f0d3e6008fe8b847f9 | select * from pg_timezone_abbrevs where abbrev = 'LMT' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0ab1ddaf80da3d6e505410bc | SELECT 1 AS "int" OFFSET 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0af12a86c15295a00daf2d61 | SELECT strpos(b COLLATE ctest_det, 'bc') FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0b0dbd38a648109c3dcc4bae | -- runs from cache SELECT injection_points_detach('TestInjectionLogLoad') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0b46d735b433c209a9e43461 | SELECT tablename, null_frac FROM pg_stats WHERE schemaname like 'pg_temp%' AND tablename = 'stats_temp' AND inherited = false AND attname = 'i' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0b69a7ce9f1a1abeda01adb6 | select t2.* from gtest32 t1 left join gtest32 t2 on false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0b80f895fb027495f7c0deac | select distinct on (a, b) a, b from (values (1, 1), (2, 2)) as t (a, b) where a = b group by grouping sets((a, b), (a)) order by a, b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0b9e3d4b985027d6a1b4e83b | SELECT xpath_nodeset(article_xml::text, '/article/author\|/article/pages') FROM articles |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0be155c47c3d49199a97401f | SELECT pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', NULL, '17'::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0be1bb817814cb884c7d086b | SELECT substring(with_nul, 5, 1) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0bea47ae500eb4db9c0dddc8 | SELECT * FROM test12fk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0d099e5538e677b98c377724 | select 'null'::jsonb::float |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0d5ded0e40344b1a3d8add25 | SELECT * FROM gtest_rule |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0d83ea15a3aca17949e0fedf | -- pg_get_sequence_data SELECT * FROM pg_get_sequence_data('test_seq1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0d9b6425e0dfe618bed3778a | SELECT date_trunc('ago', timestamp with time zone 'infinity', 'GMT') AS invalid_zone_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0e38572419f264808f92e67a | select explain_filter('explain (verbose) declare test_cur cursor for select * from int8_tbl') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0ea0167cfa8974cf4435c070 | -- Corrupted compressed data. Set control bit with read of a match tag, -- 1 byte follows. SELECT test_pglz_decompress('\\x01ff'::bytea, 1024, false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0f95e5c9306179a209853858 | SELECT s.stxrelid::regclass AS relation, array_agg(a.attname ORDER BY u.ord) AS stats_columns FROM pg_statistic_ext s CROSS JOIN LATERAL unnest(s.stxkeys::int2[]) WITH ORDINALITY AS u(attnum, ord) ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0fb06e662d80924c3cba7212 | SELECT * FROM FLOAT4_TBL ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0fef988469c23020a618f4a2 | SELECT 2 AS "int" ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 0fff6e7c33885116bad184ba | SELECT calls, query FROM pg_stat_statements WHERE query LIKE '%GROUP BY%' ORDER BY query COLLATE "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 104489e2366d553dd970fd8d | SELECT * FROM test1cs t1, (SELECT x FROM test3cs GROUP BY x) t2 WHERE t1.x = t2.x COLLATE case_insensitive ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1060131de7847732c47c6529 | select json_strip_nulls('[1,2,null,3,4]', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1061d564c58ed261913a820d | SELECT has_largeobject_privilege(1003, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 107db4ff0619d0b151d46b22 | -- RelabelType together with CoerceViaIO is also squashable SELECT * FROM test_squash WHERE id = ANY(ARRAY[1::oid::text::int::oid, 2::oid::int::oid]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 10893fd9cf3773d2055e0bfa | SELECT COUNT(*) FROM pg_stats WHERE schemaname = 'stats_import' AND tablename = 'test' AND inherited = false AND attname = 'arange' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 108f600d159ae8656e1e1b64 | -- Ensure an empty range estimates 1 row SELECT explain_mask_costs($$ SELECT * FROM generate_series(25.0, 1.0, 1.0) g(s);$$, true, true, false, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1096db0c9535c68dbaa25b20 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.26::real, 'most_common_vals', '{{2,1},{3,... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 10aeb173411e599ef490c64d | SELECT * FROM test_squash WHERE id IN (1, 2, 3, 4, 5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 10e82243f5b802daaa2f8e16 | SELECT array_reverse('{1,2}'::int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 111f26303cc013e5fc6af210 | SELECT COUNT(*) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY b HAVING b = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 11ac5e805df91d130ddd69e8 | SELECT pg_catalog.pg_clear_relation_stats(schemaname => 'stats_import', relname => 'test') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 11acbaca4f9fc9662408bb92 | -- currently not allowed because of function permissions, should arguably be allowed SELECT a, c FROM gtest12 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 11b0e9f649d47b3347849197 | SELECT a, split_part(b COLLATE ctest_det, U&'\\00E4b', 2) FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1217f28b03254ccd6b47dfb7 | SELECT a AS a1 FROM tab_search_diff_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 121f824418da461ed12665d0 | select jsonb_path_query('[1,2,3,{"b": [3,4,5]}]', 'strict $.*') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1281c77a2234ecbc34f42916 | select '12345'::jsonb::int8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 12ae9ac89af24859ead8acea | SELECT has_largeobject_privilege('regress_priv_user2', 1008, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 12b388d9b66629598a215a72 | SELECT * FROM test_squash_jsonb WHERE data = ANY (ARRAY [('"1"')::jsonb, ('"2"')::jsonb, ('"3"')::jsonb, ('"4"')::jsonb, ('"5"')::jsonb, ('"6"')::jsonb, ('"7"')::jsonb, ('"8"')::jsonb, ('"9"')::jso... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 12c85da28cf2ec813516e711 | select a, b, count(*) from gstest2 group by grouping sets ((a), (b)) having false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 12f4a18c092279e82b6a26d2 | SELECT * FROM pg_buffercache_evict(0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 12fcfaa89388702431979414 | SELECT a FROM pgss_schema_2.tab_search_diff_2 AS t1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 135da214c49bf0baaf8eba9a | -- -- test pg_get_constraintdef -- SELECT pg_get_constraintdef(oid) FROM pg_constraint WHERE conname = 'temporal_fk_rng2rng_fk' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 139c4d0a162c3f360b76d1c9 | SELECT a FROM tab_search_diff_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 141110f56c459ffa32cc1602 | -- Test comparison functions SELECT '42'::int_custom = '42'::int_custom AS eq_test |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 143115f8f4f6a8ec19ea29ac | select tuple_data_split('test9v'::regclass, t_data, t_infomask, t_infomask2, t_bits) from heap_page_items(get_raw_page('test9v', 0)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1472912ba994b3e93fdda81f | SELECT 'Jan 01 00:00:00 2024 LMT'::timestamptz |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1554edfd8e434106a51e01f7 | -- -- num_nulls() -- SELECT num_nonnulls(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 15b652b45c3fe6279b4d2641 | SELECT '42'::int_custom < '100'::int_custom AS lt_test |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 15c1aed0ddd8269f85ffaab1 | SELECT 'init' FROM pg_create_logical_replication_slot('regression_slot_stats4_twophase', 'test_decoding', false, true) s4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 15cd0c3fa5e216f92570d2a3 | SELECT lo_create(1008) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 15ee822a2955ef8669563a17 | SELECT to_char('1237'::float8, 'fmrn') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1601dc52730f014eeb28ab6c | -- Decompression with rawsize too large, fails to fill the destination -- buffer. SELECT test_pglz_decompress(test_pglz_compress( decode(repeat('abcd', 100), 'escape')), 500, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 161aa823847c5abfe463a685 | -- Check that the existing FK trigger is both deferrable and initially deferred SELECT conname, tgrelid::regclass as tgrel, regexp_replace(tgname, '[0-9]+', 'N') as tgname, tgtype, tgdeferrable, tg... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1643330687eaa13651fbfb77 | SELECT gin_index_check('gin_check_text_array_idx') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1726607569d98d11f619386d | SELECT * FROM test_squash_jsonb WHERE data IN ((SELECT '"1"')::jsonb, (SELECT '"2"')::jsonb, (SELECT '"3"')::jsonb, (SELECT '"4"')::jsonb, (SELECT '"5"')::jsonb, (SELECT '"6"')::jsonb, (SELECT '"7"... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 17b40bf4d4f31ddd760e50b2 | SELECT COUNT(*), AVG(t1.twenty) FROM tenk1 t1 LEFT JOIN LATERAL (SELECT t1.twenty AS c1, t2.unique1 AS c2, t2.two FROM tenk1 t2) s ON t1.two = s.two WHERE s.c1 = s.c2 AND t1.unique1 < 1000 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 17efd643da055c2f482e01c6 | SELECT -f1, EXTRACT(MICROSECOND FROM -f1) AS MICROSECOND, EXTRACT(MILLISECOND FROM -f1) AS MILLISECOND, EXTRACT(SECOND FROM -f1) AS SECOND, EXTRACT(MINUTE FROM -f1) AS MINUTE, EXTRACT(HOUR FROM -f1... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 18dca64933b17b386269bdef | SELECT * FROM test_squash WHERE id = ANY(ARRAY [@ '-1', @ '-2', @ '-3', @ '-4', @ '-5', @ '-6', @ '-7', @ '-8', @ '-9']) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 19281db68c8ec9fa0644a316 | select 'null'::jsonb::numeric |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 19481a6d92cd4e8528489882 | SELECT WHERE 1 IN (1::text::int::text::int, 1::text::int::text::int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 19c00d628bf95a285a55bfbe | select json_strip_nulls('null', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1a3e277dc9241a10bc11fccc | SELECT WHERE 1 = ANY (ARRAY[1, int4(1), int4(2), 2]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1a9625353b70e93d7295683b | select x, y from (select t1.unique1 as x, t1.unique2 as y from tenk1 t1, tenk1 t2) as t where x = 1 group by grouping sets (x, y) order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1aa73d974fb5be7cd04cf02d | SELECT lgamma(float8 '-infinity') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1acfa2eb17430efea87119c3 | SELECT crypt('This is just a test', '$5$rounds=5000$toolongsaltstring') = '$5$rounds=5000$toolongsaltstrin$Un/5jzAHMgOGZ5.mWJpuVolil07guHPvOW8mGRcvxa5' AS result |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1b0b1d5f9f4fd2ba6ef80b56 | SELECT array_sort(a) FROM (VALUES ('[-1:0]={7,1}'::int[])) v(a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1b13cb9b9429b8f90d4693c0 | -- error cases SELECT to_number('viv', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1b15c99398cc7d5649929883 | SELECT data FROM test_float WHERE data IN (1, '2') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1b20b04b3e7051da1ecc81b6 | SELECT gamma(float8 '1000') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1b30b646e0f0397e3d03cd44 | SELECT pg_get_indexdef(conindid, 0, true) FROM pg_constraint WHERE conname = 'temporal_rng3_uq' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1b4095717d0fba60d8ef10f0 | SELECT 1 AS "int" ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1b5d03217f30012285848164 | SELECT date_trunc( 'week', timestamp with time zone 'infinity' ) AS inf_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1b9d3af5b7d1f61187eefbbf | SELECT pg_catalog.pg_restore_attribute_stats( 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1c3e45ef82dcc1f9a1d84177 | select a, a in (null::myint,1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint) as not_hashed, a in (null::myint,1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint,8::myint)... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1c578446580edf1c0271ad7d | SELECT pg_drop_replication_slot('regression_slot_stats1'), pg_drop_replication_slot('regression_slot_stats2'), pg_drop_replication_slot('regression_slot_stats3'), pg_drop_replication_slot('regressi... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1c9723ed4425011df3050c06 | SELECT DISTINCT ON (y, x) x, y FROM (SELECT * FROM distinct_on_tbl ORDER BY x) s |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1c9ed3c9e0d02f51e48e5acf | SELECT x, count(*) FROM test3ci GROUP BY x HAVING (CASE x WHEN 'abc' COLLATE case_insensitive THEN true ELSE false END) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1cc6403909dc97be706203d2 | SELECT date_trunc( 'timezone', timestamp '2004-02-29 15:44:17.71393' ) AS notsupp_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1e8265b325da90c01e1731ec | SELECT substring(good, 4, 1) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1eb1c65c861e59294bc0330c | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'tags', 'inherited', false::boolean, 'null_frac', 0.25::real, 'elem_count_histogram', '{1,1... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1efd40da2074e96069081b9f | SELECT a, split_part(b COLLATE ctest_det, U&'\\00E4b', -1) FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1f238b4f7e77c44e0347327c | SELECT reverse(truncated) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 1f9060eb3b56cc744b085803 | SELECT to_number('MMXX ', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 202a0fb20f16a7a0486c1be5 | SELECT to_char(val, 'FMRN') FROM num_data |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2033daeb483a69802e90bb85 | select encode(decrypt(encrypt('Lets try a longer message.', '0123456789', 'aes-cfb'), '0123456789', 'aes-cfb'), 'escape') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2050950dc4500dced6ba26d9 | SELECT pg_catalog.pg_clear_relation_stats(schemaname => 'stats_import', relname => 'testseq') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2087acae8a7ad33cb1f91722 | SELECT convert_to(substring(with_nul, 5, 1), 'UTF8') FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 208ef36bb7fb3a6d06a01703 | -- inner %% matches b then zero: SELECT U&'\\0061\\0308bc' LIKE U&'\\00E4%%c' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 209d833177081115e364c3af | select jsonb_path_query('[1,2,3,{"b": [3,4,5]}]', 'strict $.*', NULL, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 20ecef331149082582d4d076 | SELECT explain_memoize(' SELECT COUNT(*), AVG(t1.twenty) FROM tenk1 t1 LEFT JOIN LATERAL (SELECT t1.two+1 AS c1, t2.unique1 AS c2 FROM tenk1 t2) s ON TRUE WHERE s.c1 = s.c2 AND t1.unique1 < 1000;',... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2180a92d6a1d362b40353aa2 | select jsonb_strip_nulls('1', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 219cf11d730e0152ca06ffe3 | select 'null'::jsonb::int4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 21a07f76e1e97c2daf939ad6 | -- Test for large values of StartSel, StopSel and FragmentDelimiter SELECT ts_headline('english', 'foo barbar', to_tsquery('english', 'foo'), 'StartSel=' \|\| repeat('x', 32768)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 21ae2125d1309fe991d79d51 | select explain_filter('explain verbose select sum(unique1) over w, sum(unique2) over (w order by hundred), sum(tenthous) over (w order by hundred) from tenk1 window w as (partition by ten)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 22366d3583116d1730b317e0 | -- trailing % matches zero: SELECT U&'\\0061\\0308bc' LIKE U&'\\00E4bc%' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 227aae0fd2e942575ec3c41a | SELECT isn_weak() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 227c97539bdfc80ab03b3094 | select xslt_process('<aaa/>', $$<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"> </xsl:stylesheet>$$) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 22a28fdd1f8217b9c4e9fa43 | -- test timestamp near POSTGRES_EPOCH_JDATE select timestamptz '1999-12-31 24:00:00' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 22a76e2b0eb6129695951b48 | SELECT count(*) FROM pagg_tab GROUP BY c ORDER BY c LIMIT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 22d3ac4d1cfde8465a2547c7 | SELECT * FROM test_squash_jsonb WHERE data IN (('"1"')::jsonb, ('"2"')::jsonb, ('"3"')::jsonb, ('"4"')::jsonb, ('"5"')::jsonb, ('"6"')::jsonb, ('"7"')::jsonb, ('"8"')::jsonb, ('"9"')::jsonb, ('"10"... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2339e58468956dca8247395c | SELECT encrypt( '\\x0011223344', '\\x000102030405', 'aes-cfb') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 235e603fa17c637f1c34e285 | SELECT array_sort(ARRAY(SELECT '1 4'::int2vector UNION ALL SELECT '1 2'::int2vector)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 238505a8dbba6516274d2dd1 | -- Test EEOP_HASHED_SCALARARRAYOP against EEOP_SCALARARRAYOP. Ensure the -- result of non-hashed vs hashed is the same. select a, a in (1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myin... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 239b46a2da3f970c2a84a469 | SELECT has_largeobject_privilege(1001, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 23cdcd74d0154ff46abb131e | SELECT to_char('100'::numeric, 'rn') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 24901b1a6dd0789e1a6ea3d5 | -- Ensure the estimated and actual row counts match when the range isn't -- evenly divisible by the step SELECT explain_mask_costs($$ SELECT * FROM generate_series(TIMESTAMPTZ '2024-02-01', TIMESTA... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2493cd2beaf3cecda95276d7 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'arange', 'inherited', false::boolean, 'range_bounds_histogram', '{"[-1,1)","[0,4)","[1,4)"... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 24a7777389e9be85ac9ffced | SELECT table_name, column_name, dependent_column FROM information_schema.column_column_usage WHERE table_schema = 'generated_virtual_tests' ORDER BY 1, 2, 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 24abcbe2ecaf115bb9336d20 | SELECT ARRAY[1, 2, 3, 4, 5] |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2509a51e39b91c90303e505c | SELECT pg_get_logical_snapshot_info(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 25635da836c36edc0d2ba400 | -- multidimensional array tests SELECT array_sort('{{1}}'::int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 25c8fe6b28492dc9fac2435a | SELECT array_reverse('{1}'::int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 25f8d5d81af0e06efedcdaf8 | SELECT set_masklen(inet(text(i)), 33) FROM INET_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 268bcbfabfebc2796a36150c | SELECT casefold('AbCd 123 #$% ıiIİ ẞ ß Ǆǅǆ Σσς' COLLATE "tr-x-icu") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 276edb4af5fd8c16e2e77a6f | SELECT uuid_extract_version(uuidv7()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 285bf8fd211ebfc363c1fe2f | SELECT DISTINCT ON (y, x) x, y FROM distinct_on_tbl ORDER BY y |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 287da0971e59574fef536235 | SELECT 1 AS "int" OFFSET 2 LIMIT 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 287df91095c7e5926a9672d7 | SELECT buffers_evicted IS NOT NULL FROM pg_buffercache_evict_all() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 28935cedba4fad2571e7f5a0 | SELECT WHERE 1 = ANY (ARRAY[1, int4(1), int4(2)]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 28c1a521d1d7ed9ef5dde7c1 | SELECT to_number('MCCM', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2907db135466ed9413921369 | SELECT test_pglz_decompress('\\x01'::bytea, 1024, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 29168be2ca880715b07b3dbe | select json_strip_nulls('{"a": {"b": null, "c": null}, "d": {} }', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 292b6bbd968ac8672ad893d6 | SELECT crypt('Hello world!', '$6$saltstring') = '$6$saltstring$svn8UoSVapNtMuq1ukKS4tPQd8iKwSMHWjl/O817G3uBnIFNjnQJuesI68u4OTLiBFdcbYEdFCoEOfaS35inz1' AS result |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2962ece50103979c1c9531f6 | SELECT explain_filter($$ EXPLAIN (DEBUG, RANGE_TABLE, FORMAT XML, COSTS OFF) SELECT genus, array_agg(name ORDER BY name) FROM vegetables GROUP BY genus $$) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 297e1d413c46a92fe2007d7a | SELECT array_reverse('{1,2,3,NULL,4,5,6}'::int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2996b4ec279c93c34d2d7cd7 | SELECT thousand, tenthous FROM tenk1 WHERE thousand IN (182, 183) AND tenthous > 7550 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 29dbb50eb03613bd74282ef2 | SELECT crypt('Hello world!', '$5$saltstring') = '$5$saltstring$5B8vYYiY.CVt1RlTTf8KbXBH3hsxY/GNooZaBBGWEc5' AS result |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 29e0471105fb45450521bdb5 | SELECT date_trunc( 'ago', timestamp 'infinity' ) AS invalid_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2a265cc1de601a58904ec4a2 | SELECT SUBSTRING(c FROM 3000 FOR 1) FROM toast_4b_utf8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2a2ebe6683f8e600388062b6 | -- Check that functions without argument are not marked as leakproof. SELECT p1.oid::regprocedure FROM pg_proc p1 JOIN pg_namespace pn ON pronamespace = pn.oid WHERE nspname = 'pg_catalog' AND prol... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2a58950412f0673681eb5929 | SELECT unnest(pg_get_acl('pg_class'::regclass, 'atest5'::regclass::oid, 3)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2a671056e4b20f2a0e145f0d | SELECT DISTINCT 2 AS "int" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2a8c00116deaccdf97f960d8 | select ss2.* from int8_tbl t1 left join (int8_tbl t2 left join (select coalesce(q1) as x, * from int8_tbl t3) ss1 on t2.q1 = ss1.q2 left join lateral (select ss1.x as y, * from int8_tbl t4) ss2 on ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2a8eb87b14390fae6eb06e53 | SELECT injection_points_attach('hash-aggregate-enter-spill-mode', 'notice') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2ae6d7d8c351e6a5b2c9053c | select 'null'::jsonb::int8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2b0604569108d5a9d75bd5c2 | SELECT * FROM test_squash_jsonb WHERE data = ANY(ARRAY [(SELECT '"1"')::jsonb, (SELECT '"2"')::jsonb, (SELECT '"3"')::jsonb, (SELECT '"4"')::jsonb, (SELECT '"5"')::jsonb, (SELECT '"6"')::jsonb, (SE... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2b0a88e092e7dcae097dcf70 | select a, b from (values (1, 1), (2, 2)) as t (a, b) where a = b group by grouping sets((a, b), (a)) order by a, b nulls first |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2b25d195c034b0da18ac39ba | select jsonb_path_query('[1,2,3]', '$.*') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2b386aa84da9177d4e3a35d7 | SELECT * from id_alw2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2b6d8781b6f0404b5346805d | SELECT '100'::int_custom >= '42'::int_custom AS ge_test |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2b7b5becb7ba8ddc8ffbb149 | SELECT c AS cidr, broadcast(c) AS "broadcast(cidr)", i AS inet, broadcast(i) AS "broadcast(inet)" FROM INET_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2bb21a45a1db7f87cee667cf | select encode(decrypt_iv('\\xf9ad6817cb58d31dd9ba6571fbc4f55d56f65b631f0f437cb828', '0123456', 'abcd', 'aes-cfb'), 'escape') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2bd31b65fdde6a7fe2a5fdcc | SELECT test1(0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2c490cb8742f95c73f6c93be | SELECT array_sort('{foo,bar,null,CCC,Abc,bbc}'::text[] COLLATE "C") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2cc3b746af2a4e7f6e7e2844 | SELECT x, count(*) FROM test3ci GROUP BY x HAVING (CASE x WHEN 'abc' COLLATE case_sensitive THEN true ELSE false END) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2cef3d813a907ae347746a5d | SELECT data FROM test_float WHERE data = ANY(ARRAY[1, '2']) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2d0053667d1e2e1df89496f4 | select jsonb_strip_nulls('{"a":1,"b":null,"c":[2,null,3],"d":{"e":4,"f":null}}', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2d35f8ac971c5a459c310eab | select encrypt('foo', '0123456789012345678901', 'aes-cfb') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2de1b5b1eb2fdedb065f2302 | SELECT is_valid('2222222222221'::ean13) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2ea5c229677e5a256452dced | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'nope', 'inherited', false::boolean, 'null_frac', 0.1::real, 'avg_width', 2::integer, 'n_di... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2ec984f58d90f0641c62e2a1 | SELECT (array[1,2])[(SELECT g.i):(SELECT g.i + 1)] FROM generate_series(1, 1) g(i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2f51327024e300bd45fd393a | SELECT to_number('123456', '99999V99') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2f8ccd18e695073bdd01491f | SELECT x, count(*) FROM test3ci GROUP BY x HAVING x = 'abc' COLLATE case_insensitive AND length(x) > 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2fc45186e45062a47a4300be | SELECT conrelid::regclass, contype, convalidated, conislocal FROM pg_catalog.pg_constraint WHERE conrelid in ('notnull_parent_upg'::regclass, 'notnull_child_upg'::regclass) ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 2fd09edeeda2dff66d33821f | SELECT 'xAb' ~* '[W-Y]' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3008ab8ad46204d5f8b1ac33 | -- Permission denied SELECT * FROM tststats.priv_test_parent_tbl WHERE a <<< 0 OR b <<< 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3021834f38ef505f5d98d482 | SELECT GROUPING(b) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 30e70ef1fb2523e11b44458f | SELECT has_largeobject_privilege('regress_priv_user2', 1010, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3111f3f1eeed0808a37de324 | select jsonb_strip_nulls('"a string"', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 316b40c62e2ae9ebc0d1fc77 | SELECT array_sort('{1}'::int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3176ff0076eea80bc42deecd | select * from (select a, b from phv_part) t where a in (1, null) group by grouping sets (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 31cb139c14afdca86f151fc0 | -- IN and ANY clauses with Vars are not squashed. SELECT * FROM test_squash a, test_squash b WHERE a.id IN (1, 2, 3, b.id, b.id + 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 31d6bf23708abf6001c47012 | -- _ matches one codepoint that forms half a grapheme: SELECT U&'\\0061\\0308bc' LIKE U&'_\\0308bc' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 31e5bc4d8cebc79af86fd1a7 | SELECT * FROM test_squash WHERE id IN (1, 2, 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 31f30a2161c1a85ce9c0dd69 | select encrypt_iv('foo', '0123456', 'abcd', 'aes-cfb') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 31fafefa1a4f01be9db611af | SELECT to_char(1234, '9.99EEEE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3215392ba99a38a38d89ecce | select generate_series(1, a) as g, a+b as ab from (values (1, 1), (2, 2)) as t (a, b) group by rollup(a, ab) order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3225e1b56229c5c1e9c50207 | select p.* from sj p, sj q where q.a = p.a and q.b = q.a - 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3229c6f76d4339b1735ab856 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 327cc72b3f1039603a69392b | SELECT to_number('MMMM', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 329935af9ac107a6b43fc1ff | -- These should return nothing, because these are STRICT functions SELECT * FROM pg_buffercache_evict(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 32a9f006fa5afaec29a92707 | SELECT to_timestamp('2024 613566758 1', 'YYYY WW D') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 32bc297f3df8d0bd73840956 | -- Ensure the row estimate behaves correctly when step size is zero. -- We expect generate_series_timestamp() to throw the error rather than in -- the support function. SELECT * FROM generate_serie... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 32efa1d15b98cf8d52406a9f | -- runs from cache SELECT injection_points_cached('TestInjectionLogLoad', 'foobar') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 33a2214e0eb8fa246c2329ed | SELECT ARRAY[1, 2, 3] |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 34268f847be8cd080336660d | select * from emp1 t1 where exists (select * from emp1 t2 where t2.id = t1.code and t2.code > 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 34586968bee91f677d3e39ec | select '1.0'::jsonb::float4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3477932401c5cac8cbc7f8d4 | -- verify correct results for min(record) and max(record) aggregates SELECT max(row(a,b)) FROM aggtest |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 34f312741b1b52a44d5c699d | SELECT to_number(' XIV ', ' RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 353a804ae2e461858b2a92b0 | select * from (select a, b from phv_part) t where a = 1 group by grouping sets (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3592da95a178013cca0abaa9 | SELECT gtest1 FROM gtest1 ORDER BY a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 35f55164e0f60cb0e753ee39 | SELECT * FROM test_squash_bigint WHERE data IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 36073767caebe474e0e056c7 | -- fail -- Another example of an abbrev that varies across zones SELECT '1912-01-01 00:00 MMT'::timestamptz |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3656b9b8d79fc0414d6315cf | -- case mapping SELECT 'xYz' ~* 'XyZ' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 369f3fec2e4a23b397a91dad | SELECT uuid_extract_version(uuidv4()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 36a71640021633ec37336a25 | SELECT timestamp with time zone 'J2452271 T X03456.001e6-08' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 36b946ff39df95002dbe8539 | select t1.unique1,t2.unique1 from tenk1 t1 inner join tenk1 t2 on t1.two = t2.two and t1.unique1 = (select min(unique1) from tenk1 where t2.unique1=unique1) where t1.unique1 < 10 and t2.unique1 < 1... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 36f20974b347dfa6be5b343c | SELECT max(row(b,a)) FROM aggtest |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3701a1fa8b2d54625ec6b53c | SELECT to_date('2147483647 01', 'CC YY') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 370b32e3af528ba6434c1f5a | SELECT x, count(*) FROM test3ci GROUP BY x HAVING x = 'abc' COLLATE case_insensitive |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 374ef982929396749db0fe93 | SELECT * FROM hash_i4_heap WHERE seqno = 9999 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 37a503d88e62d314b8bd6ab9 | SELECT relname, relpages, reltuples, relallvisible, relallfrozen FROM pg_class WHERE oid = 'stats_import.test'::regclass ORDER BY relname |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 37d4260af9258a4ec5b0b54d | select tcls1.somefunc(11) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 383e29c8ccddcb2428372d1b | SELECT toplevel, calls, query FROM pg_stat_statements ORDER BY query COLLATE "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 38b6d89ebbf9558a4b221fbc | SELECT crypt('Hello world!', '$6$rounds=10000$saltstringsaltstring') = '$6$rounds=10000$saltstringsaltst$OW1/O6BYHV6BcXZu8QVeXbDWra3Oeqh0sbHbbMCVNSnCM/UrjmM0Dp8vOuZeHBy/YTBmSK6H9qs/y3RnOaw5v.' AS r... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 39115982b4a93138b642dae0 | SELECT date_trunc( 'timezone', timestamp with time zone 'infinity' ) AS notsupp_inf_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3944d58fa8c61a39b84750fd | SELECT mode FROM pg_locks WHERE relation = 'stats_import.part_parent'::regclass AND pid = pg_backend_pid() AND granted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 396d7093e66bd3e55d5e5dd9 | SELECT sum(unique1) over (rows between 9223372036854775807 following and 1 following), unique1, four FROM tenk1 WHERE unique1 < 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 39ee6ea5c3ad01216c6df0f7 | select explain_filter('explain (analyze,buffers off,costs off) select sum(n) over() from generate_series(1,10) a(n)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3a14f9d603c09c5ec3a419e6 | select json_strip_nulls('{"a":1,"b":null,"c":[2,null,3],"d":{"e":4,"f":null}}', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3a8015f3b339994f428dbbfc | select current_setting('session_authorization') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3a88da39e9ca86b70c4b9534 | SELECT DISTINCT y, x FROM distinct_tbl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3a8bd94eea080a6ac9cbdbd0 | select 1 from emp1 full join (select * from emp1 t1 join emp1 t2 join emp1 t3 on t2.id = t3.id on true where false) s on true where false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3b24eaa54a012d11958d00bd | SELECT crypt('Hello world!', '$5$rounds=10000$saltstringsaltstring') = '$5$rounds=10000$saltstringsaltst$3xv.VbSHBb41AL9AvLeujZkZRBAwqFMz2.opqey6IcA' AS result |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3b2699201506def006f62f08 | SELECT '2222222222221'::ean13 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3beb253e92c5e37f7bcad69a | select a, a not in (1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint,8::myint) as not_hashed, a not in (1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint,8::myint,9::myin... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3c0847c4a00b7b9f3f957fb5 | SELECT * FROM test1cs t1, (SELECT x FROM test3cs UNION SELECT x FROM test3cs) t2 WHERE t1.x = t2.x COLLATE case_insensitive ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3c26ce40b8a49325616ed14e | SELECT x, count(*) FROM test3ci GROUP BY x HAVING (CASE WHEN (CASE x WHEN 'abc' COLLATE case_sensitive THEN 1 ELSE 0 END) = 1 THEN true ELSE false END) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3c47311ae5c66ac17cb321bc | SELECT DISTINCT ON (y, x) x, y FROM distinct_on_tbl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3c4e6b5b9cea547726f4f2a4 | select div(539913372912345678, 539913372912345678) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3ce7704d01a7fb208727dfc8 | SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND 1 = j1.a AND j2.a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3d39edb4157449c566f72fe9 | SELECT COUNT(*) FROM (SELECT DISTINCT x FROM hashagg_ij) s |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3d4ca481f2e7aeceed1a0136 | SELECT crypt('the minimum number is still observed', '$6$rounds=10$roundstoolow') = '$6$rounds=1000$roundstoolow$kUMsbe306n21p9R.FRkW3IGn.S9NPN0x50YhH1xhLsPuWGsUSklZt58jaTfF4ZEQpyUNGc0dqbpBYYBaHHrs... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3dd115583699023e39ad93c3 | SELECT data FROM test_float WHERE data IN (1, 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3e9f2bb8f28b2a1ae2078f0c | table part_abc_log |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3f0ff72c97f1c5222d38af18 | -- an empty object is not null and should not be stripped select jsonb_strip_nulls('{"a": {"b": null, "c": null}, "d": {} }', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3f3a230a6404675930647c56 | SELECT '(1,2)'::t |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3f3dd37f73553dc8328efde3 | select distinct on (a, b+1) a, b+1 from (values (1, 0), (2, 1)) as t (a, b) where a = b+1 group by grouping sets((a, b+1), (a)) order by a, b+1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3f694e5f3afc33271a4ccfeb | -- Both of these queries will be rewritten as an ArrayExpr, so they -- will be squashed, and have a similar queryId select where '1' IN ('1'::int::text, '2'::int::text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3f91111f6de962c323e6ca70 | SELECT a, b FROM tab_search_same |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 3fc88705b5819b92958afc1f | -- Loading SELECT injection_points_cached('TestInjectionLogLoad') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 418700d026590029e3362ba8 | SELECT isn_weak(false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4196de8f0c5075916f2065a8 | SELECT * FROM test_squash_bigint WHERE id = ANY(ARRAY[ abs(100), abs(200), abs(300), abs(400), abs(500), abs(600), abs(700), abs(800), abs(900), abs(1000), ((abs(1100)))]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 41c179ac01ba879805553ec1 | SELECT a, string_to_array(b COLLATE ctest_nondet, U&'\\00E4b') FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 41dda06b3151a87edbb7971b | SELECT table_name, column_name, column_default, is_nullable, is_generated, generation_expression FROM information_schema.columns WHERE table_schema = 'generated_stored_tests' ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 41de3f327f16ed6e8ed1702b | SELECT mode FROM pg_locks WHERE relation = 'stats_import.test'::regclass AND pid = pg_backend_pid() AND granted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4228e410999b0c85d3a55cca | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'arange', 'inherited', false::boolean, 'null_frac', 0.29::real, 'range_empty_frac', 0.5::re... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 425ac8a9ca517c040c348662 | SELECT date_trunc( 'week', timestamp 'infinity' ) AS inf_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4260422021b7450f77ee6c75 | SELECT server_name, CASE WHEN closed IS NOT false THEN true ELSE false END AS closed, remote_backend_pid <> 0 AS remote_backend_pid FROM postgres_fdw_get_connections(true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 426e4839c66af70aea201def | SELECT pg_get_logical_snapshot_meta('../snapshots') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 42732de1ce78f29617cdf721 | SELECT pg_get_indexdef(conindid, 0, true) FROM pg_constraint WHERE conname = 'temporal_mltrng_pk' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4293fd0f43cced395726f744 | SELECT count(*) FROM tab_search_same |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 42e2f20f81fcf5a4b6acd986 | SELECT DISTINCT y, x FROM distinct_tbl ORDER BY y |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4438ada9c8fdfd0ae7e353aa | SELECT * FROM test_squash_cast WHERE data IN (1::int4::casttesttype, 2::int4::casttesttype, 3::int4::casttesttype, 4::int4::casttesttype, 5::int4::casttesttype, 6::int4::casttesttype, 7::int4::cast... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 447712c1ac8e07e97b1d0a7c | SELECT COUNT(*) FROM onek t1 LEFT JOIN tenk1 t2 ON (t2.thousand = t1.tenthous OR t2.thousand = t1.thousand) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 44a9564d5dc209ed1f0cb90b | SELECT lo_create(1010) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 45200daf8a4b6d988189a754 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.24::real, 'histogram_bounds', '{1,NULL,3,... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4532e37bbece5d1eca4f1b4d | SELECT injection_points_detach('typecache-before-rel-type-cache-insert') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 455ae4a46934f301fac416ad | SELECT array_sort('{foo,bar,CCC,Abc,bbc}'::text[] COLLATE "C") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 456aba64bf0a756a744ff390 | SELECT reverse(truncated_with_nul) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 456cbb0fcb936ae08f35e9c2 | SELECT * FROM test_squash WHERE id IN (1, 2, 3, 4) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 457da3eef5159dc68800661a | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.27::real, 'range_empty_frac', 0.5::real, ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 45fbac89c7f1252bdcb6bf8e | -- __ matches two codepoints that form one grapheme: SELECT U&'\\0061\\0308bc' LIKE U&'__bc' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 46077d3675bebd47fdf080d1 | select json_strip_nulls(null, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 468b3eeabce162be84a33ceb | -- no SELECT has_largeobject_privilege('regress_priv_user2', 1008, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 46e787fd913a9699d97734f0 | SELECT * FROM temp_t |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 47aa824f56f71e0b89cb6983 | select explain_filter('explain (analyze,buffers off,costs off) select sum(n) over(partition by m) from (SELECT n < 3 as m, n from generate_series(1,2500) a(n))') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 47dff52f0a03b98cdeaf7a51 | SELECT data FROM test_float WHERE data IN ('1', '2') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 47e43b2c29c0e07adad38a78 | SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = 1 AND j2.a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 48269be2765baeba16c210b6 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attnum', 1::smallint, 'inherited', false::boolean, 'null_frac', 0.4::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 482c8cf80036f07133b0ced7 | SELECT array_sort('{{1,2,3},{2,3,4}}'::xid[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 483cedf4c02c60b320cc70ff | SELECT * FROM test_squash WHERE id IN (1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 483d120c4a668d472478e8a4 | SELECT array_reverse('{{1,2},{3,4},{5,6},{7,8}}'::int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 48792671225b32155a91dbf5 | SELECT COUNT(*) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY b, a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 488340cbcd3dda6d3fdb60a6 | SELECT unique1, unique2 FROM onek_with_null WHERE unique2 >= -1 ORDER BY unique2 DESC LIMIT 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4895850013695bbfff6b4d9d | SELECT a, b FROM gtest11 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 48cf5f3d6055e45569839ee3 | -- same as above with cases reversed -- case folding select casefold('AbCd 123 #$% ıiIİ ẞ ß Ǆǅǆ Σσς' collate PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 49dc5c907570fdd8445f3850 | SELECT thousand, tenthous FROM tenk1 WHERE thousand > -1 and thousand >= 0 AND tenthous = 3000 ORDER BY thousand |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4a12f42aaf57b4dd618dc077 | select jsonb '{"a": [1,2,3], "b": [3,4,5]}' @? '$.*' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4a2eb0149609ac7822d4e46a | SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = (EXTRACT(DOW FROM current_timestamp(0))/15 + 3)::int AND (EXTRACT(DOW FROM current_timestamp(0))/15 + 3)::int = j2.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4a5eada50b4e742fcedb099c | SELECT a, split_part(b COLLATE ctest_nondet, U&'\\00E4b', -1) FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4a727f4e17fd081a4f60932c | SELECT array_sort(a [-1:0]) FROM (VALUES ('[-2:0][20:21]={{1,2},{10,20},{1,-4}}'::int[])) v(a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4a8ba415c74030c5aa0a29ac | SELECT COUNT(*) >= 0 AS ok FROM pg_aios |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4aa8ecf56750e2c21c3c08c7 | -- Should fail because the row is locked SELECT * FROM pxtest_rowlock WHERE id = 1 FOR UPDATE NOWAIT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4b463d12c79606b4820d6534 | SELECT slot_name, spill_txns, spill_count FROM pg_stat_replication_slots WHERE slot_name = 'regression_slot_stats4_twophase' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4c04dba10a980c8ddc6205f0 | -- 03A3 SELECT lower('0Σ' COLLATE PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4c35cd6af6df856a378408c7 | SELECT data FROM test_float WHERE data = ANY(ARRAY[1, 2]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4c46483498b76afbeea2f558 | SELECT lo_create(1007) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4c5b90f011189e4f8b12df2c | SELECT * FROM test6 WHERE b = 'zyäbc' COLLATE ctest_det |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4c817baeaee14367dd4a78a5 | -- inner %% matches b then zero: SELECT U&'cb\\0061\\0308' LIKE U&'c%%\\00E4' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4c86b80539c04fd79c7b6239 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'attnum', 1::smallint, 'inherited', false::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4cf9fdc6ca36bab8c6bf497e | SELECT to_number('VIX', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4d789617d1bc0d2d804fd1c3 | -- non-ASCII characters are not alphabetic SELECT U&'\\00C1\\00E1' !~ '[[:alpha:]]' COLLATE regress_builtin_c |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4d7bc756002d865622f8a702 | SELECT t1.* FROM test3cs t1 LEFT JOIN (SELECT DISTINCT x FROM test3cs) t2 ON t1.x = t2.x COLLATE case_insensitive ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4d7ef004dc5a804388309d0e | SELECT pg_get_logical_snapshot_meta('') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4d9d6ea394ca608dc54d2705 | SELECT * FROM test_null_ordered_named_pair() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4d9f7939f264ee10729c201a | SELECT explain_mask_costs($$ SELECT * FROM generate_series(1.0, 25.0, 'NaN'::NUMERIC) g(s);$$, false, true, false, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4da1485708c3a98124366b24 | SELECT * FROM test1cs t1, test3cs t2 WHERE t1.x = t2.x COLLATE case_insensitive ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4dca6b65e1639b8f290c864b | -- error SELECT injection_points_run('TestInjectionError', 'foobar2') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4debc27920f164102abcb771 | SELECT a.attname, s.stainherit, s.stanullfrac, s.stawidth, s.stadistinct, s.stakind1, s.stakind2, s.stakind3, s.stakind4, s.stakind5, s.staop1, s.staop2, s.staop3, s.staop4, s.staop5, s.stacoll1, s... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4e1e36276bbb14ffca37fd58 | SELECT * FROM tp1 ORDER BY id, valid_at |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4e395bc03939b1ec1d353131 | select 7328412092 - div(53705623790171816464 - 1, 7328412092) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4e881068ca2afb0963172afd | -- 0391 03A3 0391 SELECT lower('ἈΣ̓Α' COLLATE PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4e945214a660c432573c4d73 | select encode(decrypt(encrypt('foo', '0123456', 'aes-cfb'), '0123456', 'aes-cfb'), 'escape') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4ebda806f904536827957311 | -- unbounded: sequence would overrun the string! SELECT test_mblen_func('pg_mblen_unbounded', 'UTF8', truncated, 3) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4ec6b9f6d3084f19c33d1726 | SELECT GROUPING(b) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY a, b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4f3e676f1c353e74f9850b50 | SELECT pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', 'relpages', '171'::integer, 'nope', 10::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4f83485955a5b7858b7ca152 | select 'null'::jsonb::float4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 4fe1e5f71fddc551cccf767e | SELECT * FROM tp2 ORDER BY id, valid_at |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5070c47c92fd0cda700495c9 | select '[]'::jsonb -> -2147483648 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5076426a7cbcaf1ac1fd497c | SELECT WHERE 1 = ANY(ARRAY[1::int::bigint::int, 2::int::bigint::int]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 50ca38e06fba31f4a8b59c21 | -- _ versus two codepoints that form one grapheme: SELECT U&'\\0061\\0308bc' LIKE U&'_bc' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 50ec33b2abf444daa1ee22fb | -- Ensure the estimates match when step is decreasing SELECT explain_mask_costs($$ SELECT * FROM generate_series(TIMESTAMPTZ '2024-03-01', TIMESTAMPTZ '2024-02-01', INTERVAL '-1 day') g(s);$$, true... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 514bcae28ea5c9be00f1b565 | SELECT to_char(1234::int8, '99999V99') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 51b965c98fddd48cf1a47655 | SELECT * FROM test3cs t1, test3cs t2 WHERE t1.x = t2.x COLLATE case_insensitive ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5230ad6047e7615b8360cffc | select * from gtest32 t group by grouping sets (a, b, c, d, e) having c = 20 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 52370613067d0c18f77d00f6 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.25::real, 'most_common_vals', '{2,1}'::te... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 52824a1e3b2635958d7591ec | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'most_common_vals', '{2,1,3}'::text, 'most_common_freqs'... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 52c8177940244531c4479bd2 | SELECT * from id_alw3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 531a6321177db3177ce23853 | -- no SELECT has_table_privilege('regress_readallstats','pg_shmem_allocations_numa','SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 53575d2d56bbb50d5fdea3ad | SELECT x, count(*) FROM test3cs GROUP BY x HAVING x = 'abc' COLLATE case_sensitive |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 535ce9fb9274bdd7274bf11a | SELECT to_char('1236'::float8, 'rn') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 53d1ff2dd92f2e1302b877ba | SELECT pgp_pub_decrypt_bytea( '\\xc1c04c030000000000000000020800a46f5b9b1905b49457a6485474f71ed9b46c2527e1 da08e1f7871e12c3d38828f2076b984a595bf60f616599ca5729d547de06a258bfbbcd30 94a321e4668cd43010... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 547ee9de42bb7b325b7240be | SELECT * FROM ft1, ft4, ft5, local_tbl WHERE ft1.c1 = ft4.c1 AND ft1.c1 = ft5.c1 AND ft1.c2 = local_tbl.c1 AND ft1.c1 < 100 AND ft5.c1 < 100 FOR UPDATE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 54dea6a878b74872bda5c56a | SELECT * FROM rescan_bhs t1 LEFT JOIN rescan_bhs t2 ON t1.a IN (SELECT a FROM rescan_bhs t3 WHERE t2.a > 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 554ee14a27469e0b87226384 | select not a from (values(true)) t(a) group by rollup(not a) having not not a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 556a096e313e658bb8a41331 | select conrelid::regclass, contype, conname, (select attname from pg_attribute where attrelid = conrelid and attnum = conkey[1]), coninhcount, conislocal from pg_constraint where contype = 'n' and ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 55c78092b13b44f9cbbc5428 | SELECT DISTINCT ON (y, x) x, y FROM (select * from distinct_on_tbl order by x, z, y) s ORDER BY y, x, z |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 561d67ec1eddc8856847b9fa | SELECT t1.c, count(t2.c) FROM pagg_tab5 t1 JOIN pagg_tab6 t2 ON t1.c = t2.c AND t1.c = t2.b GROUP BY 1 ORDER BY t1.c COLLATE "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 564fa17b52da95bb64071df9 | SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE proname >= 'abs' AND (proname, proargtypes) <= ('abs', NULL) ORDER BY proname DESC, proargtypes DESC, pronamespace DESC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 56e07ecacb447e86c9427b3b | SELECT * FROM test_squash WHERE id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11) AND data = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5768294e99d764bf5371d615 | SELECT * FROM test_squash WHERE id IN (1::oid, 2::oid::int::oid) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 579565002a658d4c9fe41f2c | SELECT substring(truncated_with_nul, 4, 1) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 57f26f4989d8af150f864ac9 | -- However many layers of RelabelType there are, the list will be squashable. SELECT * FROM test_squash WHERE id IN (1::oid, 2::oid, 3::oid, 4::oid, 5::oid, 6::oid, 7::oid, 8::oid, 9::oid) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5802b5c4a5e44982dce43509 | SELECT regexp_replace(truncated_with_nul, '^caf(.)dcba$', '\\1') = test_bytea_to_text('\\xc300') FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5813113408fdd6f1a0bc0e34 | SELECT UPPER(U&'\\00E1' COLLATE regress_builtin_c) = U&'\\00E1' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 58475736f8b49687a3399f38 | SELECT xpath_list(article_xml::text, '/article/author\|/article/pages', '\|') FROM articles |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 585a051466635f2daeecf96a | SELECT thousand, tenthous FROM tenk1 WHERE thousand > -1 AND tenthous IN (1001,3000) ORDER BY thousand limit 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 585a05268b15bc436c0d34b8 | SELECT to_char('1234'::numeric, 'rn') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 589de7e987d4bd276f4ef460 | SELECT pg_get_logical_snapshot_meta(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 590b662c0a1874b8ee818c36 | SELECT to_char(1234::int8, '9.99eeee') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5938f0da45032a5fd2af3855 | SELECT count(*) FROM tenk1 WHERE hundred = 42 AND (thousand = 42 OR thousand = 99 OR tenthous < 2) OR thousand = 41 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 594a4508c6c6eee62536482a | -- not allowed SELECT a, c FROM gtest11 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 595775e5b61d4e7bb30f7169 | -- runs from cache SELECT injection_points_cached('TestInjectionLogLoad', NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5977b15c0e56ec7d4bf574f5 | SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE proname >= 'abs' AND (proname, proargtypes) < ('abs', NULL) ORDER BY proname, proargtypes, pronamespace |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5a0aaefd90e0f98511198e3e | SELECT condeferrable, condeferred, conenforced, convalidated FROM pg_constraint WHERE conname = 'fk_con' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5a2258a330c962e0c31b146e | -- no ordering operator tests SELECT array_sort('{1}'::xid[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5a3e92e0ec8a7b4bcd3186bf | -- show constraint info select conrelid::regclass, conname, contype, coninhcount, conislocal from pg_constraint where contype = 'n' and conrelid in ('inh_parent_1'::regclass, 'inh_parent_2'::regcla... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5aafef1b68d1e37f11c5af49 | SELECT a FROM pgss_schema_2.tab_search_diff_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5b01fd6ce63805222023c915 | -- error SELECT injection_points_run('TestInjectionError', NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5b9a42566a332bca3f865b0d | SELECT uuid_extract_timestamp('017F22E2-79B0-7CC3-98C4-DC0C0C07398F') = 'Tuesday, February 22, 2022 2:22:22.00 PM GMT+05:00' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5b9c1cce2c74f1079e1c061d | SELECT '42'::int_custom <= '100'::int_custom AS le_test |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5c3bd72a99c869808bb21cd2 | SELECT crypt('foox', '$6$Szzz0yzz') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5c4386189c7055b718412b3a | SELECT i AS interval, date_trunc('ago', i) FROM INFINITE_INTERVAL_TBL WHERE NOT isfinite(i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5c569caa8e5b9f7c13636db5 | SELECT ts_headline('english', 'foo barbar', to_tsquery('english', 'foo'), 'FragmentDelimiter=' \|\| repeat('x', 32768)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5cfedf48e1b3d2d8c5741d2d | SELECT to_char(q2, 'FMRN') FROM INT8_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5d15cb55e18cab59607e1cae | SELECT pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', 'reltuples', '500'::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5db8b15f7a210bdc058183bb | -- escape character at end of pattern SELECT 'foox' LIKE 'foo\\' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5dbd1e5ba99a7a50986d3bd7 | -- Backwards scan SELECT id FROM btree_tall_tbl WHERE id = 55 ORDER BY t DESC, id DESC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5df385f8b224c43086e6da04 | SELECT * FROM test_squash_cast WHERE data = ANY (ARRAY [1::int4::casttesttype, 2::int4::casttesttype, 3::int4::casttesttype, 4::int4::casttesttype, 5::int4::casttesttype, 6::int4::casttesttype, 7::... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5e17b932a5550396a480f1aa | SELECT injection_points_attach('hash-aggregate-single-partition', 'notice') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5e3ee559a6308054f5ded856 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', NULL, 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5eb40edd469ae94218221c62 | SELECT * from id_alw1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 5f0897aaa125c257ccfc1b9f | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'arange', 'inherited', false::boolean, 'null_frac', 0.32::real, 'most_common_elems', '{3,1}... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 60260925e30bbdd039aa9d48 | SELECT array_sort('{{"1 2","3 4"}, {"1 -2","-1 4"}}'::int2vector[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6030bb7b56c5a4f91e784c15 | -- doesn't match because \\00e4 doesn't match only \\0308 SELECT U&'\\0061\\0308bc' LIKE U&'_\\00e4bc' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 605958d6102b849959a95e2b | SELECT gamma(float8 '-1000.5') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 606e11a62ae985480e83a314 | SELECT 1 AS "int" OFFSET 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 60916bbac6924e27420bb52c | SELECT unique1, unique2 FROM onek_with_null WHERE unique1 = 500 ORDER BY unique2 DESC, unique1 DESC LIMIT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 60e2de6c91dc95aec3fba7db | -- tests with array_sort SELECT array_sort('{a,B}'::text[] COLLATE case_insensitive) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 61240b2cd4023235d8e26611 | SELECT 1 AS "int" LIMIT 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 61a46a429adaf821d2bd9fce | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'tags', 'inherited', false::boolean, 'null_frac', 0.34::real, 'most_common_elems', '{one,tw... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 61c2a60b0577b79c71878733 | -- 0391 0345 03A3 0345 -- test !Final_Sigma SELECT lower('Σ' COLLATE PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 61f292943bb552e1805d99eb | SELECT relpages FROM pg_class WHERE oid = 'stats_import.part_parent'::regclass |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 62339705460bea947e3dd8cf | SELECT * FROM test_squash WHERE id = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) AND data = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 625998c6b99cbd1af8790e11 | -- Invalid inputs SELECT pg_get_acl('pg_class'::regclass, 0, 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 627bdc577e527c61a73adaf2 | select encrypt('Lets try a longer message.', '0123456789', 'aes-cfb') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 62ea777784c5a2dd25481222 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'tags', 'inherited', false::boolean, 'null_frac', 0.35::real, 'most_common_elem_freqs', '{0... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6346e0672fe6674c6a5ec529 | select conname, contype, conkey from pg_constraint where conrelid = 'notnull_tbl1'::regclass |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 63855ed73c51a3e5a166aaf2 | SELECT conname, conenforced, convalidated FROM pg_constraint WHERE conrelid = 'fk_partitioned_pk'::regclass AND contype = 'f' ORDER BY oid::regclass::text |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 63a6199eda1ee39222966d30 | SELECT pg_clear_relation_stats('stats_import', 'test') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 640c5ae86ce2e8923da5c7f3 | select * from t t1, t t2 where exists (select 1 from t t3 where t1.a = t3.a and t2.b = t3.b and t3.a = 1 and t3.b = 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 64d2b2c4555275043d1cbdf2 | SELECT WHERE 1 IN (1, int4(1), int4(2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 656ab3ee6697d6662b3294fd | SELECT pg_catalog.pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'part_parent_i', 'relpages', 2::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 659fc7a3c413c2afd4259959 | SELECT has_largeobject_privilege('regress_priv_user2', 1007, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6628f38833f41e241f9383b1 | SELECT sum(unique1) over (ORDER BY four groups between 9223372036854775807 following and unbounded following), unique1, four FROM tenk1 WHERE unique1 < 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 66f08d2e724fe3773356f134 | SELECT 1 AS "int" OFFSET 1 FETCH FIRST 2 ROW ONLY |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 66f364172130589f29bfc4aa | SELECT injection_points_attach('hash-aggregate-spill-1000', 'notice') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 66f77d6bcf083a5b05a4669d | SELECT make_valid('2222222222221'::ean13) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 671d6e2da79d24fd8822bd38 | SELECT gist_translate_cmptype_btree(7) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 673a749987c355e3489bc109 | SELECT WHERE 1 IN (1::int::bigint::int, 2::int::bigint::int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 67416cbd678354f06743c676 | SELECT * FROM NE_CHECK_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 67420ce6e2eb70c9af1ba0d2 | SELECT explain_filter($$ EXPLAIN (DEBUG, COSTS OFF) SELECT genus, array_agg(name ORDER BY name) FROM vegetables GROUP BY genus $$) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 67679f9a534e449796c03ba1 | SELECT array_sort('{1.1,3.3,5.5,2.2,null,4.4,6.6}'::float8[], false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6789555c0b36cc0a9b65d7e8 | -- no error because no sort is required SELECT array_sort('{1,2,3}'::xid[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 68555bbbfdce594d88c32e2e | -- Rewritten as an ArrayExpr, so it will be squashed select where '1' IN ('1'::int, '2'::int) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 688539c097972c649a729623 | SELECT replace(b COLLATE ctest_nondet, U&'\\00E4b', 'X') FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 689ba5bebc724d6eed33f9c3 | SELECT crypt('a short string', '$6$rounds=123456$asaltof16chars..') = '$6$rounds=123456$asaltof16chars..$BtCwjqMJGx5hrJhZywWvt0RLE8uZ4oPwcelCjmw2kSYu.Ec6ycULevoBK25fs2xXgMNrCzIMVcgEJAstJeonj1' AS r... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 68a4e85e1f9c6eba1bb2dc32 | -- Levenshtein distance metric: exercise character length cache. SELECT U&"real\\00A7_name" FROM (select 1) AS x(real_name) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 690799d043024c5d4d9a8def | -- Corrupted compressed data. Set control bit with match tag where length -- nibble is 3 bytes (extended length), no data follows. SELECT test_pglz_decompress('\\x010f01'::bytea, 1024, false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 69b0e384b40252144bfc9156 | SELECT t1.* FROM test3cs t1 LEFT JOIN test3cs t2 ON t1.x = t2.x COLLATE case_insensitive ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 69c3aed897dcfd88974e34b1 | select q2, q1 from int8_tbl intersect select * from int8_tbl order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6a25545feca2c9ec47a93988 | select type, name, total_bytes > 0, total_nblocks, free_bytes > 0, free_chunks from pg_backend_memory_contexts where name = 'Caller tuples' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6a2ad05b5c487bf7c112efab | SELECT table_name, column_name, dependent_column FROM information_schema.column_column_usage WHERE table_schema = 'generated_stored_tests' ORDER BY 1, 2, 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6aaf1896ddce30065230d073 | SELECT 1 AS "int" LIMIT 1 OFFSET 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6ab6db92c9f7d930a54c453e | SELECT * FROM test_setof_as_set(2, null) ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6b45d1fe5c5ef860771d2001 | -- ok SELECT * FROM test12pk |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6b53b00fb3d448bffe9db6f4 | SELECT pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', 'relpages', 'nope'::text, 'reltuples', 400.0::real, 'relallvisible', 4::integer, 'relallfrozen', 3::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6b54cbeb66b79e0e31064540 | select conrelid::regclass, conname, conkey, coninhcount, conislocal, connoinherit from pg_constraint where contype = 'n' and conrelid::regclass::text in ('inh_nn1', 'inh_nn2', 'inh_nn3') order by 2, 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6becd14e517c7f4341c66223 | SELECT 1 AS "int" OFFSET 1 LIMIT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6bef9c34c0b2a91f600f95eb | SELECT has_largeobject_privilege(1004, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6bf6bf34556717ac7ce0eeba | SELECT a AS a1 FROM pgss_schema_2.tab_search_diff_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6c7f2cca7465ea58cc4b8091 | SELECT has_largeobject_privilege('regress_priv_user3', 1003, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6c83b6e99742cead84a0bf46 | SELECT array_sort('{1,3,5,2,4,6}'::int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6ca32959b61d64b37f0e6252 | select count(*) >= 0 as ok from pg_ls_summariesdir() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6d4fa083c24e45292239607a | -- 0030 03A3 SELECT lower('ΑΣΑ' COLLATE PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6d557fd690c8919a284ee7dc | select * from (select a, b from phv_boolpart) t where a is true group by grouping sets (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6da89599752787e3730f16a1 | select explain_analyze(' update ab_a1 set b = 3 from ab where ab.a = 1 and ab.a = ab_a1.a;') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6e317ce28b306647d991514c | -- array_sort with order and nullsfirst flag specified SELECT array_sort('{1.1,3.3,5.5,2.2,null,4.4,6.6}'::float8[], true, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6e3a608bcc33c2a3c0ba651a | SELECT x, count(*) FROM test3ci GROUP BY x HAVING upper(x) = 'ABC' COLLATE case_insensitive |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6e6432643852ea22a9b6028b | SELECT data FROM test_float WHERE data = ANY(ARRAY['1'::double precision, '2'::double precision]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6e8a608ac68c6eab4a28d7bf | select tcls1.somefunc(13) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6e8a8a0b1b63dee86796c6ad | select ss2.* from int8_tbl t1 left join (int8_tbl t2 left join (select coalesce(q1) as x, * from int8_tbl t3) ss1 on t2.q1 = ss1.q2 inner join lateral (select ss1.x as y, * from int8_tbl t4) ss2 on... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6f371343311f7b9f630e119b | -- but pg_stat_reset_backend_stats() does SELECT pg_stat_reset_backend_stats(pg_backend_pid()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6f3eed3dac6c223c8f0a5433 | WITH m AS ( MERGE INTO sq_target t USING sq_source s ON tid = sid WHEN MATCHED AND tid >= 2 THEN UPDATE SET balance = t.balance + delta WHEN NOT MATCHED THEN INSERT (balance, tid) VALUES (balance +... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6f5b696bea0c72335787a6cb | select 'null'::jsonb::bool |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6f947b89f4130d83cb7c9dca | SELECT COUNT(*), AVG(t1.twenty) FROM tenk1 t1 LEFT JOIN LATERAL (SELECT t1.two+1 AS c1, t2.unique1 AS c2 FROM tenk1 t2) s ON TRUE WHERE s.c1 = s.c2 AND t1.unique1 < 1000 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6fca11e2f7cecb29c91b0429 | -- Corrupted compressed data. Set control bit with read of a match tag, -- no data follows. SELECT length(test_pglz_decompress('\\x01'::bytea, 1024, false)) AS ctrl_only_len |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6fdddce1385f2a393f792b51 | SELECT to_number('M CC', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6fe9d925c1f481e37a211094 | -- ok SELECT * FROM gtestnn_parent ORDER BY f1, f2, f3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 6ffa9e1e5606925e94b2b107 | SELECT '=' !~ '[[:punct:]]' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 700fc6f9bdf0f24e033f5dcd | SELECT ARRAY[1, 2, 3, 4] |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7048c38159061fba25d680f5 | select a, a not in (1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint,8::myint) as not_hashed, a not in (1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint,8::myint,9::myin... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 705e0416895bf79de7c73e76 | select type, name, ident, level, total_bytes >= free_bytes from pg_backend_memory_contexts where level = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 71933c40f6867f2281b41b1d | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'version', 150000::integer, 'null_frac', 0.2::real, 'avg... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 71a4fe9abc3d7c7999b07192 | SELECT t1.unique1 FROM tenk1 t1 LEFT JOIN (SELECT *, 42 AS phv FROM tenk1 t2) ss ON t1.unique2 = ss.unique2 WHERE ss.unique1 = ss.phv AND t1.unique1 < 100 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 71f8831ed3786fd67eea596f | SELECT date_trunc( 'timezone', timestamp with time zone '2004-02-29 15:44:17.71393' ) AS notsupp_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7230d712bed09a47a7301a8a | select make_timestamp(1999, 12, 31, 24, 0, 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 72833518b6db4b01603636af | SELECT * FROM test_squash WHERE id = ANY(ARRAY[1::oid, 2::oid::int::oid]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 728434dee6ae29cb2dd005c7 | SELECT x, count(*) FROM test3ci GROUP BY x HAVING x = 'abc' COLLATE case_sensitive |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7284453dd9e78edbef524914 | SELECT 'abc' LIKE 'a\\bc' COLLATE ctest_det |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 73253d55f0e9574e5ade130b | SELECT * FROM test_setof_as_set(2, 'set') ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 734cb7eb7b2f017f7e0b6ade | SELECT to_number('', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 735aa33de15cab3c021c906b | select * from sj p where exists (select * from sj q where q.a = p.a and q.b < 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 738af7d007dd9eac82911495 | -- Round-trip with pglz: compress then decompress. SELECT test_pglz_decompress(test_pglz_compress( decode(repeat('abcd', 100), 'escape')), 400, false) = decode(repeat('abcd', 100), 'escape') AS rou... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 73d1f25bf2569fa81f1610e2 | WITH uuidts AS ( SELECT y, ts as ts, lag(ts) OVER (ORDER BY y) AS prev_ts FROM (SELECT y, uuid_extract_timestamp(uuidv7((y \|\| ' years')::interval)) AS ts FROM generate_series(1970 - extract(year fr... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 73ed3045f24d30e1d3582457 | select timestamp '1999-12-31 24:00:00' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7407a7b1448c93fa4dc9dd9a | SELECT lgamma(float8 '1000') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 749215712380d26ff2fafaad | SELECT i AS interval, date_trunc('week', i) FROM INFINITE_INTERVAL_TBL WHERE NOT isfinite(i) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 74b1eb6eae2c0bdcf7755047 | SELECT 'Δ' ~* '[γ-λ]' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 74b2bc52625e316057b660b4 | SELECT pg_get_logical_snapshot_info('0--40796E18.snap') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 74bb940dff88e20fa8853ad3 | select * from aitest |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 74e35d059dee51b64039d8b7 | SELECT unique1 FROM tenk1 WHERE unique1 IS NULL AND unique1 IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 75afe5fc90bc240510e9f88b | SELECT * FROM temporal_rng3 ORDER BY id, valid_at |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 76571c760f5e6e9caf2f8c94 | -- test Final_Sigma SELECT lower('ΑΣ' COLLATE PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7683f1b16bbf75c7985e11d6 | SELECT tableoid::regclass, * FROM gtest_child2 ORDER BY 1, 2, 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7684dd0d9ad4e6d8339978f8 | SELECT '@' !~ '[[:alnum:]]' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 769fa336a2de69d237019edd | -- notice SELECT injection_points_run('TestInjectionLog2', NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 76e420990b41b9a97617d211 | SELECT unnest(pg_get_acl('pg_class'::regclass, 'atest5'::regclass::oid, 1)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 774d1e14de9eacb81e0fbb6d | SELECT lgamma(float8 '1e308') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 776135fc3925d926b7cf9ce2 | -- whole-row reference SELECT a, (SELECT gtest1.b) FROM gtest1 ORDER BY a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7766eb5e4e838d6a4a87bc70 | select t1.a, s.a from t_append t1 left join t_append t2 on t1.a = t2.b join lateral ( select t1.a as a union all select t2.a as a ) s on true where s.a is not null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 77784be7c054ffe146e4f244 | SELECT * FROM pg_buffercache_evict_relation(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 77ce1641d24c207c129a234f | -- Since the remote server is still connected, "closed" should be FALSE, -- or NULL if the connection status check is not available. -- In this test, the remote backend handling this connection sho... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7874c96d02186664028737a6 | -- LIMIT and OFFSET patterns -- Try some query permutations which once produced identical query IDs SELECT 1 AS "int" LIMIT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 788100d3fc2a2129ccceb1b3 | SELECT pg_catalog.pg_restore_relation_stats( 'schemaname', 3.6::float, 'relname', 'test', 'relpages', 17::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 78b76d97c441a836728e117b | select jsonb_strip_nulls('[1,{"a":1,"b":null,"c":2},3]', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 78bcfef0b5ff220bbdb6fa44 | -- true SELECT has_largeobject_privilege('regress_priv_user2', 1010, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 78bf336fcef3e91fa5509d42 | SELECT WHERE 1 IN (1, int4(1), int4(2), 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7935a42185cd4fc680089783 | SELECT crypt('the minimum number is still observed', '$5$rounds=10$roundstoolow') = '$5$rounds=1000$roundstoolow$yfvwcWrQ8l/K0DAWyuPMDNHpIVlTQebY9l/gL972bIC' AS result |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 795630730a3ae60b93cbbe08 | SELECT has_function_privilege('regress_pg_logicalinspect', 'pg_get_logical_snapshot_meta(text)', 'EXECUTE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7991297ad61115d38f59889e | SELECT to_timestamp('2011-12-18 00:00 LMT', 'YYYY-MM-DD HH24:MI TZ') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 79bf2e25acf336ae5f4c3091 | SELECT xpath_list(article_xml::text, '/article/author\|/article/pages') FROM articles |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7a53c455cd2637f6c521a00f | SELECT gist_translate_cmptype_common(3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7a9812f38cb72575fff92059 | SELECT create_and_insert() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7b2e434dd43032df863c970b | SELECT pg_get_logical_snapshot_meta('0/40796E18.snap') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7b8090f3f66ee2d2b3115340 | SELECT ((composite_f(array[1, 2, 3]))).*, 1, 2, 3, ((composite_f(array[1, 2, 3]))).*, 1, 2 FROM test_composite WHERE x IN (1, 2, 3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7bb838490e220f5bb3770305 | SELECT unique1 FROM tenk1 WHERE unique1 = ANY('{NULL,NULL,NULL}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7c2302ac88061612a9cbba2e | SELECT min(row(b,a)) FROM aggtest |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7cadff0474eab00a993e6a22 | SELECT * FROM test_squash WHERE id = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9]) AND data = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7cbd91f62deb73ae343901ad | SELECT * FROM tenk1 WHERE thousand = 42 AND (tenthous = 1 OR tenthous = 3 OR tenthous = 42 OR tenthous = 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7cc05f912c4e53ae3cc42e74 | SELECT lgamma(float8 '0') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7d77ba8a0ca7db0485b1847d | select json_strip_nulls('"a string"', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7dba235d75d3174ccf69341f | SELECT x, gamma(x), lgamma(x) FROM (VALUES (0.5), (1), (2), (3), (4), (5), (float8 'infinity'), (float8 'nan')) AS t(x) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7dcf69e2c9e4585b72b7bb6d | SELECT 1, 2, (ROW(ARRAY[1, 2], ARRAY[1, 2, 3])).*, 3, 4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7e27bb46b3dff6a2247c5c0e | -- Table owner bypasses RLS select rls_f(c) from test_t order by rls_f |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7e6fd62ceff923ccd78da6da | SELECT gamma(float8 '-1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7f71478b3bd92ad5113fae1f | SELECT pg_catalog.pg_clear_attribute_stats( schemaname => 'stats_import', relname => 'test', attname => 'arange', inherited => false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7f72fec61e6e49abd28ca139 | SELECT to_number(' XIV', ' RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 7fa09eb835e0a61dd78bb00b | -- These shouldn't fail SELECT buffer_evicted IS NOT NULL FROM pg_buffercache_evict(1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 800e8f7b36a184b2803b6b84 | SELECT thousand, tenthous FROM tenk1 WHERE thousand > 995 and tenthous in (998, 999) ORDER BY thousand desc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 809569008d6352d88f88dbdf | SELECT injection_points_attach('typecache-before-rel-type-cache-insert', 'error') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 80c2d10250a9167be5b0704f | -- array_sort SELECT array_sort('{}'::int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 814604e1403558d9bf3dad95 | SELECT pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', 'version', 150000::integer, 'relallfrozen', 3::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 81869e00941ba13ee22b9bc3 | SELECT pg_catalog.pg_clear_relation_stats(schemaname => 'stats_import', relname => 'testview') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 81d821f5c91e81be555f698e | -- No triggers SELECT conname, tgrelid::regclass as tgrel, regexp_replace(tgname, '[0-9]+', 'N') as tgname, tgtype FROM pg_trigger t JOIN pg_constraint c ON (t.tgconstraint = c.oid) WHERE tgrelid I... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 821322a10b808581f88cb5b1 | SELECT * FROM information_schema.table_privileges t WHERE grantor LIKE 'regress_grantor%' ORDER BY ROW(t.*) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8224e81d04e8a0344f368b0a | SELECT * FROM test_squash WHERE id IN (@ '-1', @ '-2', @ '-3', @ '-4', @ '-5', @ '-6', @ '-7', @ '-8', @ '-9') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 82a61a814e1afce47c69a4e1 | SELECT c AS cidr, set_masklen(cidr(text(c)), -1) AS "set_masklen(cidr)", i AS inet, set_masklen(inet(text(i)), -1) AS "set_masklen(inet)" FROM INET_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 82ac4b1b4a5e715202a79f8e | SELECT t1.a, t1.c, t2.b, t2.c FROM prt1 t1, prt2 t2 WHERE t1.a = t2.a AND t1.a = t2.b ORDER BY t1.a, t2.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 82bafd58bd2aef055ea75c16 | SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE (proname, proargtypes) > ('abs', NULL) AND proname <= 'abs' ORDER BY proname DESC, proargtypes DESC, pronamespace DESC |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 82e3ae5d74ac85e02f40c59d | SELECT relpages, reltuples, relallvisible, relallfrozen FROM pg_class WHERE oid = 'stats_import.test_i'::regclass |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 82ea0d4d11d9121676ae5480 | SELECT * FROM pg_buffercache_evict_relation('temp_pg_buffercache') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 82fd8cc7c7206af743448cd1 | SELECT * FROM temporal_mltrng ORDER BY id, valid_at |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8332480ad4c70a9ed4ab11ef | -- should fail, too many buffers pinned SELECT test_temp_pin(10, 105) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 83ca9d8dfdf146c0d9872cb3 | select raw_flags, t_bits, t_data from heap_page_items(get_raw_page('test9s', 0)), lateral heap_tuple_infomask_flags(t_infomask, t_infomask2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 83d0856132368dd5983b3518 | SELECT pid FROM remote_backend_pid |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 842775953b67eb37944ee06e | SELECT last_value(unique1) over (ORDER BY four rows between current row and 9223372036854775807 following exclude current row), unique1, four FROM tenk1 WHERE unique1 < 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 84586b82075db2774160e387 | SELECT * FROM test_squash WHERE id IN (1, 2, 3, 4, 5, 6, 7, 8, 9) AND data IN (1, 2, 3, 4, 5, 6, 7, 8, 9) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 845e9d14a6aa09b8e3596976 | -- List all the existing cached connections. loopback and loopback3 -- should be output as invalid connections. Also the server name and user name -- for loopback3 should be NULL because both serve... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8467ecd1dc2412f744ce7d8b | SELECT shobj_description('regress_hasprivs'::regrole, 'pg_authid') IS NOT NULL AS has_comment |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 84d4668950a871b58d1f4ae5 | SELECT functest_srf0() LIMIT 5 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 85304525fc72d2264fd8d265 | -- false SELECT has_largeobject_privilege('regress_priv_user3', 1005, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 856f505b0e952f1646846007 | SELECT count(*) FROM tenk1 WHERE thousand = 42 AND (tenthous = 1 OR tenthous = 3) OR thousand = 41 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 85733bc3ba9fc95abd21daf2 | SELECT pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', 'version', 150000::integer, 'relpages', '-17'::integer, 'reltuples', 400::real, 'relallvisible', 4::integer, 'rela... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 85a535f34fd6195726c3993b | -- pg_replication_origin.roname limit SELECT pg_replication_origin_create('regress_' \|\| repeat('a', 505)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 85b342d53f5d728219990242 | select explain_filter('explain (memory, analyze, buffers off) select * from int8_tbl i8') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 85b9498a357488cc591e22ec | SELECT pg_get_logical_snapshot_info('../snapshots') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 85bf20530bdc943f13ff5a4e | SELECT '1912-01-01 00:00'::timestamptz |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 85eaa6463ab27d58e08a7840 | -- symbols are not punctuation SELECT 'a8a' ~ '[[:digit:]]' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 860bb7ddbc099a89c712663e | SELECT a, b FROM pgss_schema_1.tab_search_same |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 864a5b6e5e6eb77d6ad4cf3b | SELECT has_largeobject_privilege('regress_priv_user3', 1001, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 879f43165e47f5a41869f312 | -- test replace() at the end of the string (bug #19341) SELECT replace('testX' COLLATE case_insensitive, 'x' COLLATE case_insensitive, 'er') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 87b27960a250576e1255fa44 | -- exercise the deduplication code of a UNION with mixed input slot types WITH RECURSIVE subdepartment AS ( -- select all columns to prevent projection SELECT id, parent_department, name FROM depar... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 883c0f40b0088ecf37a7eb16 | select test from copytest2 order by test collate "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8887f6a63817f6968210a217 | SELECT '(1)'::t |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 88e16a031746378c65480b00 | select explain_filter('explain (analyze,buffers off,costs off) select sum(n) over() from generate_series(1,2500) a(n)') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 88fbfc66ddd7565653061eb6 | SELECT obj_description('six'::regclass, 'pg_class') IS NULL AS six_comment_is_null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 890d073d0307157ffdc4eb49 | select explain_analyze(' update ab_a1 set b = 3 from ab_a2 where ab_a2.b = (select 1);') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 896395b3f957f44e84686584 | SELECT explain_mask_costs($$ SELECT * FROM generate_series(25.0, 2.0, 0.0) g(s);$$, false, true, false, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 89a919591ca262bf3d7ae1f7 | SELECT pg_get_indexdef(conindid, 0, true) FROM pg_constraint WHERE conname = 'temporal_rng2_pk' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 89c7f824973499d9e3c0fd5b | SELECT gin_index_check('gin_check_multicolumn_idx') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8a78b1b2c661924a178c7b00 | SELECT array_sort('{1.1,3.3,5.5,2.2,null,4.4,6.6}'::float8[], true, false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8a8f574420aabffd18abf1f4 | SELECT ARRAY[1] |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8aa54e2ada825c31a42f8aee | SELECT explain_filter($$ EXPLAIN (DEBUG, RANGE_TABLE, COSTS OFF) SELECT genus, array_agg(name ORDER BY name) FROM vegetables GROUP BY genus $$) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8ab496a223abedf7c17ca3a3 | select tcls2.somefunc(12) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8b3a4da6cba4556686fdb1c5 | select t1.q1, x from int8_tbl t1 left join (int8_tbl t2 inner join lateral (select t2.q1+1 as x, * from int8_tbl t3) t3 on t2.q2 = t3.q2) on t1.q2 = t2.q2 order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8bb704cc10e75cf6835b8e35 | select sum(t2.b) over (partition by t2.a), sum(t2.c) over (partition by t2.a), sum(t2.d) over (partition by t2.a) from gtest32 as t1 left join gtest32 as t2 on (t1.a = t2.a) order by t1.a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8bc1b22db475665885dfe95f | SELECT * FROM temporal_mltrng3 ORDER BY id, valid_at |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8bd0299c1e2a668d728cc785 | select jsonb_strip_nulls('null', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8beee78476bd92b6c63cace3 | SELECT unique1, unique2 FROM onek_with_null ORDER BY unique2 DESC LIMIT 5 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8c36bd08553570278f1b4dd3 | SELECT COUNT(*) FROM tenk1 t1, tenk1 t2 WHERE t2.thousand = t1.tenthous OR t2.thousand = t1.unique1 OR t2.thousand = t1.unique2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8c38bec91fb1fa5651b7ba29 | -- notice SELECT injection_points_run('TestInjectionLog2', 'foobar') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8d85114ca20d742b4745fde4 | SELECT to_number('IL', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8de7468592b13ee30909a7fa | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'arange', 'inherited', false::boolean, 'range_empty_frac', 0.5::real, 'range_length_histogr... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8e94d1a42515bb6559645073 | -- null SELECT pg_get_acl(0, 0, 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8eab046228c2ccaea0a51067 | select conrelid::regclass, conname, contype, coninhcount, conislocal from pg_constraint where conrelid::regclass::text in ('inh_parent', 'inh_child', 'inh_child2', 'inh_child3') order by 2, 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8f75b7e5cd0fa6ba1ed7d050 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'tags', 'inherited', false::boolean, 'most_common_elems', '{one,three}'::text, 'most_common... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 8fd81e9ff67fbd673b66477d | SELECT relpages, reltuples, relallvisible FROM pg_class WHERE oid = 'stats_import.test'::regclass |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 90256a898c453094e8d543c5 | SELECT pg_catalog.pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'testseq') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 902648383cc982e460a7ae34 | SELECT to_char('100e9'::numeric, 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 902d5499b237c17eb765251e | SELECT test_pglz_decompress(test_pglz_compress( decode(repeat('abcd', 100), 'escape')), 400, true) = decode(repeat('abcd', 100), 'escape') AS roundtrip_ok |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 90325d79f1c8ff9ffc10beaa | -- trailing % matches zero (with previous %): SELECT U&'\\0061\\0308bc' LIKE U&'\\00E4%c%' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9035f8ae8358a22f719083b8 | select t1.q1, x from int8_tbl t1 left join (int8_tbl t2 left join lateral (select t2.q1+1 as x, * from int8_tbl t3) t3 on t2.q2 = t3.q2) on t1.q2 = t2.q2 order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 904c1162efecb60b55595f30 | SELECT alter_and_insert() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 91047f737c610360a1435c8d | SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE (proname, proargtypes) >= ('abs', NULL) AND proname <= 'abs' ORDER BY proname, proargtypes, pronamespace |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 912f8e47a3d7e2847a8b34f9 | SELECT to_number('CM', 'RNRN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 91a596196f6b431afbb715a4 | SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND (j1.a*j1.c/3) = (random()/3 + 3)::int AND (random()/3 + 3)::int = (j2.a*j2.c/3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 91b8e24e5e217ddab0eaee9f | SELECT * FROM test_setof_as_set(1, 'set') ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 91fb65baaa0be2d25fca0f7d | -- -- Test the SupportRequestRows support function for generate_series_timestamp() -- -- Ensure the row estimate matches the actual rows SELECT explain_mask_costs($$ SELECT * FROM generate_series(T... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9272a5136d8c95ace5155f97 | SELECT r.rolname, ss.queryid <> 0 AS queryid_bool, ss.query, ss.calls, ss.rows FROM pg_stat_statements ss JOIN pg_roles r ON ss.userid = r.oid ORDER BY r.rolname, ss.query COLLATE "C", ss.calls, ss... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 92e7b14b71fe8c90418511f5 | SELECT to_number('VV', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9319bcc2ac22f2452c64da7c | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', NULL::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 933e1718d27ab32e59919c93 | select '12345'::jsonb::int2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9348792a9755c9c72541328e | SELECT t4.* FROM (SELECT t1.*, t2.a AS a1 FROM sj t1, sj t2 WHERE t1.b = t2.b) AS t3 JOIN sj t4 ON (t4.a = t3.a) WHERE t3.a1 = 42 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9398ba4383517b1c1c297fc4 | SELECT DISTINCT y, x FROM distinct_tbl limit 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 93d905cc413a6a1b155780ac | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'tags', 'inherited', false::boolean, 'null_frac', 0.26::real, 'elem_count_histogram', '{1,1... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9409db96cf28b72365b46999 | select t1.a from gtest32 t1 left join gtest32 t2 on t1.a = t2.a where coalesce(t2.b, 1) = 2 or t1.a is null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 945b7c5484c195febc5260e6 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.24::real, 'most_common_vals', '{2,1,3}'::... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 95097afe7388d90b08920519 | -- 0391 0343 03A3 0343 0391 SELECT lower('ᾼΣͅΑ' COLLATE PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 95943e2dbb2b90e1b0c68863 | SELECT lower('AbCd 123 #$% ıiIİ ẞ ß Ǆǅǆ Σσς' COLLATE "en-x-icu") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 95b3939c8063493430f3aaa6 | SELECT array_sort('{1.1,3.3,5.5,2.2,null,4.4,6.6}'::float8[], false, false) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 95d07fa0de474013a2345c06 | SELECT substring(truncated, 1, 3) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9685f2b8987ad62e9fdaf33c | SELECT lgamma(float8 '-1000.5') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 96883b79e7af144017026dfd | SELECT i AS inet, hostmask(i) AS "hostmask(inet)" FROM INET_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 96b963d5316a0032a22bc8ad | SELECT to_char('1235'::float4, 'rn') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 96fc3cc3b36e8bd625d67a85 | SELECT has_table_privilege('regress_readallstats','pg_aios','SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9715fb19fa96b11ca45b11bf | SELECT relpages FROM pg_class WHERE oid = 'stats_import.part_parent_i'::regclass |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9723a0a58329dd42d38ed9d7 | SELECT pg_get_logical_snapshot_info('../snapshots/0-40796E18.snap') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 976208a53e13223c3244b898 | SELECT * FROM test_squash a, test_squash b WHERE a.id = ANY (array[1, ((b.id + b.id * 2)), 5]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 977cf2f54ea2255cf6b64a09 | SELECT count(*) FROM tenk1 WHERE hundred = 42 AND (thousand = 42 OR thousand = 41 OR thousand = 99 AND tenthous = 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 97f1ab118b364ad0a19c45f7 | SELECT * FROM tenk1 WHERE thousand = 42 AND (tenthous = 1 OR tenthous = (SELECT 1 + 2) OR tenthous = 42) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 97f3fbae0ed63b00d5d453f2 | -- runs from cache SELECT injection_points_run('TestInjectionLogLoad') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9815962c3dc66cfb1b696c70 | select * from (select a, b from phv_part) t where a is null group by grouping sets (a, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 981d056fbf744f89b1cb26c5 | -- variable-offset abbreviation SELECT date_trunc('timezone', timestamp with time zone 'infinity', 'GMT') AS notsupp_zone_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 98604f59a15cfdf184cef99c | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'pg_temp', 'relname', 'stats_temp', 'attname', 'i', 'inherited', false::boolean, 'null_frac', 0.0123::real ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 989a7ab74a001e5bf8e33f29 | select array[]::int2vector |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 98aac3c3971c9b762b19b291 | -- -- Checks for invalid objects -- -- Keep this list in the same order as getObjectIdentityParts() -- in objectaddress.c. WITH objects (classid, objid, objsubid) AS (VALUES ('pg_class'::regclass, ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 995bae99eaf2b8664e91a723 | SELECT * FROM test_squash_numeric WHERE data = ANY(ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 99a5887fcfc2ac4724f8cfba | -- Ensure we get the default row estimate for infinity values SELECT explain_mask_costs($$ SELECT * FROM generate_series(TIMESTAMPTZ '-infinity', TIMESTAMPTZ 'infinity', INTERVAL '1 day') g(s);$$, ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 99f22f43ea25291434999218 | SELECT ((composite_f(array[1, 2, 3]))).* FROM test_composite |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9a20b33357d176e7390439c4 | SELECT to_char(q2, '9999999999999999PL') FROM INT8_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9a58664e52f2f5ee418f48fd | select a, b, count(*) from gstest2 group by rollup(a), b having b > 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9a72524ba2d44296b27b3643 | SELECT x, count(*) FROM test3ci GROUP BY x HAVING upper(x COLLATE case_sensitive) COLLATE case_insensitive = 'ABC' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9a84717bba4f08660e6e6de1 | -- jsonb_strip_nulls (strip_in_arrays=true) select jsonb_strip_nulls(null, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9b489fa99c205c1a1c8b348f | select conrelid::regclass, conname, contype, conkey, coninhcount, conislocal, connoinherit from pg_constraint where contype in ('n','p') and conrelid::regclass::text in ('inh_child', 'inh_parent1',... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9b5c9ae1465f7a39415541bb | -- Schema qualifications SELECT count(*) FROM pgss_schema_1.tab_search_same |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9b92f144973f3630b36ed465 | SELECT x, count(*) FROM test3ci GROUP BY x HAVING x = 'abc' COLLATE case_sensitive OR x = 'def' COLLATE case_sensitive ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9b9dc8a7e1f8bc39ded7834e | SELECT count(*) FROM tenk1 t1 WHERE t1.thousand = 42 OR t1.thousand = (SELECT t2.tenthous FROM tenk1 t2 WHERE t2.thousand = t1.tenthous + 1 LIMIT 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9c1bdc756baf32ffb6f41e57 | with a as ( select id from (values (1), (2)) as v(id) ), b as ( select max((select sum(id) from a)) as agg ) select agg from b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9c290d5e72df885da118cd1b | select grouping((select t1.v from gstest5 t2 where id = t1.id)), (select t1.v from gstest5 t2 where id = t1.id) as s from gstest5 t1 group by grouping sets(v, s) order by case when grouping((select... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9c5228f437c37d5107c0c55a | -- Ensure an empty range estimates 1 row SELECT explain_mask_costs($$ SELECT * FROM generate_series(TIMESTAMPTZ '2024-03-01', TIMESTAMPTZ '2024-02-01', INTERVAL '1 day') g(s);$$, true, true, false,... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9ca96273d96caf3f7038ae4d | -- As above but with non-default step SELECT explain_mask_costs($$ SELECT * FROM generate_series(1.0, 25.0, 2.0) g(s);$$, true, true, false, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9cc2877eb5500c0a206cf670 | -- yes SELECT has_largeobject_privilege('regress_priv_user6', 1008, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9cd335666198432dc675d438 | -- test overflow frame specifications SELECT sum(unique1) over (rows between current row and 9223372036854775807 following exclude current row), unique1, four FROM tenk1 WHERE unique1 < 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9cd3b137a8845042bac679bc | select digest(pgp_sym_decrypt_bytea(dearmor(' -----BEGIN PGP MESSAGE----- Comment: dat3.aes.sha1.mdc.s2k3.z0 jA0EBwMCxQvxJZ3G/HRg0lgBeYmTa7/uDAjPyFwSX4CYBgpZWVn/JS8JzILrcWF8 gFnkUKIE0PSaYFp+Yi1VlRf... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9d0cdfb35ac152a272a12677 | SELECT * FROM test6 WHERE b LIKE 'zyäbc' COLLATE ctest_det |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9d27925a456f09b26436b989 | SELECT COUNT(*) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9dcc1686c6d41c1c1d8513d3 | select t1.a from gtest32 t1 left join gtest32 t2 on t1.a = t2.a where coalesce(t2.b, 1) = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9e66fdb34bb01ad1e0495ed6 | SELECT JSON_QUERY(jsonb '{"a": 123}', ('$' \|\| '.' \|\| 'a' \|\| NULL)::date WITH WRAPPER) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9eda03bb90fa2018338cd107 | SELECT substring(with_nul, 4, 1) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9ef76110760b4a645060c0fa | SELECT gamma(float8 '0') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9f73bc85ec3bc09190ad422e | SELECT pg_get_logical_snapshot_info('0/40796E18.snap') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9f7c440fb1d6a018ead5b5b2 | SELECT 'xyz' !~ '[[:upper:]]' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | 9fc9de3f17c84ef87abc4b56 | SELECT test_mblen_func('pg_mblen_range', 'UTF8', truncated, 3) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a0228dcd36550f2ffcb46038 | SELECT substring(truncated, 1, 4) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a058890449770ba8a9982897 | select '"hello"'::jsonb::int2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a05d1b33488dd496f9108b4d | SELECT unnest(pg_get_acl('pg_class'::regclass, 'atest2'::regclass::oid, 0)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a0bb8770445eed3739dd549b | select 'null'::jsonb::int2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a0e0e359bd415fedd4f5ac95 | SELECT lo_oid(1::lo) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a114f2e299f29d75cce21e04 | SELECT date_trunc( 'ago', timestamp with time zone 'infinity' ) AS invalid_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a1a9f8e46ccf05f5c11a9449 | select encode(decrypt(encrypt('foo', '0123456', 'aes-cfb') \|\| '\\x00'::bytea, '0123456', 'aes-cfb'), 'escape') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a1e10d9a5a3aa76a9b512013 | select jsonb '[1,2,3,{"b": [3,4,5]}]' @? 'strict $.*' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a1e389efe24416b9438240ed | TABLE ddl_test |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a2a68a9a5ea469d6769d6344 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'nope', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a30588074b2c281c85ce5c7f | SELECT * FROM test_squash WHERE id = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) AND data = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a317cbabf7d8aa7b52a64768 | SELECT injection_points_attach('hash-aggregate-process-batch', 'notice') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a36f9bee792dc1312147caf6 | SELECT * FROM test3cs t1 WHERE EXISTS (SELECT 1 FROM test3cs t2 WHERE t1.x = t2.x COLLATE case_insensitive) ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a41ceae2841010979aa5be34 | -- Ensure the estimates match when step is decreasing SELECT explain_mask_costs($$ SELECT * FROM generate_series(25.0, 1.0, -1.0) g(s);$$, true, true, false, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a4660663c280728cfd6743f1 | SELECT encrypt( '\\x0011223344', '\\x000102030405060708090a0b0c0d0e0f10111213', 'aes-cfb') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a48cdb66b5951ed53b09660c | SELECT setseed(1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a523ae80c7a2628b3c99a5ed | SELECT i AS inet, netmask(i) AS "netmask(inet)" FROM INET_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a535698cf9fa8ea7e225c1a6 | SELECT relname, last_analyze IS NOT NULL AS analyzed, last_vacuum IS NOT NULL AS vacuumed FROM pg_stat_user_tables WHERE relid IN ('only_parted'::regclass, 'only_parted1'::regclass) ORDER BY relname |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a68391865b07e0ece60562da | SELECT a, b, replace(b COLLATE ignore_accents, 'co', 'ma') FROM test4nfd |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a6be50f8effd76a15a16b5eb | SELECT * FROM test_squash_bigint WHERE data IN (1::bigint, 2::bigint, 3::bigint, 4::bigint, 5::bigint, 6::bigint, 7::bigint, 8::bigint, 9::bigint, 10::bigint, 11::bigint) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a6d0dc318a87af3bdf28f748 | SELECT lgamma(float8 '-1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a6f2e89dbef94e83ad669bf5 | SELECT * FROM test_squash WHERE id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11) AND data IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a74c9f76f5dd3a391a627d35 | SELECT SUBSTRING(c FROM 4001 FOR 1) FROM toast_3b_utf8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a8986919a0b6e44bad1d7f0a | SELECT 'val5', 'val6' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a89ba50fffe6fda656efdd0e | SELECT * FROM test3cs t1 WHERE EXISTS (SELECT 1 FROM (SELECT DISTINCT x FROM test3cs) t2 WHERE t1.x = t2.x COLLATE case_insensitive) ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a8d6bde3792290d2aa0f2fe2 | SELECT array_sort('{a,B}'::text[] COLLATE "C") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a8ec1a4a238f32c4da04034e | SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE (proname, pronamespace) > ('abs', 0) ORDER BY proname, proargtypes, pronamespace LIMIT 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a9107cd07c0a7095999200b2 | SELECT 'abc' LIKE 'a\\bc' COLLATE ctest_nondet |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a91ee673264414a3d6b8cb5e | SELECT * FROM temporal_rng ORDER BY id, valid_at |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a943d0229b4ec1b59e836b2b | SELECT timestamp with time zone 'J2452271 T X03456-08' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | a94779434ecc0ce0bb1be835 | SELECT a, b FROM groupby_collation_t GROUP BY a, b ORDER BY a, b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | aa93148d6c78d225746dd8dc | SELECT * FROM test6 WHERE b = 'zyäbc' COLLATE ctest_nondet |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | aae16bceda06c01d040c2fbd | -- Child constraint will remain valid. SELECT conname, convalidated, conrelid::regclass FROM pg_constraint WHERE conrelid::regclass::text like 'fk_partitioned_fk%' ORDER BY oid::regclass::text |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | aaf272aca198e032b1396e96 | SELECT to_number('CLXC', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ab48771a4b912421aada1387 | SELECT * from id_alw4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ab82885f934b2cf970afce04 | SELECT * FROM test_squash WHERE id IN (1 + 1, 2 + 2, 3 + 3, 4 + 4, 5 + 5, 6 + 6, 7 + 7, 8 + 8, 9 + 9) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | abd96456f4b820b7def1cf97 | SELECT explain_memoize(' SELECT COUNT(*), AVG(t1.twenty) FROM tenk1 t1 LEFT JOIN LATERAL (SELECT t1.twenty AS c1, t2.unique1 AS c2, t2.two FROM tenk1 t2) s ON t1.two = s.two WHERE s.c1 = s.c2 AND t... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | abf001f5417640233464acdd | select jsonb '[1,2,3]' @? '$.*' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ac2eb9f11aa80e61abafcded | SELECT replace(b COLLATE ctest_det, U&'\\00E4b', 'X') FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ac369b3d5f508049177af880 | select jsonb_delete_path('{"a":[]}', '{"a",-2147483648}') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ac38c270122c216fb2bb0da5 | SELECT * FROM test_squash_numeric WHERE data IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ac419811adac755530461f75 | select * from tbl_rs t1 join lateral (select * from tbl_rs t2 where t2.a in (select t1.a+t3.a from tbl_rs t3) and t2.a < 5) on true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ac926c3149eb617a1d79d93a | -- 0391 0343 03A3 0343 SELECT lower('ᾼΣͅ' COLLATE PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | accb59b65ce91d4f736e74af | SELECT to_timestamp('1000000000,999', 'Y,YYY') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ad74a5a3309db20ccca40560 | SELECT to_char('100e9'::float4, 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | adeb977dfefc6d0afa2e7d70 | SELECT gamma(float8 '-infinity') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ae3c05629b8c5fd7f05b3e85 | SELECT to_number('XIXL', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ae4bdd0ad1c51587142f96ed | SELECT DISTINCT y, x FROM (SELECT * FROM distinct_tbl ORDER BY x) s |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ae7c25673ddcd6cb7c5f6235 | SELECT * FROM gtestx |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | aeb4e821d0ede06cd7b5bcd5 | select explain_filter('explain (analyze,buffers off,serialize) create temp table explain_temp as select * from int8_tbl i8') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | aeb8c394796c4cded691afc9 | SELECT GROUPING(a) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | aee8bdc3c75e5909a6412466 | -- Test constants evaluation in a CTE, which was causing issues in the past WITH cte AS ( SELECT 'const' as const FROM test_squash ) SELECT ARRAY['a', 'b', 'c', const::varchar] AS result FROM cte |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | aef950f1e92c0a98ab7a2ddf | SELECT regexp_replace(good, '^caf(.)$', '\\1') FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | af4a430bb8ad45c19b3e0b4f | SELECT set_masklen(cidr(text(c)), 33) FROM INET_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | afebddfbf28f6429aa73702a | SELECT to_char(-1234::int8, '9.99eeee') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | aff0a909dc8495087d195c28 | SELECT has_largeobject_privilege(1001, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b05db4b72ce919accb56db8a | select x, y from (select four as x, four as y from tenk1) as t group by grouping sets (x, y) having y is null order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b0727a549302fd7ba596a31b | SELECT count(*) FROM pgss_schema_2.tab_search_diff_1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b09e88c14d2ae51d3baa933e | -- should work, below max SELECT test_temp_pin(0, 9) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b17eb1129ca3d60c75ea91d5 | SELECT 'δ' ~* '[Γ-Λ]' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b18060ec60f00f3f70a9474a | SELECT to_date('-2147483648 01', 'CC YY') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b1a7a17f7adbf9aa56cb9d4d | SELECT to_number('qiv', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b224659c8aef4014db25f062 | -- -- Test cases for interactions between PARAM_EXEC, subplans and array -- subscripts -- -- check that array subscription doesn't conflict with PARAM_EXEC (see #19370) SELECT (array[1,2])[(SELECT ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b24c16d286212c2e1eb9b979 | select conrelid::regclass, conname, coninhcount, conislocal, connoinherit from pg_constraint where contype = 'n' and conrelid::regclass::text in ('inh_nn1', 'inh_nn2', 'inh_nn3', 'inh_nn4') order b... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b26e683e8793187baf85596f | select tcl_composite_arg_ref1(row('tkey', 42, 'ref2')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b29ba54c6d28fa0450a8c5ea | -- substring slow path: multi-byte escape char vs. multi-byte pattern char. SELECT SUBSTRING('a' SIMILAR U&'\\00AC' ESCAPE U&'\\00A7') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b2c24c8fed728e4743f616a2 | SELECT explain_filter($$ EXPLAIN (RANGE_TABLE, FORMAT JSON, COSTS OFF) SELECT genus, array_agg(name ORDER BY name) FROM vegetables GROUP BY genus $$) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b2e2fc9da09d0fb1da098aac | SELECT 'abc' LIKE 'abc' COLLATE ctest_nondet |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b2ecd912e53865cc42311781 | -- leading % matches zero (with later %): SELECT U&'\\0061\\0308bc' LIKE U&'%\\00E4%c' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b3218452574edf2d2e8acfc0 | SELECT COUNT(*) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY a HAVING a = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b350387885543c710c20f580 | -- NUL = character SELECT with_nul, reverse(with_nul), reverse(reverse(with_nul)) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b35b06fd89cadbd7fef26531 | select 1 as one group by rollup(one) order by one nulls first |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b3646950a8c9a078f6947ca4 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'histogram_bounds', '{1,2,3,4}'::text ) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b38aae554ebfd69f50e58c83 | SELECT (ROW(ARRAY[1, 2], ARRAY[1, 2, 3])).* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b38abeb8c8f408ebadd865f7 | SELECT * FROM pg_stats WHERE schemaname = 'stats_import' AND tablename = 'test' AND inherited = false AND attname = 'tags' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b38e926bc4f2d32e126cd5b4 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.21::real, 'most_common_vals', '{1,2,3}'::... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b4ae857b1af423070e9291ae | select generate_series(1, a) as g from (values (1, 1), (2, 2)) as t (a, b) group by rollup(g) order by 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b4b445064c1695359eca15ec | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.31::real, 'range_bounds_histogram', '{"[-... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b4bd9e9fbcdd1ef17801e8d9 | -- Decompression with rawsize too small, fails with source not fully -- consumed. SELECT test_pglz_decompress(test_pglz_compress( decode(repeat('abcd', 100), 'escape')), 100, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b4f919ffe5c1d43bb647fe50 | SELECT 1 AS "int" OFFSET 2 FETCH FIRST 3 ROW ONLY |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b555731025b1bce21a62c84d | -- show constraint info select conrelid::regclass, conname, contype, coninhcount, conislocal from pg_constraint where contype = 'n' and conrelid in ('inh_parent'::regclass, 'inh_child1'::regclass, ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b564d27afa0639dc65d9622b | select raw_flags, t_bits, t_data from heap_page_items(get_raw_page('test9v', 0)), lateral heap_tuple_infomask_flags(t_infomask, t_infomask2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b736f050563970e90aa2bfa6 | SELECT to_number('MMMDCM', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b79c13cbd1a907580e594c2b | SELECT has_largeobject_privilege('regress_priv_user2', 1009, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b7ee013bc783938c4f5b6bcc | SELECT has_function_privilege('regress_pg_logicalinspect', 'pg_get_logical_snapshot_info(text)', 'EXECUTE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b7efe354d7b5bce715945440 | select t1.a from t t1 left join t t2 on t1.a = t2.a join t t3 on true where exists (select 1 from t t4 join t t5 on t4.b = t5.b join t t6 on t5.b = t6.b where t1.a = t4.a and t3.a = t5.a and t4.a = 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b931fd38bc695c5701019a98 | SELECT * FROM test_squash_bigint WHERE data = ANY(ARRAY[ 1::bigint, 2::bigint, 3::bigint, 4::bigint, 5::bigint, 6::bigint, 7::bigint, 8::bigint, 9::bigint, 10::bigint, 11::bigint]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b99190fced0bb8fa59737e26 | SELECT convert_to(substring(truncated_with_nul, 4, 1), 'UTF8') FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | b9a1f8efa6e1571051420e6f | SELECT encrypt( '\\x00112233445566778899aabbccddeeff', '\\x000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f', 'aes-cfb/pad:none') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ba341b6ad2d7053a457d6294 | SELECT to_timestamp('613566758', 'W') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ba55134f51d17b2e218c4162 | SELECT * FROM test_squash WHERE id = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) AND data = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bb7904451cd2de1e6acb430a | SELECT COUNT(*) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY a, b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bb90d091dd837a58d817362f | -- and in reverse: SELECT U&'\\00E4bc' LIKE U&'\\0061\\0308_c' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bc45f1022f78eb498e40d589 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'xmin', 'inherited', false::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bc63a34f920c648123bd1f21 | SELECT indexrelid::regclass FROM pg_index WHERE (is_catalog_text_unique_index_oid(indexrelid) <> (indisunique AND indexrelid < 16384 AND EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = indexrel... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bc9224ac17dc615ba6e5437f | -- no SELECT has_largeobject_privilege('regress_priv_user2', 1007, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bca24811655a00f02370576c | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.33::real, 'most_common_elems', '{1,3}'::t... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bde8a10f00cc3f7b135ba435 | SELECT array_sort(a) FROM (VALUES ('[-2:0][20:21]={{1,2},{10,20},{1,-4}}'::int[])) v(a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | beaaafd33c71bfb179dc41c6 | select '"hello"'::jsonb::int8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bedc7b47bbc3ca9b909b17f3 | -- Check that read streams deal with lower number of pins available SELECT count(*), max(a) max_a, min(a) min_a, max(cnt) max_cnt FROM test_temp |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bf65d383e408ee3c2d290fb9 | select conrelid::regclass, conname, contype, conkey, (select attname from pg_attribute where attrelid = conrelid and attnum = conkey[1]), coninhcount, conislocal, connoinherit from pg_constraint wh... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | bfde345711be5b472942aebc | SELECT substring(good, 3, 1) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c00b6711550e6c18f967b6ca | SELECT array_agg(id ORDER BY guid_field) FROM guid3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c0307987488d92ccdd28d3ef | SELECT * FROM FLOAT8_TBL ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c0c2e032c532cdc84bf89679 | SELECT a, string_to_array(b COLLATE ctest_det, U&'\\00E4b') FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c152b9c6aaae7879559fa1f8 | select explain_filter('explain verbose select sum(unique1) over w1, sum(unique2) over (w1 order by hundred), sum(tenthous) over (w1 order by hundred rows 10 preceding) from tenk1 window w1 as (part... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c1692ec45f1bcd102dd13059 | SELECT a.attname, s.stainherit, s.stanullfrac, s.stawidth, s.stadistinct, s.stakind1, s.stakind2, s.stakind3, s.stakind4, s.stakind5, s.staop1, s.staop2, s.staop3, s.staop4, s.staop5, s.stacoll1, s... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c170119d8fca0c5c62ae2298 | SELECT 'xAb' !~* '[c-d]' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c1dc28e5f940b0ab702331de | SELECT to_number('LXC', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c1eea14dfcbedceff3071063 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'nope', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c1f1f5d0099ef46fb60a374b | SELECT explain_filter($$ EXPLAIN (DEBUG, COSTS OFF) INSERT INTO vegetables (name, genus) VALUES ('Brotero''s carrot', 'brassica') RETURNING id $$) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c2464fd4e44e78b26beeebca | -- array_sort with order specified SELECT array_sort('{1.1,3.3,5.5,2.2,null,4.4,6.6}'::float8[], true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c298c7e6ae647ba8aa57d83d | SELECT min(row(a,b)) FROM aggtest |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c2e0623a30661fe6c461b13a | SELECT make_date(-2147483648, 1, 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c3f9b57ac8c5ed0fec0057ec | select a, a in (1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint,8::myint) as not_hashed, a in (1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint,8::myint,9::myint) as ha... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c40d15649b17b2d984dfd865 | SELECT c AS cidr, abbrev(c) AS "abbrev(cidr)", i AS inet, abbrev(i) AS "abbrev(inet)" FROM INET_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c416d51e87fd44de1417d8a3 | SELECT pg_get_constraintdef(oid), conname, conkey FROM pg_constraint WHERE conrelid = 'tbl'::regclass::oid AND contype = 'p' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c4845a46c59d4ddf1ec49e0d | SELECT has_largeobject_privilege('regress_priv_user3', 1005, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c54702e8c36c43f37ac363c3 | -- can't be pushed down WITH cte AS ( UPDATE ft2 SET c3 = 'bar' WHERE postgres_fdw_abs(c1) > 2000 RETURNING * ) SELECT * FROM cte ORDER BY c1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c5488ee01cb890ec8154e8d8 | select conrelid::regclass, conname, conkey, coninhcount, conislocal, connoinherit from pg_constraint where contype = 'n' and conrelid::regclass::text in ('inh_nn1', 'inh_nn2', 'inh_nn3', 'inh_nn4')... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c562ef84787fc782040b7cbf | SELECT to_char(1234, '99999V99') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c5cdacb25c9251738c28f653 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'arange', 'inherited', false::boolean, 'null_frac', 0.28::real, 'range_length_histogram', '... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c5e2cb890a675ac67da1c6e6 | select encrypt('foo', '0123456789', 'aes-cfb') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c65abe4a42c0ab6744df81c1 | -- same as above with cases reversed -- case folding select casefold('AbCd 123 #$% ıiIİ ẞ ß Ǆǅǆ Σσς' collate PG_C_UTF8) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c6e987f16ebecc417ca54a56 | SELECT to_date('-100000000', 'CC') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c6f2fcd144a420aa0d45ac7d | SELECT test_pglz_decompress('\\x01ff'::bytea, 1024, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c769ad32b456be91091ee3ae | SELECT unique1 FROM tenk1 WHERE unique1 = ANY(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c773ac282ce18e9662529420 | select jsonb_path_query('[1,2,3,{"b": [3,4,5]}]', 'lax $.*') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c7c80c1112f31e3310b64c21 | SELECT date_trunc( 'week', timestamp with time zone 'infinity', 'GMT') AS inf_zone_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c7f87f56a6b376e265b269fe | SELECT array_sort('{1.1,3.3,5.5,2.2,null,4.4,6.6}'::float8[], false, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c818cae0a0830d2b5c98e426 | SELECT crypt('a short string', '$5$rounds=123456$asaltof16chars..') = '$5$rounds=123456$asaltof16chars..$gP3VQ/6X7UUEW3HkBn2w1/Ptq2jxPyzV/cZKmF/wJvD' AS result |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c83a9e19b5aeb40ca552e827 | SELECT pg_catalog.pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'nope', 'relpages', 17::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c851989217291ddac01d5ab2 | -- Test for correct conversion between numbers and Roman numerals WITH rows AS (SELECT i, to_char(i, 'RN') AS roman FROM generate_series(1, 3999) AS i) SELECT bool_and(to_number(roman, 'RN') = i) a... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c85319415de77fca02455228 | -- Optimiser treat GROUP-BY operator as an 'uniqueser' of the input SELECT * FROM check_estimated_rows(' SELECT * FROM generate_series(1, 1) t1 LEFT JOIN ( SELECT x FROM grouping_unique t2 GROUP BY... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c85738efcc614a9272d667e8 | -- -- Test the SupportRequestRows support function for generate_series_numeric() -- -- Ensure the row estimate matches the actual rows SELECT explain_mask_costs($$ SELECT * FROM generate_series(1.0... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c8888a2c7436110d8c5854f4 | -- new cursors with pins can be created after subtrans rollback SELECT test_temp_pin(10, 94) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c8cdb6ca04fc031e9862c313 | SELECT SUBSTRING(c FROM 1 FOR 1) FROM toast_3b_utf8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c8ef4e75248b85f9085f5706 | SELECT t1.a, t1.c, t2.b, t2.c FROM prt1_l t1, prt2_l t2 WHERE t1.a = t2.a AND t1.a = t2.b AND t1.c = t2.c ORDER BY t1.a, t2.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c90677afc8407348921d9a24 | SELECT crypt('foox', '$5$Szzz0yzz') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c94283c527e2120b656118fe | SELECT tableoid::regclass, * FROM gtest_child3 ORDER BY 1, 2, 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c94ff8a19310be13b88f8fa0 | SELECT date_trunc( 'timezone', timestamp 'infinity' ) AS notsupp_inf_trunc |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c97a2327728c1c855348ef06 | SELECT pg_restore_relation_stats( 'schemaname', 'pg_temp', 'relname', 'stats_temp', 'relpages', '-19'::integer, 'reltuples', 401::real, 'relallvisible', 5::integer, 'relallfrozen', 3::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c9c14f35e634459ab8ad7ca1 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.22::real, 'most_common_vals', '{2,1,3}'::... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c9d482e28b443afad57d9283 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'inherited', false::boolean, 'null_frac', 0.1::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | c9e7e676b9d32831f09dab23 | SELECT ARRAY[1::oid, 2::oid, 3::oid, 4::oid, 5::oid, 6::oid, 7::oid, 8::oid, 9::oid] |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ca8624d1fca8a0674659aae7 | SELECT * FROM test_squash WHERE id = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9]) AND data = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | caf58cde551fe4dbfc30153b | -- nothing in cache SELECT injection_points_load('TestInjectionLogLoad') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cb4ecf31b07a3def241912de | SELECT strpos(b COLLATE ctest_nondet, 'bc') FROM test6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cb6323f8da4b8d29f797fc57 | -- invalid short mb character = silently dropped SELECT regexp_replace(truncated, '^caf(.)$', '\\1') FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cbbabd5fb4110ead85bff5d2 | SELECT test_mblen_func('pg_encoding_mblen', 'GB18030', truncated_with_nul, 3) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cbdeedb3d9dfbe66b40e0037 | -- This is a tricky one. A naive implementation would first test -- \\00E4 matches \\0061, which is true under ignore_accents, but then -- the rest of the string won't match anymore. Therefore, the -... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cc1d0042810700dea4fd5573 | SELECT buffers_evicted IS NOT NULL FROM pg_buffercache_evict_relation('shared_pg_buffercache') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cc332b9310d77e0a25f318da | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.23::real, 'most_common_vals', '{2,four,3}... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cc37b26c8e7ca6cbbcb85ace | SELECT pg_get_logical_snapshot_info('0-40796E18.foo') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cc6856343c2bd0a9dab46d7a | SELECT xpath_nodeset(article_xml::text, '/article/author\|/article/pages', 'result', 'item') FROM articles |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cc7417dc8e7234e1779b182d | -- error expected select current_user = session_user |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cd3d6f865c263fb0f3926f35 | SELECT test_dsa_allocate(6501, 6600, 100) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cdbd4c0a97312e71b62bbe90 | SELECT '1912-01-01 00:00 MMT'::timestamptz AT TIME ZONE 'UTC' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cddb2dc8fa90ba35140c1f5f | -- 0391 03A3 0030 SELECT lower('ἈΣ̓' COLLATE PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ce21fe2e16e5f64e13caebeb | select conrelid::regclass::text as relname, conname, conislocal, coninhcount, conenforced, convalidated from pg_constraint where conname like 'inh\\_check\\_constraint%' order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ce45c67e25d2a4bc62aea115 | select * from (select tattle(3, ten) as v, count(*) from tenk1 where unique1 < 3 group by 1) ss where ss.v |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ce56e356de02fc4bfde9c042 | select explain_filter('explain (analyze,buffers off,serialize) select * from int8_tbl i8') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ce5a4928cc0fbf3865fbb184 | -- Rewritten as an OpExpr, so it will not be squashed select where '1' IN ('1'::int, '2'::int::text) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ce808cef6ebd423458527fa1 | select json_strip_nulls('[1,{"a":1,"b":null,"c":2},3]', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cebc74cd1ab935e0cf368317 | select * from (select generate_series(1, ten) as g, count(*) from tenk1 group by 1) ss where ss.g = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ced705c9d9ff5ac22392cfa7 | SELECT test_pglz_decompress('\\x010f01'::bytea, 1024, true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cefe879dab826ced55321d4e | -- should be at least 2x as large than temp_buffers SELECT pg_relation_size('test_temp') / current_setting('block_size')::int8 > 200 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cf0da5dc11ceb735d0d3c383 | -- If a corrupted string contains NUL in the tail bytes of a multibyte -- character (invalid in all encodings), it is considered part of the -- character for length purposes. An error will only be ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cf39473bcf96cafeeeacb0da | SELECT * FROM pg_stats WHERE schemaname = 'stats_import' AND tablename = 'test' AND inherited = false AND attname = 'arange' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cf4e7b22e46f2c60ebd780aa | SELECT current_user, session_user |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cf8719cfc23c10c2d6f1e033 | -- nothing SELECT injection_points_attach('TestInjectionLogLoad', 'notice') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | cfb75e9fb1e954f5a6d3561f | -- -- test EXTRACT -- SELECT f1, EXTRACT(MICROSECOND FROM f1) AS MICROSECOND, EXTRACT(MILLISECOND FROM f1) AS MILLISECOND, EXTRACT(SECOND FROM f1) AS SECOND, EXTRACT(MINUTE FROM f1) AS MINUTE, EXTR... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d1643117127e58ae2bee8a50 | SELECT * FROM test_squash WHERE id IN (1, 2, 3, 4, 5, 6, 7, 8, 9) AND data = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d1efafa0e018596f7ae9a9fa | select x, y \|\| 'y' from (select four as x, four as y from tenk1) as t group by grouping sets (x, y) order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d224fe54b0a64484c3d010ac | SELECT unique1 FROM tenk1 WHERE (thousand, tenthous) > (NULL, 5) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d230f27716f6d3910ebd16ab | SELECT unnest(pg_get_acl('pg_class'::regclass, 'atest5'::regclass::oid, 2)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d282030b93d5f2910653a551 | SELECT substring(with_nul, 3, 1) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d29026d90c1894ec2e5917e9 | SELECT reverse(good) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d2be8e8aa73ca3c1641107c5 | SELECT pg_get_logical_snapshot_meta('0-40796E18.foo.snap') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d2dcfa7d964dc3f3f4f7546c | SELECT pg_get_logical_snapshot_info('0/40796E18.foo.snap') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d301b95cfcc9230308cdd265 | SELECT array_sort('{1.1,3.3,5.5,2.2,4.4,6.6}'::numeric[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d3199c3d667e0872ab72a27d | SELECT x, count(*) FROM test3ci GROUP BY x HAVING x = 'abc' COLLATE case_sensitive AND length(x) > 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d3aa65aacbd823250019b581 | select 8e9000 - div(8e18000 - 1, 9e9000 - 1) * 9 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d3cd5c68d003673a4e5571c9 | SELECT to_timestamp('0.-2147483648', 'SS.MS') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d41ea75b9f66db52448378b1 | -- all of the above should be accepted -- some day we might allow these cases, but for now they're errors: select array[]::oidvector |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d4239ca1df9036b78e2b74d4 | select x, y from (select unique1::oid as x, unique2 as y from tenk1) as t where x::integer = 1 group by grouping sets (x, y) order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d48089ce766080e495a118b2 | -- JSON errcontext: truncate long data. SELECT repeat(U&'\\00A7', 30)::json |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d494a7368e5e6bc881d038d9 | -- test stratnum translation support functions SELECT gist_translate_cmptype_common(7) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d4bbd352dcb4580dd3c752a9 | -- As above but with generate_series_timestamp SELECT explain_mask_costs($$ SELECT * FROM generate_series(TIMESTAMP '2024-02-01', TIMESTAMP '2024-03-01', INTERVAL '1 day') g(s);$$, true, true, fals... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d50f98ad5f82bb691d9adfc1 | SELECT 1 AS "int" LIMIT 3 OFFSET 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d51c3638b5ba4a8dfd3ff9fe | -- Ensure we get the default row estimate for error cases (infinity/NaN values -- and zero step size) SELECT explain_mask_costs($$ SELECT * FROM generate_series('-infinity'::NUMERIC, 'infinity'::NU... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d566bf7bf6aac6295d4859d2 | SELECT count(*) FROM pgss_parallel_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d567c9fb0eeac3fbe950cb2b | -- sanity check of system catalog SELECT attrelid, attname, attgenerated FROM pg_attribute WHERE attgenerated NOT IN ('', 's', 'v') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d5731c9d73e02b3a6b862604 | SELECT 'abc' LIKE 'abc' COLLATE ctest_det |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d61ac649572a9b9756df2d1f | -- As above but with generate_series_timestamptz_at_zone() SELECT explain_mask_costs($$ SELECT * FROM generate_series(TIMESTAMPTZ '2024-02-01', TIMESTAMPTZ '2024-03-01', INTERVAL '1 day', 'UTC') g(... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d648cc9d3be8addd688e4a11 | SELECT pg_get_acl('pg_class'::regclass, 'atest2'::regclass::oid, 0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d67e51e5c0d9bec940f7242f | SELECT * FROM test_squash WHERE id = ANY (ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) AND data = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d6ad6971d69f5f5176713890 | SELECT relname, last_analyze IS NOT NULL AS analyzed, last_vacuum IS NOT NULL AS vacuumed FROM pg_stat_user_tables WHERE relid IN ('only_inh_parent'::regclass, 'only_inh_child'::regclass) ORDER BY ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d6dc045aefd858742be71de9 | -- DISTINCT and ORDER BY patterns -- Try some query permutations which once produced identical query IDs SELECT DISTINCT 1 AS "int" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d7eb04d394ef1d7043916c62 | -- 0391 03A3 SELECT lower('ΑΣ0' COLLATE PG_UNICODE_FAST) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d8093c92ef2899f3ad053afe | SELECT query, parallel_workers_to_launch > 0 AS has_workers_to_launch, parallel_workers_launched > 0 AS has_workers_launched FROM pg_stat_statements WHERE query ~ 'SELECT count' ORDER BY query COLL... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d85e7c7bc9a8e13761b2aaae | -- These should fail because they need to be called as SUPERUSER SELECT * FROM pg_buffercache_evict(1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d905e8ab253f059767cef00d | SELECT crypt('This is just a test', '$6$rounds=5000$toolongsaltstring') = '$6$rounds=5000$toolongsaltstrin$lQ8jolhgVRVhY4b5pZKaysCLi0QBxGoNeKQzQ3glMhwllF7oGDZxUhx1yxdYcz/e1JSbq3y6JMxxl8audkUEm0' AS... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d91fd8c10020aa9cb7bdf6c9 | SELECT good, truncated, with_nul FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d93b224d5ed7a5ef7fe2926e | --fail -- array_reverse SELECT array_reverse('{}'::int[]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d94fc0b777dbfaefd0270dc4 | SELECT x, count(*) FROM test3ci GROUP BY x HAVING ROW(x, 1) < ROW('ABC' COLLATE case_sensitive, 1) ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d978cf1b05a483a0b8e7775e | SELECT to_char(1234.56::float4, '99999V99') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | d9d6cf07e71ebccc2a457b0a | -- for nested arrays, only constants are squashed SELECT ARRAY[ ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], ARRAY[1, 2, 3, 4, 5... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | da00680b0c31f208404e3cd2 | SELECT COUNT(*) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY a HAVING a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | da229d4368a1383319e28e72 | select '[1.0]'::jsonb::float4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | da79aeabec249d13836b5ff9 | SELECT pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', 'relpages', '16'::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dab51521196360ff2ed738ca | SELECT xpath_nodeset(article_xml::text, '/article/author\|/article/pages', 'item_without_toptag') FROM articles |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dabec9939ad29e2056938881 | SELECT pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', 'relallvisible') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | db03b5c93ee96282a007ef2d | SELECT * FROM pg_stats WHERE schemaname = 'stats_import' AND tablename = 'test' AND inherited = false AND attname = 'id' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | db3c8c06cfe52ef14c0c276d | SELECT pg_catalog.pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 0::oid, 'relpages', 17::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | db4539fad6b54a13ce4ae600 | -- Collation of c should be the one defined for the column ("C"), not -- the one of the generation expression. (Note that we cannot just -- test with, say, using COLLATION FOR, because the collatio... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | db49666e2b0253162e408f9c | SELECT data FROM test_float WHERE data = ANY(ARRAY['1', 2]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | db8f4c624e9b363474714232 | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.36::real, 'elem_count_histogram', '{1,1,1... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dbd45d10dd281fda72eed0e6 | SELECT * FROM pxtest_rowlock WHERE id = 1 FOR SHARE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dc3dafc526d8850335871784 | -- This shows why replace should be greedy. Otherwise, in the NFD -- case, the match would stop before the decomposed accents, which -- would leave the accents in the results. SELECT a, b, replace(... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dc4ef091da0789ce13e1907e | SELECT lower('AbCd 123 #$% ıiIİ ẞ ß Ǆǅǆ Σσς' COLLATE "tr-x-icu") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dc662c621735a7c95fc17873 | SELECT data FROM test_float WHERE data IN ('1', 2) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dcc0830a985f1bbc34bb5388 | SELECT relpages, reltuples, relallvisible, relallfrozen FROM pg_class WHERE oid = 'stats_import.test'::regclass |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dce69e9762a61c463d3761c8 | SELECT pg_catalog.pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test_i', 'relpages', 18::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dd2f72c5c8f87b6be2442ec1 | SELECT stxname, stxdexpr IS NULL as expr_stats_is_null FROM pg_statistic_ext s LEFT JOIN pg_statistic_ext_data d ON s.oid = d.stxoid WHERE stxname = 'test_stats' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dd5f85b3893a1b93bdf4aaa9 | SELECT mode FROM pg_locks WHERE relation = 'stats_import.test_i'::regclass AND pid = pg_backend_pid() AND granted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | de02ed0bee8a387721df14b6 | SELECT COUNT(test_encoding(encoding, description, input)) > 0 FROM encoding_tests |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | de327abd7ab80605c50f123f | select jsonb_strip_nulls('[1,2,null,3,4]', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | de8b6c1ea495c666d87a5884 | SELECT json_value('"aaa"', jsonpaths RETURNING json) FROM jsonpaths |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | de9f2d76c5eed7ce97be6241 | -- unbounded: sequence would overrun the string, if the terminator were really -- the end of it SELECT test_mblen_func('pg_mblen_unbounded', 'UTF8', truncated_with_nul, 3) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | debc2c28c7166f374cd40b9b | SELECT pg_catalog.pg_restore_relation_stats( 'schemaname', 'stats_import', 'relpages', 17::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dec198eb899598652a5b1095 | SELECT injection_points_cached(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | dec4ce457655824f377159b0 | SELECT to_char(1234.56::float8, '99999V99') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ded4ca4ff50ab80310e6f8de | -- All constraints will be invalid, and _fkey2 constraints will not be enforced. SELECT conname, conenforced, convalidated FROM pg_constraint WHERE conrelid = 'fk_notpartitioned_fk'::regclass ORDER... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | def2d084b9277b6bc92df864 | -- Some additional tests for RN input SELECT to_number('CvIiI', 'rn') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | def509d245e31619f8f9ab71 | select * from (select a::oid as x, b from phv_part) t where x::int = 1 group by grouping sets (x, b) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | df1c8e3b0246312ba9518f2c | SELECT * FROM gtest_rule_log |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e01de7f29f40789f30fd4e30 | SELECT crypt('we have a short salt string but not a short password', '$6$rounds=77777$short') = '$6$rounds=77777$short$WuQyW2YR.hBNpjjRhpYD/ifIw05xdfeEyQoMxIXbkvr0gge1a1x3yRULJ5CCaUeOxFmtlcGZelFl5C... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e031654d7152a80bc7e24bf9 | SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = 2 AND j2.a = 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e061289475f15ac6e7bcc3db | select encode(decrypt_iv('\\xfea064', '0123456', 'abcd', 'aes-cfb'), 'escape') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e107aff925a5b1f4b8e143a8 | SELECT casefold('AbCd 123 #$% ıiIİ ẞ ß Ǆǅǆ Σσς' COLLATE "en-x-icu") |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e13877ab2bd5768d8e7ffe29 | SELECT substring(truncated_with_nul, 5, 1) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e16f3b881f565836745a3866 | -- condition detected when using the cstr variants SELECT test_mblen_func('pg_mblen_cstr', 'UTF8', truncated_with_nul, 3) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e1c1a5d391dc60b1745326d1 | SELECT tableoid::regclass, * FROM gtest_child ORDER BY 1, 2, 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e2154a2c3b55d5b566527113 | SELECT pg_catalog.pg_restore_relation_stats( 'relname', 'test', 'relpages', 17::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e2201d66fb12a3baee9741bb | -- ROW() expression with row expansion SELECT (ROW(ARRAY[1,2])).* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e22cc4bf484bbce2f5cb40a5 | SELECT WHERE 1 = ANY(ARRAY[1::text::int::text::int, 1::text::int::text::int]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e23a1cdc9e432cd4ebbe5ded | SELECT a.attname, s.stainherit, s.stanullfrac, s.stawidth, s.stadistinct, s.stakind1, s.stakind2, s.stakind3, s.stakind4, s.stakind5, s.staop1, s.staop2, s.staop3, s.staop4, s.staop5, s.stacoll1, s... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e23fe97fcab6bd8c0727121f | -- constraint on f1 should have three parents select conrelid::regclass, contype, conname, (select attname from pg_attribute where attrelid = conrelid and attnum = conkey[1]), coninhcount, conisloc... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e30360fab6acca3619b5c5f4 | -- bounds preservation tests SELECT array_sort(a) FROM (VALUES ('[10:12][20:21]={{1,2},{10,20},{3,4}}'::int[])) v(a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e31b1fa5b094f1fac5d3f903 | SELECT crypt('we have a short salt string but not a short password', '$5$rounds=77777$short') = '$5$rounds=77777$short$JiO1O3ZpDAxGJeaDIuqCoEFysAe1mZNJRs3pw0KQRd/' AS result |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e3609358f32f49589ea5c9bf | SELECT '൧' ~ '\\d' COLLATE PG_UNICODE_FAST |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e37216fcd58872127d0606c3 | SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE proname = 'zzzzzz' AND (proname, proargtypes) > ('abs', NULL) AND pronamespace IN (1, 2, 3) AND proargtypes IN ('26 23', '5077') ORDER B... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e4e284d15a7f6f9148c78ab5 | select where '1' = ANY (array['1'::int::text, '2'::int::text]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e4e41064003690d20174332d | -- These test GROUPS mode with an offset large enough to cause overflow when -- added to currentgroup. Although the overflow doesn't produce visibly wrong -- results (due to the incremental nature ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e5361b8c9e7263832bfc23a0 | SELECT x, count(*) FROM test3cs GROUP BY x HAVING x = 'abc' COLLATE case_insensitive ORDER BY 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e5ca8c44966f0470d916801c | SELECT to_char('100e9'::float8, 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e64679f207a9412b566adf11 | SELECT to_number('CM', 'MIRN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e6856aae6e7395973f76ddec | -- **************** pg_attribute **************** -- Look for illegal values in pg_attribute fields SELECT a1.attrelid, a1.attname FROM pg_attribute as a1 WHERE a1.attrelid = 0 OR a1.atttypid = 0 O... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e68630a070a8962d15367055 | -- non-DST -- Recognize "LMT" as whatever it means in the current zone SELECT 'Jan 01 00:00:00 1000 LMT'::timestamptz |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e69e46c79a638fd973c3165e | select * from gtest_cursor order by id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e6a76454242826a955d6971d | -- The child constraint will also be valid. SELECT conname, convalidated FROM pg_constraint WHERE conrelid = 'fk_partitioned_fk_2'::regclass ORDER BY oid::regclass::text |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e6d97a5e28392c327c309258 | select json_strip_nulls('1', true) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e6ddc21a30b9d3fb5ef23ee4 | SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND (j1.a*j1.a) = (EXTRACT(DOW FROM current_timestamp(0))/15 + 3)::int AND (EXTRACT(DOW FROM current_timestamp(0))/15 + 3)::int = (j2.a*j2.a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e7225caaeb73de72158289c1 | SELECT test_dsa_allocate(1001, 2000, 100) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e7a35c6d0dc2472d3838bf23 | select replaceme('fie') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e7ebaff2e4687acfcffa7923 | SELECT * FROM sj j1, sj j2 WHERE j1.b = j2.b AND j1.a = 2 AND j2.a = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e80eb14b9b7e07a3d2c9f992 | SELECT t, lower(t), initcap(t), upper(t), length(convert_to(t, 'UTF8')) AS t_bytes, length(convert_to(lower(t), 'UTF8')) AS lower_t_bytes, length(convert_to(initcap(t), 'UTF8')) AS initcap_t_bytes,... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e812482f25f99d7ed560b5ca | SELECT pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', 'relallvisible', 5::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e81913bc895c0a9073b191c4 | select count(*) from gstest2 group by grouping sets (()) having false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e825e9e854a8fb59c47ada7e | SELECT count(*) FROM pg_temp.tab_search_diff_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e85440d6cffeb8274c2a677a | select a, b, row_number() over (order by a, b nulls first) from (values (1, 1), (2, 2)) as t (a, b) where a = b group by grouping sets((a, b), (a)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e86c2191f2fba1f8a4ed342d | -- Should not leak SELECT * FROM tststats.priv_test_view WHERE a <<< 0 OR b <<< 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e878085ebb58f999a07f4f38 | SELECT pg_catalog.pg_restore_relation_stats( 'schemaname', 'stats_import', 'relname', 'test', 'relpages', 18::integer, 'reltuples', 21::real, 'relallvisible', 24::integer, 'relallfrozen', 27::integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e87f462dcf6448f076f947fd | select pg_get_viewdef('v1'::regclass) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e8e0c204acddda24e4652a09 | -- condition detected when using the length/range variants SELECT test_mblen_func('pg_mblen_with_len', 'UTF8', truncated, 3) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e9141c3c4f805d740278e7bf | SELECT mode FROM pg_locks WHERE relation = 'stats_import.part_parent_i'::regclass AND pid = pg_backend_pid() AND granted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e93aaf5070013e935bda4ead | SELECT * FROM test_squash_bigint WHERE id IN (abs(100), abs(200), abs(300), abs(400), abs(500), abs(600), abs(700), abs(800), abs(900), abs(1000), ((abs(1100)))) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e940093375ba54f091406f83 | SELECT GROUPING(b) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY b, a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | e9fb7d2b88421bb2c53d6c2f | SELECT c AS cidr, set_masklen(cidr(text(c)), 24) AS "set_masklen(cidr)", i AS inet, set_masklen(inet(text(i)), 24) AS "set_masklen(inet)" FROM INET_TBL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ea0c5470038663c9f08870a8 | select a, b from t_opf group by a, b order by b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ea0e494f729806d2a2de22f7 | select a, b, count(*) from gstest2 group by grouping sets ((a, b), (a)) having a > 1 and b > 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | eaf912c753587758d867e40f | SELECT * FROM pg_buffercache_evict_all() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | eb957ebdb65ab172b546af60 | SELECT to_number('DCCCD', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ec4b181865549670fa51a56b | SELECT a FROM tab_search_diff_2 AS t1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ecca47d97eb9465f8c436397 | SELECT count(*) > 0 FROM pg_buffercache_numa |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ed0e81fbb5ae8bfa09ec11ad | SELECT pg_stat_get_backend_io(0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ed879adcd71de02499226fc5 | -- leading % matches zero: SELECT U&'\\0061\\0308bc' LIKE U&'%\\00E4bc' COLLATE ignore_accents |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ede230c1e37b5628aebafb69 | -- Forwards scan SELECT id FROM btree_tall_tbl WHERE id = 55 ORDER BY t, id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | edea42ed20fcf128eb94faed | SELECT pg_get_logical_snapshot_meta('0-40796E18.foo') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | edebc2455081d2662bb33be7 | SELECT has_largeobject_privilege(1003, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | edfc7e8510e15283ca89ae1f | select a < b and b < 3 from (values (1, 2)) t(a, b) group by rollup(a < b and b < 3) having a < b and b < 3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | eecc3881f49bc7e1116e4f0d | with contexts as ( select * from pg_backend_memory_contexts ) select count(*) > 1 from contexts c1, contexts c2 where c2.name = 'CacheMemoryContext' and c1.path[c2.level] = c2.path[c2.level] |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | eed980d10273fa8541a76a3b | SELECT to_date('100000000', 'CC') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ef252fe4641b07fee45f1413 | select encrypt('', 'foo', 'aes-cfb') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ef917d6f8532ef10518b1e2b | -- Permission denied SELECT * FROM tststats.priv_test_tbl WHERE a <<< 0 OR b <<< 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | efbfdb674859809f8cf2e9c9 | SELECT pg_get_indexdef(conindid, 0, true) FROM pg_constraint WHERE conname = 'temporal_mltrng2_pk' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | efdf37637eb25c7d667b309b | SELECT has_largeobject_privilege(1004, 'UPDATE') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | effd0162bca08be436cf4db7 | SELECT '100'::int_custom > '42'::int_custom AS gt_test |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f0478c01276a8811db9d7f3a | SELECT row_to_json(j)::jsonb FROM ( SELECT left(E'abcdefghijklmnopqrstuv"\\twxyz012345678', a) AS a FROM generate_series(0,37) a ) j |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f07931825b4b7b81420587d5 | SELECT has_largeobject_privilege(1002, 'SELECT') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f08df4f5abeb69717aad65c2 | -- Verify data was inserted correctly SELECT * FROM test_table ORDER BY id |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f090fbdf5908ec0557a4752f | SELECT crypt('', '$5$Szzz0yzz') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f09a01ce76b7ad0e601b8567 | SELECT count(*) FROM tenk1 WHERE hundred = 42 AND (thousand < 42 OR thousand < 99 OR 43 > thousand OR 42 > thousand) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f0bad52a4bed13155cde71c1 | select '[]'::jsonb ->> -2147483648 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f0d01735da53190b4dc1afc8 | SELECT * FROM test1cs t1, (SELECT DISTINCT x FROM test3cs) t2 WHERE t1.x = t2.x COLLATE case_insensitive ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f17c41e17b0e2f18894bf03d | SELECT * FROM test_squash WHERE id = ANY(ARRAY[1::text::int::oid, 2::oid::int::oid]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f1e816a595958e5876922f1c | SELECT toplevel, calls, rows, query FROM pg_stat_statements WHERE toplevel IS FALSE ORDER BY query COLLATE "C" |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f243deedd6efbdccad9cb641 | select jsonb_path_query('{"a": [1,2,3], "b": [3,4,5]}', '$.*') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f248c0aca673cda315858da5 | SELECT * FROM test_squash_bigint WHERE data = ANY(ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f2ca1561ecaf42e9e7c61aea | select a, count(*) from gstest2 group by grouping sets ((a), ()) having false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f2fd93b53bb574fa6e3e822b | SELECT gist_translate_cmptype_btree(3) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f3402610444baaab90cd7ef3 | SELECT * FROM test_squash WHERE id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10) AND data = 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f3c07094ffb1b8340f447605 | SELECT c.relname, COUNT(*) AS num_stats FROM pg_class AS c JOIN pg_statistic s ON s.starelid = c.oid WHERE c.relnamespace = 'stats_import'::regnamespace AND c.relname IN ('test', 'test_clone', 'is_... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f5f743f43455e93f27bdc689 | SELECT count(*) FROM pg_logical_slot_get_changes('regression_slot_stats4_twophase', NULL, NULL, 'include-xids', '0', 'skip-empty-xacts', '1') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f628709d4511eef92060aedf | -- GROUP BY, HAVING, GROUPING SELECT COUNT(*) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY a |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f6c70074a5e642167c707135 | SELECT table_name, column_name, column_default, is_nullable, is_generated, generation_expression FROM information_schema.columns WHERE table_schema = 'generated_virtual_tests' ORDER BY 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f6c7513976be17b82dee29ae | SELECT test_temp_pin(0, 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f74eb39f678e1bbc0ac854bd | SELECT pg_get_indexdef(conindid, 0, true) FROM pg_constraint WHERE conname = 'temporal_rng_pk' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f797c32991f71db4136f2782 | table part_abc_view |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f81dbadacd173483e60157eb | select a, a not in (null::myint,1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint) as not_hashed, a not in (null::myint,1::myint,2::myint,3::myint,4::myint,5::myint,6::myint,7::myint,8... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f844c4ef58f9422954c40bc5 | SELECT * FROM test6 WHERE b LIKE 'zyäbc' COLLATE ctest_nondet |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f8b43791f324c571ef42f020 | SELECT SUBSTRING(c FROM 4000 FOR 1) FROM toast_3b_utf8 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f8b75bb9be74c4b9c71761b2 | SELECT gin_index_check('gin_check_jsonb_idx') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f982c18d1689c5af8cfe492d | SELECT array_sort(a [-1:0][20:20]) FROM (VALUES ('[-2:0][20:21]={{1,2},{10,20},{1,-4}}'::int[])) v(a) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | f990a0cfa5850a17c1716fc1 | SELECT length(good) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fa102e2ae41dc55dea504c01 | select explain_filter('explain (analyze, buffers off, verbose) select * from int8_tbl i8') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fa522de5f5021478dbecbeb0 | select t1.q1, x from int8_tbl t1 left join (int8_tbl t2 left join lateral (select t2.q2 as x, * from int8_tbl t3) ss on t2.q2 = ss.q1) on t1.q1 = t2.q1 order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fa553d95071c0c32509721b3 | SELECT explain_filter($$ EXPLAIN (BUFFERS OFF, COSTS OFF, SUMMARY OFF, TIMING OFF, ANALYZE, DEBUG) SELECT * FROM vegetables v1, vegetables v2 WHERE v1.id = v2.id; $$) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | faabe2b5815d71a0b44147dd | SELECT data FROM test_float WHERE data = ANY(ARRAY[1.0::double precision, 1.0::double precision]) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fad522d2e2f41ec8a16eddb3 | SELECT substring(truncated_with_nul, 3, 1) FROM regress_encoding |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fb342ed177d9b3333a3aa62a | SELECT lo_create(1009) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fb84b5fa11ec833be507e64d | -- -- test pg_get_constraintdef -- SELECT pg_get_constraintdef(oid) FROM pg_constraint WHERE conname = 'temporal_fk_mltrng2mltrng_fk' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fbab04a2c279c2aded6a26b0 | SELECT thousand, tenthous FROM tenk1 WHERE thousand < 3 and thousand <= 2 AND tenthous = 1001 ORDER BY thousand |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fbacc83d8debfa8979c51df1 | SELECT '42'::int_custom <> '42'::int_custom AS nt_test |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fbb90ffaf51fa0fdf582cb48 | select tuple_data_split('test9s'::regclass, t_data, t_infomask, t_infomask2, t_bits) from heap_page_items(get_raw_page('test9s', 0)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fbd9650d0225fe14aee526c8 | SELECT * FROM pg_buffercache_evict_relation(1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fbef6282f9ae7e06bea4d9ac | select grouping((select t1.v from gstest5 t2 where id = t1.id)), (select t1.v from gstest5 t2 where id = t1.id) as s, case when grouping((select t1.v from gstest5 t2 where id = t1.id)) = 0 then (se... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fc36eadd7cd53377042b00c3 | SELECT to_number('DCM', 'RN') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fcab9fd0a60778368294840e | SELECT data FROM test_float WHERE data IN (1.0, 1.0) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fd01c9ce4570971238ba94c1 | select min(v) from bytea_test_table |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fd4098a7ea35a0b276d66dec | select * from p t1 where exists (select 1 from p t2 where t1.a = t2.a and t1.a = 1) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fd6adf9fde2048f05314fb4c | SELECT pg_get_logical_snapshot_info('-1--40796E18.snap') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fdc10ea94d8a6880eaf1afbe | SELECT * FROM temporal_partitioned ORDER BY id, valid_at |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fe23a298fe9b14f6fd1ed2a6 | -- PostgreSQL doesn't allow strings to contain NUL. If a corrupted string -- contains NUL at a character boundary position, some functions treat it as a -- character while others treat it as a term... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fe37f4beb96892b4595718da | SELECT pg_catalog.pg_restore_attribute_stats( 'schemaname', 'stats_import', 'relname', 'test', 'attname', 'id', 'inherited', false::boolean, 'null_frac', 0.2::real, 'nope', 0.5::real) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fe59fb33e54b98f9a5062173 | SELECT a.attname, s.stainherit, s.stanullfrac, s.stawidth, s.stadistinct, s.stakind1, s.stakind2, s.stakind3, s.stakind4, s.stakind5, s.staop1, s.staop2, s.staop3, s.staop4, s.staop5, s.stacoll1, s... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | fe62e1b1f509bacc8e683891 | SELECT COUNT(*) FROM (VALUES (1::INT, 2::INT)) AS t(a, b) GROUP BY GROUPING SETS(a, ()) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ffc2fe0d8930369fc2f6eca4 | SELECT unnest(pg_get_acl('pg_class'::regclass, 'atest5'::regclass::oid, 4)) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ffc533d39b1943badc16a4fd | select x, y from (select unique1 as x, unique2 as y from tenk1) as t where x = 1 group by grouping sets (x, y) order by 1, 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ffc943dbfcb0ecca6fa9ec34 | SELECT test_relpath() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ffcace8272664cb2acc87857 | SELECT shobj_description('regress_hasprivs'::regrole, 'pg_authid') IS NULL AS no_comment |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_SELECT_STMT | ffd1e467770c72dcac5a2de9 | -- Check invalid input for pg_stat_get_backend_io() SELECT pg_stat_get_backend_io(NULL) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | 06c49c2598a343bab290a5e8 | ROLLBACK PREPARED 'regress_p1' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | 09a519f1dfbbd7ddd4a52878 | PREPARE TRANSACTION 'test1_abort' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | 2831a46d24833482f4cb23f0 | ROLLBACK PREPARED 'regress_p2' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | 654d01869718e035886d58f3 | ROLLBACK TO SAVEPOINT rescue_me |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | 80ac4a12bcaa8faef2ef8c16 | ROLLBACK PREPARED 'test1_abort' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | a0e74a0bb4a73bf7241baff3 | -- exhaust buffer pins in subtrans, check things work after SAVEPOINT rescue_me |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | aa0ac87c82b4745c1fbaa384 | PREPARE TRANSACTION 'regress_p2' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | d331e3dd2c9ab37b9f3f6fd4 | PREPARE TRANSACTION 'regress_p1' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | 22366abd032ef8aa45fb73d5 | -- -- partitioned FK referenced updates NO ACTION -- TRUNCATE temporal_partitioned_mltrng, temporal_partitioned_fk_mltrng2mltrng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | 278bffcc4aabf82056abd874 | -- ok -- -- Test RETURNING OLD/NEW. -- -- Start with new data, to ensure predictable TIDs. -- TRUNCATE foo |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | 289bb78cd7f52a8681db775d | TRUNCATE emp1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | 4e4628ec9f2f64ea0f792c3e | TRUNCATE temporal3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | 5bd1ac995de128dbde489d46 | -- -- ON CONFLICT: multiranges -- TRUNCATE temporal_mltrng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | 7cb26cd92e826d0d3e23478d | -- should fail here. -- -- test FK referenced updates NO ACTION -- TRUNCATE temporal_rng, temporal_fk_rng2rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | 88f4b7f1ef107df1d8154841 | TRUNCATE test_temp |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | 8ce39e3ecc5a300c0b46d9ed | -- -- partitioned FK referenced updates NO ACTION -- TRUNCATE temporal_partitioned_rng, temporal_partitioned_fk_rng2rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | 9df578ad67975f5410855ddc | TRUNCATE temporal_mltrng3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | bceee8dd56988b3c0d487dae | -- should fail here. -- -- test FK referenced updates NO ACTION -- TRUNCATE temporal_mltrng, temporal_fk_mltrng2mltrng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | c17f1b95815e0e7ba321fb29 | -- Remove the invalid data and try again. TRUNCATE fk_partitioned_fk_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | dc742dfc870558fc0181b654 | TRUNCATE temporal_rng |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | ddca4a771065d8cfa3acb135 | --error TRUNCATE notnull_tbl1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRUNCATE_STMT | f1e1ead370b1958de18b6bf6 | TRUNCATE ctest |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 00e5f0ead885c69780e53256 | UPDATE ctest SET salt = gen_salt('sha512crypt', 1000000000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 0171469c12bdc6fff169452c | UPDATE foo_parted SET a = 3, b = b + 1, c = c \|\| '->P3' WHERE a = 1 RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 01b65f160642594be7c0f0c3 | -- should fail: UPDATE temporal_partitioned_mltrng SET valid_at = datemultirange(daterange('2016-01-01', '2016-02-01')) WHERE id = '[5,6)' AND valid_at = datemultirange(daterange('2018-01-01', '201... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 0201440c73937e43a2d86912 | -- -- test FK referencing updates -- -- slide the edge across a referenced transition: UPDATE temporal_fk_rng2rng SET valid_at = daterange('2018-01-02', '2018-02-20') WHERE id = '[1,2)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 03c150eec203ee04b1cf20b2 | update gtest_cursor set a = 99 where current of curs |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 0b7f3a4b27354951dae6a4fd | -- a PK update growing the referenced multirange is fine: UPDATE temporal_mltrng SET valid_at = datemultirange(daterange('2018-01-01', '2018-03-01')) WHERE id = '[1,2)' AND valid_at @> '2018-01-25'... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 0e9632a414ab995aea166e1b | WITH t1 AS (SELECT * FROM emp1) UPDATE emp1 SET code = t1.code + 1 FROM t1 WHERE t1.id = emp1.id RETURNING emp1.id, emp1.code, t1.code |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 102adaea9a732d7425f6fa5f | -- rejects empty: UPDATE temporal_mltrng SET id = '[1,2)', valid_at = '{}' WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 12afa24a85eea3e21e4674d0 | UPDATE temporal_rng SET valid_at = daterange('2018-01-15', '2018-02-15') WHERE id = '[2,3)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 12c3fbcd7d5ea56af9725817 | -- should fail: UPDATE temporal_fk_mltrng2mltrng SET valid_at = datemultirange(daterange('2018-01-02', '2018-05-01')) WHERE id = '[1,2)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 165556b0d38c27e8a1f808a7 | UPDATE ucview SET f1 = f1 + 10 WHERE CURRENT OF c1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 189432d64ea6e1d6f7f8ad89 | -- rejects empty: UPDATE temporal_rng3 SET valid_at = 'empty' WHERE id = '[1,2)' AND valid_at IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 1dd0285a885e26154f4796f2 | -- a PK update that fails because both are referenced: UPDATE temporal_rng SET valid_at = daterange('2016-01-01', '2016-02-01') WHERE id = '[5,6)' AND valid_at = daterange('2018-01-01', '2018-02-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 1ea11fdc492d073447107b4b | -- a PK update shrinking the referenced range and changing the id invalidates the whole range (error): UPDATE temporal_rng SET id = '[2,3)', valid_at = daterange('2018-01-15', '2018-03-01') WHERE i... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 1ed93f6613134e2593e0a17c | UPDATE temporal_rng SET valid_at = daterange('2016-01-01', '2016-02-01') WHERE id = '[5,6)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 20733f3a575d615e5c2b4c59 | UPDATE foo_parted SET a = 2, b = b + 1, c = c \|\| '->P2' WHERE a = 1 RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 218625c200694f09403f7abc | -- set the multirange part to NULL UPDATE temporal_mltrng SET id = '[1,2)', valid_at = NULL WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 252d46a19475a9e9c4de813c | -- update the multirange part UPDATE temporal_mltrng SET valid_at = '{[2020-01-01,2021-01-01)}' WHERE id = '[11,12)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 285009db46157f0f6eb0e664 | -- still rejects empty when scalar part is NULL: UPDATE temporal_rng3 SET id = NULL, valid_at = 'empty' WHERE id = '[1,2)' AND valid_at IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 2c04ccaa489c0f04569dedff | UPDATE temporal_fk_mltrng2mltrng SET parent_id = '[8,9)' WHERE id = '[1,2)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 324d01cc2c0fb5c8340100d5 | -- update the multirange part UPDATE temporal_mltrng3 SET valid_at = '{[2020-01-01,2021-01-01)}' WHERE id = '[11,12)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 33494f81f5e20dc6945d9829 | -- can't be pushed down UPDATE ft2 SET c3 = 'bar' FROM ft4 INNER JOIN ft5 ON (ft4.c1 = ft5.c1) WHERE ft2.c1 > 1200 AND ft2.c2 = ft4.c1 RETURNING old, new, ft2, ft2.*, ft4, ft4.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 34e3abc1ee8271f24aee67e8 | -- should fail UPDATE foo SET f4 = f4 + 1 RETURNING old, new |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 39b8450e164e8e8964d7dccf | -- should fail: UPDATE temporal_partitioned_fk_rng2rng SET valid_at = daterange('2000-01-01', '2000-04-01') WHERE id = '[1,2)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 3bfcefa3d5caf6797c1e4fb5 | -- error, nulls exist UPDATE notnull_tbl1 SET a = 100 WHERE b = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 3dd662a5acf8c35703369ea0 | UPDATE temporal_partitioned_mltrng SET valid_at = datemultirange(daterange('2016-02-01', '2016-03-01')) WHERE id = '[5,6)' AND valid_at = datemultirange(daterange('2018-02-01', '2018-03-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 3e407ede64c58126ffe8385b | -- set the scalar part to NULL UPDATE temporal_rng3 SET id = NULL, valid_at = daterange('2020-01-01', '2021-01-01') WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 3fa988d4cfb90c25188035db | update aitest set price_on = 11 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 4045f55b95dde1a2c520e33b | UPDATE temporal_mltrng SET valid_at = datemultirange(daterange('2016-01-01', '2016-02-01')) WHERE id = '[5,6)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 409360d83fe66b653c749fed | UPDATE gtest_rule SET a = 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 44c3f5c8f807c50f3fc6f3b6 | UPDATE ctest SET salt = gen_salt('sha512crypt', 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 44f4f90ad93b707f1431361a | UPDATE temporal_partitioned_mltrng SET valid_at = datemultirange(daterange('2018-01-01', '2018-02-01')) WHERE id = '[5,6)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 4926b1d5d120a1646a15a872 | -- -- range PK: test updates -- -- update the scalar part UPDATE temporal_rng SET id = '[11,12)' WHERE id = '[1,2)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 494cc7610ed1dac7a4e4e33d | UPDATE ctest SET salt = gen_salt('sha256crypt', 9999) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 4f61bc2b3870ea7a7338972e | -- changing the scalar part fails: UPDATE temporal_rng SET id = '[7,8)' WHERE id = '[5,6)' AND valid_at = daterange('2018-01-01', '2018-02-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 4fe68277538ddf8c2b8f28f9 | -- should fail: UPDATE temporal_rng SET id = '[1,2)', valid_at = daterange('2018-03-05', '2018-05-05') WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 511354f9610d17bedb4d8311 | -- -- test FK referencing updates -- -- slide the edge across a referenced transition: UPDATE temporal_fk_mltrng2mltrng SET valid_at = datemultirange(daterange('2018-01-02', '2018-02-20')) WHERE id... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 548a81f18083596d1e4c64e5 | UPDATE foo SET f4 = 100 WHERE f1 = 5 RETURNING old.tableoid::regclass, old.ctid, old.*, old, new.tableoid::regclass, new.ctid, new.*, new, old.f4::text\|\|'->'\|\|new.f4::text AS change |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 59d67b920ae816c33e7ef746 | -- set the scalar part to NULL UPDATE temporal_mltrng3 SET id = NULL, valid_at = datemultirange(daterange('2020-01-01', '2021-01-01')) WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 5d184840567fe30e064172c6 | -- can't be pushed down UPDATE ft2 SET c2 = c2 + 400, c3 = c3 \|\| '_update7b' WHERE c1 % 10 = 7 AND c1 < 40 RETURNING old.*, new.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 5d1cfbc009f63a358b38ace3 | UPDATE toast_4b_utf8 SET c = repeat(U&'\\+01F680', 3000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 5d37313fd99f832ec130b814 | -- changing the scalar part fails: UPDATE temporal_mltrng SET id = '[7,8)' WHERE id = '[5,6)' AND valid_at = datemultirange(daterange('2018-01-01', '2018-02-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 60a97042a3b6490b40d57638 | UPDATE foo_parted_v SET a = 1, c = c \|\| '->P1' WHERE a = 2 AND c = 'P2' RETURNING 'P2:'\|\|old.dummy, 'P1:'\|\|new.dummy |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 658e7b6e5279691e5ff21187 | -- set the range part to NULL UPDATE temporal_rng3 SET id = '[1,2)', valid_at = NULL WHERE id IS NULL AND valid_at @> '2020-06-01'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 67ff0a214d220535515b4e02 | UPDATE temporal_mltrng SET valid_at = CASE WHEN lower(valid_at) = '2018-01-01' THEN datemultirange(daterange('2018-01-01', '2018-01-05')) WHEN lower(valid_at) = '2018-02-01' THEN datemultirange(dat... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 6a44dee2463c59ebaab613f9 | -- move a row from the first partition to the second UPDATE temporal_partitioned_fk_mltrng2mltrng SET id = '[4,5)' WHERE id = '[1,2)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 6b91f7c7af334aaf7db63e54 | -- a PK update growing the referenced range is fine: UPDATE temporal_rng SET valid_at = daterange('2018-01-01', '2018-03-01') WHERE id = '[1,2)' AND valid_at @> '2018-01-25'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 6ee2f6b5fe43dd6f9b81213a | -- -- partitioned FK referencing updates -- UPDATE temporal_partitioned_fk_mltrng2mltrng SET valid_at = datemultirange(daterange('2000-01-01', '2000-02-13')) WHERE id = '[2,3)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 7408c26365dedad110201a0e | -- set the scalar part to NULL UPDATE temporal_rng SET id = NULL, valid_at = daterange('2018-03-05', '2018-05-05') WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 76ab0d167891653d253f7eee | UPDATE foo_parted SET a = 1, b = b + 1, c = c \|\| '->P1' WHERE a = 3 RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 7a50ddeac5659378fba60590 | -- diagnose incomplete char iff within the substring UPDATE toast_3b_utf8 SET c = c \|\| test_bytea_to_text('\\xe280') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 7ab753e63570e128fde4d45f | -- still rejects empty when scalar part is NULL: UPDATE temporal_mltrng3 SET id = NULL, valid_at = '{}' WHERE id = '[1,2)' AND valid_at IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 7b9de71c952b772750205b66 | UPDATE temporal_mltrng SET valid_at = datemultirange(daterange('2018-01-15', '2018-02-15')) WHERE id = '[2,3)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 7bba6a09ca4c390d6b0a6819 | UPDATE gtest26 SET a = 11 WHERE a = 10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 7c9b5e2825aff1ffc6b64a13 | UPDATE temporal_fk_rng2rng SET parent_id = '[8,9)' WHERE id = '[1,2)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 7cca6e2c1076249953f825e8 | UPDATE gtest_rule SET a = (SELECT max(b) FROM gtest_rule) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 810a77eb1e3518cb94e7b327 | -- should fail: UPDATE temporal_fk_rng2rng SET valid_at = daterange('2018-01-02', '2018-05-01') WHERE id = '[1,2)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 81b4c4c80a30203688571b6e | UPDATE ctest SET salt = gen_salt('sha256crypt', 1000000000) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 846a034945cc707a464e93ed | -- should fail: UPDATE temporal_partitioned_rng SET valid_at = daterange('2016-01-01', '2016-02-01') WHERE id = '[5,6)' AND valid_at = daterange('2018-01-01', '2018-02-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 876d216832a81d32f6be1108 | UPDATE foo SET f4 = 100 WHERE f1 = 5 RETURNING (SELECT old.f4 = new.f4), (SELECT max(old.f4 + x) FROM generate_series(1, 10) x) old_max, (SELECT max(new.f4 + x) FROM generate_series(1, 10) x) new_max |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 89bcd06474aa8a00a439dbbf | UPDATE gtest1 SET a = 3 WHERE b = 4 RETURNING old.*, new.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 8be2bbfae2b2fc5e3f2039a3 | -- a PK update changing only the id invalidates the whole multirange (error): UPDATE temporal_mltrng SET id = '[2,3)' WHERE id = '[1,2)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 8daa0ae661a9d194908e9a90 | UPDATE gtest_rule SET a = 100 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 8df46a29480fde691d23d494 | UPDATE joinview SET f3 = f3 + 1 WHERE f3 = 57 RETURNING old.*, new.*, *, new.f3 - old.f3 AS delta_f3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 8faf123a9d510d38db6329af | UPDATE temporal_rng SET valid_at = daterange('2018-01-15', '2018-03-01') WHERE id = '[1,2)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 909a7f1319f198f03c19d246 | UPDATE temporal_rng SET valid_at = CASE WHEN lower(valid_at) = '2018-01-01' THEN daterange('2018-01-01', '2018-01-05') WHEN lower(valid_at) = '2018-02-01' THEN daterange('2018-01-05', '2018-03-01')... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 938b607a7976b355ae292328 | -- update both at once UPDATE temporal_rng SET id = '[21,22)', valid_at = '[2018-01-02,2018-02-03)' WHERE id = '[11,12)' AND valid_at @> '2020-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 97b39bafc0ea9c79e2ca8387 | UPDATE rw_view2 SET b='R3' WHERE a=3 RETURNING old.*, new.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 98620619d7582b7bf50c7355 | -- rejects empty: UPDATE temporal_mltrng3 SET valid_at = '{}' WHERE id = '[1,2)' AND valid_at IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 9e0644e0c85ae1cdee04c78b | UPDATE temporal_partitioned_rng SET valid_at = daterange('2016-02-01', '2016-03-01') WHERE id = '[5,6)' AND valid_at = daterange('2018-02-01', '2018-03-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | 9f479ae80ff9863c9cd79deb | -- set the scalar part to NULL UPDATE temporal_mltrng SET id = NULL, valid_at = datemultirange(daterange('2018-03-05', '2018-05-05')) WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | a16e6f3060b7d15766d5ea04 | -- -- multirange PK: test updates -- -- update the scalar part UPDATE temporal_mltrng SET id = '[11,12)' WHERE id = '[1,2)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | a34cbb670abe0e63f169e81b | UPDATE ctest SET salt = gen_salt('sha512crypt', 9999) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | abcdb9c6bae627673776754e | -- -- partitioned FK referencing updates -- UPDATE temporal_partitioned_fk_rng2rng SET valid_at = daterange('2000-01-01', '2000-02-13') WHERE id = '[2,3)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | ad411a65da96b15fdf8a52dc | UPDATE foo SET f4 = f4 + 1 RETURNING old.f3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | afde8c2cec3216a54823c104 | -- move a row from the second partition to the first UPDATE temporal_partitioned_fk_rng2rng SET id = '[1,2)' WHERE id = '[4,5)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | b00edbe27e347c186df44fac | UPDATE temporal_mltrng SET valid_at = datemultirange(daterange('2016-02-01', '2016-03-01')) WHERE id = '[5,6)' AND valid_at = datemultirange(daterange('2018-02-01', '2018-03-01')) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | b571340672accf3bb51b9114 | UPDATE public.tt SET b = b * 2 RETURNING a, b, old.b, new.b, tt.b, public.tt.b |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | b9058a7103d03d6a302359c6 | -- should fail: UPDATE temporal_rng3 SET valid_at = daterange('2018-03-01', '2018-05-05') WHERE id = '[1,2)' AND valid_at IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | b9796d22b820822438c8fb8d | -- update the range part UPDATE temporal_rng3 SET valid_at = '[2020-01-01,2021-01-01)' WHERE id = '[11,12)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | bad2789125197d804b6d1e74 | -- set the multirange part to NULL UPDATE temporal_mltrng3 SET id = '[1,2)', valid_at = NULL WHERE id IS NULL AND valid_at @> '2020-06-01'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | c3b455bb725569400ffdb439 | -- update the range part UPDATE temporal_rng SET valid_at = '[2020-01-01,2021-01-01)' WHERE id = '[11,12)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | c42ed443155da1aa10e12c7c | UPDATE joinview SET f3 = f3 + 1, f4 = 7 WHERE f3 = 58 RETURNING old.*, new.*, *, new.f3 - old.f3 AS delta_f3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | c5d00278cccc746fc25fa91a | -- move a row from the first partition to the second UPDATE temporal_partitioned_fk_rng2rng SET id = '[4,5)' WHERE id = '[1,2)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | c5d59edecf851be298095ce1 | UPDATE testpub_gencol SET a = 100 WHERE a = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | c929ed747bf3f292de02780a | UPDATE temporal_rng SET valid_at = daterange('2016-02-01', '2016-03-01') WHERE id = '[5,6)' AND valid_at = daterange('2018-02-01', '2018-03-01') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | c9357130292068635fa8e287 | -- rejects empty: UPDATE temporal_rng SET id = '[1,2)', valid_at = 'empty' WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | c994d3d1c7333e869a6a39af | -- -- multirange UQ: test updates -- -- update the scalar part UPDATE temporal_mltrng3 SET id = '[11,12)' WHERE id = '[1,2)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | cbe6b7ac2b50064141c028d7 | -- a PK update shrinking the referenced multirange and changing the id invalidates the whole multirange (error): UPDATE temporal_mltrng SET id = '[2,3)', valid_at = datemultirange(daterange('2018-0... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | ccde6fee1247a6a40a7b2e97 | UPDATE ctest SET salt = gen_salt('sha256crypt') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | cd787a95dc89cfbcf570857f | UPDATE foo_parted SET a = 4, b = b + 1, c = c \|\| '->P4' WHERE a = 3 RETURNING old.tableoid::regclass, old.ctid, old.*, new.tableoid::regclass, new.ctid, new.*, * |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | cd93b4b1c856a97e2f389f04 | UPDATE test12pk SET x = 'ABC' WHERE x = 'abc' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | d16f098a5f25c486b0862953 | -- a PK update changing only the id invalidates the whole range (error): UPDATE temporal_rng SET id = '[2,3)' WHERE id = '[1,2)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | d35560300fb13f5392ca9aa6 | -- set the range part to NULL UPDATE temporal_rng SET id = '[1,2)', valid_at = NULL WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | d65a683d4d9084c3d7122517 | UPDATE ctest SET salt = gen_salt('sha256crypt', 10) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | d71295d724e19746c9d86c48 | UPDATE rw_view2 SET b='Row three' WHERE a=3 RETURNING old.*, new.* |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | d75320be6c8d2c928c191f68 | -- a PK update that fails because both are referenced: UPDATE temporal_mltrng SET valid_at = datemultirange(daterange('2016-01-01', '2016-02-01')) WHERE id = '[5,6)' AND valid_at = datemultirange(d... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | d9a3728d9cb112340c900ee8 | UPDATE ctest SET salt = gen_salt('sha512crypt') |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | e01611eda7d8b4a14cc156fc | -- Check that temp table drop is transactional and preserves dirty -- buffer contents UPDATE test_temp SET cnt = cnt + 1 WHERE a = -1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | ed067cc528e24da8ace388e7 | -- -- range UQ: test updates -- -- update the scalar part UPDATE temporal_rng3 SET id = '[11,12)' WHERE id = '[1,2)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | f135dac1a4a2b8057612a949 | -- update both at once UPDATE temporal_mltrng3 SET id = '[21,22)', valid_at = '{[2018-01-02,2018-02-03)}' WHERE id = '[11,12)' AND valid_at @> '2020-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | f195bdd06ee6287a4464cc66 | UPDATE test4nfd SET b = normalize(b, nfd) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | f1d44e581e945a93978e4bbe | -- update both at once UPDATE temporal_mltrng SET id = '[21,22)', valid_at = '{[2018-01-02,2018-02-03)}' WHERE id = '[11,12)' AND valid_at @> '2020-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | f4dbe6a23be87dc874519c68 | UPDATE pt SET b = 'x' WHERE false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | f63a6b83ea3bfcaa8e8ef283 | -- should fail: UPDATE temporal_partitioned_fk_mltrng2mltrng SET valid_at = datemultirange(daterange('2000-01-01', '2000-04-01')) WHERE id = '[1,2)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | f6d29e686179bec9a6739527 | UPDATE temporal_partitioned_rng SET valid_at = daterange('2018-01-01', '2018-02-01') WHERE id = '[5,6)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | f9d6dcd0096ade16fc0e3125 | -- should fail: UPDATE temporal_mltrng SET id = '[1,2)', valid_at = datemultirange(daterange('2018-03-05', '2018-05-05')) WHERE id = '[21,22)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | fd8ef87aa77fa6ce78ec883b | -- should fail: UPDATE temporal_mltrng3 SET valid_at = datemultirange(daterange('2018-03-01', '2018-05-05')) WHERE id = '[1,2)' AND valid_at IS NULL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | fe1297dfaf64d728a007567a | -- update both at once UPDATE temporal_rng3 SET id = '[21,22)', valid_at = '[2018-01-02,2018-02-03)' WHERE id = '[11,12)' AND valid_at @> '2020-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | fe2386acc3044deca773fff2 | update aitest set price_on = null |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | fea9c9fd8fa81111ac5e1066 | -- move a row from the second partition to the first UPDATE temporal_partitioned_fk_mltrng2mltrng SET id = '[1,2)' WHERE id = '[4,5)' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | fea9d0eb8f05e85deac6fb0e | update aitest set price_on = 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_UPDATE_STMT | ff68bce24e27917b31b0ac6e | UPDATE temporal_mltrng SET valid_at = datemultirange(daterange('2018-01-15', '2018-03-01')) WHERE id = '[1,2)' AND valid_at @> '2018-01-15'::date |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 0c7856546c93b75bf6f5f11b | ANALYZE sb_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 100f590ad7f303060124ecc5 | VACUUM (FREEZE) bmscantest |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 1048707597954ef158a15626 | vacuum analyze sl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 1dee96b63832f860930bfa50 | VACUUM vac_tab_auto |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 25d744a1be4f5f764324815d | analyze tuplesest_parted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 294dfe1053b1214cdd4dd64d | ANALYZE stats_import.test |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 33e07ffb801c2534d51617e6 | ANALYZE distinct_on_tbl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 522629018b0fde6932b66337 | -- Ensure partitioned table and the partitions are analyzed ANALYZE only_parted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 5755a2737922393e02a2eacc | VACUUM ANALYZE tbl_phv |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 59d591856e9d288a21e0a975 | ANALYZE sb_1, sb_2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 63031e02b9d1d5652592f6ac | ANALYZE pagg_tab5 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 6b9592e5b4b1de6f50835b68 | ANALYZE vegetables |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 6f3ad7aacf661510007237b5 | VACUUM ANALYZE bitmap_split_or |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 7dd0133f56e5383bb7e72f76 | -- Ensure parent and child are vacuumed VACUUM only_inh_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 8c44ce91adffd832b20dd23c | analyze sj |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | 8e81f3df3627b5b2291b8822 | -- Computation of the stats fails, no data generated. ANALYZE test_table |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | afd3cb303792096c87cc0f04 | analyze gtest32 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | ba3e02b058984e822c7b47f6 | VACUUM ANALYZE vegetables |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | be57595c4143da4fa1c11f1c | ANALYZE stats_import.part_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | c0d6e27636438a09501d3732 | analyze tbl_rs |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | c12b35940c84858280a77450 | ANALYZE bitmap_split_or |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | c628d64c98546559b8f68272 | ANALYZE grouping_unique |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | c736588b0663e6ad10cc8a75 | ANALYZE distinct_tbl |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | ccfecd9cd88ed5b880448365 | ANALYZE pagg_tab6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | cf27aeb179ed4ee78c95a604 | ANALYZE agg_bad |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | cfd4a32da9e5340d899a529a | analyze tuplesest_tab |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | db7d1f663d1f115d98a0e25f | ANALYZE pagg_tab4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VACUUM_STMT | ed79b94208e3791e8be73c92 | -- Ensure the parent and child are analyzed ANALYZE only_inh_parent |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 0a1bb26a6c9969059f983c5e | -- =================================================================== -- test for postgres_fdw_get_connections function with check_conn = true -- ==================================================... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 0a92d7953984b52d37f47240 | SET ROLE regress_buffercache_normal |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 115ef4f145e86f3773048a7f | SET passwordcheck.min_password_length = 6 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 12ed353d05aaeaba9ead437d | set join_collapse_limit to 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 1456ca6fdb5f8d883c96a541 | -- First permanent schema SET search_path = 'pgss_schema_1' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 14cc2cdb2d7d5a1cdd419666 | SET debug_parallel_query = off |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 1c1b2911d0b5b68cb49bbeb0 | SET SESSION work_mem = '400kB' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 1e506dba60cd562bbe233ba6 | SET check_function_bodies TO off |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 1e6cd580437a60964d67e269 | -- Special cases. Keep these ones at the end to avoid conflicts. SET SCHEMA 'foo' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 26d5e8213809a66e75f85b0f | -- Check that the Hash Join bucket size estimator detects equal clauses correctly. SET enable_nestloop = 'off' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 3076b5a0d6759fccad99f93d | set constraint_exclusion to on |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 316ad88daed44ffecc49b9dc | -- Temporary schema SET search_path = 'pg_temp' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 3419ea41ce1ad5cd04378e9d | SET track_activities = off |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 39aca97ac77425608c2f89a8 | SET vacuum_truncate = false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 3d13b6dd637280a6ba852125 | SET vacuum_truncate = true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 43da2c17ca92e5d5fadb054a | SET track_activities = on |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 4a3eabde0a1d33842d545a8e | SET SESSION AUTHORIZATION 'regress_stat_set_2' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 4c66527a9a2bfca711404370 | SET md5_password_warnings = off |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 4ca1d6474812a9b310eb49f8 | SET TIME ZONE 'Asia/Tokyo' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 4f8ee9203a612d010143ccb7 | set search_path = tcls1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 51f407ce7f924914ce156c28 | SET enable_hashjoin = false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 523ec0e054c3edd3f9e23361 | SET plan_cache_mode = 'force_generic_plan' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 548d0076132ee3325dcf10a1 | SET enable_mergejoin = 'off' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 550bd92bb5da2639ddc0cf51 | set work_mem to 64 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 56e255cc2385bb4dd2de94fc | SET search_path = generated_stored_tests |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 5de4410f77fab36aff76e7ba | -- Read UTF8 data as LATIN1: no error SET client_encoding TO LATIN1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 682934369fb534abc1b20726 | SET enable_mergejoin = false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 6d1839eed61ec5ac230e12c3 | SET ROLE regress_stats_superuser |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 6f2a6cbda2576fcc49fdcad8 | -- Read UTF8 data as EUC_JP: no error SET client_encoding TO EUC_JP |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7204f495770c4653898e2659 | -- Second permanent schema SET search_path = 'pgss_schema_2' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 72e109e539bcbdc2c7945c5a | SET isn.weak TO TRUE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 750be8524268170d74916a18 | SET search_path = generated_virtual_tests |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 786cca2283d0119a50a5442b | set enable_hashjoin to on |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7893dadaf526c76dffae2408 | set role regress_caller |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7aaef161c7b337df3f8c45a5 | SET ROLE regress_grantor1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7c624d59481ef75a710ba576 | set enable_mergejoin to on |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 7ee5bc5bd6dd7c2666344832 | -- which might be nothing SET timezone = 'UTC' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 8040c74b34ef655c02ee7460 | SET SESSION AUTHORIZATION 'regress_stat_set_1' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 85ea7d422f1cc06c33f8ac98 | SET SCHEMA 'public' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 8fe17ceaed8892fe8a5433b9 | SET LOCAL work_mem TO DEFAULT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 90cee60327e0c99de57bbf59 | SET intervalstyle to 'asd' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 91a37892128d95204b48327c | set local from_collapse_limit to 2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 98e250b7ba41ec9905f0089f | SET LOCAL max_parallel_maintenance_workers = 4 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 9969f928ffabef315f803e21 | set search_path = tcls2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | a2e1fd253c48cdf2013f8a3b | -- Tests for WITHOUT OVERLAPS. -- -- We leave behind several tables to test pg_dump etc: -- temporal_rng, temporal_rng2, -- temporal_fk_rng2rng. SET datestyle TO ISO, YMD |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | a57c575614ccd44c15217f63 | SET ROLE NONE |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | ae04cefd218f5d66f708b770 | set role regress_mr |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | b33ad4c1e41652477fb135cd | SET LOCAL work_mem = '256kB' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | b36ef414cd79e63bbfec3352 | SET TIME ZONE LOCAL |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | bbfa3b246f90dfacb270c043 | SET debug_parallel_query = true |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | c09aaee59b6d147334cd5d21 | SET timezone = 'Europe/London' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | c7beb1c7202bfd46a2484fb0 | SET enable_partition_pruning TO on |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | cff94d1cf0b77c4a8d2670fe | set session authorization regress_parallel_worker |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | d04a614431f3d8e31f8dd3b2 | SET LOCAL work_mem = DEFAULT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | d287f287fc7c56495a62fd1d | SET SESSION work_mem = '300kB' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | d8902bac66c59364b8c1b4fd | set local parallel_tuple_cost=0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | e1a7144c5231b2ea634f1e88 | SET max_parallel_workers_per_gather = 1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | e7ba3d20184a307f32b3bb46 | SET work_mem = DEFAULT |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | ebbb44540054280c1b0b7a81 | set role regress_fn_owner |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | ed04e6384dd05bcdfac8f86d | SET debug_parallel_query = false |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | f25d4689a2aff455faca7a37 | SET pgcrypto.builtin_crypto_enabled = off |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | f4305aeb77ad7a28b29d54eb | set local enable_hashagg = off |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | f5d3e908ca015a0cec81679b | -- from timezone_abbreviations SET timezone = 'America/Montevideo' |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | fc56a3ee91dc23d55af2573b | set local enable_bitmapscan = off |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 014f15d121ce8b14a254d3fc | CREATE VIEW pg_shmem_allocations_numa AS SELECT * FROM pg_get_shmem_allocations_numa() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 0534b45ad8db4e617d9c0851 | CREATE VIEW pg_replication_slots AS SELECT L.slot_name, L.plugin, L.slot_type, L.datoid, D.datname AS database, L.temporary, L.active, L.active_pid, L.xmin, L.catalog_xmin, L.restart_lsn, L.confirm... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 07be7fd8f62f9e4ca97b584a | -- Create a view for convenient access. CREATE VIEW pg_buffercache_numa AS SELECT P.* FROM pg_buffercache_numa_pages() AS P (bufferid integer, os_page_num bigint, numa_node integer) |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 17f7a5433977c77c154af034 | CREATE VIEW rw_view1 AS SELECT *, 'Const' AS c, (SELECT concat('b: ', b)) AS d FROM base_tbl WHERE a>0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 1b221cc499b028b70fe05a2e | CREATE VIEW pg_stat_wal AS SELECT w.wal_records, w.wal_fpi, w.wal_bytes, w.wal_buffers_full, w.stats_reset FROM pg_stat_get_wal() w |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 21c5e3de09161bb74d0eb949 | -- cross-partition update that uses ReturningExpr nodes, without returning -- old/new table values CREATE VIEW foo_parted_v AS SELECT *, 'xxx' AS dummy FROM foo_parted |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 23182a218d9dc1f49e001a92 | create view part_abc_view as select * from part_abc where b <> 'a' with check option |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 343f1073188be467d8b854d8 | CREATE VIEW pg_stat_subscription_stats AS SELECT ss.subid, s.subname, ss.apply_error_count, ss.sync_error_count, ss.confl_insert_exists, ss.confl_update_origin_differs, ss.confl_update_exists, ss.c... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 3c8304e5d0bd76177fe5d1b9 | CREATE VIEW pg_stat_progress_vacuum AS SELECT S.pid AS pid, S.datid AS datid, D.datname AS datname, S.relid AS relid, CASE S.param1 WHEN 0 THEN 'initializing' WHEN 1 THEN 'scanning heap' WHEN 2 THE... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 41c17a2e7856ef4a42182556 | CREATE VIEW pg_stat_progress_analyze AS SELECT S.pid AS pid, S.datid AS datid, D.datname AS datname, CAST(S.relid AS oid) AS relid, CASE S.param1 WHEN 0 THEN 'initializing' WHEN 1 THEN 'acquiring s... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 481694219061ddc4175dfcc5 | CREATE VIEW pg_aios AS SELECT * FROM pg_get_aios() |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 5411adeca029c9627c5fa741 | CREATE VIEW table_constraints AS SELECT CAST(current_database() AS sql_identifier) AS constraint_catalog, CAST(nc.nspname AS sql_identifier) AS constraint_schema, CAST(c.conname AS sql_identifier) ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 58db98d9b98070deca31c74f | -- not updatable without rules/triggers CREATE VIEW rw_view2 AS SELECT *, 'Const2' AS c2 FROM rw_view1 WHERE a<10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 60d727ea1fb1ffc26842daf1 | CREATE VIEW rw_view1 AS SELECT *, 'Const1' AS c1 FROM base_tbl WHERE a>0 OFFSET 0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 62cbeffefd27df27223ccf23 | CREATE TEMP VIEW id_alw2_view AS SELECT * FROM id_alw2 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 7761a56d06dd82b4b016a939 | CREATE VIEW stats_import.testview AS SELECT * FROM stats_import.test |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 78b464b94408eacf0b5a7253 | CREATE VIEW constraint_column_usage AS SELECT CAST(current_database() AS sql_identifier) AS table_catalog, CAST(tblschema AS sql_identifier) AS table_schema, CAST(tblname AS sql_identifier) AS tabl... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 84d2dd9ef36b4a8112edab09 | -- check that we preserve join alias in GROUP BY expressions create temp view v1 as select f1::int from t1 left join t2 using (f1) group by f1 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 88bbf970b513af676a6b164d | CREATE VIEW check_constraints AS SELECT CAST(current_database() AS sql_identifier) AS constraint_catalog, CAST(rs.nspname AS sql_identifier) AS constraint_schema, CAST(con.conname AS sql_identifier... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | 982830f4c7ddccb6c68f7cdb | -- =================================================================== -- test cleanup of failed connections on abort -- =================================================================== CREATE V... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | a5aa8922c6dd77640c9eabc0 | CREATE VIEW pg_stat_all_tables AS SELECT C.oid AS relid, N.nspname AS schemaname, C.relname AS relname, pg_stat_get_numscans(C.oid) AS seq_scan, pg_stat_get_lastscan(C.oid) AS last_seq_scan, pg_sta... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | b75c1b27d7c72f451dd6d986 | CREATE VIEW rw_view2 AS SELECT aa AS aaa, bb AS bbb, c AS c1, 'Const2' AS c2 FROM rw_view1 WHERE aa<10 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | ca37205a360af9bb93bfe582 | CREATE VIEW rw_view1 AS SELECT b AS bb, a AS aa, 'Const1' AS c FROM base_tbl WHERE a>0 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | caf9805e603e2ebec6e348b3 | CREATE VIEW pg_sequences AS SELECT N.nspname AS schemaname, C.relname AS sequencename, pg_get_userbyid(C.relowner) AS sequenceowner, S.seqtypid::regtype AS data_type, S.seqstart AS start_value, S.s... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | d1962931c0a56958d1642504 | CREATE VIEW pg_stat_database AS SELECT D.oid AS datid, D.datname AS datname, CASE WHEN (D.oid = (0)::oid) THEN 0 ELSE pg_stat_get_db_numbackends(D.oid) END AS numbackends, pg_stat_get_db_xact_commi... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | d222be732caea2f71ff30751 | CREATE VIEW pg_timezone_abbrevs AS SELECT * FROM pg_timezone_abbrevs_zone() z UNION ALL (SELECT * FROM pg_timezone_abbrevs_abbrevs() a WHERE NOT EXISTS (SELECT 1 FROM pg_timezone_abbrevs_zone() z2 ... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | d71f4d5e630211f5a90dd4d0 | CREATE VIEW pg_stat_io AS SELECT b.backend_type, b.object, b.context, b.reads, b.read_bytes, b.read_time, b.writes, b.write_bytes, b.write_time, b.writebacks, b.writeback_time, b.extends, b.extend_... |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | de495bfa89f14a87ab37bf15 | CREATE TEMP VIEW id_alw3_view AS SELECT * FROM id_alw3 |
| DEEP_SUPPORTED | PG_QUERY__NODE__NODE_VIEW_STMT | f72c2a95b644a02b2461f103 | CREATE VIEW pg_stat_checkpointer AS SELECT pg_stat_get_checkpointer_num_timed() AS num_timed, pg_stat_get_checkpointer_num_requested() AS num_requested, pg_stat_get_checkpointer_num_performed() AS ... |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 090b1ce389b2c10a2b506f15 | ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON LARGE OBJECTS TO public |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 502b895cf225d7d286512da9 | -- no ALTER DEFAULT PRIVILEGES GRANT SELECT ON LARGE OBJECTS TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 67e3f40014d2d2f347238a74 | -- true ALTER DEFAULT PRIVILEGES REVOKE UPDATE ON LARGE OBJECTS FROM regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_DEFAULT_PRIVILEGES_STMT | 6ae1a6a6468c957427a88589 | -- no ALTER DEFAULT PRIVILEGES GRANT ALL ON LARGE OBJECTS TO regress_priv_user2 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | 6a6f8e7e23dca156c632048e | alter extension test_ext7 update to '2.2bad' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_EXTENSION_STMT | b714bdf4645f52f39124c30b | -- New functions and views for pg_stat_statements in 1.12 AlTER EXTENSION pg_stat_statements UPDATE TO '1.12' |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 02943481957998163dc52eda | -- error: duplicates not allowed in column list ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5 (a, a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 2714a132fa387a16c2935b6e | -- error: virtual generated column "e" can't be in list ALTER PUBLICATION testpub_fortable ADD TABLE testpub_tbl5 (a, e) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | 52d7259230f9645916abd830 | ALTER PUBLICATION testpub_fortable SET TABLE testpub_tbl1 (id, ctid) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | a1788f53fc8b2cede5b672d7 | ALTER PUBLICATION testpub_ins_trunct ADD TABLE pub_test.testpub_nopk, testpub_tbl1 |
| ERROR | PG_QUERY__NODE__NODE_ALTER_PUBLICATION_STMT | fc3cb3903bca7dab8f30ea24 | ALTER PUBLICATION testpub_fortable SET TABLE testpub_tbl5 (a, a) |
| ERROR | PG_QUERY__NODE__NODE_ALTER_TSCONFIGURATION_STMT | 5ffca48f8e01844fc4f59d1f | ALTER TEXT SEARCH CONFIGURATION evttrig_tscfg DROP MAPPING FOR word |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 1021fb3d0a7c5db4f2f75029 | COPY (UPDATE stats_track_tab SET x = 2 WHERE x = 1 RETURNING x) TO stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 21a551ddacfd544860681ac8 | COPY ( MERGE INTO sq_target t USING sq_source s ON tid = sid WHEN MATCHED AND tid >= 2 THEN UPDATE SET balance = t.balance + delta WHEN NOT MATCHED THEN INSERT (balance, tid) VALUES (balance + delt... |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 97a87590b73ff273af267947 | COPY (MERGE INTO stats_track_tab USING (SELECT 1 id) ON x = id WHEN MATCHED THEN UPDATE SET x = id WHEN NOT MATCHED THEN INSERT (x) VALUES (id) RETURNING x) TO stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | 9b46c73306a625f23f8f618a | COPY (INSERT INTO stats_track_tab (x) VALUES (1) RETURNING x) TO stdout |
| ERROR | PG_QUERY__NODE__NODE_COPY_STMT | fd4a7deb7ff5aaa96a94b6e4 | COPY (DELETE FROM stats_track_tab WHERE x = 2 RETURNING x) TO stdout |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | 23dd1029d5bba8c70d73048d | CREATE EXTENSION autoinc |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | a3c1f91ad698bbcf1c2fb205 | -- Tests with various custom types CREATE EXTENSION test_custom_types |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | a93222982285c427b218c7c2 | CREATE EXTENSION refint |
| ERROR | PG_QUERY__NODE__NODE_CREATE_EXTENSION_STMT | cedc59780c463971860b2d29 | CREATE EXTENSION pg_logicalinspect |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 03a66b4f338787a1f3cbf6d6 | -- Generated columns in column list, when 'publish_generated_columns'='none' CREATE PUBLICATION pub1 FOR table gencols(a, gen1) WITH (publish_generated_columns = none) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 2897635b6f4de4db02753b47 | CREATE PUBLICATION testpub_xxx WITH (publish_generated_columns) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 4a88011ed4300ea926b7eba9 | CREATE PUBLICATION testpub_xxx WITH (publish_generated_columns = stored, publish_generated_columns = none) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 8796caefd4e58608a5a9e5b8 | CREATE PUBLICATION testpub_ins_trunct WITH (publish = insert) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 92cdda89011e57af1205066f | CREATE PUBLICATION testpub8 FOR TABLE testpub_rf_tbl7 WHERE (y > 100) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | 9abb37de72b3a7de6e36f807 | CREATE PUBLICATION testpub7 FOR TABLE testpub_rf_tbl6 WHERE (y > 100) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | a4a0b8e031456fa3739f07b4 | CREATE PUBLICATION pub1 FOR ALL TABLES WITH (publish_generated_columns = stored) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | a5e09d1078d0b1f769deaf71 | -- error - generated column "b" must be published explicitly as it is -- part of the REPLICA IDENTITY index. CREATE PUBLICATION pub_gencol FOR TABLE testpub_gencol |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | b1f39566e0f5f35c1dc739d0 | -- ok - generated column "b" is published explicitly CREATE PUBLICATION pub_gencol FOR TABLE testpub_gencol with (publish_generated_columns = stored) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_PUBLICATION_STMT | d7ebfe49ac3aae32cc22d215 | CREATE PUBLICATION testpub_xxx WITH (publish_generated_columns = foo) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_STMT | e06e6ec92a7d3f86807488e6 | CREATE TEMP TABLE fktable2 (fk int references pktable ENFORCED NOT ENFORCED) |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | 2b8ba84770bdc5cb524e843b | CREATE TEMPORARY TABLE pgss_ctas_2 AS EXECUTE test_prepare_pgss |
| ERROR | PG_QUERY__NODE__NODE_CREATE_TABLE_AS_STMT | 55880f2e11738903f5001875 | CREATE TEMPORARY TABLE pgss_ctas_4 AS EXECUTE test_prepare_pgss |
| ERROR | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 88426cde677fdf2db899fe39 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE TABLE selinto_schema.tbl_withdata4 (a) AS EXECUTE data_sel WITH DATA |
| ERROR | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 93f278c08e373e77b5b6ec22 | EXPLAIN (ANALYZE, COSTS OFF, SUMMARY OFF, TIMING OFF, BUFFERS OFF) CREATE TABLE selinto_schema.tbl_nodata4 (a) AS EXECUTE data_sel WITH NO DATA |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 494fcc53382a209ca0206acd | -- DELETE turned into UPDATE by a rule has OLD and NEW CREATE RULE foo_del_rule AS ON DELETE TO foo DO INSTEAD UPDATE foo SET f2 = f2\|\|' (deleted)', f3 = -1, f4 = -1 WHERE f1 = OLD.f1 RETURNING * |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 8c08d691e7a72d363f35ee82 | CREATE RULE sj_del_rule AS ON DELETE TO sj DO INSTEAD UPDATE sj SET a = 1 WHERE a = old.a |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | 9ff8255bc28be323a084200d | CREATE RULE gtest_rule_ins AS ON INSERT TO gtest_rule DO ALSO INSERT INTO gtest_rule_log VALUES ('INS', NULL, NEW.b) |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | bc43b25d4addcb75ad51e35e | CREATE RULE rw_view1_upd_rule AS ON UPDATE TO rw_view1 DO INSTEAD UPDATE base_tbl SET b=NEW.b WHERE a=OLD.a RETURNING * |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | c281a2becc7be3b7be9a922e | CREATE RULE id_alw3_ins AS ON INSERT TO id_alw3 DO INSTEAD WITH t1 AS (INSERT INTO id_alw1 DEFAULT VALUES RETURNING i) INSERT INTO id_alw2_view DEFAULT VALUES RETURNING i |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | f1aa3d1fbaca64416b33f144 | -- rule quals referring to generated columns: -- NEW.b in the rule qual should reflect the generated column's new value CREATE RULE gtest_rule_qual AS ON UPDATE TO gtest_rule WHERE NEW.b > 100 DO I... |
| ERROR | PG_QUERY__NODE__NODE_RULE_STMT | fb616ccb356ba622b8c66f74 | CREATE RULE gtest_rule_upd AS ON UPDATE TO gtest_rule DO ALSO INSERT INTO gtest_rule_log VALUES ('UPD', OLD.b, NEW.b) |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | 2db1be1a87b20a369c00f95d | -- Ensure only the parent is vacuumed VACUUM ONLY only_inh_parent |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | 76951a3bc86863d0e59649f1 | -- Try ANALYZE ONLY with a column list ANALYZE ONLY vacparted(a,b) |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | 98e35171ec0c7f5ca3952c20 | -- Ensure only parent is analyzed ANALYZE ONLY only_inh_parent |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | b80cd6f58cdc7b0899fd60db | -- Ensure only the partitioned table is analyzed ANALYZE ONLY only_parted |
| ERROR | PG_QUERY__NODE__NODE_VACUUM_STMT | f23eac5f2baa7393de3c7e95 | -- VACUUM ONLY on a partitioned table does nothing, ensure we get a warning. VACUUM ONLY vacparted |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 278202514ab9c9f1d0e03ba6 | SET LOCAL work_mem FROM CURRENT |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 663d123df1d48c5423a418e2 | SET work_mem FROM CURRENT |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | a57b18b744c2f48fedc760dd | SET LOCAL SESSION AUTHORIZATION 'regress_stat_set_1' |
| ERROR | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | efa1b85c4bda6d329cfe770a | SET LOCAL SESSION AUTHORIZATION 'regress_stat_set_2' |
| PARTIAL | PG_QUERY__NODE__NODE_INSERT_STMT | fff040341e4a1456c3de7ef8 | INSERT INTO onek_with_null(unique1, unique2) VALUES (NULL, -1), (NULL, 2_147_483_647), (NULL, NULL), (100, NULL), (500, NULL) |
| PARTIAL | PG_QUERY__NODE__NODE_LOAD_STMT | df5ab9de4096a79d0a2bcbef | LOAD 'pg_overexplain' |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_ALTER_TABLE_STMT | 9561b52e5be5e680ed62a2fe | -- this should fail alter table renameColumn add column y int check (x > 0) not enforced enforced |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 02c1feda5a273db2fd42d0ec | CREATE OR REPLACE FUNCTION regexp_replace(string citext, pattern citext, replacement text, flags text) returns TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_replace( $1:... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 07e9dfbff7c03eafa8e4cba1 | CREATE OR REPLACE FUNCTION replace( citext, citext, citext ) RETURNS TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_replace( $1::text, pg_catalog.regexp_replace($2::text,... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 29ed872195838cbbfb853d18 | CREATE OR REPLACE FUNCTION regexp_match(string citext, pattern citext, flags text) RETURNS TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_match( $1::text, $2::text, CAS... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 34ddc60e42243b39b9a29ebc | CREATE OR REPLACE FUNCTION xpath_nodeset(text,text) RETURNS text LANGUAGE SQL STRICT IMMUTABLE PARALLEL SAFE RETURN xpath_nodeset($1, $2, ''::text, ''::text) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 582ac887e748820d06805fe7 | CREATE OR REPLACE FUNCTION split_part( citext, citext, int ) RETURNS TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN (pg_catalog.regexp_split_to_array( $1::text, pg_catalog.regexp_replace($... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 6678e49f5283fe3bd751581b | CREATE FUNCTION brintest_func() RETURNS int LANGUAGE sql IMMUTABLE RETURN 0 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 732be611398e0e89085b01ff | CREATE OR REPLACE FUNCTION regexp_matches(string citext, pattern citext, flags text) RETURNS SETOF TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE ROWS 10 RETURN pg_catalog.regexp_matches( $1::t... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 77a934280f167a9f11cf22b5 | CREATE OR REPLACE FUNCTION regexp_split_to_array(string citext, pattern citext, flags text) RETURNS TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_split_to_array( $1::t... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 7afeb53ae81d14fd56094215 | CREATE OR REPLACE FUNCTION regexp_split_to_table(string citext, pattern citext) RETURNS SETOF TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_split_to_table( $1::text, $2:... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8ac6f3a5ff7e33879b7793df | CREATE OR REPLACE FUNCTION translate( citext, citext, text ) RETURNS TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.translate( pg_catalog.translate( $1::text, pg_catalog.lower($... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 8f3b5a835ac43107c7431661 | CREATE OR REPLACE FUNCTION regexp_matches(string citext, pattern citext) RETURNS SETOF TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE ROWS 1 RETURN pg_catalog.regexp_matches( $1::text, $2::text... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | 9d71f32fc8d7f112ab85f8e2 | CREATE OR REPLACE FUNCTION regexp_replace(string citext, pattern citext, replacement text) returns TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_replace( $1::text, $2::t... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | baff09b99ecc67af8b8fed5a | CREATE OR REPLACE FUNCTION regexp_split_to_table(string citext, pattern citext, flags text) RETURNS SETOF TEXT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_split_to_table( $... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | ca2bb148f733f74a462fecef | CREATE FUNCTION btree_test_func() RETURNS int LANGUAGE sql IMMUTABLE RETURN 0 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | ce6259a312f5e882727e5989 | CREATE OR REPLACE FUNCTION regexp_split_to_array(string citext, pattern citext) RETURNS TEXT[] LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.regexp_split_to_array( $1::text, $2::tex... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | dfc4a6953697f459dd196a71 | CREATE OR REPLACE FUNCTION strpos( citext, citext ) RETURNS INT LANGUAGE SQL IMMUTABLE STRICT PARALLEL SAFE RETURN pg_catalog.strpos( pg_catalog.lower( $1::text ), pg_catalog.lower( $2::text ) ) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_CREATE_FUNCTION_STMT | f3d19683f78af2a29e954f3d | CREATE OR REPLACE FUNCTION xpath_nodeset(text,text,text) RETURNS text LANGUAGE SQL STRICT IMMUTABLE PARALLEL SAFE RETURN xpath_nodeset($1, $2, ''::text, $3) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | 44283f06afae43f5513c8c1e | -- -- Similar to the previous test case, but this time it's a backwards scan -- using a < RowCompare. Must use the <= strategy (and not the < strategy). -- explain (costs off) SELECT proname, proar... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_EXPLAIN_STMT | c79a810f9f1c2a65e80ebeae | EXPLAIN (COSTS OFF) (WITH a AS (SELECT 4) (SELECT 1, 2)) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_INSERT_STMT | 3e97fad4c86f8610ecd5ec00 | INSERT INTO zerocol SELECT RETURNING old.*, new.*, * |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_INSERT_STMT | b269e341f499d75cf1d8cf66 | INSERT INTO zerocol SELECT RETURNING old.tableoid::regclass, old.ctid, new.tableoid::regclass, new.ctid, ctid, * |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 2442b608284e5dff96ac99c7 | SELECT crypt('a very much longer text to encrypt. This one even stretches over more' 'than one line.', '$5$rounds=1400$anotherlongsaltstring') = '$5$rounds=1400$anotherlongsalts$Rx.j8H.h8HjEDGomFU8... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 4414b8358396adc3491bb8e9 | SELECT crypt('a very much longer text to encrypt. This one even stretches over more' 'than one line.', '$6$rounds=1400$anotherlongsaltstring') = '$6$rounds=1400$anotherlongsalts$POfYwTEok97VWcjxIiS... |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | 971f16c75af88b76ccb1715b | SELECT array_sort(ARRAY[[2,4],[2,1],[6,5]]) |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_SELECT_STMT | c1850a2d38c3fca98271de6a | SELECT proname, proargtypes, pronamespace FROM pg_proc WHERE (proname, pronamespace) < ('abs', 1_000_000) ORDER BY proname DESC, proargtypes DESC, pronamespace DESC LIMIT 1 |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 2883046f1e58bfa966e2f29d | SET SESSION CHARACTERISTICS AS TRANSACTION READ ONLY, READ ONLY |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | f8df4d44e2f17213c6326e62 | SET SESSION CHARACTERISTICS AS TRANSACTION READ ONLY, READ WRITE |
| TRAILING_INPUT | PG_QUERY__NODE__NODE_VARIABLE_SHOW_STMT | 6b6c8b3bbddfd97dd05a27b4 | SHOW isn.weak |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 096f4b0b73310691abeadfe7 | reset rls_test.blah |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 3747b884a086d1d9ec428b7d | RESET vacuum_truncate |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 4b8498aed90d75217b2f8c13 | RESET pgcrypto.builtin_crypto_enabled |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 5954f0934735e897c82231fe | RESET track_activities |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | 8ac05b0ba5c9ca0866a68709 | RESET compute_query_id |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | c79f307fdb85a0dcc9750476 | RESET client_encoding |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | ca170ff06bce041d2255d66a | reset join_collapse_limit |
| TYPE_MISMATCH | PG_QUERY__NODE__NODE_VARIABLE_SET_STMT | e336a80662312435443ceae9 | RESET ALL |

## Newly Supported Baseline Transitions

| Previous | Current | Oracle Node | ID | SQL |
| --- | --- | --- | --- | --- |
| ERROR | DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | 33873c0047519609077c6129 | ROLLBACK TO SAVEPOINT settings |
| ERROR | DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | a1c8abfcfd392c7ee858a9d6 | rollback to settings |
| ERROR | DEEP_SUPPORTED | PG_QUERY__NODE__NODE_TRANSACTION_STMT | cdb9707dbd061211f6b2e580 | savepoint settings |

## Regressed Baseline Transitions

| Previous | Current | Oracle Node | ID | SQL |
| --- | --- | --- | --- | --- |
| - | - | - | - | - |

## Structural Feature Witness Links

| Feature ID | Kind | Symbol | Witnesses | Target |
| --- | --- | --- | --- | --- |
| b466094b002b05c919a15d79 | grammar | ColConstraintElem:GENERATED generated_when AS '(' a_expr ')' opt_virtual_or_stored | pg18-generated-virtual-column | GENERATED generated_when AS '(' a_expr ')' opt_virtual_or_stored |
| 0712f1ff020d542c7a16c41e | grammar | ColConstraintElem:NOT NULL_P opt_no_inherit | pg18-not-null-no-inherit | NOT NULL_P opt_no_inherit |
| b499271507628d5fc9180006 | grammar | ConstraintAttr:ENFORCED | pg18-not-enforced-constraint | ENFORCED |
| 8f28ab5b7f253e5486eb6996 | grammar | ConstraintAttr:NOT ENFORCED | pg18-not-enforced-constraint | NOT ENFORCED |
| 0999b592516fab5490e07e8b | grammar | ConstraintAttributeElem:ENFORCED | pg18-not-enforced-constraint | ENFORCED |
| eb7d604137142f87b5eb592a | grammar | ConstraintAttributeElem:NOT ENFORCED | pg18-not-enforced-constraint | NOT ENFORCED |
| 6682e8cd239c980698e5ab9f | grammar | ConstraintElem:FOREIGN KEY '(' columnList optionalPeriodName ')' REFERENCES qualified_name opt_column_and_period_list key_match key_actions ConstraintAttributeSpec | pg18-temporal-period-foreign-key | FOREIGN KEY '(' columnList optionalPeriodName ')' REFERENCES qualified_name opt_column_and_period_list key_match key_actions ConstraintAttributeSpec |
| cff4eceea125b72afbf135dc | grammar | ConstraintElem:NOT NULL_P ColId ConstraintAttributeSpec | pg18-not-null-no-inherit | NOT NULL_P ColId ConstraintAttributeSpec |
| cc5655928112efa3ad1b3188 | grammar | ConstraintElem:PRIMARY KEY '(' columnList opt_without_overlaps ')' opt_c_include opt_definition OptConsTableSpace ConstraintAttributeSpec | pg18-temporal-primary-without-overlaps | PRIMARY KEY '(' columnList opt_without_overlaps ')' opt_c_include opt_definition OptConsTableSpace ConstraintAttributeSpec |
| f15017359b8bb14751bee3c6 | grammar | ConstraintElem:UNIQUE opt_unique_null_treatment '(' columnList opt_without_overlaps ')' opt_c_include opt_definition OptConsTableSpace ConstraintAttributeSpec | pg18-temporal-unique-without-overlaps | UNIQUE opt_unique_null_treatment '(' columnList opt_without_overlaps ')' opt_c_include opt_definition OptConsTableSpace ConstraintAttributeSpec |
| 3ec56fa8decf947ffff9ede5 | grammar | a_expr:a_expr IN_P '(' expr_list ')' | pg18-in-expression-list-location | a_expr IN_P '(' expr_list ')' |
| 2d29c7732f6beca9c6c6c5d5 | grammar | a_expr:a_expr IN_P select_with_parens | pg18-in-expression-list-location | a_expr IN_P select_with_parens |
| 64289baa78763e18bc529af0 | grammar | a_expr:a_expr NOT_LA IN_P '(' expr_list ')' | pg18-in-expression-list-location | a_expr NOT_LA IN_P '(' expr_list ')' |
| cc4203ef010ad54c0377ee00 | grammar | a_expr:a_expr NOT_LA IN_P select_with_parens %prec NOT_LA | pg18-in-expression-list-location | a_expr NOT_LA IN_P select_with_parens %prec NOT_LA |
| db0aec71e3007c85e06dd235 | grammar | alter_table_cmd:ALTER CONSTRAINT name INHERIT | pg18-alter-constraint-inherit | ALTER CONSTRAINT name INHERIT |
| 7f71b003d82e6afc30d4bc84 | grammar | bare_label_keyword:ENFORCED | pg18-not-enforced-constraint | ENFORCED |
| 5e4328cba03c27d09f1e22ef | grammar | bare_label_keyword:OBJECTS_P | pg18-default-privileges-large-objects | OBJECTS_P |
| d7e6796087489ab7badc6981 | grammar | bare_label_keyword:PERIOD | pg18-temporal-period-foreign-key | PERIOD |
| 55186d44ad6079d980e5bae7 | grammar | bare_label_keyword:VIRTUAL | pg18-generated-virtual-column | VIRTUAL |
| 3f91bb45e5a2e4ddaede7637 | grammar | defacl_privilege_target:LARGE_P OBJECTS_P | pg18-default-privileges-large-objects | LARGE_P OBJECTS_P |
| 8d4e03bc74c8f52a6be41a0e | grammar | opclass_item:OPERATOR Iconst any_operator opclass_purpose | pg18-opclass-purpose | OPERATOR Iconst any_operator opclass_purpose |
| a5c04aacedc53c836a221622 | grammar | opclass_item:OPERATOR Iconst operator_with_argtypes opclass_purpose | pg18-opclass-purpose | OPERATOR Iconst operator_with_argtypes opclass_purpose |
| 9c7843cafcc7f54bb94155fb | grammar | opt_column_and_period_list:'(' columnList optionalPeriodName ')' | pg18-temporal-period-foreign-key | '(' columnList optionalPeriodName ')' |
| b09308923b41199e3a197992 | grammar | opt_virtual_or_stored:STORED | pg18-generated-virtual-column | STORED |
| 0648d7d39a6fe4b392a7217f | grammar | opt_virtual_or_stored:VIRTUAL | pg18-generated-virtual-column | VIRTUAL |
| 4a4b0264e55ef3dd08ae1185 | grammar | opt_without_overlaps:WITHOUT OVERLAPS | pg18-temporal-primary-without-overlaps, pg18-temporal-unique-without-overlaps | WITHOUT OVERLAPS |
| 27543b82ca2de3b2708b3195 | grammar | optionalPeriodName:',' PERIOD columnElem | pg18-temporal-period-foreign-key | ',' PERIOD columnElem |
| 02b4ffdba64aae3d517a2261 | grammar | returning_clause:RETURNING returning_with_clause target_list | pg18-returning-with-old-new | RETURNING returning_with_clause target_list |
| 0a011280798d8db0c0aa4811 | grammar | returning_option:returning_option_kind AS ColId | pg18-returning-with-old-new | returning_option_kind AS ColId |
| d9da398439833074986db5f6 | grammar | returning_option_kind:NEW | pg18-returning-with-old-new | NEW |
| 82923f27c91d78b6fba786c1 | grammar | returning_option_kind:OLD | pg18-returning-with-old-new | OLD |
| f892419cc7d2aef5ee9d7185 | grammar | returning_options:returning_option | pg18-returning-with-old-new | returning_option |
| 33639818ce9f0d1b273f2930 | grammar | returning_options:returning_options ',' returning_option | pg18-returning-with-old-new | returning_options ',' returning_option |
| a9d3eedf2c9f68210872e534 | grammar | returning_with_clause:WITH '(' returning_options ')' | pg18-returning-with-old-new | WITH '(' returning_options ')' |
| 866bc626afa15d0f801f0e45 | grammar | unreserved_keyword:ENFORCED | pg18-not-enforced-constraint | ENFORCED |
| 7f6e0f0f0e6e545ed8ea04fa | grammar | unreserved_keyword:OBJECTS_P | pg18-default-privileges-large-objects | OBJECTS_P |
| 3a3f31a247ca4b3bd5dc0a3d | grammar | unreserved_keyword:PERIOD | pg18-temporal-period-foreign-key | PERIOD |
| 3698ad9c3fa74365b6a1cb62 | grammar | unreserved_keyword:VIRTUAL | pg18-generated-virtual-column | VIRTUAL |
| 3849310c06eae89b49acf7cf | grammar | vacuum_relation:relation_expr opt_name_list | pg18-vacuum-relation-columns | relation_expr opt_name_list |
| c32ffdf92b576f9a143f459d | keyword | enforced | pg18-not-enforced-constraint | enforced token=ENFORCED category=UNRESERVED_KEYWORD label=BARE_LABEL |
| e20313c1347cb56a8c0cfe67 | keyword | objects | pg18-default-privileges-large-objects | objects token=OBJECTS_P category=UNRESERVED_KEYWORD label=BARE_LABEL |
| 29fb0b93477794c486080982 | keyword | period | pg18-temporal-period-foreign-key | period token=PERIOD category=UNRESERVED_KEYWORD label=BARE_LABEL |
| dedf6c20b02f9ef477c748ba | keyword | virtual | pg18-generated-virtual-column | virtual token=VIRTUAL category=UNRESERVED_KEYWORD label=BARE_LABEL |

## Reviewed Structural Dispositions

| Feature ID | Kind | Symbol | Disposition | Reason |
| --- | --- | --- | --- | --- |
| b8cf00108e360388910554d3 | parse_node | ATAlterConstraint.__type__ | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| f12bf7a8e5958051c25824aa | parse_node | ATAlterConstraint.alterDeferrability | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| f3063a5bf5710a6e303f8039 | parse_node | ATAlterConstraint.alterEnforceability | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 12e1cf79921b354411b0fcf3 | parse_node | ATAlterConstraint.alterInheritability | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 0f78c8481b3db8ef190dc061 | parse_node | ATAlterConstraint.conname | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 4a2687c90202e3d4758130b0 | parse_node | ATAlterConstraint.deferrable | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 4357150bff32fcdbd9d08eff | parse_node | ATAlterConstraint.initdeferred | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 2c4349de9fb8b31f43f44c80 | parse_node | ATAlterConstraint.is_enforced | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| ab91be7189de96a8cd125098 | parse_node | ATAlterConstraint.noinherit | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 9cae5a398d3f7c68a908b803 | parse_node | ATAlterConstraint.type | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 16f2a4ad128ea0209c3f393c | parse_node | A_ArrayExpr.list_end | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 3799ce7e9b08f5d58e33fed7 | parse_node | A_ArrayExpr.list_start | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| ba0c280345b8f6cb34168f1a | parse_node | A_Expr.rexpr_list_end | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| c645c05807dd96159ae5cee2 | parse_node | A_Expr.rexpr_list_start | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 2abb35112b9a7d4bbbdec54e | parse_node | ColumnDef.inhcount | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| d074b81eea4a755f8e3d73d2 | parse_node | Constraint.fk_with_period | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 0eb0d7ff405744884de4cea3 | parse_node | Constraint.generated_kind | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 01976e1943fedd2961561f69 | parse_node | Constraint.is_enforced | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 0f785435b3bbea98104a1e75 | parse_node | Constraint.pk_with_period | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 3be4fa193d2a6b8528fcb323 | parse_node | Constraint.without_overlaps | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| f75b44c1adebadc71e50aafb | parse_node | CreateStmt.nnconstraints | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 1bd7dd38d994f6c3c7fed4b3 | parse_node | DeleteStmt.returningClause | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 44e64d5ccef498593c50fc2c | parse_node | FunctionParameter.location | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 8c7c02eccd864140a0a37cde | parse_node | IndexStmt.iswithoutoverlaps | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| ca807bac5752aeecff8171ac | parse_node | InsertStmt.returningClause | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| d21b4b82145b9a60be10f47c | parse_node | MergeStmt.returningClause | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 4c55e9478f166e2df1dde61e | parse_node | Query.read_as | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 7569680d32917c19566fb2e5 | parse_node | RangeTblEntry.custom_query_jumble | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 68453fcbe8a37aa78a95c884 | parse_node | RangeTblEntry.groupexprs | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 539e8338a643952d53beac3f | parse_node | ReturningClause.__type__ | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 769d0bae124fa1cb462253c5 | parse_node | ReturningClause.exprs | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 4fd29bb4408fe5772b182c6d | parse_node | ReturningClause.options | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 4a72487a3f4b4129e2f8da56 | parse_node | ReturningClause.type | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| da7a0952f103aed0abb8291c | parse_node | ReturningOption.__type__ | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 96f4ecf6bbb35451e61044ea | parse_node | ReturningOption.location | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| a053093d80b45caea57b0dde | parse_node | ReturningOption.option | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| ccf2cdb55d256c1c833a744c | parse_node | ReturningOption.type | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| e57735cd57e37af0b84d63c4 | parse_node | ReturningOption.value | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 6abf1b2bdb524ed8d3d2c37b | parse_node | SortGroupClause.reverse_sort | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| f8b4d677022c9900d1332c0f | parse_node | UpdateStmt.returningClause | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 84db6d550ad0e8e29d3b1e74 | parse_node | VariableSetStmt.jumble_args | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 9a3575645c97e3692d974a20 | parse_node | VariableSetStmt.query_jumble_location | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 04d1de3982fdc0855dc3776f | parse_node | VariableSetStmt.type | internal_non_syntax | PostgreSQL parse-node struct/schema delta; SQL exposure is reviewed through grammar, keyword, and committed baseline witnesses. |
| 99fafbbd49ee4198c62ad788 | protobuf | ATAlterConstraint.__type__ | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| d1eea67636746f8563176ec7 | protobuf | ATAlterConstraint.alter_deferrability | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| beace5ec1e8fac02edb73924 | protobuf | ATAlterConstraint.alter_enforceability | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 201f51d7273051109c091bb5 | protobuf | ATAlterConstraint.alter_inheritability | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| db1bf3020f3cb7492250cb4e | protobuf | ATAlterConstraint.conname | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| dba9bc7f4c9ea4312c8cb462 | protobuf | ATAlterConstraint.deferrable | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| aab4bfe418a2137c309f0b8d | protobuf | ATAlterConstraint.initdeferred | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 33f5eb283394abc669cbcedd | protobuf | ATAlterConstraint.is_enforced | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 47e94b4aa2d2f9eb7b04c2e9 | protobuf | ATAlterConstraint.noinherit | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 35266399d4823cd760e7aee0 | protobuf | A_ArrayExpr.list_end | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| afc2df1a96b58439fe5b5920 | protobuf | A_ArrayExpr.list_start | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| e3f6519af29dae239b46d6df | protobuf | A_Expr.rexpr_list_end | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 5d4588b1a89e7ddf8e7b99ab | protobuf | A_Expr.rexpr_list_start | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| a5bec5653ad19cbc8a90ce57 | protobuf | ArrayExpr.list_end | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 4f6d0f356933b6a96c8bc4ec | protobuf | ArrayExpr.list_start | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| f915fccb3cb3be5adda80ac9 | protobuf | CompareType.COMPARE_CONTAINED_BY | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 45557791257c4c8b929dec66 | protobuf | CompareType.COMPARE_EQ | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 97594b9e951c8e76928cf54f | protobuf | CompareType.COMPARE_GE | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 8abaa475fe87fdbb73932012 | protobuf | CompareType.COMPARE_GT | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 9767f4666ad071019961a93d | protobuf | CompareType.COMPARE_INVALID | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 9e07727a5c3a35c653a7ab87 | protobuf | CompareType.COMPARE_LE | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| ed545c53484ba531a63d45f2 | protobuf | CompareType.COMPARE_LT | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 781af6709bd4153b4e6387ec | protobuf | CompareType.COMPARE_NE | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| dc1ab2bc891b22239e6fc85b | protobuf | CompareType.COMPARE_OVERLAP | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| d7cb861570a366c9d411487c | protobuf | CompareType.COMPARE_TYPE_UNDEFINED | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| a8ee0625dc7466bc6004e701 | protobuf | CompareType.__type__ | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 638627d1c694cb8796f8bd1a | protobuf | ConstrType.CONSTR_ATTR_ENFORCED | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 5f9b4ce5db4751663f356cd6 | protobuf | ConstrType.CONSTR_ATTR_NOT_ENFORCED | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 4fd507c1a0dff8e041b0e2a1 | protobuf | Constraint.fk_with_period | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| e88142846cc95a51588370c1 | protobuf | Constraint.generated_kind | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 7beb803b2fefc7063d324f5f | protobuf | Constraint.is_enforced | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| d2e1dfc67d707ca65b833b3b | protobuf | Constraint.pk_with_period | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 1cbd3e15ac62a47ba86713f1 | protobuf | Constraint.without_overlaps | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 8d5907806b0ccf81fa526701 | protobuf | CreateStmt.nnconstraints | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| cfbc29cdc51d7887a5f1d84b | protobuf | DeleteStmt.returning_clause | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 3ff39f45866ed0b7403a5a72 | protobuf | FunctionParameter.location | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 51fb628f4bb8034936d00d3a | protobuf | IndexStmt.iswithoutoverlaps | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 9705869d97453e967d6aef1e | protobuf | InsertStmt.returning_clause | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| f886a04471fb46eda4e8fbdb | protobuf | IntoClause.view_query | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| d7f980f8a790da96ceaea62a | protobuf | JoinType.JOIN_RIGHT_SEMI | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 9bcdcb2ca182da9fd98575ba | protobuf | MergeStmt.returning_clause | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 212b9ef7ec6181dc3bbd9e89 | protobuf | Node.atalter_constraint | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 42229312a6a61a789567fd76 | protobuf | Node.returning_clause | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 1c72a3cacc39ffdb951f5d70 | protobuf | Node.returning_expr | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| a32578e9c470e0cfcc8548c0 | protobuf | Node.returning_option | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| f31ab347b72f6f707550f4c3 | protobuf | Query.has_group_rte | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 117e82bc27e5308f38a5b193 | protobuf | Query.returning_new_alias | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| fe504037084bd3a7b584a64f | protobuf | Query.returning_old_alias | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| ca4f4be2c7daf13be7a33cda | protobuf | RTEKind.RTE_GROUP | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 5a15411916da1998231886bd | protobuf | RangeTblEntry.groupexprs | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| ea01715e79000827ef3aa3e7 | protobuf | ReturningClause.__type__ | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| c64e9fc1a8e25ec2d9abf853 | protobuf | ReturningClause.exprs | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| fef5f7e37cb446dc16a9c4ba | protobuf | ReturningClause.options | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 7d5f4ac6a46062abe52579da | protobuf | ReturningExpr.__type__ | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| e424c5546de968de969d8a0f | protobuf | ReturningExpr.retexpr | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 84cbbc27c529b3b05ba5ed4a | protobuf | ReturningExpr.retlevelsup | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| db0d3e472e3557f34bacb580 | protobuf | ReturningExpr.retold | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 165aea6f0141d8431d431a05 | protobuf | ReturningExpr.xpr | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 83bf6cf93edeb312eb0752c9 | protobuf | ReturningOption.__type__ | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| ad9dc1787b0106bf00173876 | protobuf | ReturningOption.location | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| c4232757b29cdd6e2630212d | protobuf | ReturningOption.option | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| cccd6ebe3e27af07e62d0bf7 | protobuf | ReturningOption.value | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| ff6b9fb99b9d611aedd02d6f | protobuf | ReturningOptionKind.RETURNING_OPTION_KIND_UNDEFINED | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 6f52e61006d38988658e8355 | protobuf | ReturningOptionKind.RETURNING_OPTION_NEW | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| b122b6a9b199d047e198b461 | protobuf | ReturningOptionKind.RETURNING_OPTION_OLD | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| c27c81d9c0d3dab5e254eec3 | protobuf | ReturningOptionKind.__type__ | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 43aca411746996180906583e | protobuf | RowCompareExpr.cmptype | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| dba24aa509c124f3d732c665 | protobuf | SortGroupClause.reverse_sort | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| b559a98f80b5d53406f5e829 | protobuf | Token.ENFORCED | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 3e865ef7a90a9bd28ac0fbea | protobuf | Token.OBJECTS_P | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 34d058c87a842801dc4135b9 | protobuf | Token.PERIOD | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| b40d8c588ad2954771423f13 | protobuf | Token.VIRTUAL | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 1067158a0c520bb06f38706c | protobuf | UpdateStmt.returning_clause | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 34dc891f29b0c6c9476fe9d2 | protobuf | Var.varreturningtype | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 8ee8fe6105d4e6afd4b23d72 | protobuf | VarReturningType.VAR_RETURNING_DEFAULT | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| f4a0fd2262e5beaed7b58d9d | protobuf | VarReturningType.VAR_RETURNING_NEW | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 4ecf5220a62622c6ef5c1569 | protobuf | VarReturningType.VAR_RETURNING_OLD | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| b684e634177bb735efb97cd2 | protobuf | VarReturningType.VAR_RETURNING_TYPE_UNDEFINED | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 9e53147558d72000ffaada5a | protobuf | VarReturningType.__type__ | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| cf1ddeb0bea94a4287be6435 | protobuf | VariableSetStmt.jumble_args | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |
| 8716ce92ae147aad8607317f | protobuf | VariableSetStmt.location | internal_non_syntax | libpg_query protobuf/API schema delta; ParserSQL compatibility is evaluated through SQL acceptance and statement-type classification, not protobuf field parity. |

## Unwitnessed Structural Features

| Feature ID | Kind | Symbol | Witnesses | Target |
| --- | --- | --- | --- | --- |
| - | - | - | - | - |

## Unlinked Witnesses

| Witness ID |
| --- |
| pg-json-object-constructor |
| pg-merge-statement |

## Reproduction

- `make pg-compat-refresh PG_COMPAT_CACHE=/tmp/parsersql-pg-compat`
- `make pg-compat PG_COMPAT_CACHE=/tmp/parsersql-pg-compat`
- `python3 ./scripts/pg_compat/run_compat.py refresh --cache /tmp/parsersql-pg-compat`
