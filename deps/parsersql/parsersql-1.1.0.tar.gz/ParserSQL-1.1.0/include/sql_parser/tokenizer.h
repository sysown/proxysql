#ifndef SQL_PARSER_TOKENIZER_H
#define SQL_PARSER_TOKENIZER_H

#include "sql_parser/token.h"
#include "sql_parser/keywords_mysql.h"
#include "sql_parser/keywords_pgsql.h"

namespace sql_parser {

template <Dialect D>
class Tokenizer {
public:
    void reset(const char* input, size_t len) {
        start_ = input;
        cursor_ = input;
        end_ = input + len;
        has_peeked_ = false;
        has_error_ = false;
        has_fatal_error_ = false;
        has_user_variables_ = false;
        hint_allowed_ = false;
        after_dot_ = false;
        paren_depth_ = 0;
        first_open_paren_ = nullptr;
        error_source_ = {};
    }

    // True iff the tokenizer has emitted at least one TK_ERROR token since
    // the last reset(). Lets callers distinguish "couldn't build an AST"
    // from "the input was syntactically invalid" and surface the latter
    // as ParseResult::ERROR rather than PARTIAL.
    bool has_error() const { return has_error_; }
    bool has_fatal_error() const { return has_fatal_error_; }
    bool has_user_variables() const { return has_user_variables_; }
    StringRef error_source() const { return error_source_; }

    // Hook for parser-level (non-tokenizer) errors -- when the parser
    // detects clearly invalid input (e.g. `SET = X`, `SET x = ;`,
    // `SET x = ,foo`) it can flag the error so the eventual ParseResult
    // is ERROR rather than PARTIAL with a null AST.
    void flag_error() { has_error_ = true; }
    void flag_error_at(StringRef source) {
        has_error_ = true;
        if (error_source_.empty()) error_source_ = source;
    }
    void flag_fatal_error_at(StringRef source) {
        has_fatal_error_ = true;
        flag_error_at(source);
    }

    Token next_token() {
        if (has_peeked_) {
            has_peeked_ = false;
            return peeked_;
        }
        return scan_token();
    }

    Token peek() {
        if (!has_peeked_) {
            peeked_ = scan_token();
            has_peeked_ = true;
        }
        return peeked_;
    }

    void skip() {
        if (has_peeked_) {
            has_peeked_ = false;
        } else {
            scan_token();
        }
    }

    // Expose start/end of input for remaining-input calculation and for
    // safe lookback (e.g. detecting whether an identifier token was source-
    // delimited via a preceding backtick / double-quote byte).
    const char* input_begin() const { return start_; }
    const char* input_end() const { return end_; }

private:
    const char* start_ = nullptr;
    const char* cursor_ = nullptr;
    const char* end_ = nullptr;
    Token peeked_;
    bool has_peeked_ = false;
    bool hint_allowed_ = false;
    bool after_dot_ = false;
    bool has_error_ = false;
    bool has_fatal_error_ = false;
    bool has_user_variables_ = false;
    uint32_t paren_depth_ = 0;
    const char* first_open_paren_ = nullptr;
    StringRef error_source_;

    uint32_t offset() const {
        return static_cast<uint32_t>(cursor_ - start_);
    }

    char current() const { return (cursor_ < end_) ? *cursor_ : '\0'; }
    char advance() {
        char c = current();
        if (cursor_ < end_) ++cursor_;
        return c;
    }
    char peek_char(size_t ahead = 0) const {
        const char* p = cursor_ + ahead;
        return (p < end_) ? *p : '\0';
    }

    void skip_whitespace_and_comments() {
        while (cursor_ < end_) {
            char c = *cursor_;

            // Whitespace
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                ++cursor_;
                continue;
            }

            // PostgreSQL accepts any `--` line comment. MySQL requires the
            // second dash to be followed by whitespace or a control byte.
            const bool dash_comment = c == '-' && peek_char(1) == '-' &&
                (D == Dialect::PostgreSQL ||
                 (cursor_ + 2 < end_ &&
                  (static_cast<unsigned char>(peek_char(2)) <= 0x20 ||
                   static_cast<unsigned char>(peek_char(2)) == 0x7f)));
            if (dash_comment) {
                hint_allowed_ = false;
                cursor_ += 2;
                while (cursor_ < end_ && *cursor_ != '\n') ++cursor_;
                continue;
            }

            // # line comment (MySQL only)
            if constexpr (D == Dialect::MySQL) {
                if (c == '#') {
                    hint_allowed_ = false;
                    ++cursor_;
                    while (cursor_ < end_ && *cursor_ != '\n') ++cursor_;
                    continue;
                }
            }

            // /* block comment */
            if (c == '/' && peek_char(1) == '*') {
                if constexpr (D == Dialect::MySQL) {
                    if (hint_allowed_ && peek_char(2) == '+') return;
                }
                hint_allowed_ = false;
                const char* comment_start = cursor_;
                cursor_ += 2;
                if constexpr (D == Dialect::PostgreSQL) {
                    // PostgreSQL supports nested block comments
                    int depth = 1;
                    while (cursor_ < end_ && depth > 0) {
                        if (*cursor_ == '/' && peek_char(1) == '*') {
                            ++depth;
                            cursor_ += 2;
                        } else if (*cursor_ == '*' && peek_char(1) == '/') {
                            --depth;
                            cursor_ += 2;
                        } else {
                            ++cursor_;
                        }
                    }
                    if (depth != 0) {
                        flag_fatal_error_at(StringRef{comment_start,
                            static_cast<uint32_t>(end_ - comment_start)});
                    }
                } else {
                    // MySQL: no nesting
                    const bool executable = cursor_ < end_ &&
                        (*cursor_ == '!' ||
                         (cursor_ + 1 < end_ && cursor_[0] == 'M' && cursor_[1] == '!'));
                    bool has_user_variable_marker = false;
                    bool closed = false;
                    while (cursor_ < end_) {
                        if (*cursor_ == '*' && peek_char(1) == '/') {
                            cursor_ += 2;
                            closed = true;
                            break;
                        }
                        if (*cursor_ == '@') has_user_variable_marker = true;
                        ++cursor_;
                    }
                    if (!closed) {
                        flag_fatal_error_at(StringRef{comment_start,
                            static_cast<uint32_t>(end_ - comment_start)});
                    }
                    // MySQL and MariaDB executable comments run as SQL. Until
                    // their contents are parsed exactly, preserve any possible
                    // user variable use and force conservative classification.
                    if (executable && has_user_variable_marker) {
                        has_user_variables_ = true;
                        flag_fatal_error_at(StringRef{comment_start,
                            static_cast<uint32_t>(cursor_ - comment_start)});
                    }
                }
                continue;
            }

            break;  // not whitespace or comment
        }
    }

    Token make_token(TokenType type, const char* text_start, uint32_t text_len,
                     const char* source_start = nullptr, uint32_t source_len = 0) {
        if (!source_start) {
            source_start = text_start;
            source_len = text_len;
        }
        if (type == TokenType::TK_ERROR) {
            has_error_ = true;
            if (error_source_.empty()) error_source_ = StringRef{source_start, source_len};
        }
        if (type == TokenType::TK_LPAREN) {
            if (paren_depth_ == 0) first_open_paren_ = source_start;
            ++paren_depth_;
        } else if (type == TokenType::TK_RPAREN && paren_depth_ > 0) {
            if (--paren_depth_ == 0) first_open_paren_ = nullptr;
        } else if (type == TokenType::TK_EOF && paren_depth_ > 0) {
            flag_fatal_error_at(StringRef{first_open_paren_,
                static_cast<uint32_t>(end_ - first_open_paren_)});
        }
        if (type == TokenType::TK_USER_VARIABLE) has_user_variables_ = true;
        if constexpr (D == Dialect::MySQL) {
            // MySQL lexes qualified components as identifiers, even when
            // spelled SELECT/UPDATE/etc.; they do not introduce hints.
            hint_allowed_ = !after_dot_ && (type == TokenType::TK_SELECT || type == TokenType::TK_INSERT ||
                type == TokenType::TK_UPDATE || type == TokenType::TK_DELETE || type == TokenType::TK_REPLACE);
            after_dot_ = type == TokenType::TK_DOT;
        }
        return Token{type, StringRef{text_start, text_len},
                     StringRef{source_start, source_len},
                     static_cast<uint32_t>(source_start - start_)};
    }

    Token scan_identifier_or_keyword() {
        const char* start = cursor_;
        while (cursor_ < end_) {
            char c = *cursor_;
            bool is_cont = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                           (c >= '0' && c <= '9') || c == '_';
            // PostgreSQL allows `$` as an identifier continuation char (but
            // not as the first char, which is enforced because $ at start
            // is handled by the $$ / $N branches in next_token_impl()).
            // e.g. `SET search_path = schema$1` — `schema$1` is a single
            // identifier, not `schema` followed by the placeholder `$1`.
            if (!is_cont && D == Dialect::PostgreSQL && c == '$' && cursor_ > start) {
                is_cont = true;
            }
            if (is_cont) {
                ++cursor_;
            } else {
                break;
            }
        }
        uint32_t len = static_cast<uint32_t>(cursor_ - start);

        // Keyword lookup
        TokenType kw;
        if constexpr (D == Dialect::MySQL) {
            kw = mysql_keywords::lookup(start, len);
        } else {
            kw = pgsql_keywords::lookup(start, len);
        }
        return make_token(kw, start, len);
    }

    Token scan_number() {
        const char* start = cursor_;
        bool has_dot = false;
        while (cursor_ < end_ && *cursor_ >= '0' && *cursor_ <= '9') ++cursor_;
        if (cursor_ < end_ && *cursor_ == '.') {
            has_dot = true;
            ++cursor_;
            while (cursor_ < end_ && *cursor_ >= '0' && *cursor_ <= '9') ++cursor_;
        }
        bool has_exponent = false;
        if (cursor_ < end_ && (*cursor_ == 'e' || *cursor_ == 'E')) {
            has_exponent = true;
            ++cursor_;
            if (cursor_ < end_ && (*cursor_ == '+' || *cursor_ == '-')) ++cursor_;
            const char* exponent_digits = cursor_;
            while (cursor_ < end_ && *cursor_ >= '0' && *cursor_ <= '9') ++cursor_;
            if (cursor_ == exponent_digits) {
                return make_token(TokenType::TK_ERROR, start,
                    static_cast<uint32_t>(cursor_ - start));
            }
        }
        uint32_t len = static_cast<uint32_t>(cursor_ - start);
        return make_token(has_dot || has_exponent ? TokenType::TK_FLOAT : TokenType::TK_INTEGER,
                          start, len);
    }

    static bool is_hex_digit(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') ||
               (c >= 'A' && c <= 'F');
    }

    static bool is_token_word_char(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') ||
               (c >= 'A' && c <= 'Z') || c == '_' || c == '$';
    }

    Token scan_prefixed_base_literal(bool hex) {
        const char* start = cursor_;
        cursor_ += 2;
        const char* digits = cursor_;
        while (cursor_ < end_ && (hex ? is_hex_digit(*cursor_) : (*cursor_ == '0' || *cursor_ == '1'))) {
            ++cursor_;
        }
        bool invalid = cursor_ == digits;
        if (cursor_ < end_ && is_token_word_char(*cursor_)) {
            invalid = true;
            while (cursor_ < end_ && is_token_word_char(*cursor_)) ++cursor_;
        }
        uint32_t len = static_cast<uint32_t>(cursor_ - start);
        return make_token(invalid ? TokenType::TK_ERROR :
                          (hex ? TokenType::TK_HEX_LITERAL : TokenType::TK_BIT_LITERAL),
                          start, len);
    }

    Token scan_quoted_base_literal(bool hex) {
        const char* start = cursor_;
        cursor_ += 2; // prefix and opening quote
        bool invalid = false;
        while (cursor_ < end_ && *cursor_ != '\'') {
            if (hex ? !is_hex_digit(*cursor_) : (*cursor_ != '0' && *cursor_ != '1')) invalid = true;
            ++cursor_;
        }
        if (cursor_ >= end_) {
            return make_token(TokenType::TK_ERROR, start,
                              static_cast<uint32_t>(cursor_ - start));
        }
        ++cursor_;
        uint32_t len = static_cast<uint32_t>(cursor_ - start);
        if (hex && ((len - 3) & 1)) invalid = true; // quoted hex encodes whole bytes
        return make_token(invalid ? TokenType::TK_ERROR :
                          (hex ? TokenType::TK_HEX_LITERAL : TokenType::TK_BIT_LITERAL),
                          start, len);
    }

    Token scan_single_quoted_string(bool escape_prefix = false) {
        const char* source_start = cursor_;
        if (escape_prefix) ++cursor_;
        ++cursor_;  // skip opening quote
        const char* content_start = cursor_;
        while (cursor_ < end_) {
            if (*cursor_ == '\'') {
                // Check for doubled single-quote escape ('')
                if (cursor_ + 1 < end_ && *(cursor_ + 1) == '\'') {
                    cursor_ += 2;  // skip both quotes
                    continue;
                }
                break;  // end of string
            }
            if (*cursor_ == '\\' && (D == Dialect::MySQL || escape_prefix)) {
                ++cursor_;  // skip escaped char
                if (cursor_ < end_) ++cursor_;
            } else {
                ++cursor_;
            }
        }
        uint32_t len = static_cast<uint32_t>(cursor_ - content_start);
        if (cursor_ >= end_) {
            return make_token(TokenType::TK_ERROR, source_start,
                              static_cast<uint32_t>(cursor_ - source_start));
        }
        ++cursor_;  // skip closing quote
        return make_token(TokenType::TK_STRING, content_start, len, source_start,
                          static_cast<uint32_t>(cursor_ - source_start));
    }

    Token scan_double_quoted_string() {
        const char* source_start = cursor_;
        ++cursor_;
        const char* content_start = cursor_;
        while (cursor_ < end_) {
            if (*cursor_ == '"') {
                if (cursor_ + 1 < end_ && cursor_[1] == '"') {
                    cursor_ += 2;
                    continue;
                }
                break;
            }
            if (*cursor_ == '\\') {
                ++cursor_;
                if (cursor_ < end_) ++cursor_;
            } else {
                ++cursor_;
            }
        }
        uint32_t len = static_cast<uint32_t>(cursor_ - content_start);
        if (cursor_ >= end_) {
            return make_token(TokenType::TK_ERROR, source_start,
                              static_cast<uint32_t>(cursor_ - source_start));
        }
        ++cursor_;
        return make_token(TokenType::TK_STRING, content_start, len, source_start,
                          static_cast<uint32_t>(cursor_ - source_start));
    }

    Token scan_mysql_user_variable() {
        has_user_variables_ = true;
        const char* source_start = cursor_;
        ++cursor_; // @
        if (cursor_ >= end_) return make_token(TokenType::TK_AT, source_start, 1);

        char delimiter = *cursor_;
        if (delimiter == '\'' || delimiter == '"' || delimiter == '`') {
            ++cursor_;
            const char* content_start = cursor_;
            while (cursor_ < end_) {
                if (*cursor_ == delimiter) {
                    if (cursor_ + 1 < end_ && cursor_[1] == delimiter) {
                        cursor_ += 2;
                        continue;
                    }
                    uint32_t text_len = static_cast<uint32_t>(cursor_ - content_start);
                    ++cursor_;
                    return make_token(TokenType::TK_USER_VARIABLE, content_start, text_len,
                                      source_start,
                                      static_cast<uint32_t>(cursor_ - source_start));
                }
                if (*cursor_ == '\\') {
                    ++cursor_;
                    if (cursor_ < end_) ++cursor_;
                } else {
                    ++cursor_;
                }
            }
            return make_token(TokenType::TK_ERROR, source_start,
                              static_cast<uint32_t>(cursor_ - source_start));
        }

        const char* name_start = cursor_;
        while (cursor_ < end_) {
            char c = *cursor_;
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '$') {
                ++cursor_;
            } else {
                break;
            }
        }
        if (cursor_ == name_start) return make_token(TokenType::TK_AT, source_start, 1);
        return make_token(TokenType::TK_USER_VARIABLE, name_start,
                          static_cast<uint32_t>(cursor_ - name_start), source_start,
                          static_cast<uint32_t>(cursor_ - source_start));
    }

    // MySQL: backtick-quoted identifier
    // Unclosed backticks emit TK_ERROR so the parser can fail cleanly with
    // ParseResult::ERROR -- otherwise the tokenizer would silently swallow
    // the rest of the input as one giant identifier (e.g. `SET x = `foo`
    // would become identifier `foo` followed by an unclosed-backtick scan
    // that consumes everything to EOF as another identifier).
    Token scan_backtick_identifier() {
        const char* open_pos = cursor_;
        ++cursor_;  // skip opening backtick
        const char* content_start = cursor_;
        while (cursor_ < end_) {
            if (*cursor_ == '`') {
                if (cursor_ + 1 < end_ && cursor_[1] == '`') { cursor_ += 2; continue; }
                break;
            }
            ++cursor_;
        }
        if (cursor_ >= end_) {
            return make_token(TokenType::TK_ERROR, open_pos, 1);
        }
        uint32_t len = static_cast<uint32_t>(cursor_ - content_start);
        ++cursor_;  // skip closing backtick
        return make_token(TokenType::TK_IDENTIFIER, content_start, len, open_pos,
                          static_cast<uint32_t>(cursor_ - open_pos));
    }

    // PostgreSQL: double-quoted identifier
    // Unclosed `"` emits TK_ERROR -- same rationale as scan_backtick_identifier
    // above. `SET search_path = "unclosed_quote, public` would otherwise be
    // treated as identifier `unclosed_quote, public` (commas, spaces and all),
    // pass validation, and corrupt search_path with garbage.
    Token scan_double_quoted_identifier() {
        const char* open_pos = cursor_;
        ++cursor_;  // skip opening quote
        const char* content_start = cursor_;
        while (cursor_ < end_) {
            if (*cursor_ == '"') {
                if (cursor_ + 1 < end_ && cursor_[1] == '"') { cursor_ += 2; continue; }
                break;
            }
            ++cursor_;
        }
        if (cursor_ >= end_) {
            return make_token(TokenType::TK_ERROR, open_pos, 1);
        }
        uint32_t len = static_cast<uint32_t>(cursor_ - content_start);
        ++cursor_;  // skip closing quote
        return make_token(TokenType::TK_IDENTIFIER, content_start, len, open_pos,
                          static_cast<uint32_t>(cursor_ - open_pos));
    }

    // PostgreSQL dollar quotes preserve their complete delimiter for emission.
    Token scan_dollar_string(uint32_t delimiter_len = 2) {
        const char* source_start = cursor_;
        cursor_ += delimiter_len;
        const char* content_start = cursor_;
        while (cursor_ < end_) {
            if (*cursor_ == '$' && static_cast<size_t>(end_ - cursor_) >= delimiter_len &&
                std::memcmp(cursor_, source_start, delimiter_len) == 0) {
                uint32_t len = static_cast<uint32_t>(cursor_ - content_start);
                cursor_ += delimiter_len;
                return make_token(TokenType::TK_STRING, content_start, len, source_start,
                                  static_cast<uint32_t>(cursor_ - source_start));
            }
            ++cursor_;
        }
        return make_token(TokenType::TK_ERROR, source_start,
                          static_cast<uint32_t>(cursor_ - source_start));
    }

    static bool pg_operator_char(char c) {
        switch (c) {
            case '~': case '!': case '@': case '#': case '^': case '&': case '|':
            case '`': case '?': case '+': case '-': case '*': case '/': case '%':
            case '<': case '>': case '=': return true;
            default: return false;
        }
    }

    Token scan_pg_operator() {
        const char* start = cursor_;
        while (cursor_ < end_ && pg_operator_char(*cursor_)) {
            if ((*cursor_ == '/' && peek_char(1) == '*') ||
                (*cursor_ == '-' && peek_char(1) == '-')) break;
            ++cursor_;
        }
        // SQL operators followed by a sign form separate tokens, except when
        // a non-SQL operator character makes the whole name unambiguous.
        if (cursor_ - start > 1 && (cursor_[-1] == '+' || cursor_[-1] == '-')) {
            bool special = false;
            for (const char* p = start; p < cursor_ - 1; ++p)
                if (std::strchr("~!@#^&|`?%", *p)) { special = true; break; }
            if (!special)
                while (cursor_ - start > 1 && (cursor_[-1] == '+' || cursor_[-1] == '-')) --cursor_;
        }
        const uint32_t len = static_cast<uint32_t>(cursor_ - start);
        TokenType type = TokenType::TK_PG_OPERATOR;
        if (len >= 64) type = TokenType::TK_ERROR;
        else if (len == 1) {
            switch (*start) {
                case '+': type = TokenType::TK_PLUS; break;
                case '-': type = TokenType::TK_MINUS; break;
                case '*': type = TokenType::TK_ASTERISK; break;
                case '/': type = TokenType::TK_SLASH; break;
                case '%': type = TokenType::TK_PERCENT; break;
                case '^': type = TokenType::TK_CARET; break;
                case '=': type = TokenType::TK_EQUAL; break;
                case '<': type = TokenType::TK_LESS; break;
                case '>': type = TokenType::TK_GREATER; break;
                default: break;
            }
        } else if (len == 2) {
            if (start[0] == '<' && start[1] == '=') type = TokenType::TK_LESS_EQUAL;
            else if (start[0] == '>' && start[1] == '=') type = TokenType::TK_GREATER_EQUAL;
            else if ((start[0] == '<' && start[1] == '>') || (start[0] == '!' && start[1] == '='))
                type = TokenType::TK_NOT_EQUAL;
            else if (start[0] == '=' && start[1] == '>') type = TokenType::TK_NAMED_ARGUMENT;
        }
        return make_token(type, start, len);
    }

    Token scan_token() {
        skip_whitespace_and_comments();

        if (cursor_ >= end_) {
            return make_token(TokenType::TK_EOF, cursor_, 0);
        }

        char c = *cursor_;

        if constexpr (D == Dialect::MySQL) {
            if (hint_allowed_ && c == '/' && peek_char(1) == '*' && peek_char(2) == '+') {
                const char* begin = cursor_;
                cursor_ += 3;
                while (cursor_ < end_ && !(*cursor_ == '*' && peek_char(1) == '/')) ++cursor_;
                if (cursor_ == end_) {
                    flag_fatal_error_at({begin, static_cast<uint32_t>(cursor_ - begin)});
                    return make_token(TokenType::TK_ERROR, begin, static_cast<uint32_t>(cursor_ - begin));
                }
                cursor_ += 2;
                return make_token(TokenType::TK_MYSQL_OPTIMIZER_HINT, begin, static_cast<uint32_t>(cursor_ - begin));
            }
            if ((c == 'x' || c == 'X') && peek_char(1) == '\'') {
                return scan_quoted_base_literal(true);
            }
            if ((c == 'b' || c == 'B') && peek_char(1) == '\'') {
                return scan_quoted_base_literal(false);
            }
            if (c == '0' && (peek_char(1) == 'x' || peek_char(1) == 'X')) {
                return scan_prefixed_base_literal(true);
            }
            if (c == '0' && (peek_char(1) == 'b' || peek_char(1) == 'B')) {
                return scan_prefixed_base_literal(false);
            }
        }

        if constexpr (D == Dialect::PostgreSQL) {
            if ((c == 'E' || c == 'e') && peek_char(1) == '\'')
                return scan_single_quoted_string(true);
        }

        // Identifiers and keywords
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_') {
            return scan_identifier_or_keyword();
        }

        // Numbers
        if (c >= '0' && c <= '9') {
            return scan_number();
        }

        // Dot — could be start of .123 float or just dot
        if (c == '.' && cursor_ + 1 < end_ &&
            peek_char(1) >= '0' && peek_char(1) <= '9') {
            return scan_number();
        }

        // String literals
        if (c == '\'') return scan_single_quoted_string();

        // MySQL: double-quoted strings; PostgreSQL: double-quoted identifiers
        if (c == '"') {
            if constexpr (D == Dialect::MySQL) {
                return scan_double_quoted_string();
            } else {
                return scan_double_quoted_identifier();
            }
        }

        // Backtick identifier (MySQL only)
        if constexpr (D == Dialect::MySQL) {
            if (c == '`') return scan_backtick_identifier();
        }

        if constexpr (D == Dialect::PostgreSQL) {
            if (pg_operator_char(c)) return scan_pg_operator();
        }

        // @ and @@
        if (c == '@') {
            if (peek_char(1) == '@') {
                const char* s = cursor_;
                cursor_ += 2;
                return make_token(TokenType::TK_DOUBLE_AT, s, 2);
            }
            if constexpr (D == Dialect::MySQL) {
                return scan_mysql_user_variable();
            } else {
                const char* s = cursor_;
                ++cursor_;
                return make_token(TokenType::TK_AT, s, 1);
            }
        }

        // $ — PostgreSQL: $N placeholder or $$string$$
        if constexpr (D == Dialect::PostgreSQL) {
            if (c == '$') {
                if (peek_char(1) == '$') {
                    return scan_dollar_string();
                }
                if (peek_char(1) >= '0' && peek_char(1) <= '9') {
                    const char* start = cursor_;
                    ++cursor_;  // skip $
                    while (cursor_ < end_ && *cursor_ >= '0' && *cursor_ <= '9')
                        ++cursor_;
                    uint32_t len = static_cast<uint32_t>(cursor_ - start);
                    return make_token(TokenType::TK_DOLLAR_NUM, start, len);
                }
                const char* tag_end = cursor_ + 1;
                if (tag_end < end_ && ((*tag_end >= 'a' && *tag_end <= 'z') ||
                    (*tag_end >= 'A' && *tag_end <= 'Z') || *tag_end == '_' ||
                    static_cast<unsigned char>(*tag_end) >= 128)) {
                    ++tag_end;
                    while (tag_end < end_ && ((*tag_end >= 'a' && *tag_end <= 'z') ||
                        (*tag_end >= 'A' && *tag_end <= 'Z') ||
                        (*tag_end >= '0' && *tag_end <= '9') || *tag_end == '_' ||
                        static_cast<unsigned char>(*tag_end) >= 128)) ++tag_end;
                    if (tag_end < end_ && *tag_end == '$')
                        return scan_dollar_string(static_cast<uint32_t>(tag_end + 1 - cursor_));
                }
                // A dollar sign outside a quoted delimiter or parameter is invalid.
                {
                    const char* start = cursor_;
                    ++cursor_;  // consume $ so error offset is precise
                    return make_token(TokenType::TK_ERROR, start, 1);
                }
            }
        }

        // Two-character operators
        if (cursor_ + 1 < end_) {
            char c2 = peek_char(1);

            if constexpr (D == Dialect::MySQL) {
                if (c == '-' && c2 == '>') {
                    const char* start = cursor_;
                    cursor_ += 2;
                    if (cursor_ < end_ && *cursor_ == '>') ++cursor_;
                    return make_token(TokenType::TK_MYSQL_JSON_ARROW, start,
                        static_cast<uint32_t>(cursor_ - start));
                }
            }

            if (c == '<' && c2 == '<') { auto s = cursor_; cursor_ += 2; return make_token(TokenType::TK_SHIFT_LEFT, s, 2); }
            if (c == '>' && c2 == '>') { auto s = cursor_; cursor_ += 2; return make_token(TokenType::TK_SHIFT_RIGHT, s, 2); }
            if (c == '<' && c2 == '=') { auto s = cursor_; cursor_ += 2; return make_token(TokenType::TK_LESS_EQUAL, s, 2); }
            if (c == '>' && c2 == '=') { auto s = cursor_; cursor_ += 2; return make_token(TokenType::TK_GREATER_EQUAL, s, 2); }
            if (c == '!' && c2 == '=') { auto s = cursor_; cursor_ += 2; return make_token(TokenType::TK_NOT_EQUAL, s, 2); }
            if (c == '<' && c2 == '>') { auto s = cursor_; cursor_ += 2; return make_token(TokenType::TK_NOT_EQUAL, s, 2); }
            if (c == '|' && c2 == '|') { auto s = cursor_; cursor_ += 2; return make_token(TokenType::TK_DOUBLE_PIPE, s, 2); }

            if (c == ':' && c2 == '=') { auto s = cursor_; cursor_ += 2; return make_token(TokenType::TK_COLON_EQUAL, s, 2); }

            if constexpr (D == Dialect::PostgreSQL) {
                if (c == ':' && c2 == ':') { auto s = cursor_; cursor_ += 2; return make_token(TokenType::TK_DOUBLE_COLON, s, 2); }
            }
        }

        // Single-character operators/punctuation
        const char* s = cursor_;
        ++cursor_;
        switch (c) {
            case '(': return make_token(TokenType::TK_LPAREN, s, 1);
            case ')': return make_token(TokenType::TK_RPAREN, s, 1);
            case '[': return make_token(TokenType::TK_LBRACKET, s, 1);
            case ']': return make_token(TokenType::TK_RBRACKET, s, 1);
            case ',': return make_token(TokenType::TK_COMMA, s, 1);
            case ';': return make_token(TokenType::TK_SEMICOLON, s, 1);
            case '.': return make_token(TokenType::TK_DOT, s, 1);
            case '*': return make_token(TokenType::TK_ASTERISK, s, 1);
            case '+': return make_token(TokenType::TK_PLUS, s, 1);
            case '-': return make_token(TokenType::TK_MINUS, s, 1);
            case '/': return make_token(TokenType::TK_SLASH, s, 1);
            case '%': return make_token(TokenType::TK_PERCENT, s, 1);
            case '=': return make_token(TokenType::TK_EQUAL, s, 1);
            case '<': return make_token(TokenType::TK_LESS, s, 1);
            case '>': return make_token(TokenType::TK_GREATER, s, 1);
            case '&': return make_token(TokenType::TK_AMPERSAND, s, 1);
            case '|': return make_token(TokenType::TK_PIPE, s, 1);
            case '^': return make_token(TokenType::TK_CARET, s, 1);
            case '~': return make_token(TokenType::TK_TILDE, s, 1);
            case '!': return make_token(TokenType::TK_EXCLAIM, s, 1);
            case ':': return make_token(TokenType::TK_COLON, s, 1);
            case '?': return make_token(TokenType::TK_QUESTION, s, 1);
            case '#': return make_token(TokenType::TK_HASH, s, 1);
            default:  return make_token(TokenType::TK_ERROR, s, 1);
        }
    }
};

} // namespace sql_parser

#endif // SQL_PARSER_TOKENIZER_H
