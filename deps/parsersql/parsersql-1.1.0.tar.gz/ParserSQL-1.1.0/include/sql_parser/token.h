#ifndef SQL_PARSER_TOKEN_H
#define SQL_PARSER_TOKEN_H

#include "sql_parser/common.h"
#include <cstdint>

namespace sql_parser {

enum class TokenType : uint16_t {
    TK_EOF = 0,
    TK_ERROR,
    TK_IDENTIFIER,
    TK_INTEGER,
    TK_FLOAT,
    TK_STRING,
    TK_LPAREN,
    TK_RPAREN,
    TK_LBRACKET,      // [
    TK_RBRACKET,      // ]
    TK_COMMA,
    TK_SEMICOLON,
    TK_DOT,
    TK_ASTERISK,
    TK_PLUS,
    TK_MINUS,
    TK_SLASH,
    TK_PERCENT,
    TK_EQUAL,
    TK_NOT_EQUAL,
    TK_LESS,
    TK_GREATER,
    TK_LESS_EQUAL,
    TK_GREATER_EQUAL,
    TK_AMPERSAND,
    TK_PIPE,
    TK_CARET,
    TK_SHIFT_LEFT,
    TK_SHIFT_RIGHT,
    TK_TILDE,
    TK_EXCLAIM,
    TK_COLON,
    TK_QUESTION,
    TK_AT,
    TK_DOUBLE_AT,
    TK_HASH,
    TK_COLON_EQUAL,
    TK_DOUBLE_PIPE,
    TK_DOUBLE_COLON,
    TK_DOLLAR_NUM,
    TK_SELECT, TK_INSERT, TK_UPDATE, TK_DELETE, TK_REPLACE,
    TK_FROM, TK_WHERE, TK_SET, TK_INTO, TK_VALUES, TK_AS, TK_ON, TK_USING,
    TK_JOIN, TK_INNER, TK_LEFT, TK_RIGHT, TK_FULL, TK_OUTER, TK_CROSS, TK_NATURAL,
    TK_ORDER, TK_BY, TK_GROUP, TK_HAVING, TK_LIMIT, TK_OFFSET, TK_FETCH,
    TK_ASC, TK_DESC, TK_DISTINCT, TK_ALL,
    TK_AND, TK_OR, TK_XOR, TK_NOT, TK_IS, TK_NULL, TK_IN, TK_BETWEEN, TK_LIKE, TK_EXISTS,
    TK_DIV, TK_MOD, TK_REGEXP, TK_SOUNDS, TK_MEMBER, TK_INTERVAL,
    TK_CASE, TK_WHEN, TK_THEN, TK_ELSE, TK_END, TK_TRUE, TK_FALSE,
    TK_NAMES, TK_CHARACTER, TK_CHARSET, TK_COLLATE, TK_GLOBAL, TK_SESSION, TK_LOCAL,
    TK_PERSIST, TK_DEFAULT, TK_TRANSACTION, TK_ISOLATION, TK_LEVEL,
    TK_READ, TK_WRITE, TK_ONLY, TK_COMMITTED, TK_UNCOMMITTED, TK_REPEATABLE,
    TK_SERIALIZABLE, TK_TO,
    TK_CREATE, TK_ALTER, TK_DROP, TK_TRUNCATE, TK_TABLE, TK_INDEX, TK_VIEW,
    TK_DATABASE, TK_SCHEMA, TK_IF,
    TK_BEGIN, TK_START, TK_COMMIT, TK_ROLLBACK, TK_SAVEPOINT,
    TK_USE, TK_SHOW, TK_PREPARE, TK_EXECUTE, TK_DEALLOCATE,
    TK_GRANT, TK_REVOKE, TK_LOCK, TK_UNLOCK, TK_LOAD, TK_DATA,
    TK_FOR, TK_SHARE, TK_NOWAIT, TK_SKIP, TK_LOCKED,
    TK_OUTFILE, TK_DUMPFILE, TK_IGNORE, TK_LOW_PRIORITY, TK_QUICK, TK_RESET,
    TK_UNION, TK_OF,
    TK_SQL_CALC_FOUND_ROWS,
    TK_COUNT, TK_SUM, TK_AVG, TK_MIN, TK_MAX,

    // INSERT/REPLACE related tokens
    TK_DELAYED,
    TK_HIGH_PRIORITY,
    TK_DUPLICATE,
    TK_KEY,
    TK_CONFLICT,
    TK_DO,
    TK_NOTHING,
    TK_RETURNING,
    TK_CONSTRAINT,

    // Compound query operators
    TK_INTERSECT,
    TK_EXCEPT,

    // EXPLAIN/DESCRIBE/CALL/LOAD DATA related tokens
    TK_EXPLAIN,
    TK_DESCRIBE,
    TK_CALL,
    TK_PROCEDURE,
    TK_FORMAT,
    TK_ANALYZE,
    TK_VERBOSE,
    TK_COSTS,
    TK_SETTINGS,
    TK_BUFFERS,
    TK_WAL,
    TK_TIMING,
    TK_SUMMARY,
    TK_INFILE,
    TK_LINES,
    TK_TERMINATED,
    TK_ENCLOSED,
    TK_ESCAPED,
    TK_OPTIONALLY,
    TK_CONCURRENT,
    TK_STARTING,
    TK_COLUMNS,
    TK_FIELDS,
    TK_ROWS,
    TK_ARRAY,
    TK_ROW,

    // Window function tokens
    TK_OVER,
    TK_PARTITION,
    TK_ROW_NUMBER,
    TK_RANK,
    TK_DENSE_RANK,
    TK_LAG,
    TK_LEAD,
    TK_FIRST_VALUE,
    TK_LAST_VALUE,

    // CTE tokens
    TK_WITH,
    TK_RECURSIVE,

    // MySQL lossless user-variable/literal tokens. Keep appended so existing
    // enum values remain stable for consumers that index by TokenType.
    TK_USER_VARIABLE,
    TK_HEX_LITERAL,
    TK_BIT_LITERAL,
    TK_PG_OPERATOR,  // PostgreSQL symbolic operator name
    TK_NAMED_ARGUMENT, // =>, reserved for PostgreSQL named function arguments
    TK_MYSQL_JSON_ARROW, // -> and ->>; spelling distinguishes unquoting
    TK_MYSQL_OPTIMIZER_HINT, // complete comment in a native hint position
};

struct Token {
    TokenType type = TokenType::TK_EOF;
    StringRef text;
    StringRef source;
    uint32_t offset = 0;
};

} // namespace sql_parser

#endif // SQL_PARSER_TOKEN_H
