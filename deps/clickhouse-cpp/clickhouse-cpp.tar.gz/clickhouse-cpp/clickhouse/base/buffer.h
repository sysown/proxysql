#pragma once

#include <cstdint>
#include <vector>

namespace clickhouse {

using Buffer = std::vector<uint8_t>;

}
