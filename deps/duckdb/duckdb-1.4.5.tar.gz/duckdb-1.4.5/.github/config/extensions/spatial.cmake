if (${BUILD_COMPLETE_EXTENSION_SET})
################# SPATIAL
duckdb_extension_load(spatial
    DONT_LINK LOAD_TESTS
    GIT_URL https://github.com/duckdb/duckdb-spatial
    GIT_TAG 14cc57b574a969956d9ac713d5fe23e2f4143c09
    INCLUDE_DIR src/spatial
    TEST_DIR test/sql
    )
endif()
