#! /bin/sh

./mk/std-autogen.sh .
